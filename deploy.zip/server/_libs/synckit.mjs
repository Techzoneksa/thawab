import { i as cjsRequire, n as isPkgAvailable, r as tryExtensions, t as findUp } from "./pkgr__core.mjs";
import { createHash } from "node:crypto";
import fs from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";
import path from "node:path";
import { MessageChannel, Worker, receiveMessageOnPort } from "node:worker_threads";
//#region node_modules/synckit/lib/common.js
var NODE_OPTIONS$1 = process.env.NODE_OPTIONS?.split(/\s+/);
var hasFlag = (flag) => NODE_OPTIONS$1?.includes(flag) || process.argv.includes(flag);
var parseVersion = (version) => version.split(".").map(Number.parseFloat);
var compareVersion = (version1, version2) => {
	const versions1 = parseVersion(version1);
	const versions2 = parseVersion(version2);
	const length = Math.max(versions1.length, versions2.length);
	for (let i = 0; i < length; i++) {
		const v1 = versions1[i] || 0;
		const v2 = versions2[i] || 0;
		if (v1 > v2) return 1;
		if (v1 < v2) return -1;
	}
	return 0;
};
var NODE_VERSION = process.versions.node;
var compareNodeVersion = (version) => compareVersion(NODE_VERSION, version);
//#endregion
//#region node_modules/synckit/lib/constants.js
var TsRunner = {
	Node: "node",
	Bun: "bun",
	TsNode: "ts-node",
	EsbuildRegister: "esbuild-register",
	EsbuildRunner: "esbuild-runner",
	OXC: "oxc",
	SWC: "swc",
	TSX: "tsx"
};
var { NODE_OPTIONS: NODE_OPTIONS_ = "", SYNCKIT_EXEC_ARGV = "", SYNCKIT_GLOBAL_SHIMS, SYNCKIT_TIMEOUT, SYNCKIT_TS_RUNNER } = process.env;
var TS_ESM_PARTIAL_SUPPORTED = compareNodeVersion("16") >= 0 && compareNodeVersion("18.19") < 0;
var MTS_SUPPORTED = compareNodeVersion("20.8") >= 0;
MTS_SUPPORTED || compareNodeVersion("18.19");
var STRIP_TYPES_FLAG = "--experimental-strip-types";
var TRANSFORM_TYPES_FLAG = "--experimental-transform-types";
var NO_STRIP_TYPES_FLAG = "--no-experimental-strip-types";
var NODE_OPTIONS = NODE_OPTIONS_.split(/\s+/);
var NO_STRIP_TYPES = hasFlag("--no-experimental-strip-types") && (compareNodeVersion("22.10") >= 0 ? process.features.typescript === false : !hasFlag("--experimental-strip-types") && !hasFlag("--experimental-transform-types"));
var DEFAULT_TIMEOUT = SYNCKIT_TIMEOUT ? +SYNCKIT_TIMEOUT : void 0;
var DEFAULT_EXEC_ARGV = SYNCKIT_EXEC_ARGV.split(",");
var DEFAULT_TS_RUNNER = SYNCKIT_TS_RUNNER;
var DEFAULT_GLOBAL_SHIMS = ["1", "true"].includes(SYNCKIT_GLOBAL_SHIMS);
var DEFAULT_GLOBAL_SHIMS_PRESET = [{
	moduleName: "node-fetch",
	globalName: "fetch"
}, {
	moduleName: "node:perf_hooks",
	globalName: "performance",
	named: "performance"
}];
var IMPORT_FLAG = "--import";
var REQUIRE_FLAGS = /* @__PURE__ */ new Set(["--require", "-r"]);
var LOADER_FLAG = "--loader";
var LOADER_FLAGS = /* @__PURE__ */ new Set([LOADER_FLAG, "--experimental-loader"]);
var IMPORT_FLAG_SUPPORTED = compareNodeVersion("20.6") >= 0;
//#endregion
//#region node_modules/synckit/lib/helpers.js
var isFile = (path) => {
	try {
		return !!fs.statSync(path, { throwIfNoEntry: false })?.isFile();
	} catch {
		return false;
	}
};
var dataUrl = (code) => new URL(`data:text/javascript,${encodeURIComponent(code)}`);
var hasRequireFlag = (execArgv) => execArgv.some((execArg) => REQUIRE_FLAGS.has(execArg));
var hasImportFlag = (execArgv) => execArgv.includes(IMPORT_FLAG);
var hasLoaderFlag = (execArgv) => execArgv.some((execArg) => LOADER_FLAGS.has(execArg));
var setupTsRunner = (workerPath, { execArgv = DEFAULT_EXEC_ARGV, tsRunner } = {}) => {
	let ext = path.extname(workerPath);
	if (!/([/\\])node_modules\1/.test(workerPath) && (!ext || /^\.[cm]?js$/.test(ext))) {
		const workPathWithoutExt = ext ? workerPath.slice(0, -ext.length) : workerPath;
		let extensions;
		switch (ext) {
			case ".cjs":
				extensions = [".cts", ".cjs"];
				break;
			case ".mjs":
				extensions = [".mts", ".mjs"];
				break;
			default:
				extensions = [".ts", ".js"];
				break;
		}
		const found = tryExtensions(workPathWithoutExt, extensions);
		let differentExt;
		if (found && (!ext || (differentExt = found !== workPathWithoutExt))) {
			workerPath = found;
			if (differentExt) ext = path.extname(workerPath);
		}
	}
	const isTs = /\.[cm]?ts$/.test(workerPath);
	let jsUseEsm = ext === ".mjs";
	let tsUseEsm = ext === ".mts";
	if (isTs) {
		if (!tsUseEsm && ext !== ".cts") {
			const pkg = findUp(workerPath);
			if (pkg) tsUseEsm = cjsRequire(pkg).type === "module";
		}
		const stripTypesIndex = execArgv.indexOf(STRIP_TYPES_FLAG);
		const transformTypesIndex = execArgv.indexOf(TRANSFORM_TYPES_FLAG);
		const noStripTypesIndex = execArgv.indexOf(NO_STRIP_TYPES_FLAG);
		const noStripTypes = noStripTypesIndex > stripTypesIndex || noStripTypesIndex > transformTypesIndex || stripTypesIndex === -1 && transformTypesIndex === -1 && NO_STRIP_TYPES;
		if (tsRunner == null) {
			if (process.versions.bun) tsRunner = TsRunner.Bun;
			else if (!noStripTypes && compareNodeVersion("22.6") >= 0) tsRunner = TsRunner.Node;
			else if (isPkgAvailable(TsRunner.TsNode)) tsRunner = TsRunner.TsNode;
		}
		switch (tsRunner) {
			case TsRunner.Bun: break;
			case TsRunner.Node:
				if (compareNodeVersion("22.6") < 0) throw new Error("type stripping is not supported in this node version");
				if (noStripTypes) throw new Error("type stripping is disabled explicitly");
				if (compareNodeVersion("23.6") >= 0) break;
				if (compareNodeVersion("22.7") >= 0 && !execArgv.includes("--experimental-transform-types")) execArgv = [TRANSFORM_TYPES_FLAG, ...execArgv];
				else if (compareNodeVersion("22.6") >= 0 && !execArgv.includes("--experimental-strip-types")) execArgv = [STRIP_TYPES_FLAG, ...execArgv];
				break;
			case TsRunner.TsNode:
				if (tsUseEsm) {
					if (!execArgv.includes("--loader")) execArgv = [
						LOADER_FLAG,
						`${TsRunner.TsNode}/esm`,
						...execArgv
					];
				} else if (!hasRequireFlag(execArgv)) execArgv = [
					"-r",
					`${TsRunner.TsNode}/register`,
					...execArgv
				];
				break;
			case TsRunner.EsbuildRegister:
				if (tsUseEsm) {
					if (!hasLoaderFlag(execArgv)) execArgv = [
						LOADER_FLAG,
						`${TsRunner.EsbuildRegister}/loader`,
						...execArgv
					];
				} else if (!hasRequireFlag(execArgv)) execArgv = [
					"-r",
					TsRunner.EsbuildRegister,
					...execArgv
				];
				break;
			case TsRunner.EsbuildRunner:
				if (!hasRequireFlag(execArgv)) execArgv = [
					"-r",
					`${TsRunner.EsbuildRunner}/register`,
					...execArgv
				];
				break;
			case TsRunner.OXC:
				if (!execArgv.includes("--import")) execArgv = [
					IMPORT_FLAG,
					`@${TsRunner.OXC}-node/core/register`,
					...execArgv
				];
				break;
			case TsRunner.SWC:
				if (tsUseEsm) {
					if (IMPORT_FLAG_SUPPORTED) {
						if (!hasImportFlag(execArgv)) execArgv = [
							IMPORT_FLAG,
							`@${TsRunner.SWC}-node/register/esm-register`,
							...execArgv
						];
					} else if (!hasLoaderFlag(execArgv)) execArgv = [
						LOADER_FLAG,
						`@${TsRunner.SWC}-node/register/esm`,
						...execArgv
					];
				} else if (!hasRequireFlag(execArgv)) execArgv = [
					"-r",
					`@${TsRunner.SWC}-node/register`,
					...execArgv
				];
				break;
			case TsRunner.TSX:
				if (IMPORT_FLAG_SUPPORTED) {
					if (!execArgv.includes("--import")) execArgv = [
						IMPORT_FLAG,
						TsRunner.TSX,
						...execArgv
					];
				} else if (!execArgv.includes("--loader")) execArgv = [
					LOADER_FLAG,
					TsRunner.TSX,
					...execArgv
				];
				break;
			default: throw new Error(`Unknown ts runner: ${String(tsRunner)}`);
		}
	} else if (!jsUseEsm && ext !== ".cjs") {
		const pkg = findUp(workerPath);
		if (pkg) jsUseEsm = cjsRequire(pkg).type === "module";
	}
	let resolvedPnpLoaderPath;
	if (process.versions.pnp) {
		let pnpApiPath;
		try {
			pnpApiPath = cjsRequire.resolve("pnpapi");
		} catch {}
		if (pnpApiPath && !NODE_OPTIONS.some((option, index) => REQUIRE_FLAGS.has(option) && pnpApiPath === cjsRequire.resolve(NODE_OPTIONS[index + 1])) && !execArgv.includes(pnpApiPath)) {
			execArgv = [
				"-r",
				pnpApiPath,
				...execArgv
			];
			const pnpLoaderPath = path.resolve(pnpApiPath, "../.pnp.loader.mjs");
			if (isFile(pnpLoaderPath)) {
				resolvedPnpLoaderPath = pathToFileURL(pnpLoaderPath).href;
				execArgv = [
					LOADER_FLAG,
					resolvedPnpLoaderPath,
					...execArgv
				];
			}
		}
	}
	return {
		ext,
		isTs,
		jsUseEsm,
		tsRunner,
		tsUseEsm,
		workerPath,
		pnpLoaderPath: resolvedPnpLoaderPath,
		execArgv
	};
};
var md5Hash = (text) => createHash("md5").update(text).digest("hex");
var encodeImportModule = (moduleNameOrGlobalShim, type = "import") => {
	const { moduleName, globalName, named, conditional } = typeof moduleNameOrGlobalShim === "string" ? { moduleName: moduleNameOrGlobalShim } : moduleNameOrGlobalShim;
	const importStatement = type === "import" ? `import${globalName ? " " + (named === null ? "* as " + globalName : named?.trim() ? `{${named}}` : globalName) + " from" : ""} '${path.isAbsolute(moduleName) ? String(pathToFileURL(moduleName)) : moduleName}'` : `${globalName ? "const " + (named?.trim() ? `{${named}}` : globalName) + "=" : ""}require('${moduleName.replace(/\\/g, "\\\\")}')`;
	if (!globalName) return importStatement;
	const overrideStatement = `globalThis.${globalName}=${named?.trim() ? named : globalName}`;
	return importStatement + (conditional === false ? `;${overrideStatement}` : `;if(!globalThis.${globalName})${overrideStatement}`);
};
var _generateGlobals = (globalShims, type) => globalShims.reduce((acc, shim) => `${acc}${acc ? ";" : ""}${encodeImportModule(shim, type)}`, "");
var globalsCache;
var tmpdir;
var _dirname = typeof __dirname === "undefined" ? path.dirname(fileURLToPath(import.meta.url)) : __dirname;
var generateGlobals = (workerPath, globalShims, type = "import") => {
	if (globalShims.length === 0) return "";
	globalsCache ?? (globalsCache = /* @__PURE__ */ new Map());
	const cached = globalsCache.get(workerPath);
	if (cached) {
		const [content, filepath] = cached;
		if (type === "require" && !filepath || type === "import" && filepath && isFile(filepath)) return content;
	}
	const globals = _generateGlobals(globalShims, type);
	let content = globals;
	let filepath;
	if (type === "import") {
		if (!tmpdir) tmpdir = path.resolve(findUp(_dirname), "../node_modules/.synckit");
		fs.mkdirSync(tmpdir, { recursive: true });
		filepath = path.resolve(tmpdir, md5Hash(workerPath) + ".mjs");
		content = encodeImportModule(filepath);
		fs.writeFileSync(filepath, globals);
	}
	globalsCache.set(workerPath, [content, filepath]);
	return content;
};
var sharedBuffer;
var sharedBufferView;
function startWorkerThread(workerPath, { timeout = DEFAULT_TIMEOUT, execArgv = DEFAULT_EXEC_ARGV, tsRunner = DEFAULT_TS_RUNNER, transferList = [], globalShims = DEFAULT_GLOBAL_SHIMS } = {}) {
	const { port1: mainPort, port2: workerPort } = new MessageChannel();
	const { isTs, ext, jsUseEsm, tsUseEsm, tsRunner: finalTsRunner, workerPath: finalWorkerPath, pnpLoaderPath, execArgv: finalExecArgv } = setupTsRunner(workerPath, {
		execArgv,
		tsRunner
	});
	const workerPathUrl = pathToFileURL(finalWorkerPath);
	if (/\.[cm]ts$/.test(finalWorkerPath)) {
		const isTsxSupported = !tsUseEsm || TS_ESM_PARTIAL_SUPPORTED;
		if (!finalTsRunner) throw new Error("No ts runner specified, ts worker path is not supported");
		else if ([
			TsRunner.EsbuildRegister,
			TsRunner.EsbuildRunner,
			...TS_ESM_PARTIAL_SUPPORTED ? [TsRunner.OXC, TsRunner.SWC] : [],
			...isTsxSupported ? [] : [TsRunner.TSX]
		].includes(finalTsRunner)) throw new Error(`${finalTsRunner} is not supported for ${ext} files yet` + (isTsxSupported ? ", you can try [tsx](https://github.com/esbuild-kit/tsx) instead" : MTS_SUPPORTED ? ", you can try [oxc](https://github.com/oxc-project/oxc-node) or [swc](https://github.com/swc-project/swc-node/tree/master/packages/register) instead" : ""));
	}
	const finalGlobalShims = (globalShims === true ? DEFAULT_GLOBAL_SHIMS_PRESET : Array.isArray(globalShims) ? globalShims : []).filter(({ moduleName }) => isPkgAvailable(moduleName));
	sharedBufferView ?? (sharedBufferView = new Int32Array(sharedBuffer ?? (sharedBuffer = new SharedArrayBuffer(4)), 0, 1));
	const useGlobals = finalGlobalShims.length > 0;
	const useEval = isTs ? !tsUseEsm : !jsUseEsm && useGlobals;
	const worker = new Worker(jsUseEsm && useGlobals || tsUseEsm && finalTsRunner === TsRunner.TsNode ? dataUrl(`${generateGlobals(finalWorkerPath, finalGlobalShims)};import '${String(workerPathUrl)}'`) : useEval ? `${generateGlobals(finalWorkerPath, finalGlobalShims, "require")};${encodeImportModule(finalWorkerPath, "require")}` : workerPathUrl, {
		eval: useEval,
		workerData: {
			sharedBufferView,
			workerPort,
			pnpLoaderPath
		},
		transferList: [workerPort, ...transferList],
		execArgv: finalExecArgv
	});
	let nextID = 0;
	const receiveMessageWithId = (port, expectedId, waitingTimeout) => {
		const start = Date.now();
		const status = Atomics.wait(sharedBufferView, 0, 0, waitingTimeout);
		Atomics.store(sharedBufferView, 0, 0);
		if (!["ok", "not-equal"].includes(status)) {
			const abortMsg = {
				id: expectedId,
				cmd: "abort"
			};
			port.postMessage(abortMsg);
			throw new Error("Internal error: Atomics.wait() failed: " + status);
		}
		const msg = receiveMessageOnPort(mainPort)?.message;
		if (msg?.id == null || msg.id < expectedId) {
			const waitingTime = Date.now() - start;
			return receiveMessageWithId(port, expectedId, waitingTimeout ? waitingTimeout - waitingTime : void 0);
		}
		const { id, ...message } = msg;
		if (expectedId !== id) throw new Error(`Internal error: Expected id ${expectedId} but got id ${id}`);
		return {
			id,
			...message
		};
	};
	const syncFn = (...args) => {
		const id = nextID++;
		const msg = {
			id,
			args
		};
		worker.postMessage(msg);
		const { result, error, properties, stdio } = receiveMessageWithId(mainPort, id, timeout);
		for (const { type, chunk, encoding } of stdio) process[type].write(chunk, encoding);
		if (error) throw Object.assign(error, properties);
		return result;
	};
	worker.unref();
	return syncFn;
}
//#endregion
//#region node_modules/synckit/lib/index.js
var syncFnCache;
function createSyncFn(workerPath, timeoutOrOptions) {
	syncFnCache ?? (syncFnCache = /* @__PURE__ */ new Map());
	if (typeof workerPath !== "string" || workerPath.startsWith("file://")) workerPath = fileURLToPath(workerPath);
	const cachedSyncFn = syncFnCache.get(workerPath);
	if (cachedSyncFn) return cachedSyncFn;
	if (!path.isAbsolute(workerPath)) throw new Error("`workerPath` must be absolute");
	const syncFn = startWorkerThread(workerPath, typeof timeoutOrOptions === "number" ? { timeout: timeoutOrOptions } : timeoutOrOptions);
	syncFnCache.set(workerPath, syncFn);
	return syncFn;
}
//#endregion
export { createSyncFn as t };
