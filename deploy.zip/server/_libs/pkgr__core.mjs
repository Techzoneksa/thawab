import { i as __require } from "../_runtime.mjs";
import { createRequire } from "node:module";
import fs from "node:fs";
import path from "node:path";
//#region node_modules/@pkgr/core/lib/constants.js
var cjsRequire = typeof __require === "function" ? __require : createRequire(import.meta.url);
var EXTENSIONS = [
	".ts",
	".tsx",
	...cjsRequire.extensions ? Object.keys(cjsRequire.extensions) : [
		".js",
		".json",
		".node"
	]
];
//#endregion
//#region node_modules/@pkgr/core/lib/helpers.js
var tryPkg = (pkg) => {
	try {
		return cjsRequire.resolve(pkg);
	} catch {}
};
var isPkgAvailable = (pkg) => Boolean(tryPkg(pkg));
var ANY_FILE_TYPES = /* @__PURE__ */ new Set(["any", true]);
var isAnyFileType = (type) => ANY_FILE_TYPES.has(type);
var tryFileStats = (filename, type = "file", base = process.cwd()) => {
	if (!type) type = "file";
	if (typeof filename === "string") {
		const filepath = path.resolve(base, filename);
		let stats;
		try {
			stats = fs.statSync(filepath, { throwIfNoEntry: false });
		} catch {}
		return stats && (isAnyFileType(type) || (Array.isArray(type) ? type : [type]).some((type) => stats[`is${type[0].toUpperCase()}${type.slice(1)}`]())) ? {
			filepath,
			stats
		} : void 0;
	}
	for (const file of filename ?? []) {
		const result = tryFileStats(file, type, base);
		if (result) return result;
	}
};
var tryFile = (filename, type = "file", base) => tryFileStats(filename, type, base)?.filepath ?? "";
var tryExtensions = (filepath, extensions = EXTENSIONS) => {
	const ext = [...extensions, ""].find((ext) => tryFile(filepath + ext));
	return ext == null ? "" : filepath + ext;
};
var findUp = (entryOrOptions, options) => {
	if (typeof entryOrOptions === "string") options = {
		entry: entryOrOptions,
		...options
	};
	else if (entryOrOptions) options = options ? {
		...entryOrOptions,
		...options
	} : entryOrOptions;
	let { entry = process.cwd(), search = "package.json", type, stop } = options ?? {};
	search = Array.isArray(search) ? search : [search];
	do {
		const searched = tryFile(search, type, entry);
		if (searched) return searched;
		const lastEntry = entry;
		entry = path.dirname(entry);
		if (entry === lastEntry) break;
	} while (!stop || entry !== stop);
	return "";
};
//#endregion
export { cjsRequire as i, isPkgAvailable as n, tryExtensions as r, findUp as t };
