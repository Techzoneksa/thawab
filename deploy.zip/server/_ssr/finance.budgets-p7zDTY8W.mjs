import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { J as Pencil, P as Search, U as Plus, Wt as CircleCheckBig, jt as Eye, lt as Lock, ut as LockOpen, v as Trash2, wt as Funnel } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, E as PrintButton, F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { a as getBudget, c as unlockBudget, i as deleteBudget, n as approveBudget, o as getBudgets, s as lockBudget } from "./budgets-DCUxNMYq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.budgets-p7zDTY8W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [yearFilter, setYearFilter] = (0, import_react.useState)("الكل");
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [actionTarget, setActionTarget] = (0, import_react.useState)(null);
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const { data, isLoading, error } = useQuery({
		queryKey: ["budgets", {
			search: searchQuery,
			status: statusFilter,
			year: yearFilter
		}],
		queryFn: () => getBudgets({
			search: searchQuery,
			status: statusFilter,
			year: yearFilter
		})
	});
	const budgets = data?.items || [];
	const total = data?.total || 0;
	const { data: detailData } = useQuery({
		queryKey: ["budget", detailId],
		queryFn: () => detailId ? getBudget(detailId) : Promise.resolve(null),
		enabled: !!detailId
	});
	const years = Array.from(new Set(budgets.map((b) => b.year))).sort();
	const yearOptions = ["الكل", ...years.length ? years : [
		"1446",
		"1447",
		"1448"
	]];
	const openAdd = () => navigate({ to: "/finance/budgets/new" });
	const openEdit = (b) => {
		if (b.status !== "مسودة") {
			showToast("لا يمكن تعديل موازنة معتمدة أو مقفلة. افتح التفاصيل لعرض السجل أو تنفيذ إجراء.", "error");
			return;
		}
		navigate({
			to: "/finance/budgets/$id/edit",
			params: { id: b.id }
		});
	};
	const deleteMutation = useMutation({
		mutationFn: deleteBudget,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["budgets"] });
			showToast("تم حذف الموازنة بنجاح", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const actionMutation = useMutation({
		mutationFn: async (vars) => {
			return {
				approve: approveBudget,
				lock: lockBudget,
				unlock: unlockBudget
			}[vars.action]({
				id: vars.id,
				userId: vars.userId,
				userName: vars.userName
			});
		},
		onSuccess: (_, vars) => {
			queryClient.invalidateQueries({ queryKey: ["budgets"] });
			queryClient.invalidateQueries({ queryKey: ["budget"] });
			showToast({
				approve: "تم اعتماد الموازنة",
				lock: "تم قفل الموازنة",
				unlock: "تم فتح قفل الموازنة"
			}[vars.action], "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleActionConfirm = () => {
		if (actionTarget) actionMutation.mutate({
			id: actionTarget.id,
			action: actionTarget.action,
			userId: user?.id,
			userName: user?.name
		});
	};
	const stats = [
		{
			label: "إجمالي الموازنات",
			value: fmtNum(total)
		},
		{
			label: "معتمدة",
			value: budgets.filter((b) => b.status === "معتمد").length
		},
		{
			label: "مقفلة",
			value: budgets.filter((b) => b.status === "مقفل").length
		},
		{
			label: "إجمالي المخطط",
			value: fmtSAR(budgets.reduce((s, b) => s + b.amount, 0))
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المالية",
			"الموازنات"
		],
		title: "الموازنات",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: budgets,
				filename: "الموازنات.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: openAdd,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " موازنة جديدة"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base lg:text-xl font-extrabold mt-1 tabular-nums truncate",
						children: s.value
					})]
				}, s.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث بالاسم أو القسم أو السنة...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الحالة",
					options: ["الكل", ...BUDGET_STATUSES],
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "السنة",
					options: yearOptions,
					value: yearFilter,
					onChange: (e) => setYearFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "الموازنات",
				count: `${fmtNum(total)} موازنة`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 })
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء تحميل الموازنات",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["budgets"] }),
					children: "إعادة المحاولة"
				})
			}) : budgets.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد موازنات",
				description: "ابدأ بإضافة أول موازنة",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة موازنة"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الموازنة",
					"السنة",
					"القسم",
					"المخطط",
					"المصروف",
					"الحالة",
					""
				],
				rows: budgets,
				renderRow: (b) => {
					const pct = b.amount > 0 ? Math.round(b.spent / b.amount * 100) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setDetailId(b.id),
							className: "font-semibold hover:text-primary text-right",
							children: b.name
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "font-mono text-xs",
							children: b.year
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "text-xs",
							children: b.department || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "tabular-nums font-bold",
							children: fmtSAR(b.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 min-w-[120px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 flex-1 rounded-full bg-muted overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-full ${pct > 90 ? "bg-destructive" : pct > 70 ? "bg-warning" : "bg-success"}`,
									style: { width: `${Math.min(100, pct)}%` }
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs tabular-nums",
								children: [pct, "%"]
							})]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: statusTone(b.status),
							children: b.status
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getBudgetActions(b, setDetailId, openEdit, setDeleteTarget, setActionTarget) }) })
					] });
				},
				mobileCard: (b) => {
					const pct = b.amount > 0 ? Math.round(b.spent / b.amount * 100) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setDetailId(b.id),
										className: "text-sm font-bold hover:text-primary text-right",
										children: b.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground",
										children: [
											b.year,
											" · ",
											b.department || "—"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(b.status),
									children: b.status
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-2 flex-1 rounded-full bg-muted overflow-hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `h-full ${pct > 90 ? "bg-destructive" : pct > 70 ? "bg-warning" : "bg-success"}`,
										style: { width: `${Math.min(100, pct)}%` }
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-bold tabular-nums",
									children: [pct, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: ["المخطط: ", fmtSAR(b.amount)]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-bold",
									children: ["المنصرف: ", fmtSAR(b.spent)]
								})]
							})
						]
					}, b.id);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailId,
				onClose: () => setDetailId(null),
				title: `الموازنة: ${detailData?.item?.name || ""}`,
				onSave: () => setDetailId(null),
				saveText: "إغلاق",
				children: detailData && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "السنة",
									value: detailData.item.year
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحالة",
									value: detailData.item.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "القسم",
									value: detailData.item.department || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "العملة",
									value: detailData.item.currency
								})
							]
						}),
						detailData.item.description && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الوصف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm mt-1",
							children: detailData.item.description
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-2",
							children: "مقارنة المخطط بالفعلي"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-2",
							children: detailData.lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: "لا توجد سطور"
							}) : detailData.lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg border p-2 bg-muted/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex justify-between text-xs mb-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-semibold",
											children: [
												l.accountCode,
												" - ",
												l.accountName
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted-foreground",
											children: l.costCenterName || ""
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-3 gap-2 text-xs",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded bg-info/10 p-1.5 text-center",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-muted-foreground",
													children: "المخطط"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "font-bold tabular-nums",
													children: fmtSAR(l.plannedAmount)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded bg-success/10 p-1.5 text-center",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-success",
													children: "الفعلي"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "font-bold tabular-nums text-success",
													children: fmtSAR(l.actualAmount)
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `rounded p-1.5 text-center ${(l.variance || 0) < 0 ? "bg-destructive/10" : "bg-warning/10"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-muted-foreground",
													children: "الفرق"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "font-bold tabular-nums",
													children: fmtSAR(l.variance || 0)
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-1 h-2 rounded-full bg-muted overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `h-full ${(l.utilization || 0) > 90 ? "bg-destructive" : (l.utilization || 0) > 70 ? "bg-warning" : "bg-success"}`,
											style: { width: `${Math.min(100, l.utilization || 0)}%` }
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[10px] text-muted-foreground mt-1 text-center",
										children: [l.utilization || 0, "% استخدام"]
									})
								]
							}, l.id))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "p-3 bg-primary/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-muted-foreground",
											children: "إجمالي المخطط"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold tabular-nums",
											children: fmtSAR(detailData.totals.planned)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-success",
											children: "إجمالي الفعلي"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold tabular-nums text-success",
											children: fmtSAR(detailData.totals.actual)
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-muted-foreground",
											children: "الفرق"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold tabular-nums",
											children: fmtSAR(detailData.totals.variance)
										})]
									})
								]
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: handleDelete,
				title: "حذف الموازنة",
				message: "لا يمكن حذف موازنة معتمدة أو مقفلة.",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget,
				onClose: () => setActionTarget(null),
				onConfirm: handleActionConfirm,
				title: actionTarget ? actionTarget.action === "approve" ? "اعتماد الموازنة" : actionTarget.action === "lock" ? "قفل الموازنة" : "فتح قفل الموازنة" : "",
				message: actionTarget ? `هل تريد ${actionTarget.action === "approve" ? "اعتماد" : actionTarget.action === "lock" ? "قفل" : "فتح قفل"} الموازنة "${actionTarget.name}"؟` : "",
				confirmText: actionTarget ? actionTarget.action === "approve" ? "اعتماد" : actionTarget.action === "lock" ? "قفل" : "فتح" : "",
				cancelText: "إلغاء",
				variant: "default"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: statusFilter,
						onChange: (e) => setStatusFilter(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), BUDGET_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "السنة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: yearFilter,
						onChange: (e) => setYearFilter(e.target.value),
						children: yearOptions.map((y) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: y }, y))
					})] })]
				})
			})
		]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-semibold",
			children: value
		})]
	});
}
function getBudgetActions(b, setDetailId, openEdit, setDeleteTarget, setActionTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => setDetailId(b.id)
	}];
	if (b.status === "مسودة") {
		actions.push({
			label: "تعديل",
			icon: Pencil,
			onClick: () => openEdit(b)
		});
		actions.push({
			label: "اعتماد",
			icon: CircleCheckBig,
			onClick: () => setActionTarget({
				id: b.id,
				name: b.name,
				action: "approve"
			})
		});
		actions.push({
			label: "حذف",
			icon: Trash2,
			onClick: () => setDeleteTarget(b.id),
			variant: "destructive"
		});
	}
	if (b.status === "معتمد") actions.push({
		label: "قفل",
		icon: Lock,
		onClick: () => setActionTarget({
			id: b.id,
			name: b.name,
			action: "lock"
		})
	});
	if (b.status === "مقفل") actions.push({
		label: "فتح القفل",
		icon: LockOpen,
		onClick: () => setActionTarget({
			id: b.id,
			name: b.name,
			action: "unlock"
		})
	});
	return actions;
}
//#endregion
export { Page as component };
