import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { G as Play, J as Pencil, P as Search, U as Plus, Y as Pause, jt as Eye, v as Trash2, wt as Funnel } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, E as PrintButton, F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, g as ExportButton, h as EntityFormDrawer, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { a as deleteCostCenter, i as deactivateCostCenter, n as activateCostCenter, o as getCostCenters, r as createCostCenter, s as updateCostCenter, t as COST_CENTER_STATUSES } from "./cost-centers-Dv7ULNqn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.cost-centers-BlaoiX47.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [statusTarget, setStatusTarget] = (0, import_react.useState)(null);
	const [formCode, setFormCode] = (0, import_react.useState)("");
	const [formName, setFormName] = (0, import_react.useState)("");
	const [formManager, setFormManager] = (0, import_react.useState)("");
	const [formBudget, setFormBudget] = (0, import_react.useState)("0");
	const [formSpent, setFormSpent] = (0, import_react.useState)("0");
	const [formStatus, setFormStatus] = (0, import_react.useState)("نشط");
	const [formDescription, setFormDescription] = (0, import_react.useState)("");
	const [formNotes, setFormNotes] = (0, import_react.useState)("");
	const { data, isLoading, error } = useQuery({
		queryKey: ["cost-centers", {
			search: searchQuery,
			status: statusFilter
		}],
		queryFn: () => getCostCenters({
			search: searchQuery,
			status: statusFilter
		})
	});
	const costCenters = data?.items || [];
	const total = data?.total || 0;
	const openAdd = () => {
		setEditing(null);
		setFormCode("");
		setFormName("");
		setFormManager("");
		setFormBudget("0");
		setFormSpent("0");
		setFormStatus("نشط");
		setFormDescription("");
		setFormNotes("");
		setAddOpen(true);
	};
	const openEdit = (c) => {
		setEditing(c);
		setFormCode(c.code);
		setFormName(c.name);
		setFormManager(c.manager);
		setFormBudget(String(c.budget));
		setFormSpent(String(c.spent));
		setFormStatus(c.status);
		setFormDescription(c.description || "");
		setFormNotes(c.notes || "");
		setAddOpen(true);
	};
	const createMutation = useMutation({
		mutationFn: createCostCenter,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["cost-centers"] });
			showToast("تم إضافة مركز التكلفة بنجاح", "success");
			setAddOpen(false);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const updateMutation = useMutation({
		mutationFn: updateCostCenter,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["cost-centers"] });
			showToast("تم تحديث مركز التكلفة بنجاح", "success");
			setAddOpen(false);
			setEditing(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deleteCostCenter,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["cost-centers"] });
			showToast("تم حذف مركز التكلفة بنجاح", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const statusMutation = useMutation({
		mutationFn: async (vars) => {
			return (vars.action === "deactivate" ? deactivateCostCenter : activateCostCenter)({
				id: vars.id,
				userId: vars.userId,
				userName: vars.userName
			});
		},
		onSuccess: (_, vars) => {
			queryClient.invalidateQueries({ queryKey: ["cost-centers"] });
			showToast(vars.action === "deactivate" ? "تم إيقاف مركز التكلفة" : "تم تفعيل مركز التكلفة", "success");
			setStatusTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleSave = () => {
		if (!formCode.trim()) return showToast("يرجى إدخال رمز المركز", "error");
		if (!formName.trim()) return showToast("يرجى إدخال اسم المركز", "error");
		const payload = {
			code: formCode,
			name: formName,
			manager: formManager,
			budget: parseFloat(formBudget) || 0,
			spent: parseFloat(formSpent) || 0,
			status: formStatus,
			description: formDescription,
			notes: formNotes,
			userId: user?.id,
			userName: user?.name
		};
		if (editing) updateMutation.mutate({
			id: editing.id,
			...payload
		});
		else createMutation.mutate(payload);
	};
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleStatusConfirm = () => {
		if (statusTarget) statusMutation.mutate({
			id: statusTarget.id,
			action: statusTarget.action,
			userId: user?.id,
			userName: user?.name
		});
	};
	const stats = [
		{
			label: "إجمالي المراكز",
			value: fmtNum(total)
		},
		{
			label: "مراكز نشطة",
			value: costCenters.filter((c) => c.status === "نشط").length
		},
		{
			label: "إجمالي الموازنات",
			value: fmtSAR(costCenters.reduce((s, c) => s + c.budget, 0))
		},
		{
			label: "إجمالي المصروف",
			value: fmtSAR(costCenters.reduce((s, c) => s + c.spent, 0))
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المالية",
			"مراكز التكلفة"
		],
		title: "مراكز التكلفة",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: costCenters,
				filename: "مراكز_التكلفة.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: openAdd,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " مركز جديد"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base lg:text-xl font-extrabold mt-1 tabular-nums truncate",
						children: s.value
					})]
				}, s.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث بالرمز أو الاسم...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الحالة",
					options: ["الكل", ...COST_CENTER_STATUSES],
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "مراكز التكلفة",
				count: `${fmtNum(total)} مركز`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 })
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء تحميل مراكز التكلفة",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["cost-centers"] }),
					children: "إعادة المحاولة"
				})
			}) : costCenters.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد مراكز تكلفة",
				description: "ابدأ بإضافة أول مركز",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة مركز"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الرمز",
					"الاسم",
					"المسؤول",
					"الموازنة",
					"المصروف",
					"الحالة",
					""
				],
				rows: costCenters,
				renderRow: (c) => {
					const pct = c.budget > 0 ? Math.round(c.spent / c.budget * 100) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "font-mono text-xs",
							children: c.code
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "font-semibold",
							children: c.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "text-muted-foreground",
							children: c.manager || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "tabular-nums",
							children: fmtSAR(c.budget)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 min-w-[120px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 flex-1 rounded-full bg-muted overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-full ${pct > 90 ? "bg-destructive" : pct > 70 ? "bg-warning" : "bg-success"}`,
									style: { width: `${Math.min(100, pct)}%` }
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs tabular-nums",
								children: [pct, "%"]
							})]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: statusTone(c.status),
							children: c.status
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getCostCenterActions(c, setStatusTarget, openEdit, setDeleteTarget) }) })
					] });
				},
				mobileCard: (c) => {
					const pct = c.budget > 0 ? Math.round(c.spent / c.budget * 100) : 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-bold truncate",
										children: c.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground font-mono",
										children: [
											c.code,
											" · ",
											c.manager || "—"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(c.status),
									children: c.status
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-2 flex-1 rounded-full bg-muted overflow-hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `h-full ${pct > 90 ? "bg-destructive" : pct > 70 ? "bg-warning" : "bg-success"}`,
										style: { width: `${Math.min(100, pct)}%` }
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs tabular-nums font-bold",
									children: [pct, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: ["الموازنة: ", fmtSAR(c.budget)]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-bold",
									children: ["المصروف: ", fmtSAR(c.spent)]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex justify-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => openEdit(c),
									className: "text-primary text-xs font-semibold",
									children: "تعديل"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setDeleteTarget(c.id),
									className: "text-destructive text-xs font-semibold",
									children: "حذف"
								})]
							})
						]
					}, c.id);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: addOpen,
				onClose: () => {
					setAddOpen(false);
					setEditing(null);
				},
				title: editing ? "تعديل مركز التكلفة" : "إضافة مركز تكلفة جديد",
				onSave: handleSave,
				loading: createMutation.isPending || updateMutation.isPending,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الرمز *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: formCode,
							onChange: (e) => setFormCode(e.target.value),
							placeholder: "CC-100"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الاسم *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: formName,
							onChange: (e) => setFormName(e.target.value)
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "المسؤول"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						value: formManager,
						onChange: (e) => setFormManager(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الموازنة (ر.س)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							type: "number",
							value: formBudget,
							onChange: (e) => setFormBudget(e.target.value)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "المصروف (ر.س)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							type: "number",
							value: formSpent,
							onChange: (e) => setFormSpent(e.target.value)
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						value: formStatus,
						onChange: (e) => setFormStatus(e.target.value),
						children: COST_CENTER_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الوصف"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						rows: 2,
						value: formDescription,
						onChange: (e) => setFormDescription(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "ملاحظات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						rows: 2,
						value: formNotes,
						onChange: (e) => setFormNotes(e.target.value)
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: handleDelete,
				title: "حذف مركز التكلفة",
				message: "لا يمكن حذف مركز تكلفة مستخدم في قيود أو موازنات. أوقف المركز بدلاً من ذلك.",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!statusTarget,
				onClose: () => setStatusTarget(null),
				onConfirm: handleStatusConfirm,
				title: statusTarget ? statusTarget.action === "deactivate" ? "إيقاف مركز التكلفة" : "تفعيل مركز التكلفة" : "",
				message: statusTarget ? `هل تريد ${statusTarget.action === "deactivate" ? "إيقاف" : "تفعيل"} مركز التكلفة "${statusTarget.name}"؟` : "",
				confirmText: statusTarget ? statusTarget.action === "deactivate" ? "إيقاف" : "تفعيل" : "",
				cancelText: "إلغاء",
				variant: "default"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: statusFilter,
						onChange: (e) => setStatusFilter(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), COST_CENTER_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
					})] })
				})
			})
		]
	});
}
function getCostCenterActions(c, setStatusTarget, openEdit, setDeleteTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => showToast(`${c.code} - ${c.name}`, "info")
	}];
	actions.push({
		label: "تعديل",
		icon: Pencil,
		onClick: () => openEdit(c)
	});
	if (c.status === "نشط") actions.push({
		label: "إيقاف",
		icon: Pause,
		onClick: () => setStatusTarget({
			id: c.id,
			name: `${c.code} - ${c.name}`,
			action: "deactivate"
		})
	});
	else if (c.status === "موقوف") actions.push({
		label: "تفعيل",
		icon: Play,
		onClick: () => setStatusTarget({
			id: c.id,
			name: `${c.code} - ${c.name}`,
			action: "activate"
		})
	});
	actions.push({
		label: "حذف",
		icon: Trash2,
		onClick: () => setDeleteTarget(c.id),
		variant: "destructive"
	});
	return actions;
}
//#endregion
export { Page as component };
