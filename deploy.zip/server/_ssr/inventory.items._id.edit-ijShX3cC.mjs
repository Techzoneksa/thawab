import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { H as PowerOff, M as Settings2, U as Plus, V as Power, pn as Archive, tt as Minus, un as ArrowRightLeft } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, P as statusTone, c as ConfirmDialog, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { t as getAuditEntries } from "./audit-DP6UgtXG.mjs";
import { s as getWarehouses } from "./warehouses-sU_fp7nA.mjs";
import { c as getInventoryItem, d as receiveInventoryItem, f as transferInventoryItem, i as adjustInventoryItem, n as MOVEMENT_TYPES, o as deactivateInventoryItem, p as updateInventoryItem, r as activateInventoryItem, s as deleteInventoryItem, t as ITEM_STATUSES, u as issueInventoryItem } from "./inventory-items-mo3tbFC9.mjs";
import { t as Route } from "./inventory.items._id.edit-5VQs2kwA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.items._id.edit-ijShX3cC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATEGORIES = [
	"مواد غذائية",
	"ملابس",
	"أجهزة إلكترونية",
	"أثاث",
	"مواد تنظيف",
	"أدوات مكتبية",
	"مستلزمات طبية",
	"أخرى"
];
function EditItemPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const detailQuery = useQuery({
		queryKey: ["inventoryItemDetail", id],
		queryFn: () => getInventoryItem(id)
	});
	const warehouses = (useQuery({
		queryKey: ["warehouses-simple"],
		queryFn: () => getWarehouses({ limit: 1e3 })
	}).data?.items || []).filter((w) => w.status === "نشط");
	const item = detailQuery.data?.item;
	const movementCount = detailQuery.data?.movementCount ?? 0;
	const poLineCount = detailQuery.data?.poLineCount ?? 0;
	const hasMovements = detailQuery.data?.hasMovements ?? false;
	const [name, setName] = (0, import_react.useState)("");
	const [sku, setSku] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("");
	const [unit, setUnit] = (0, import_react.useState)("");
	const [warehouseId, setWarehouseId] = (0, import_react.useState)("");
	const [minQuantity, setMinQuantity] = (0, import_react.useState)("0");
	const [price, setPrice] = (0, import_react.useState)("0");
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(null);
	const [movementType, setMovementType] = (0, import_react.useState)("receive");
	const [mvQty, setMvQty] = (0, import_react.useState)("");
	const [mvWarehouseId, setMvWarehouseId] = (0, import_react.useState)("");
	const [mvToWarehouseId, setMvToWarehouseId] = (0, import_react.useState)("");
	const [mvNotes, setMvNotes] = (0, import_react.useState)("");
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	if (item && !hydrated) {
		setName(item.name);
		setSku(item.sku);
		setCategory(item.category);
		setUnit(item.unit);
		setWarehouseId(item.warehouseId || "");
		setMinQuantity(String(item.minQuantity || 0));
		setPrice(String(item.price || 0));
		setStatus(item.status || "نشط");
		setNotes(item.notes || "");
		setMvWarehouseId(item.warehouseId || "");
		setHydrated(true);
	}
	const handleSave = async () => {
		const errs = [];
		if (!name.trim()) errs.push("اسم الصنف مطلوب");
		const min = parseFloat(minQuantity) || 0;
		if (min < 0) errs.push("الحد الأدنى لا يمكن أن يكون سالبًا");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			await updateInventoryItem({
				id,
				name: name.trim(),
				sku: sku || void 0,
				category: category || void 0,
				unit,
				warehouseId: warehouseId || void 0,
				minQuantity: min,
				price: parseFloat(price) || 0,
				status,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItemDetail", id] });
			showToast("تم حفظ التعديلات", "success");
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const handleMovement = async () => {
		const qty = parseFloat(mvQty);
		if (!qty || qty <= 0) {
			showToast("الكمية يجب أن تكون أكبر من صفر", "error");
			return;
		}
		if (movementType === "transfer") {
			if (!mvWarehouseId || !mvToWarehouseId) {
				showToast("يرجى اختيار مستودع المصدر والوجهة", "error");
				return;
			}
			if (mvWarehouseId === mvToWarehouseId) {
				showToast("لا يمكن التحويل لنفس المستودع", "error");
				return;
			}
		}
		try {
			if (movementType === "receive") {
				await receiveInventoryItem({
					id,
					quantity: qty,
					warehouseId: mvWarehouseId || void 0,
					notes: mvNotes || void 0,
					userId: user?.id,
					userName: user?.name
				});
				showToast(`تم استلام ${qty} ${item?.unit}`, "success");
			} else if (movementType === "issue") {
				await issueInventoryItem({
					id,
					quantity: qty,
					warehouseId: mvWarehouseId || void 0,
					notes: mvNotes || void 0,
					userId: user?.id,
					userName: user?.name
				});
				showToast(`تم صرف ${qty} ${item?.unit}`, "success");
			} else if (movementType === "transfer") {
				await transferInventoryItem({
					id,
					fromWarehouseId: mvWarehouseId,
					toWarehouseId: mvToWarehouseId,
					quantity: qty,
					notes: mvNotes || void 0,
					userId: user?.id,
					userName: user?.name
				});
				showToast(`تم تحويل ${qty} ${item?.unit}`, "success");
			} else {
				await adjustInventoryItem({
					id,
					quantity: qty,
					warehouseId: mvWarehouseId || void 0,
					notes: mvNotes || void 0,
					userId: user?.id,
					userName: user?.name
				});
				showToast(`تمت تسوية ${qty} ${item?.unit}`, "success");
			}
			queryClient.invalidateQueries({ queryKey: ["inventoryItemDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItemAudit", id] });
			setMvQty("");
			setMvNotes("");
			setConfirmAction(null);
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل تنفيذ الحركة", "error");
		}
	};
	const auditQuery = useQuery({
		queryKey: ["inventoryItemAudit", id],
		queryFn: () => getAuditEntries({
			entityType: "صنف",
			entityId: id,
			limit: 50
		}),
		enabled: !!item
	});
	const tabs = [
		{
			id: "basic",
			label: "بيانات الصنف",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات الصنف",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم الصنف",
						required: true,
						error: errors[0],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "رمز SKU",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: sku,
							onChange: (e) => setSku(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "التصنيف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— اختر —"
							}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c,
								children: c
							}, c))]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "وحدة القياس",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: unit,
							onChange: (e) => setUnit(e.target.value)
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المستودع الافتراضي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: warehouseId,
							onChange: (e) => setWarehouseId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— لا يوجد —"
							}), warehouses.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: w.id,
								children: w.name
							}, w.id))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحد الأدنى",
						error: errors[1],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: minQuantity,
							onChange: (e) => setMinQuantity(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "سعر الوحدة",
						hint: "ر.س",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: price,
							onChange: (e) => setPrice(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحالة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: status,
							onChange: (e) => setStatus(e.target.value),
							children: ITEM_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								children: s
							}, s))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value),
							rows: 3
						})
					})
				]
			})
		},
		{
			id: "movements",
			label: "حركة المخزون",
			badge: hasMovements ? String(movementCount) : void 0,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "حركة المخزون",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-muted/40 p-3 mb-3 text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground",
								children: "الكمية الحالية"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-base font-bold tabular-nums",
								children: [
									item?.quantity ?? 0,
									" ",
									item?.unit
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground",
								children: "الحد الأدنى"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-base font-bold tabular-nums",
								children: [
									item?.minQuantity ?? 0,
									" ",
									item?.unit
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground",
								children: "إجمالي الحركات"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-bold tabular-nums",
								children: movementCount
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground",
								children: "أوامر شراء مرتبطة"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-bold tabular-nums",
								children: poLineCount
							})] })
						]
					}), item && item.quantity <= item.minQuantity && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 text-warning font-semibold",
						children: "⚠ الكمية وصلت للحد الأدنى — يرجى إعادة الطلب."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border bg-card shadow-card p-4 sm:p-5 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-2",
							children: "نوع الحركة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 sm:grid-cols-4 gap-2",
							children: MOVEMENT_TYPES.map((t) => {
								const cfg = {
									استلام: {
										value: "receive",
										icon: Plus,
										color: "success"
									},
									صرف: {
										value: "issue",
										icon: Minus,
										color: "warning"
									},
									تحويل: {
										value: "transfer",
										icon: ArrowRightLeft,
										color: "info"
									},
									تسوية: {
										value: "adjust",
										icon: Settings2,
										color: "primary"
									}
								}[t];
								const Icon = cfg.icon;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setMovementType(cfg.value),
									className: `inline-flex items-center justify-center gap-2 rounded-lg border px-3 py-2.5 text-xs sm:text-sm font-semibold transition-colors min-h-[40px] ${movementType === cfg.value ? "bg-primary text-primary-foreground border-primary" : "bg-background hover:bg-muted"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 14 }),
										" ",
										t
									]
								}, cfg.value);
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
							children: [movementType === "transfer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "من مستودع",
								required: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
									value: mvWarehouseId,
									onChange: (e) => setMvWarehouseId(e.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "— اختر —"
									}), warehouses.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: w.id,
										children: w.name
									}, w.id))]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "إلى مستودع",
								required: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
									value: mvToWarehouseId,
									onChange: (e) => setMvToWarehouseId(e.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "— اختر —"
									}), warehouses.filter((w) => w.id !== mvWarehouseId).map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: w.id,
										children: w.name
									}, w.id))]
								})
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "المستودع",
								hint: "اختياري",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
									value: mvWarehouseId,
									onChange: (e) => setMvWarehouseId(e.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "— افتراضي —"
									}), warehouses.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: w.id,
										children: w.name
									}, w.id))]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "الكمية",
								required: true,
								hint: item?.unit || "",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									type: "number",
									step: "0.01",
									value: mvQty,
									onChange: (e) => setMvQty(e.target.value),
									dir: "ltr"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "ملاحظات",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
								value: mvNotes,
								onChange: (e) => setMvNotes(e.target.value),
								rows: 2,
								placeholder: "سبب الحركة..."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex justify-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setConfirmAction("movement"),
								disabled: !mvQty || parseFloat(mvQty) <= 0,
								className: "inline-flex items-center justify-center gap-2 rounded-lg bg-primary text-primary-foreground px-4 py-2.5 text-sm font-semibold hover:opacity-90 disabled:opacity-50 min-h-[40px]",
								children: "تنفيذ الحركة"
							})
						})
					]
				})]
			})
		},
		{
			id: "summary",
			label: "ملخص",
			content: item ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ملخص الصنف",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "اسم الصنف",
						value: item.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "SKU",
						value: item.sku || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "التصنيف",
						value: item.category || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الوحدة",
						value: item.unit
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الكمية الحالية",
						value: `${item.quantity} ${item.unit}`,
						tone: item.quantity <= item.minQuantity ? "warning" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الحد الأدنى",
						value: `${item.minQuantity} ${item.unit}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "سعر الوحدة",
						value: fmtSAR(item.price)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الحالة",
						value: item.status,
						tone: item.status === "نشط" ? "success" : "warning"
					})
				]
			}) : null
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			badge: auditQuery.data?.items.length,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "سجل العمليات",
				children: auditQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "جاري التحميل..."
				}) : (auditQuery.data?.items ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "لا توجد عمليات مسجلة على هذا الصنف."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: (auditQuery.data?.items ?? []).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border bg-card px-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-foreground",
									children: e.action
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground font-mono",
									children: e.timestamp?.slice(0, 16).replace("T", " ")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground mt-0.5",
								children: e.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-muted-foreground mt-0.5",
								children: ["المستخدم: ", e.userName || "—"]
							})
						]
					}, e.id))
				})
			})
		}
	];
	const activateMut = useMutation({
		mutationFn: () => activateInventoryItem({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["inventoryItemDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItemAudit", id] });
			showToast("تم تفعيل الصنف", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deactivateMut = useMutation({
		mutationFn: () => deactivateInventoryItem({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["inventoryItemDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItemAudit", id] });
			showToast("تم إيقاف الصنف", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMut = useMutation({
		mutationFn: () => deleteInventoryItem({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			showToast("تم حذف الصنف", "success");
			navigate({ to: "/inventory/items" });
		},
		onError: (err) => showToast(err.message, "error")
	});
	if (detailQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الأصناف",
		breadcrumb: ["المخزون", "الأصناف"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الأصناف",
		breadcrumb: ["المخزون", "الأصناف"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-center py-12 text-muted-foreground",
			children: "الصنف غير موجود"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "الأصناف",
		breadcrumb: [
			"المخزون",
			"الأصناف",
			"تعديل"
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
				breadcrumb: [
					{
						label: "المخزون",
						to: "/inventory/items"
					},
					{
						label: "الأصناف",
						to: "/inventory/items"
					},
					{ label: item.name }
				],
				title: item.name,
				subtitle: `${item.category || ""} · ${item.unit} · ${item.quantity} متوفر`,
				draftNumber: item.id,
				status: {
					label: item.status,
					tone: statusTone(item.status)
				},
				tabs,
				defaultTab: "basic",
				loading: saving,
				validationErrors: errors,
				primaryLabel: "حفظ التعديلات",
				secondaryLabel: "حفظ وإغلاق",
				showSecondary: false,
				extraActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [item.status === "نشط" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("deactivate"),
					className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium hover:bg-muted transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PowerOff, { size: 15 }), " إيقاف"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("activate"),
					className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium hover:bg-muted transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Power, { size: 15 }), " تفعيل"]
				}), !hasMovements && !poLineCount && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("delete"),
					className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { size: 15 }), " حذف"]
				})] }),
				onPrimary: handleSave,
				onCancel: () => navigate({ to: "/inventory/items" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "movement",
				onClose: () => setConfirmAction(null),
				onConfirm: handleMovement,
				title: "تأكيد الحركة",
				message: `هل تريد تنفيذ حركة "${MOVEMENT_TYPES.find((t) => [
					"استلام",
					"صرف",
					"تحويل",
					"تسوية"
				][MOVEMENT_TYPES.indexOf(t)] === movementType)}" بكمية ${mvQty} ${item.unit}؟`,
				confirmText: "تنفيذ",
				cancelText: "تراجع"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "activate",
				onClose: () => setConfirmAction(null),
				onConfirm: () => activateMut.mutate(),
				title: "تفعيل الصنف",
				message: `هل تريد تفعيل الصنف "${item.name}"؟`,
				confirmText: "تفعيل",
				cancelText: "إلغاء",
				loading: activateMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "deactivate",
				onClose: () => setConfirmAction(null),
				onConfirm: () => deactivateMut.mutate(),
				title: "إيقاف الصنف",
				message: `هل تريد إيقاف الصنف "${item.name}"؟ سيختفي من القوائم المتاحة للحركات الجديدة.`,
				confirmText: "إيقاف",
				cancelText: "إلغاء",
				variant: "destructive",
				loading: deactivateMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "delete",
				onClose: () => setConfirmAction(null),
				onConfirm: () => deleteMut.mutate(),
				title: "حذف الصنف",
				message: `هل تريد حذف الصنف "${item.name}"؟`,
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive",
				loading: deleteMut.isPending
			})
		]
	});
}
//#endregion
export { EditItemPage as component };
