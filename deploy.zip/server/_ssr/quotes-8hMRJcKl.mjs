//#region node_modules/.nitro/vite/services/ssr/assets/quotes-8hMRJcKl.js
var API_BASE = "/api/procurement/quotes";
var QUOTE_STATUSES = [
	"بانتظار",
	"مقبول",
	"مرفوض"
];
async function getQuotes(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.requestId) params.set("requestId", filters.requestId);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب عروض الأسعار");
	return res.json();
}
async function getQuote(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات عرض السعر");
	return res.json();
}
async function createQuote(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة عرض السعر");
	}
	return (await res.json()).item;
}
async function updateQuote(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث عرض السعر");
	}
	return (await res.json()).item;
}
async function acceptQuote(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "accept"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في قبول عرض السعر");
	}
	return (await res.json()).item;
}
async function rejectQuote(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "reject"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في رفض عرض السعر");
	}
	return (await res.json()).item;
}
async function deleteQuote(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف عرض السعر");
	}
}
//#endregion
export { getQuote as a, updateQuote as c, deleteQuote as i, acceptQuote as n, getQuotes as o, createQuote as r, rejectQuote as s, QUOTE_STATUSES as t };
