//#region node_modules/.nitro/vite/services/ssr/assets/journal-Da8V5shh.js
var API_BASE = "/api/finance/journal";
var JOURNAL_STATUSES = [
	"مسودة",
	"بانتظار الاعتماد",
	"مرحّل",
	"ملغى",
	"معكوس"
];
var JOURNAL_FUNDS = [
	"مقيد",
	"غير مقيد",
	"أوقاف"
];
async function getJournalEntries(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.fund && filters.fund !== "الكل") params.set("fund", filters.fund);
	if (filters.projectId) params.set("projectId", filters.projectId);
	if (filters.page) params.set("page", String(filters.page));
	if (filters.limit) params.set("limit", String(filters.limit));
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب قيود اليومية");
	return res.json();
}
async function getJournalEntry(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات القيد");
	return res.json();
}
async function createJournalEntry(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة القيد");
	}
	return (await res.json()).item;
}
async function updateJournalEntry(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث القيد");
	}
	return (await res.json()).item;
}
async function deleteJournalEntry(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف القيد");
	}
}
async function postJournalEntry(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "post"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في ترحيل القيد");
	}
	return (await res.json()).item;
}
async function reverseJournalEntry(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "reverse"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في عكس القيد");
	}
	return (await res.json()).item;
}
async function cancelJournalEntry(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "cancel"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إلغاء القيد");
	}
	return (await res.json()).item;
}
//#endregion
export { deleteJournalEntry as a, postJournalEntry as c, createJournalEntry as i, reverseJournalEntry as l, JOURNAL_STATUSES as n, getJournalEntries as o, cancelJournalEntry as r, getJournalEntry as s, JOURNAL_FUNDS as t, updateJournalEntry as u };
