import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, y as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, P as statusTone, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { a as getBudget, c as unlockBudget, l as updateBudget, n as approveBudget, s as lockBudget } from "./budgets-DCUxNMYq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.budgets._id.edit-w_6XJAa3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditBudgetPage() {
	const { id } = useParams({ from: "/finance/budgets/$id/edit" });
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: payload, isLoading } = useQuery({
		queryKey: ["budget", id],
		queryFn: () => getBudget(id),
		enabled: !!id
	});
	const item = payload?.item;
	const serverLines = payload?.lines || [];
	const totals = payload?.totals;
	const [name, setName] = (0, import_react.useState)("");
	const [year, setYear] = (0, import_react.useState)("");
	const [department, setDepartment] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (item) {
			setName(item.name);
			setYear(item.year);
			setDepartment(item.department || "");
			setDescription(item.description || "");
			setNotes(item.notes || "");
		}
	}, [item]);
	const isEditable = item?.status === "مسودة";
	const isApproved = item?.status === "معتمد";
	const isLocked = item?.status === "مقفل";
	const updateMutation = useMutation({
		mutationFn: (data) => updateBudget({
			id,
			...data
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["budget", id] });
			queryClient.invalidateQueries({ queryKey: ["budgets"] });
			showToast("تم تحديث الموازنة", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const approveMutation = useMutation({
		mutationFn: () => approveBudget({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["budget", id] });
			queryClient.invalidateQueries({ queryKey: ["budgets"] });
			showToast("تم اعتماد الموازنة", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const lockMutation = useMutation({
		mutationFn: () => lockBudget({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["budget", id] });
			queryClient.invalidateQueries({ queryKey: ["budgets"] });
			showToast("تم قفل الموازنة", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const unlockMutation = useMutation({
		mutationFn: () => unlockBudget({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["budget", id] });
			queryClient.invalidateQueries({ queryKey: ["budgets"] });
			showToast("تم فتح قفل الموازنة", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleSave = async (andClose) => {
		if (!isEditable) {
			showToast("لا يمكن تعديل موازنة معتمدة أو مقفلة", "error");
			return;
		}
		setSaving(true);
		try {
			await updateMutation.mutateAsync({
				name,
				year,
				department: department || void 0,
				description: description || void 0,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			if (andClose) navigate({ to: "/finance/budgets" });
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الموازنات",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الموازنات",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center py-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-base font-bold mb-2",
				children: "الموازنة غير موجودة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => navigate({ to: "/finance/budgets" }),
				className: "text-primary hover:underline text-sm",
				children: "العودة"
			})]
		})
	});
	const tabs = [
		{
			id: "basic",
			label: "البيانات الأساسية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات الموازنة",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم الموازنة",
						required: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value),
							disabled: !isEditable
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "السنة المالية",
						required: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: year,
							onChange: (e) => setYear(e.target.value),
							dir: "ltr",
							disabled: !isEditable
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الإدارة / القسم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: department,
							onChange: (e) => setDepartment(e.target.value),
							disabled: !isEditable
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحالة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: item.status,
							disabled: true
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "وصف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: description,
							onChange: (e) => setDescription(e.target.value),
							rows: 3,
							disabled: !isEditable
						})
					})
				]
			})
		},
		{
			id: "lines",
			label: "بنود الموازنة",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "بنود الموازنة",
				description: isEditable ? "يمكن تعديل البنود قبل الاعتماد" : "للقراءة فقط",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border bg-card overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "min-w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-muted/60 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-10",
										children: "#"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground",
										children: "الحساب"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-32",
										children: "مخطط"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-32",
										children: "فعلي"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-32",
										children: "فرق"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-24",
										children: "% استخدام"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: serverLines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 6,
								className: "px-3 py-6 text-center text-muted-foreground text-xs",
								children: "لا توجد بنود"
							}) }) : serverLines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2 text-muted-foreground tabular-nums",
										children: l.lineNumber
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs font-mono text-muted-foreground tabular-nums",
											children: l.accountCode || "—"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm",
											children: l.accountName || "—"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2 font-mono tabular-nums text-left",
										children: fmtSAR(l.plannedAmount)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2 font-mono tabular-nums text-left",
										children: fmtSAR(l.actualAmount || 0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: `px-3 py-2 font-mono tabular-nums text-left ${(l.variance || 0) < 0 ? "text-destructive" : "text-success"}`,
										children: fmtSAR(l.variance || 0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3 py-2 font-mono tabular-nums text-left",
										children: [(l.utilization || 0).toFixed(1), "%"]
									})
								]
							}, l.id)) })]
						})
					}), totals && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t bg-muted/30 px-3 py-3 flex items-center justify-end gap-4 text-sm font-bold tabular-nums",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["إجمالي مخطط: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: fmtSAR(totals.planned)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["إجمالي فعلي: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: fmtSAR(totals.actual)
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: totals.variance < 0 ? "text-destructive" : "text-success",
								children: ["فرق: ", fmtSAR(totals.variance)]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["نسبة الاستخدام: ", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-foreground",
								children: [(totals.utilization || 0).toFixed(1), "%"]
							})] })
						]
					})]
				})
			})
		},
		{
			id: "notes",
			label: "الملاحظات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "ملاحظات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 5,
						disabled: !isEditable
					})
				})
			})
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "سجل التدقيق",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "الحالة",
							value: item.status
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "أنشأ بواسطة",
							value: item.createdBy || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ الإنشاء",
							value: item.createdAt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "آخر تحديث",
							value: item.updatedAt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "اعتمد بواسطة",
							value: item.approvedBy || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ الاعتماد",
							value: item.approvedAt || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "قفل بواسطة",
							value: item.lockedBy || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ القفل",
							value: item.lockedAt || "—"
						})
					]
				})
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الموازنات",
		breadcrumb: [
			"المالية",
			"الموازنات",
			item.name
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المالية",
					to: "/finance/budgets"
				},
				{
					label: "الموازنات",
					to: "/finance/budgets"
				},
				{ label: item.name }
			],
			title: `موازنة: ${item.name}`,
			subtitle: `${year} · ${department || "بدون قسم"} · ${fmtSAR(item.amount)}`,
			draftNumber: item.id,
			status: {
				label: item.status,
				tone: statusTone(item.status)
			},
			isReadOnly: !isEditable,
			readonlyReason: isLocked ? "الموازنة مقفلة. لفتحها استخدم إجراء فتح القفل." : isApproved ? "الموازنة معتمدة. البنود للقراءة فقط." : "",
			tabs,
			defaultTab: "basic",
			loading: saving || updateMutation.isPending,
			primaryLabel: isEditable ? "حفظ ومتابعة" : "للقراءة فقط",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: isEditable,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/finance/budgets" }),
			extraActions: isEditable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => approveMutation.mutate(),
				disabled: approveMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg bg-success px-3 py-2 text-sm font-semibold text-success-foreground hover:opacity-90 transition-opacity min-h-[40px]",
				children: "اعتماد"
			}) : isApproved ? isLocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => unlockMutation.mutate(),
				disabled: unlockMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg border border-warning/30 bg-warning/10 text-warning px-3 py-2 text-sm font-semibold hover:bg-warning/20 transition-colors min-h-[40px]",
				children: "فتح القفل"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => lockMutation.mutate(),
				disabled: lockMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg border border-primary/30 bg-primary/10 text-primary px-3 py-2 text-sm font-semibold hover:bg-primary/20 transition-colors min-h-[40px]",
				children: "قفل الموازنة"
			}) : null
		})
	});
}
//#endregion
export { EditBudgetPage as component };
