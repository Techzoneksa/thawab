import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { G as Play, Ht as CircleX, J as Pencil, U as Plus, Wt as CircleCheckBig, Y as Pause, ft as List, jt as Eye, pt as LayoutGrid, v as Trash2, wt as Funnel } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, E as PrintButton, F as useAuth, N as showToast, P as statusTone, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { a as deleteProject, c as getProjects, l as pauseProject, n as cancelProject, r as completeProject, t as activateProject } from "./projects-fdUGDKDE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projects-BlXBdnSS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PROJECT_CATEGORIES = [
	"الكل",
	"إغاثي",
	"تنموي",
	"تعليمي",
	"صحي",
	"اجتماعي"
];
var PROJECT_BRANCHES = [
	"الكل",
	"الفرع الرئيسي",
	"فرع مكة",
	"فرع الرياض",
	"فرع جدة"
];
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [view, setView] = (0, import_react.useState)("grid");
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [statusTarget, setStatusTarget] = (0, import_react.useState)(null);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [categoryFilter, setCategoryFilter] = (0, import_react.useState)("الكل");
	const [branchFilter, setBranchFilter] = (0, import_react.useState)("الكل");
	const [page, setPage] = (0, import_react.useState)(1);
	const [apiFilters, setApiFilters] = (0, import_react.useState)({
		search: "",
		status: "",
		category: "",
		branch: "",
		page: 1,
		limit: 50
	});
	const { data, isLoading, error } = useQuery({
		queryKey: ["projects", apiFilters],
		queryFn: () => getProjects(apiFilters)
	});
	const projects = data?.items || [];
	const total = data?.total || 0;
	const totalPages = Math.ceil(total / 50);
	(0, import_react.useEffect)(() => {
		setPage(1);
		setApiFilters((f) => ({
			...f,
			search: searchQuery,
			status: statusFilter,
			category: categoryFilter,
			branch: branchFilter,
			page: 1
		}));
	}, [
		searchQuery,
		statusFilter,
		categoryFilter,
		branchFilter
	]);
	(0, import_react.useEffect)(() => {
		setApiFilters((f) => ({
			...f,
			page
		}));
	}, [page]);
	const deleteMutation = useMutation({
		mutationFn: deleteProject,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["projects"] });
			showToast("تم حذف المشروع بنجاح", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const statusMutation = useMutation({
		mutationFn: async (vars) => {
			return {
				activate: activateProject,
				pause: pauseProject,
				complete: completeProject,
				cancel: cancelProject
			}[vars.action]({
				id: vars.id,
				userId: vars.userId,
				userName: vars.userName
			});
		},
		onSuccess: (_, vars) => {
			queryClient.invalidateQueries({ queryKey: ["projects"] });
			showToast({
				activate: "تم تفعيل المشروع",
				pause: "تم إيقاف المشروع",
				complete: "تم إكمال المشروع",
				cancel: "تم إلغاء المشروع"
			}[vars.action], "success");
			setStatusTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => navigate({ to: "/projects/new" });
	const openEdit = (p) => navigate({
		to: "/projects/$id/edit",
		params: { id: p.id }
	});
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleStatusConfirm = () => {
		if (statusTarget) statusMutation.mutate({
			id: statusTarget.id,
			action: statusTarget.action,
			userId: user?.id,
			userName: user?.name
		});
	};
	const isReadOnly = (p) => p.status === "مكتمل" || p.status === "ملغي";
	const stats = [
		{
			label: "إجمالي المشاريع",
			value: fmtNum(total)
		},
		{
			label: "مشاريع نشطة",
			value: projects.filter((p) => p.status === "نشط").length
		},
		{
			label: "مشاريع مكتملة",
			value: projects.filter((p) => p.status === "مكتمل").length
		},
		{
			label: "الميزانية الكلية",
			value: fmtSAR(projects.reduce((s, p) => s + p.budget, 0))
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المشاريع والمستفيدون",
			"المشاريع والبرامج"
		],
		title: "المشاريع والبرامج",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden lg:flex rounded-lg border overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setView("grid"),
					className: `px-3 py-2 ${view === "grid" ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { size: 15 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setView("table"),
					className: `px-3 py-2 ${view === "table" ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { size: 15 })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: projects,
				filename: "المشاريع.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: openAdd,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " مشروع جديد"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base lg:text-xl font-extrabold mt-1 tabular-nums truncate",
						children: s.value
					})]
				}, s.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث بالاسم أو الكود أو المدير...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الحالة",
					options: [
						"الكل",
						"مخطط",
						"نشط",
						"متوقف",
						"مكتمل",
						"ملغي"
					],
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "التصنيف",
					options: PROJECT_CATEGORIES,
					value: categoryFilter,
					onChange: (e) => setCategoryFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الفرع",
					options: PROJECT_BRANCHES,
					value: branchFilter,
					onChange: (e) => setBranchFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء تحميل المشاريع",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["projects"] }),
					children: "إعادة المحاولة"
				})
			}) : projects.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد مشاريع",
				description: "ابدأ بإضافة أول مشروع",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة مشروع"
				})
			}) : view === "grid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 lg:gap-4",
				children: projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4 lg:p-5 hover:border-primary transition-all",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-muted-foreground font-mono",
										children: p.code || p.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold text-sm lg:text-base mt-0.5 truncate",
										children: p.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground mt-0.5 truncate",
										children: ["المدير: ", p.manager]
									}),
									p.category && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-[11px] text-muted-foreground mt-0.5 truncate",
										children: [p.category, p.branch && ` · ${p.branch}`]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(p.status),
								children: p.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 lg:mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between text-xs mb-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نسبة الإنجاز" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-bold tabular-nums",
									children: [p.progress, "%"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 rounded-full bg-muted overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-gradient-to-l from-primary to-info",
									style: { width: `${p.progress}%` }
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2 mt-3 lg:mt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-muted/60 p-2 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] lg:text-[10px] text-muted-foreground",
										children: "الميزانية"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] lg:text-xs font-bold tabular-nums mt-0.5",
										children: fmtSAR(p.budget)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-success/10 p-2 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] lg:text-[10px] text-success",
										children: "التبرعات"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] lg:text-xs font-bold tabular-nums mt-0.5 text-success",
										children: fmtSAR(p.donations)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-warning/15 p-2 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] lg:text-[10px] text-warning-foreground",
										children: "المنصرف"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] lg:text-xs font-bold tabular-nums mt-0.5",
										children: fmtSAR(p.spent)
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center justify-between text-xs text-muted-foreground border-t pt-2 lg:pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [fmtNum(p.beneficiaryCount), " مستفيد"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/projects/$id",
										params: { id: p.id },
										className: "text-info text-xs font-semibold",
										children: "تفاصيل"
									}),
									!isReadOnly(p) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => openEdit(p),
										className: "text-primary text-xs font-semibold",
										children: "تعديل"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setDeleteTarget(p.id),
										className: "text-destructive text-xs font-semibold",
										children: "حذف"
									})
								]
							})]
						})
					]
				}, p.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"المشروع",
					"المدير",
					"الميزانية",
					"المنصرف",
					"التبرعات",
					"المستفيدون",
					"الإنجاز",
					"الحالة",
					""
				],
				rows: projects,
				renderRow: (p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/projects/$id",
						params: { id: p.id },
						className: "font-semibold hover:text-primary",
						children: p.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] text-muted-foreground font-mono",
						children: p.code || p.id
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-muted-foreground",
						children: p.manager
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums",
						children: fmtSAR(p.budget)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums",
						children: fmtSAR(p.spent)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums text-success font-semibold",
						children: fmtSAR(p.donations)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums",
						children: fmtNum(p.beneficiaryCount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 min-w-[140px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-2 flex-1 rounded-full bg-muted overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-primary",
								style: { width: `${p.progress}%` }
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs",
							children: [p.progress, "%"]
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(p.status),
						children: p.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getProjectActions(p, setStatusTarget, openEdit, setDeleteTarget) }) })
				] }),
				mobileCard: (p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/projects/$id",
					params: { id: p.id },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 hover:border-primary transition-colors",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-bold truncate",
										children: p.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										children: p.manager
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(p.status),
									children: p.status
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-2 flex-1 rounded-full bg-muted overflow-hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-full bg-gradient-to-l from-primary to-info",
										style: { width: `${p.progress}%` }
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-bold tabular-nums",
									children: [p.progress, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid grid-cols-3 gap-2 text-center text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded bg-muted/50 p-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "ميزانية"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold tabular-nums",
												children: fmtSAR(p.budget)
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded bg-success/10 p-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-success",
												children: "تبرعات"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold tabular-nums",
												children: fmtSAR(p.donations)
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded bg-warning/15 p-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-warning-foreground",
												children: "منصرف"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-bold tabular-nums",
												children: fmtSAR(p.spent)
											})
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 text-xs text-muted-foreground flex justify-between items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [fmtNum(p.beneficiaryCount), " مستفيد"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [!isReadOnly(p) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: (e) => {
											e.preventDefault();
											openEdit(p);
										},
										className: "text-primary",
										children: "تعديل"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: (e) => {
											e.preventDefault();
											setDeleteTarget(p.id);
										},
										className: "text-destructive",
										children: "حذف"
									})]
								})]
							})
						]
					})
				}, p.id)
			}),
			totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mt-3 px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: [
						"صفحة ",
						page,
						" من ",
						totalPages,
						" | ",
						total,
						" مشروع"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "px-3 py-1.5 text-xs rounded-lg border bg-background hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed min-h-[36px]",
						disabled: page <= 1,
						onClick: () => setPage((p) => Math.max(1, p - 1)),
						children: "السابق"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "px-3 py-1.5 text-xs rounded-lg border bg-background hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed min-h-[36px]",
						disabled: page >= totalPages,
						onClick: () => setPage((p) => Math.min(totalPages, p + 1)),
						children: "التالي"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: handleDelete,
				title: "حذف المشروع",
				message: "هل أنت متأكد من حذف هذا المشروع؟ لا يمكن حذف مشروع مرتبط بتبرعات أو مساعدات.",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!statusTarget,
				onClose: () => setStatusTarget(null),
				onConfirm: handleStatusConfirm,
				title: statusTarget ? getStatusTitle(statusTarget.action) : "",
				message: statusTarget ? `هل تريد ${getStatusVerb(statusTarget.action)} مشروع "${statusTarget.name}"؟` : "",
				confirmText: statusTarget ? getStatusConfirm(statusTarget.action) : "",
				cancelText: "إلغاء",
				variant: statusTarget?.action === "cancel" ? "destructive" : "default"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الحالة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: statusFilter,
							onChange: (e) => setStatusFilter(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مخطط" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "نشط" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "متوقف" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مكتمل" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ملغي" })
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "التصنيف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: categoryFilter,
							onChange: (e) => setCategoryFilter(e.target.value),
							children: PROJECT_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الفرع"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: branchFilter,
							onChange: (e) => setBranchFilter(e.target.value),
							children: PROJECT_BRANCHES.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: b }, b))
						})] })
					]
				})
			})
		]
	});
}
function getProjectActions(p, setStatusTarget, openEdit, setDeleteTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => showToast(`مشروع: ${p.name} · ${p.status}`, "info")
	}];
	if (p.status !== "مكتمل" && p.status !== "ملغي") actions.push({
		label: "تعديل",
		icon: Pencil,
		onClick: () => openEdit(p)
	});
	if (p.status === "مخطط" || p.status === "متوقف") actions.push({
		label: "تفعيل",
		icon: Play,
		onClick: () => setStatusTarget({
			id: p.id,
			name: p.name,
			action: "activate"
		})
	});
	if (p.status === "نشط") {
		actions.push({
			label: "إيقاف",
			icon: Pause,
			onClick: () => setStatusTarget({
				id: p.id,
				name: p.name,
				action: "pause"
			})
		});
		actions.push({
			label: "إكمال",
			icon: CircleCheckBig,
			onClick: () => setStatusTarget({
				id: p.id,
				name: p.name,
				action: "complete"
			})
		});
	}
	if (p.status !== "ملغي" && p.status !== "مكتمل") actions.push({
		label: "إلغاء",
		icon: CircleX,
		onClick: () => setStatusTarget({
			id: p.id,
			name: p.name,
			action: "cancel"
		}),
		variant: "destructive"
	});
	actions.push({
		label: "حذف",
		icon: Trash2,
		onClick: () => setDeleteTarget(p.id),
		variant: "destructive"
	});
	return actions;
}
function getStatusTitle(action) {
	return {
		activate: "تفعيل المشروع",
		pause: "إيقاف المشروع",
		complete: "إكمال المشروع",
		cancel: "إلغاء المشروع"
	}[action] || "تغيير الحالة";
}
function getStatusVerb(action) {
	return {
		activate: "تفعيل",
		pause: "إيقاف",
		complete: "إكمال",
		cancel: "إلغاء"
	}[action] || "تغيير";
}
function getStatusConfirm(action) {
	return {
		activate: "تفعيل",
		pause: "إيقاف",
		complete: "إكمال",
		cancel: "إلغاء"
	}[action] || "تأكيد";
}
//#endregion
export { Page as component };
