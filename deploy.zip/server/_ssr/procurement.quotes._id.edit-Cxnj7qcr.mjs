import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { Yt as Check, n as X, pn as Archive } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, P as statusTone, c as ConfirmDialog, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { t as getAuditEntries } from "./audit-DP6UgtXG.mjs";
import { a as getQuote, c as updateQuote, i as deleteQuote, n as acceptQuote, s as rejectQuote, t as QUOTE_STATUSES } from "./quotes-8hMRJcKl.mjs";
import { t as Route } from "./procurement.quotes._id.edit-BtuJe6Av.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.quotes._id.edit-Cxnj7qcr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditQuotePage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const detailQuery = useQuery({
		queryKey: ["quoteDetail", id],
		queryFn: () => getQuote(id)
	});
	const item = detailQuery.data?.item;
	const [supplier, setSupplier] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("");
	const [delivery, setDelivery] = (0, import_react.useState)("");
	const [warranty, setWarranty] = (0, import_react.useState)("");
	const [rating, setRating] = (0, import_react.useState)("0");
	const [validUntil, setValidUntil] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("بانتظار");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(null);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	if (item && !hydrated) {
		setSupplier(item.supplier);
		setPrice(String(item.price || 0));
		setDelivery(item.delivery || "");
		setWarranty(item.warranty || "");
		setRating(String(item.rating || 0));
		setValidUntil(item.validUntil || "");
		setStatus(item.status || "بانتظار");
		setNotes(item.notes || "");
		setHydrated(true);
	}
	const isReadOnly = !!item && (item.status === "مقبول" || item.status === "مرفوض");
	const handleSave = async () => {
		if (isReadOnly) {
			showToast("لا يمكن تعديل عرض مقبول أو مرفوض", "error");
			return;
		}
		const errs = [];
		if (!supplier.trim()) errs.push("اسم المورد مطلوب");
		if (!price || parseFloat(price) <= 0) errs.push("السعر يجب أن يكون أكبر من صفر");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			await updateQuote({
				id,
				supplier: supplier.trim(),
				price: parseFloat(price) || 0,
				delivery: delivery || void 0,
				warranty: warranty || void 0,
				rating: parseFloat(rating) || 0,
				validUntil: validUntil || void 0,
				status,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["quotes"] });
			queryClient.invalidateQueries({ queryKey: ["quoteDetail", id] });
			showToast("تم حفظ التعديلات", "success");
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const auditQuery = useQuery({
		queryKey: ["quoteAudit", id],
		queryFn: () => getAuditEntries({
			entityType: "عرض سعر",
			entityId: id,
			limit: 50
		}),
		enabled: !!item
	});
	const tabs = [
		{
			id: "basic",
			label: "بيانات العرض",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات عرض السعر",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المورد",
						required: true,
						error: errors[0],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: supplier,
							onChange: (e) => setSupplier(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "السعر",
						required: true,
						error: errors[1],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: price,
							onChange: (e) => setPrice(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "مدة التسليم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: delivery,
							onChange: (e) => setDelivery(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الضمان",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: warranty,
							onChange: (e) => setWarranty(e.target.value)
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "التقييم",
						hint: "من 1 إلى 5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							max: "5",
							step: "0.5",
							value: rating,
							onChange: (e) => setRating(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "صالح حتى",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: validUntil,
							onChange: (e) => setValidUntil(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحالة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: status,
							onChange: (e) => setStatus(e.target.value),
							children: QUOTE_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								children: s
							}, s))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value),
							rows: 3
						})
					})
				]
			})
		},
		{
			id: "summary",
			label: "ملخص",
			content: item ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ملخص العرض",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "المورد",
						value: item.supplier
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "السعر",
						value: fmtSAR(item.price)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الحالة",
						value: item.status,
						tone: item.status === "مقبول" ? "success" : item.status === "مرفوض" ? "destructive" : "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "التقييم",
						value: `${item.rating || 0} / 5`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "صالح حتى",
						value: item.validUntil || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "مدة التسليم",
						value: item.delivery || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الضمان",
						value: item.warranty || "—"
					})
				]
			}) : null
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			badge: auditQuery.data?.items.length,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "سجل العمليات",
				children: auditQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "جاري التحميل..."
				}) : (auditQuery.data?.items ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "لا توجد عمليات مسجلة على هذا العرض."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: (auditQuery.data?.items ?? []).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border bg-card px-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-foreground",
									children: e.action
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground font-mono",
									children: e.timestamp?.slice(0, 16).replace("T", " ")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground mt-0.5",
								children: e.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-muted-foreground mt-0.5",
								children: ["المستخدم: ", e.userName || "—"]
							})
						]
					}, e.id))
				})
			})
		}
	];
	const acceptMut = useMutation({
		mutationFn: () => acceptQuote({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["quotes"] });
			queryClient.invalidateQueries({ queryKey: ["quoteDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["quoteAudit", id] });
			showToast("تم قبول العرض", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const rejectMut = useMutation({
		mutationFn: () => rejectQuote({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["quotes"] });
			queryClient.invalidateQueries({ queryKey: ["quoteDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["quoteAudit", id] });
			showToast("تم رفض العرض", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMut = useMutation({
		mutationFn: () => deleteQuote({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["quotes"] });
			showToast("تم حذف العرض", "success");
			navigate({ to: "/procurement/quotes" });
		},
		onError: (err) => showToast(err.message, "error")
	});
	if (detailQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "عروض الأسعار",
		breadcrumb: ["المشتريات", "عروض الأسعار"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "عروض الأسعار",
		breadcrumb: ["المشتريات", "عروض الأسعار"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-center py-12 text-muted-foreground",
			children: "العرض غير موجود"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "عروض الأسعار",
		breadcrumb: [
			"المشتريات",
			"عروض الأسعار",
			"تعديل"
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
				breadcrumb: [
					{
						label: "المشتريات",
						to: "/procurement/requests"
					},
					{
						label: "عروض الأسعار",
						to: "/procurement/quotes"
					},
					{ label: item.supplier }
				],
				title: item.supplier,
				subtitle: `${fmtSAR(item.price)} · ${item.delivery || ""}`,
				draftNumber: item.id,
				status: {
					label: item.status,
					tone: statusTone(item.status)
				},
				isReadOnly,
				readonlyReason: isReadOnly ? "هذا العرض مقبول أو مرفوض. لا يمكن تعديله بعد الآن للحفاظ على سلامة سجلات المنافسة." : void 0,
				tabs,
				defaultTab: "basic",
				loading: saving,
				validationErrors: errors,
				primaryLabel: "حفظ التعديلات",
				secondaryLabel: "حفظ وإغلاق",
				showSecondary: false,
				extraActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [item.status === "بانتظار" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("accept"),
					className: "inline-flex items-center gap-1.5 rounded-lg border border-success/40 bg-success/10 px-3 py-2 text-sm font-medium text-success hover:bg-success/20 transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 15 }), " قبول"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("reject"),
					className: "inline-flex items-center gap-1.5 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/20 transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 15 }), " رفض"]
				})] }), item.status === "بانتظار" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("delete"),
					className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { size: 15 }), " حذف"]
				})] }),
				onPrimary: handleSave,
				onCancel: () => navigate({ to: "/procurement/quotes" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "accept",
				onClose: () => setConfirmAction(null),
				onConfirm: () => acceptMut.mutate(),
				title: "قبول عرض السعر",
				message: `هل تريد قبول عرض "${item.supplier}" بسعر ${fmtSAR(item.price)}؟ سيتم ترميزه كعرض فائز ولن تستطيع تعديله بعد الآن.`,
				confirmText: "قبول العرض",
				cancelText: "إلغاء",
				loading: acceptMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "reject",
				onClose: () => setConfirmAction(null),
				onConfirm: () => rejectMut.mutate(),
				title: "رفض عرض السعر",
				message: `هل تريد رفض عرض "${item.supplier}"؟`,
				confirmText: "رفض",
				cancelText: "تراجع",
				variant: "destructive",
				loading: rejectMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "delete",
				onClose: () => setConfirmAction(null),
				onConfirm: () => deleteMut.mutate(),
				title: "حذف عرض السعر",
				message: `هل تريد حذف عرض "${item.supplier}"؟ هذا الإجراء لا يمكن التراجع عنه.`,
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive",
				loading: deleteMut.isPending
			})
		]
	});
}
//#endregion
export { EditQuotePage as component };
