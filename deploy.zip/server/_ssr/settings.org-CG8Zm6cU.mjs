import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Lt as Coins, en as Building2 } from "../_libs/lucide-react.mjs";
import { N as showToast, S as MobilePageHeader, a as Btn, i as Badge, n as AppShell, s as Card } from "./actions-qTEe1ygX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings.org-CG8Zm6cU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const fields = [
		{
			l: "اسم الجمعية",
			k: "name"
		},
		{
			l: "رقم التسجيل بالمركز الوطني",
			k: "regNo"
		},
		{
			l: "الرقم الضريبي",
			k: "taxNo"
		},
		{
			l: "البريد الإلكتروني",
			k: "email"
		},
		{
			l: "الجوال",
			k: "phone"
		},
		{
			l: "المدير التنفيذي",
			k: "ceo"
		},
		{
			l: "السنة المالية",
			k: "fiscalYear"
		},
		{
			l: "العملة الأساسية",
			k: "currency"
		}
	];
	const [form, setForm] = (0, import_react.useState)({
		name: "جمعية البر الخيرية",
		regNo: "1234",
		taxNo: "300123456700003",
		email: "info@albir.org.sa",
		phone: "920001234",
		ceo: "د. عبدالله بن محمد السبيعي",
		fiscalYear: "1446هـ (هجري)",
		currency: "ر.س - الريال السعودي"
	});
	function handleSave() {
		showToast("تم حفظ التغييرات بنجاح", "success");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"الإعدادات",
			"إعدادات الجمعية"
		],
		title: "إعدادات الجمعية",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			variant: "primary",
			className: "hidden lg:inline-flex",
			onClick: handleSave,
			children: "حفظ التغييرات"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, { title: "إعدادات الجمعية" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-bold mb-4",
					children: "المعلومات الأساسية"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: fields.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: f.l
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm min-h-[44px]",
						value: form[f.k],
						onChange: (e) => setForm({
							...form,
							[f.k]: e.target.value
						})
					})] }, f.k))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-6 mt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-bold mb-3",
						children: "القدرات المُفعّلة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							"متعدد الفروع",
							"متعدد العملات",
							"متعدد المستأجرين",
							"REST API",
							"تطبيق جوال",
							"Webhooks",
							"فاتورة إلكترونية",
							"استضافة داخل المملكة"
						].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							tone: "success",
							children: ["✓ ", c]
						}, c))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2 mt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
							variant: "outline",
							onClick: () => showToast("تم إضافة فرع جديد (تجريبي)", "success"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { size: 14 }), " إضافة فرع"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
							variant: "outline",
							onClick: () => showToast("تم إضافة عملة جديدة (تجريبي)", "success"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Coins, { size: 14 }), " إضافة عملة"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden fixed bottom-16 right-0 left-0 z-20 border-t bg-surface/95 backdrop-blur px-4 py-3 safe-area-bottom shadow-[0_-2px_6px_rgba(0,0,0,0.06)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "w-full rounded-xl bg-primary text-primary-foreground py-3.5 font-bold text-sm min-h-[48px]",
					onClick: handleSave,
					children: "حفظ التغييرات"
				})
			})
		]
	});
};
//#endregion
export { SplitComponent as component };
