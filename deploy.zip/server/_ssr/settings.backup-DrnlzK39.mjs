import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Ft as DatabaseBackup, I as RotateCcw, Pt as Download, Ut as CircleCheck, j as Settings, v as Trash2 } from "../_libs/lucide-react.mjs";
import { N as showToast, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, h as EntityFormDrawer, i as Badge, j as Td, n as AppShell, s as Card, t as ActionMenu, y as MobileActionRow } from "./actions-qTEe1ygX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings.backup-DrnlzK39.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [backups, setBackups] = (0, import_react.useState)([
		{
			d: "1446/10/12 03:00",
			size: "1.84 GB",
			type: "تلقائي يومي",
			status: "ناجح"
		},
		{
			d: "1446/10/11 03:00",
			size: "1.82 GB",
			type: "تلقائي يومي",
			status: "ناجح"
		},
		{
			d: "1446/10/10 03:00",
			size: "1.80 GB",
			type: "تلقائي يومي",
			status: "ناجح"
		},
		{
			d: "1446/10/05 14:20",
			size: "1.79 GB",
			type: "يدوي",
			status: "ناجح"
		},
		{
			d: "1446/10/01 03:00",
			size: "1.74 GB",
			type: "أرشيف شهري",
			status: "ناجح"
		}
	]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [confirmOpen, setConfirmOpen] = (0, import_react.useState)(false);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(() => {});
	const [restoreOpen, setRestoreOpen] = (0, import_react.useState)(false);
	const [restoreTarget, setRestoreTarget] = (0, import_react.useState)("");
	const [schedFreq, setSchedFreq] = (0, import_react.useState)("يومي");
	const [schedTime, setSchedTime] = (0, import_react.useState)("03:00");
	const [schedRetain, setSchedRetain] = (0, import_react.useState)("30");
	function handleCreateBackup() {
		setLoading(true);
		setTimeout(() => {
			const now = /* @__PURE__ */ new Date();
			setBackups([{
				d: `${`${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, "0")}/${String(now.getDate()).padStart(2, "0")}`} ${`${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`}`,
				size: "1.85 GB",
				type: "يدوي",
				status: "ناجح"
			}, ...backups]);
			setLoading(false);
			showToast("تم إنشاء النسخة الاحتياطية بنجاح", "success");
		}, 1500);
	}
	function handleRestore(b) {
		setRestoreTarget(b.d);
		setRestoreOpen(true);
		setConfirmAction(() => () => {
			showToast(`تمت استعادة النسخة الاحتياطية ${b.d} بنجاح`, "success");
		});
	}
	function handleDownload(b) {
		showToast(`بدء تحميل النسخة الاحتياطية ${b.d} (${b.size})`, "success");
	}
	function handleDelete(i) {
		setConfirmAction(() => () => {
			setBackups(backups.filter((_, idx) => idx !== i));
			showToast("تم حذف النسخة الاحتياطية", "success");
		});
		setConfirmOpen(true);
	}
	function handleSaveSettings() {
		showToast("تم حفظ إعدادات النسخ الاحتياطي", "success");
		setSettingsOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"الإعدادات",
			"النسخ الاحتياطي"
		],
		title: "النسخ الاحتياطي والاستعادة",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => setSettingsOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { size: 15 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden md:inline",
					children: "الإعدادات"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: handleCreateBackup,
				disabled: loading,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DatabaseBackup, {
					size: 15,
					className: loading ? "animate-pulse" : ""
				}), loading ? "جارٍ الإنشاء..." : "نسخة احتياطية الآن"]
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: "آخر نسخة احتياطية"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xl font-extrabold mt-1",
								children: "قبل 6 ساعات"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								tone: "success",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
									size: 11,
									className: "inline ms-1"
								}), "ناجحة"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: "حجم البيانات"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xl font-extrabold mt-1",
								children: "1.84 GB"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: "مشفّرة AES-256"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: "موقع التخزين"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xl font-extrabold mt-1",
								children: "السعودية"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "info",
								children: "3 نسخ جغرافية"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "النسخ الاحتياطي",
				count: `${backups.length} نسخة`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MobileActionRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => setSettingsOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { size: 15 }), " إعدادات"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: handleCreateBackup,
				disabled: loading,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DatabaseBackup, {
					size: 15,
					className: loading ? "animate-pulse" : ""
				}), loading ? "جارٍ..." : "إنشاء نسخة"]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 lg:mt-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"التاريخ والوقت",
					"الحجم",
					"النوع",
					"الحالة",
					""
				],
				rows: backups,
				renderRow: (b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: b.d
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums",
						children: b.size
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: b.type }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "success",
						children: b.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
						{
							label: "استعادة",
							icon: RotateCcw,
							onClick: () => handleRestore(b)
						},
						{
							label: "تحميل",
							icon: Download,
							onClick: () => handleDownload(b)
						},
						{
							label: "حذف",
							icon: Trash2,
							variant: "destructive",
							onClick: () => handleDelete(i)
						}
					] }) })
				] }),
				mobileCard: (b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "success",
								children: b.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "info",
								children: b.type
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-xs",
							children: b.d
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "tabular-nums text-sm font-semibold mt-1",
							children: b.size
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 mt-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
									variant: "primary",
									className: "flex-1 text-xs",
									onClick: () => handleDownload(b),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 12 }), " تحميل"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
									variant: "outline",
									className: "flex-1 text-xs",
									onClick: () => handleRestore(b),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 12 }), " استعادة"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									variant: "outline",
									className: "flex-1 text-xs",
									onClick: () => handleDelete(i),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 12 })
								})
							]
						})
					]
				}, i)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: settingsOpen,
				onClose: () => setSettingsOpen(false),
				title: "إعدادات النسخ الاحتياطي",
				onSave: handleSaveSettings,
				saveText: "حفظ الإعدادات",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "التكرار"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: schedFreq,
						onChange: (e) => setSchedFreq(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "يومي" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "أسبوعي" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "شهري" })
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الوقت"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "time",
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: schedTime,
						onChange: (e) => setSchedTime(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الاحتفاظ بـ (عدد النسخ)"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: schedRetain,
						onChange: (e) => setSchedRetain(e.target.value)
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmOpen,
				onClose: () => setConfirmOpen(false),
				onConfirm: () => {
					confirmAction();
					setConfirmOpen(false);
				},
				title: "تأكيد حذف النسخة الاحتياطية",
				message: "هل أنت متأكد من حذف هذه النسخة الاحتياطية؟",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: restoreOpen,
				onClose: () => setRestoreOpen(false),
				onConfirm: () => {
					confirmAction();
					setRestoreOpen(false);
				},
				title: "تأكيد استعادة النسخة الاحتياطية",
				message: `سيتم استعادة البيانات من النسخة "${restoreTarget}". هل أنت متأكد؟`,
				confirmText: "استعادة",
				cancelText: "إلغاء",
				variant: "default"
			})
		]
	});
};
//#endregion
export { SplitComponent as component };
