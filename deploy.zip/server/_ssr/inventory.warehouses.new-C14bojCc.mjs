import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { r as createWarehouse, t as WAREHOUSE_STATUSES } from "./warehouses-sU_fp7nA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.warehouses.new-C14bojCc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NewWarehousePage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const [name, setName] = (0, import_react.useState)("");
	const [location, setLocation] = (0, import_react.useState)("");
	const [manager, setManager] = (0, import_react.useState)("");
	const [capacity, setCapacity] = (0, import_react.useState)("0");
	const [occupancy, setOccupancy] = (0, import_react.useState)("0");
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const handleSave = async (andClose) => {
		const errs = [];
		if (!name.trim()) errs.push("اسم المستودع مطلوب");
		if (!location.trim()) errs.push("موقع المستودع مطلوب");
		const cap = parseFloat(capacity) || 0;
		const occ = parseFloat(occupancy) || 0;
		if (cap < 0) errs.push("السعة يجب ألا تكون سالبة");
		if (occ < 0) errs.push("الإشغال يجب ألا يكون سالبًا");
		if (cap > 0 && occ > cap) errs.push("الإشغال لا يمكن أن يتجاوز السعة");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			const created = await createWarehouse({
				name: name.trim(),
				location: location.trim(),
				manager: manager || void 0,
				capacity: cap,
				occupancy: occ,
				status,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["warehouses"] });
			showToast(`تم إنشاء المستودع ${created.name}`, "success");
			if (andClose) navigate({ to: "/inventory/warehouses" });
			else navigate({
				to: "/inventory/warehouses/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const tabs = [{
		id: "basic",
		label: "بيانات المستودع",
		content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
			title: "بيانات المستودع",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "اسم المستودع",
					required: true,
					error: errors[0],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "مثال: المستودع الرئيسي"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الموقع",
					required: true,
					error: errors[1],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: location,
						onChange: (e) => setLocation(e.target.value),
						placeholder: "المدينة، الحي، الشارع"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "مدير المستودع",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: manager,
						onChange: (e) => setManager(e.target.value),
						placeholder: "اسم الشخص المسؤول"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "السعة",
					hint: "بالكيلو/قطعة",
					error: errors[2] || errors[4],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						min: "0",
						step: "0.01",
						value: capacity,
						onChange: (e) => setCapacity(e.target.value),
						dir: "ltr"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الإشغال الحالي",
					error: errors[3] || errors[4],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						min: "0",
						step: "0.01",
						value: occupancy,
						onChange: (e) => setOccupancy(e.target.value),
						dir: "ltr"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الحالة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
						value: status,
						onChange: (e) => setStatus(e.target.value),
						children: WAREHOUSE_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 3
					})
				})
			]
		})
	}];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المستودعات",
		breadcrumb: [
			"المخزون",
			"المستودعات",
			"جديد"
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المخزون",
					to: "/inventory/items"
				},
				{
					label: "المستودعات",
					to: "/inventory/warehouses"
				},
				{ label: "مستودع جديد" }
			],
			title: "مستودع جديد",
			subtitle: name || "أدخل بيانات المستودع",
			draftNumber: "مسودة جديدة",
			status: {
				label: status,
				tone: status === "نشط" ? "success" : "muted"
			},
			tabs,
			defaultTab: "basic",
			loading: saving,
			validationErrors: errors,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/inventory/warehouses" })
		})
	});
}
//#endregion
export { NewWarehousePage as component };
