//#region node_modules/.nitro/vite/services/ssr/assets/donors-BTleOe7U.js
var API_BASE = "/api/donors";
async function getDonors(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.type && filters.type !== "الكل") params.set("type", filters.type);
	if (filters.tag && filters.tag !== "الكل") params.set("tag", filters.tag);
	if (filters.city && filters.city !== "الكل") params.set("city", filters.city);
	if (filters.page) params.set("page", String(filters.page));
	if (filters.limit) params.set("limit", String(filters.limit));
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب المتبرعين");
	return res.json();
}
async function getDonor(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات المتبرع");
	return (await res.json()).item;
}
async function createDonor(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة المتبرع");
	}
	return (await res.json()).item;
}
async function updateDonor(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث المتبرع");
	}
	return (await res.json()).item;
}
async function deleteDonor(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	if (!(await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" })).ok) throw new Error("فشل في حذف المتبرع");
}
//#endregion
export { updateDonor as a, getDonors as i, deleteDonor as n, getDonor as r, createDonor as t };
