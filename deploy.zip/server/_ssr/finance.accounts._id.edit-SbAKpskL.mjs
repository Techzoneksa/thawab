import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, y as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, P as statusTone, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, o as FormSegmented, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { t as getAuditEntries } from "./audit-DP6UgtXG.mjs";
import { a as deactivateAccount, c as getAccounts, l as updateAccount, n as ACCOUNT_TYPES, r as activateAccount, s as getAccount, t as ACCOUNT_STATUSES } from "./accounts-i45ITZyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.accounts._id.edit-SbAKpskL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditAccountPage() {
	const { id } = useParams({ from: "/finance/accounts/$id/edit" });
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: accountData, isLoading } = useQuery({
		queryKey: ["account", id],
		queryFn: () => getAccount(id),
		enabled: !!id
	});
	const { data: allData } = useQuery({
		queryKey: ["accounts-all"],
		queryFn: () => getAccounts({ limit: 1e3 })
	});
	const allAccounts = allData?.items || [];
	const account = accountData?.item;
	const lineCount = accountData?.lineCount || 0;
	const childCount = accountData?.childCount || 0;
	const hasTransactions = accountData?.hasTransactions || false;
	const [code, setCode] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("تفصيلي");
	const [parentId, setParentId] = (0, import_react.useState)("");
	const [currency, setCurrency] = (0, import_react.useState)("SAR");
	const [postable, setPostable] = (0, import_react.useState)(true);
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [description, setDescription] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (account) {
			setCode(account.code);
			setName(account.name);
			setType(account.type);
			setParentId(account.parentId || "");
			setCurrency(account.currency);
			setPostable(account.postable);
			setStatus(account.status);
			setDescription(account.description || "");
			setNotes(account.notes || "");
		}
	}, [account]);
	const isReadOnly = hasTransactions;
	const readOnlyReason = hasTransactions ? "لا يمكن تعديل هذا الحساب لوجود قيود مرحلة عليه. يمكن إيقافه أو تفعيله فقط." : "";
	const validate = () => {
		const e = {};
		if (!name.trim()) e.name = "اسم الحساب مطلوب";
		setErrors(e);
		return Object.keys(e).length === 0;
	};
	const updateMutation = useMutation({
		mutationFn: updateAccount,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["accounts"] });
			queryClient.invalidateQueries({ queryKey: ["account", id] });
			showToast("تم تحديث الحساب بنجاح", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const statusMutation = useMutation({
		mutationFn: (action) => action === "deactivate" ? deactivateAccount({
			id,
			userId: user?.id,
			userName: user?.name
		}) : activateAccount({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: (_, action) => {
			queryClient.invalidateQueries({ queryKey: ["account", id] });
			queryClient.invalidateQueries({ queryKey: ["accounts"] });
			showToast(action === "deactivate" ? "تم إيقاف الحساب" : "تم تفعيل الحساب", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleSave = async (andClose) => {
		if (isReadOnly) return;
		if (!validate()) {
			showToast("يرجى تصحيح الأخطاء قبل الحفظ", "error");
			return;
		}
		setSaving(true);
		try {
			await updateMutation.mutateAsync({
				id,
				name: name.trim(),
				type,
				parentId: parentId || null,
				currency,
				postable,
				status,
				description,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			if (andClose) navigate({ to: "/finance/accounts" });
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const { data: auditData } = useQuery({
		queryKey: [
			"audit",
			"account",
			id
		],
		queryFn: () => getAuditEntries({
			entityType: "account",
			entityId: id,
			limit: 100
		}),
		enabled: !!id
	});
	const auditEntries = auditData?.items || [];
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "دليل الحسابات",
		breadcrumb: [
			"المالية",
			"دليل الحسابات",
			"تحميل..."
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!account) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "دليل الحسابات",
		breadcrumb: ["المالية", "دليل الحسابات"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center py-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-base font-bold mb-2",
				children: "الحساب غير موجود"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => navigate({ to: "/finance/accounts" }),
				className: "text-primary hover:underline text-sm",
				children: "العودة إلى دليل الحسابات"
			})]
		})
	});
	const parent = parentId ? allAccounts.find((a) => a.id === parentId) : null;
	const tabs = [
		{
			id: "basic",
			label: "البيانات الأساسية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "تعريف الحساب",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "رقم الحساب",
						hint: "لا يمكن تعديل رقم حساب له حركات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: code,
							disabled: true,
							dir: "ltr",
							className: "font-mono"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم الحساب",
						required: true,
						error: errors.name,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value),
							invalid: !!errors.name,
							disabled: isReadOnly
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "نوع الحساب",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: type,
							onChange: (e) => {
								const v = e.target.value;
								setType(v);
								if (v === "رئيسي") setPostable(false);
								else setPostable(true);
							},
							disabled: isReadOnly,
							children: ACCOUNT_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: t,
								children: t
							}, t))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحساب الأب",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: parentId,
							onChange: (e) => setParentId(e.target.value),
							disabled: isReadOnly || type === "رئيسي",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— (بدون أب)"
							}), allAccounts.filter((a) => a.type === "رئيسي" && a.id !== id).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: a.id,
								children: [
									a.code,
									" — ",
									a.name
								]
							}, a.id))]
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الوصف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: description,
							onChange: (e) => setDescription(e.target.value),
							rows: 2,
							disabled: isReadOnly
						})
					})
				]
			})
		},
		{
			id: "structure",
			label: "الهيكل المحاسبي",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "الهيكل",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "المستوى",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: String(account.level),
						disabled: true,
						dir: "ltr",
						className: "font-mono"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "عدد الحسابات الفرعية",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: fmtNum(childCount),
						disabled: true,
						dir: "ltr",
						className: "font-mono"
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الحساب الأب",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: parent ? `${parent.code} — ${parent.name}` : "— (بدون أب)",
						disabled: true
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "إجمالي القيود المرحلة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: fmtNum(lineCount),
						disabled: true,
						dir: "ltr",
						className: "font-mono"
					})
				})] })]
			})
		},
		{
			id: "posting",
			label: "إعدادات الترحيل",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ضبط الترحيل",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "قابل للترحيل",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSegmented, {
							value: postable ? "yes" : "no",
							onChange: (v) => setPostable(v === "yes"),
							disabled: isReadOnly || type === "رئيسي",
							options: [{
								value: "yes",
								label: "نعم — يقبل قيود يومية"
							}, {
								value: "no",
								label: "لا — حساب رئيسي فقط"
							}]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "العملة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: currency,
							onChange: (e) => setCurrency(e.target.value),
							disabled: isReadOnly,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "SAR",
									children: "ر.س — ريال سعودي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "USD",
									children: "$ — دولار أمريكي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "EUR",
									children: "€ — يورو"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "EGP",
									children: "ج.م — جنيه مصري"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحالة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: status,
							onChange: (e) => setStatus(e.target.value),
							disabled: isReadOnly,
							children: ACCOUNT_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								children: s
							}, s))
						})
					})] }),
					!isReadOnly && status === "نشط" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => statusMutation.mutate("deactivate"),
						disabled: statusMutation.isPending,
						className: "inline-flex items-center justify-center gap-1.5 rounded-lg border border-warning/30 bg-warning/10 text-warning-foreground px-3 py-2 text-sm font-medium hover:bg-warning/20 transition-colors min-h-[40px]",
						children: "إيقاف الحساب"
					}),
					!isReadOnly && status === "موقوف" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => statusMutation.mutate("activate"),
						disabled: statusMutation.isPending,
						className: "inline-flex items-center justify-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium hover:bg-muted transition-colors min-h-[40px]",
						children: "تفعيل الحساب"
					})
				]
			})
		},
		{
			id: "balance",
			label: "الأرصدة والاستخدامات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "الرصيد الحالي والإحصاءات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "الرصيد الحالي",
							value: fmtSAR(account.balance),
							tone: account.balance >= 0 ? "success" : "warning"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "العملة",
							value: account.currency
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "عدد القيود المرحلة",
							value: fmtNum(lineCount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "عدد الحسابات الفرعية",
							value: fmtNum(childCount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ الإنشاء",
							value: account.createdAt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "آخر تحديث",
							value: account.updatedAt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "أنشأ بواسطة",
							value: account.createdBy || "—"
						})
					]
				})
			})
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			badge: auditEntries.length || void 0,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "سجل التعديلات",
				children: auditEntries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "لا توجد تعديلات مسجلة بعد."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: auditEntries.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border bg-background p-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2 mb-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: e.action
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: e.timestamp
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: e.userName
							}),
							e.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs mt-1",
								children: e.description
							})
						]
					}, e.id))
				})
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "دليل الحسابات",
		breadcrumb: [
			"المالية",
			"دليل الحسابات",
			account.code
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المالية",
					to: "/finance/accounts"
				},
				{
					label: "دليل الحسابات",
					to: "/finance/accounts"
				},
				{ label: account.code }
			],
			title: `${account.code} — ${account.name}`,
			subtitle: `${type} · المستوى ${account.level}${parent ? ` · تحت ${parent.code}` : ""}`,
			draftNumber: account.code,
			status: {
				label: account.status,
				tone: statusTone(account.status)
			},
			isReadOnly,
			readonlyReason: readOnlyReason,
			tabs,
			defaultTab: "basic",
			loading: saving || updateMutation.isPending,
			primaryLabel: isReadOnly ? "غير قابل للتعديل" : "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: !isReadOnly,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/finance/accounts" })
		})
	});
}
//#endregion
export { EditAccountPage as component };
