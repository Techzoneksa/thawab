//#region node_modules/.nitro/vite/services/ssr/assets/budgets-DCUxNMYq.js
var API_BASE = "/api/finance/budgets";
var BUDGET_STATUSES = [
	"مسودة",
	"معتمد",
	"مقفل",
	"ملغى"
];
async function getBudgets(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.year && filters.year !== "الكل") params.set("year", filters.year);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب الموازنات");
	return res.json();
}
async function getBudget(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات الموازنة");
	return res.json();
}
async function createBudget(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة الموازنة");
	}
	return (await res.json()).item;
}
async function updateBudget(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث الموازنة");
	}
	return (await res.json()).item;
}
async function deleteBudget(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف الموازنة");
	}
}
async function approveBudget(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "approve"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في اعتماد الموازنة");
	}
	return (await res.json()).item;
}
async function lockBudget(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "lock"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في قفل الموازنة");
	}
	return (await res.json()).item;
}
async function unlockBudget(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "unlock"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في فتح قفل الموازنة");
	}
	return (await res.json()).item;
}
//#endregion
export { getBudget as a, unlockBudget as c, deleteBudget as i, updateBudget as l, approveBudget as n, getBudgets as o, createBudget as r, lockBudget as s, BUDGET_STATUSES as t };
