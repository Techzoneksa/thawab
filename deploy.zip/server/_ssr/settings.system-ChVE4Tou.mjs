import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { A as ShieldCheck, St as Globe, r as Wrench } from "../_libs/lucide-react.mjs";
import { N as showToast, S as MobilePageHeader, a as Btn, c as ConfirmDialog, i as Badge, n as AppShell, s as Card } from "./actions-qTEe1ygX.mjs";
import { v as TENANTS } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings.system-ChVE4Tou.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [maintenanceMode, setMaintenanceMode] = (0, import_react.useState)(false);
	const [confirmOpen, setConfirmOpen] = (0, import_react.useState)(false);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(() => {});
	function handleSave() {
		showToast("تم حفظ الإعدادات بنجاح", "success");
	}
	function handleToggleMaintenance() {
		setConfirmAction(() => () => {
			setMaintenanceMode(!maintenanceMode);
			showToast(`تم ${!maintenanceMode ? "تفعيل" : "إلغاء"} وضع الصيانة`, "success");
		});
		setConfirmOpen(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"الإعدادات",
			"إعدادات النظام"
		],
		title: "إعدادات النظام العامة",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
			variant: "primary",
			onClick: handleSave,
			children: "حفظ الإعدادات"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, { title: "إعدادات النظام العامة" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "font-bold mb-3 inline-flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, {
								size: 16,
								className: "text-primary"
							}), "البنية متعددة المستأجرين"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground mb-3",
							children: "نظام خاص بإدارة الجمعية مع عزل كامل للبيانات لكل فرع."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: TENANTS.map((t, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between rounded-lg border p-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: i === 0 ? "primary" : "muted",
									children: i === 0 ? "المستأجر الحالي" : "نشط"
								})]
							}, t))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "font-bold mb-3 inline-flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
								size: 16,
								className: "text-success"
							}), "الأمان والامتثال"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2 text-sm",
							children: [
								"استضافة سحابية داخل المملكة العربية السعودية (Riyadh Region)",
								"تشفير البيانات أثناء النقل (TLS 1.3) وأثناء التخزين (AES-256)",
								"متوافق مع متطلبات الهيئة الوطنية للأمن السيبراني",
								"متوافق مع نظام حماية البيانات الشخصية (PDPL)",
								"متوافق مع متطلبات المركز الوطني لتنمية القطاع غير الربحي",
								"تكامل مع فاتورة (الهيئة العامة للزكاة والضريبة والجمارك)"
							].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-success mt-0.5",
									children: "✓"
								}), t]
							}, t))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 pt-4 border-t",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, {
										size: 16,
										className: "text-warning"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-semibold",
										children: "وضع الصيانة"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: handleToggleMaintenance,
									className: `relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${maintenanceMode ? "bg-destructive" : "bg-muted"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `inline-block h-5 w-5 transform rounded-full bg-white transition-transform shadow-sm ${maintenanceMode ? "translate-x-[22px]" : "translate-x-[2px]"}` })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground mt-2",
								children: maintenanceMode ? "النظام في وضع الصيانة حالياً" : "النظام يعمل بشكل طبيعي"
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden fixed bottom-16 right-0 left-0 z-20 border-t bg-surface/95 backdrop-blur px-4 py-3 safe-area-bottom shadow-[0_-2px_6px_rgba(0,0,0,0.06)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "w-full rounded-xl bg-primary text-primary-foreground py-3.5 font-bold text-sm min-h-[48px]",
					onClick: handleSave,
					children: "حفظ الإعدادات"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmOpen,
				onClose: () => setConfirmOpen(false),
				onConfirm: () => {
					confirmAction();
					setConfirmOpen(false);
				},
				title: maintenanceMode ? "إلغاء وضع الصيانة" : "تفعيل وضع الصيانة",
				message: maintenanceMode ? "هل تريد إلغاء وضع الصيانة والعودة للتشغيل العادي؟" : "سيتم تعطيل وصول المستخدمين للنظام. هل أنت متأكد؟",
				confirmText: maintenanceMode ? "إلغاء الصيانة" : "تفعيل الصيانة",
				cancelText: "إلغاء",
				variant: maintenanceMode ? "default" : "destructive"
			})
		]
	});
};
//#endregion
export { SplitComponent as component };
