import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { $ as PackageCheck, B as Printer, Ht as CircleX, P as Search, U as Plus, Wt as CircleCheckBig, jt as Eye, v as Trash2 } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, E as PrintButton, F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { s as getSuppliers } from "./suppliers-CkCPjZYa.mjs";
import { a as deletePurchaseOrder, c as receivePurchaseOrder, n as cancelPurchaseOrder, r as closePurchaseOrder, s as getPurchaseOrders, t as approvePurchaseOrder } from "./purchase-orders-DLaoDtmH.mjs";
import { c as getPurchaseRequests } from "./purchase-requests-CdC7mUrc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.orders-CTxKy8tD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const [receiveTarget, setReceiveTarget] = (0, import_react.useState)(null);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [actionTarget, setActionTarget] = (0, import_react.useState)(null);
	const [receiveLines, setReceiveLines] = (0, import_react.useState)({});
	const { data, isLoading, error } = useQuery({
		queryKey: ["purchaseOrders", { search: searchQuery }],
		queryFn: () => getPurchaseOrders({ search: searchQuery })
	});
	const { data: suppliersData } = useQuery({
		queryKey: ["suppliers-all"],
		queryFn: () => getSuppliers({})
	});
	const { data: requestsData } = useQuery({
		queryKey: ["purchaseRequests-approved"],
		queryFn: () => getPurchaseRequests({ status: "معتمد" })
	});
	const detailQuery = useQuery({
		queryKey: ["purchaseOrderDetail", detailId],
		queryFn: async () => detailId ? await fetch(`/api/procurement/orders?id=${detailId}`).then((r) => r.json()) : null,
		enabled: !!detailId
	});
	const approveMutation = useMutation({
		mutationFn: approvePurchaseOrder,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			showToast("تم اعتماد أمر الشراء", "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const cancelMutation = useMutation({
		mutationFn: cancelPurchaseOrder,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			showToast("تم إلغاء أمر الشراء", "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const closeMutation = useMutation({
		mutationFn: closePurchaseOrder,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			showToast("تم إغلاق أمر الشراء", "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const receiveMutation = useMutation({
		mutationFn: receivePurchaseOrder,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseOrderDetail"] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			showToast("تم تسجيل الاستلام وتحديث المخزون", "success");
			setReceiveTarget(null);
			setReceiveLines({});
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deletePurchaseOrder,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			showToast("تم حذف أمر الشراء", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => {
		navigate({ to: "/procurement/orders/new" });
	};
	const openReceive = (o) => {
		setReceiveTarget(o);
		setReceiveLines({});
	};
	const handleReceive = () => {
		if (!receiveTarget || !detailQuery.data?.lines) return;
		const receipts = detailQuery.data.lines.filter((l) => {
			return parseFloat(receiveLines[l.id] || "0") > 0;
		}).map((l) => ({
			lineId: l.id,
			receivedQty: parseFloat(receiveLines[l.id] || "0")
		}));
		if (receipts.length === 0) return showToast("يرجى إدخال كمية واحدة على الأقل للاستلام", "error");
		receiveMutation.mutate({
			id: receiveTarget.id,
			receipts,
			userId: user?.id,
			userName: user?.name
		});
	};
	const items = data?.items || [];
	const total = data?.total || 0;
	const stats = {
		draft: items.filter((o) => o.status === "مسودة").length,
		approved: items.filter((o) => o.status === "معتمد").length,
		partial: items.filter((o) => o.status === "تم الاستلام جزئيًا").length,
		received: items.filter((o) => o.status === "تم الاستلام").length,
		closed: items.filter((o) => o.status === "مغلق").length,
		cancelled: items.filter((o) => o.status === "ملغي").length,
		totalValue: items.reduce((s, o) => s + (o.total || 0), 0),
		total
	};
	const suppliers = suppliersData?.items || [];
	requestsData?.items;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المشتريات",
			"أوامر الشراء"
		],
		title: "أوامر الشراء",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: items.map((o) => ({
					id: o.id,
					supplierId: o.supplierId || "",
					subject: o.subject,
					date: o.date,
					deliveryDate: o.deliveryDate,
					total: o.total,
					receivedAmount: o.receivedAmount,
					status: o.status,
					notes: o.notes
				})),
				filename: "purchase-orders.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, { label: "طباعة" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: openAdd,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "إنشاء أمر شراء"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "إجمالي الأوامر"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold tabular-nums",
							children: fmtSAR(stats.total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "قيمة الأوامر"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-primary tabular-nums",
							children: fmtSAR(stats.totalValue)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "معتمد + قيد الاستلام"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-info tabular-nums",
							children: fmtSAR(stats.approved + stats.partial)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "مستلم + مغلق"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-success tabular-nums",
							children: fmtSAR(stats.received + stats.closed)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:flex items-center gap-2 mb-3 hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "أوامر الشراء",
				count: `${total} أمر`
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء جلب أوامر الشراء",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] }),
					children: "إعادة المحاولة"
				})
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد أوامر شراء",
				description: "ابدأ بإنشاء أول أمر شراء",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إنشاء أمر شراء"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الرقم",
					"الموضوع",
					"المورد",
					"المبلغ",
					"الحالة",
					""
				],
				rows: items,
				renderRow: (o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: o.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => navigate({
							to: "/procurement/orders/$id/edit",
							params: { id: o.id }
						}),
						className: "font-semibold hover:text-primary text-right",
						children: o.subject
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: o.date
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-xs",
						children: suppliers.find((s) => s.id === o.supplierId)?.name || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums font-bold",
						children: fmtSAR(o.total)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(o.status),
						children: o.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getOrderActions(o, navigate, setActionTarget, openReceive, setDeleteTarget) }) })
				] }),
				mobileCard: (o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(o.status),
								children: o.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted-foreground",
								children: o.id
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => navigate({
								to: "/procurement/orders/$id/edit",
								params: { id: o.id }
							}),
							className: "font-semibold text-right hover:text-primary",
							children: o.subject
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground mt-1",
							children: [
								suppliers.find((s) => s.id === o.supplierId)?.name || "—",
								" · ",
								o.date
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums font-bold",
								children: fmtSAR(o.total)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: ["مستلم: ", fmtSAR(o.receivedAmount)]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px]",
								onClick: () => navigate({
									to: "/procurement/orders/$id/edit",
									params: { id: o.id }
								}),
								children: "تفاصيل"
							}), (o.status === "معتمد" || o.status === "تم الاستلام جزئيًا") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "flex-1 rounded-lg bg-success/15 text-success text-xs font-semibold py-2 min-h-[36px]",
								onClick: () => openReceive(o),
								children: "استلام"
							})]
						})
					]
				}, o.id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailId && !receiveTarget,
				onClose: () => setDetailId(null),
				title: `تفاصيل أمر الشراء: ${detailQuery.data?.item?.subject || ""}`,
				onSave: () => setDetailId(null),
				saveText: "إغلاق",
				children: detailQuery.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحالة",
									value: detailQuery.data.item.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "المورد",
									value: suppliers.find((s) => s.id === detailQuery.data.item.supplierId)?.name || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "التاريخ",
									value: detailQuery.data.item.date
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "تاريخ التوريد",
									value: detailQuery.data.item.deliveryDate || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الإجمالي",
									value: fmtSAR(detailQuery.data.item.total)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "المستلم",
									value: fmtSAR(detailQuery.data.item.receivedAmount)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-primary/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-muted-foreground mb-2",
								children: "سطور الأمر"
							}), detailQuery.data.lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs py-1 border-b last:border-0 flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-semibold",
									children: l.description
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-muted-foreground",
									children: [
										l.quantity,
										" ",
										l.unit,
										" × ",
										fmtSAR(l.unitPrice),
										" =",
										" ",
										fmtSAR(l.quantity * l.unitPrice)
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "مستلم"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold",
										children: l.receivedQuantity || 0
									})]
								})]
							}, l.id))]
						}),
						detailQuery.data.item.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-1",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm whitespace-pre-wrap",
							children: detailQuery.data.item.notes
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!receiveTarget,
				onClose: () => {
					setReceiveTarget(null);
					setReceiveLines({});
				},
				title: `استلام أصناف الأمر: ${receiveTarget?.id || ""}`,
				onSave: handleReceive,
				loading: receiveMutation.isPending,
				saveText: "تأكيد الاستلام",
				children: receiveTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-info/10 p-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold text-info mb-1",
							children: "📦 تسجيل الاستلام"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs",
							children: "أدخل الكميات المستلمة. سيتم تحديث المخزون تلقائياً وإنشاء حركة استلام لكل صنف."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 bg-muted/30",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold mb-2",
							children: "سطور الأمر"
						}), (detailQuery.data?.lines)?.map((l) => {
							const remaining = l.quantity - (l.receivedQuantity || 0);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs py-2 border-b last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between mb-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: l.description
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [
											"متبقي: ",
											remaining,
											" ",
											l.unit
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										className: "flex-1 rounded-lg border bg-background p-2 text-sm",
										value: receiveLines[l.id] || "",
										onChange: (e) => setReceiveLines({
											...receiveLines,
											[l.id]: e.target.value
										}),
										placeholder: "0",
										max: remaining
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: l.unit
									})]
								})]
							}, l.id);
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget && actionTarget.action === "approve",
				onClose: () => setActionTarget(null),
				onConfirm: () => {
					if (actionTarget) approveMutation.mutate({
						id: actionTarget.order.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "اعتماد أمر الشراء",
				message: `هل تريد اعتماد أمر الشراء "${actionTarget?.order.subject}"؟`,
				confirmText: "اعتماد",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget && actionTarget.action === "cancel",
				onClose: () => setActionTarget(null),
				onConfirm: () => {
					if (actionTarget) cancelMutation.mutate({
						id: actionTarget.order.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "إلغاء أمر الشراء",
				message: `هل تريد إلغاء أمر الشراء "${actionTarget?.order.subject}"؟`,
				confirmText: "إلغاء",
				cancelText: "تراجع",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget && actionTarget.action === "close",
				onClose: () => setActionTarget(null),
				onConfirm: () => {
					if (actionTarget) closeMutation.mutate({
						id: actionTarget.order.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "إغلاق أمر الشراء",
				message: `هل تريد إغلاق أمر الشراء "${actionTarget?.order.subject}"؟`,
				confirmText: "إغلاق",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: () => {
					if (deleteTarget) deleteMutation.mutate({
						id: deleteTarget.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "تأكيد الحذف",
				message: deleteTarget ? `هل تريد حذف أمر الشراء "${deleteTarget.subject}"؟ لا يمكن حذف الأوامر التي تم استلامها.` : "",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			})
		]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-semibold",
			children: value
		})]
	});
}
function getOrderActions(o, navigate, setActionTarget, openReceive, setDeleteTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => navigate({
			to: "/procurement/orders/$id/edit",
			params: { id: o.id }
		})
	}, {
		label: "طباعة",
		icon: Printer,
		onClick: () => window.print()
	}];
	if (o.status === "مسودة") {
		actions.push({
			label: "اعتماد",
			icon: CircleCheckBig,
			onClick: () => setActionTarget({
				order: o,
				action: "approve"
			})
		});
		actions.push({
			label: "حذف",
			icon: Trash2,
			variant: "destructive",
			onClick: () => setDeleteTarget(o)
		});
	}
	if (o.status === "معتمد" || o.status === "تم الاستلام جزئيًا") actions.push({
		label: "استلام",
		icon: PackageCheck,
		onClick: () => openReceive(o)
	});
	if (o.status === "تم الاستلام") actions.push({
		label: "إغلاق",
		icon: CircleX,
		onClick: () => setActionTarget({
			order: o,
			action: "close"
		})
	});
	if (o.status !== "ملغي" && o.status !== "مغلق") actions.push({
		label: "إلغاء",
		icon: CircleX,
		onClick: () => setActionTarget({
			order: o,
			action: "cancel"
		})
	});
	return actions;
}
//#endregion
export { Page as component };
