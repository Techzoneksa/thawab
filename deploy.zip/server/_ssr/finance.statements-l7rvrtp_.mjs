import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { At as FileChartColumnIncreasing, R as RefreshCw, wt as Funnel } from "../_libs/lucide-react.mjs";
import { A as Table, C as MobileSearchInput, D as PrintStyle, E as PrintButton, N as showToast, O as SectionTitle, P as statusTone, S as MobilePageHeader, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, g as ExportButton, i as Badge, j as Td, m as EmptyState, n as AppShell, s as Card } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { c as getProjects } from "./projects-fdUGDKDE.mjs";
import { o as getCostCenters } from "./cost-centers-Dv7ULNqn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.statements-l7rvrtp_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var API_BASE = "/api/finance/statements";
async function getStatement(filters) {
	const params = new URLSearchParams();
	params.set("type", filters.type);
	if (filters.startDate) params.set("startDate", filters.startDate);
	if (filters.endDate) params.set("endDate", filters.endDate);
	if (filters.asOf) params.set("asOf", filters.asOf);
	if (filters.costCenterId) params.set("costCenterId", filters.costCenterId);
	if (filters.projectId) params.set("projectId", filters.projectId);
	if (filters.budgetId) params.set("budgetId", filters.budgetId);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في جلب القائمة المالية");
	}
	return res.json();
}
async function getTrialBalance(filters) {
	return getStatement({
		type: "trial-balance",
		...filters
	});
}
async function getIncomeExpense(filters) {
	return getStatement({
		type: "income-expense",
		...filters
	});
}
async function getFinancialPosition(filters) {
	return getStatement({
		type: "financial-position",
		...filters
	});
}
async function getBudgetVsActual(filters) {
	return getStatement({
		type: "budget-vs-actual",
		...filters
	});
}
var TABS = [
	{
		key: "trial-balance",
		label: "ميزان المراجعة"
	},
	{
		key: "income-expense",
		label: "الإيرادات والمصروفات"
	},
	{
		key: "financial-position",
		label: "المركز المالي"
	},
	{
		key: "budget-vs-actual",
		label: "الفعلي مقابل الموازنة"
	}
];
function todayISO() {
	return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function defaultStart() {
	return `${(/* @__PURE__ */ new Date()).getFullYear()}-01-01`;
}
function Page() {
	const [activeTab, setActiveTab] = (0, import_react.useState)("trial-balance");
	const [startDate, setStartDate] = (0, import_react.useState)(defaultStart());
	const [endDate, setEndDate] = (0, import_react.useState)(todayISO());
	const [asOf, setAsOf] = (0, import_react.useState)(todayISO());
	const [costCenterId, setCostCenterId] = (0, import_react.useState)("");
	const [projectId, setProjectId] = (0, import_react.useState)("");
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const tbQuery = useQuery({
		queryKey: [
			"statement",
			"trial-balance",
			{
				startDate,
				endDate,
				costCenterId,
				projectId
			}
		],
		queryFn: () => getTrialBalance({
			startDate,
			endDate,
			costCenterId: costCenterId || void 0,
			projectId: projectId || void 0
		}),
		enabled: activeTab === "trial-balance"
	});
	const ieQuery = useQuery({
		queryKey: [
			"statement",
			"income-expense",
			{
				startDate,
				endDate,
				costCenterId,
				projectId
			}
		],
		queryFn: () => getIncomeExpense({
			startDate,
			endDate,
			costCenterId: costCenterId || void 0,
			projectId: projectId || void 0
		}),
		enabled: activeTab === "income-expense"
	});
	const fpQuery = useQuery({
		queryKey: [
			"statement",
			"financial-position",
			{
				asOf,
				costCenterId,
				projectId
			}
		],
		queryFn: () => getFinancialPosition({
			asOf,
			costCenterId: costCenterId || void 0,
			projectId: projectId || void 0
		}),
		enabled: activeTab === "financial-position"
	});
	const baQuery = useQuery({
		queryKey: [
			"statement",
			"budget-vs-actual",
			{
				startDate,
				endDate
			}
		],
		queryFn: () => getBudgetVsActual({
			startDate,
			endDate
		}),
		enabled: activeTab === "budget-vs-actual"
	});
	const { data: ccData } = useQuery({
		queryKey: ["cost-centers", { search: "" }],
		queryFn: () => getCostCenters({})
	});
	const ccList = ccData?.items || [];
	const { data: projData } = useQuery({
		queryKey: ["projects", { search: "" }],
		queryFn: () => getProjects({})
	});
	const projectList = (projData?.items || []).map((p) => ({
		id: p.id,
		name: p.name
	}));
	const isLoading = activeTab === "trial-balance" ? tbQuery.isLoading : activeTab === "income-expense" ? ieQuery.isLoading : activeTab === "financial-position" ? fpQuery.isLoading : baQuery.isLoading;
	const error = activeTab === "trial-balance" ? tbQuery.error : activeTab === "income-expense" ? ieQuery.error : activeTab === "financial-position" ? fpQuery.error : baQuery.error;
	const refreshAll = () => {
		tbQuery.refetch();
		ieQuery.refetch();
		fpQuery.refetch();
		baQuery.refetch();
		showToast("تم تحديث القوائم المالية", "success");
	};
	const exportData = () => {
		if (activeTab === "trial-balance" && tbQuery.data && tbQuery.data.type === "trial-balance") return tbQuery.data.rows.map((r) => ({
			الرمز: r.accountCode,
			الحساب: r.accountName,
			النوع: r.accountType,
			"إجمالي مدين": fmtSAR(r.totalDebit),
			"إجمالي دائن": fmtSAR(r.totalCredit),
			"رصيد (مدين)": r.isDebit ? fmtSAR(r.balance) : "—",
			"رصيد (دائن)": !r.isDebit ? fmtSAR(r.balance) : "—"
		}));
		if (activeTab === "income-expense" && ieQuery.data && ieQuery.data.type === "income-expense") {
			const rows = [];
			ieQuery.data.revenues.forEach((r) => {
				rows.push({
					القسم: "إيرادات",
					الرمز: r.accountCode,
					الحساب: r.accountName,
					المبلغ: fmtSAR(Math.max(0, r.netAmount))
				});
			});
			ieQuery.data.expenses.forEach((r) => {
				rows.push({
					القسم: "مصروفات",
					الرمز: r.accountCode,
					الحساب: r.accountName,
					المبلغ: fmtSAR(Math.max(0, r.netAmount))
				});
			});
			return rows;
		}
		if (activeTab === "financial-position" && fpQuery.data && fpQuery.data.type === "financial-position") {
			const rows = [];
			fpQuery.data.assets.forEach((r) => rows.push({
				القسم: "أصول",
				الرمز: r.accountCode,
				الحساب: r.accountName,
				الرصيد: fmtSAR(r.balance)
			}));
			fpQuery.data.liabilities.forEach((r) => rows.push({
				القسم: "التزامات",
				الرمز: r.accountCode,
				الحساب: r.accountName,
				الرصيد: fmtSAR(r.balance)
			}));
			fpQuery.data.equity.forEach((r) => rows.push({
				القسم: "حقوق ملكية",
				الرمز: r.accountCode,
				الحساب: r.accountName,
				الرصيد: fmtSAR(r.balance)
			}));
			return rows;
		}
		if (activeTab === "budget-vs-actual" && baQuery.data && baQuery.data.type === "budget-vs-actual") {
			const rows = [];
			baQuery.data.budgets.forEach((b) => {
				b.lines.forEach((l) => {
					rows.push({
						الموازنة: b.budget.name,
						"السطر رقم": l.lineNumber,
						المخطط: fmtSAR(l.plannedAmount),
						الفعلي: fmtSAR(l.actualAmount),
						الفرق: fmtSAR(l.variance),
						"نسبة الاستخدام": `${l.utilization}%`
					});
				});
			});
			return rows;
		}
		return [];
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintStyle, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المالية",
			"القوائم المالية"
		],
		title: "القوائم المالية",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: refreshAll,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { size: 15 }), "تحديث"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: exportData(),
				filename: `statement-${activeTab}.csv`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "القوائم المالية",
				count: TABS.find((t) => t.key === activeTab)?.label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				activeTab !== "financial-position" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateField, {
					label: "من",
					value: startDate,
					onChange: setStartDate
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateField, {
					label: "إلى",
					value: endDate,
					onChange: setEndDate
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DateField, {
					label: "كما في",
					value: asOf,
					onChange: setAsOf
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "appearance-none rounded-lg border bg-background pr-3 pl-7 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring min-h-[36px]",
					value: costCenterId,
					onChange: (e) => setCostCenterId(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "كل مراكز التكلفة"
					}), ccList.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: c.id,
						children: [
							c.code,
							" - ",
							c.name
						]
					}, c.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "appearance-none rounded-lg border bg-background pr-3 pl-7 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring min-h-[36px]",
					value: projectId,
					onChange: (e) => setProjectId(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "كل المشاريع"
					}), projectList.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p.id,
						children: p.name
					}, p.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, { placeholder: "بحث في القائمة..." })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 overflow-x-auto no-scrollbar pb-2 -mx-1 px-1 flex-nowrap mb-3",
				children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setActiveTab(t.key),
					className: `whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-colors min-h-[36px] ${t.key === activeTab ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:bg-muted/80"}`,
					children: t.label
				}, t.key))
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء جلب القائمة المالية",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: refreshAll,
					children: "إعادة المحاولة"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				activeTab === "trial-balance" && tbQuery.data?.type === "trial-balance" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrialBalanceView, { data: tbQuery.data }),
				activeTab === "income-expense" && ieQuery.data?.type === "income-expense" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IncomeExpenseView, { data: ieQuery.data }),
				activeTab === "financial-position" && fpQuery.data?.type === "financial-position" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinancialPositionView, { data: fpQuery.data }),
				activeTab === "budget-vs-actual" && baQuery.data?.type === "budget-vs-actual" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BudgetVsActualView, { data: baQuery.data })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						activeTab !== "financial-position" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "من تاريخ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: startDate,
							onChange: (e) => setStartDate(e.target.value)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "إلى تاريخ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: endDate,
							onChange: (e) => setEndDate(e.target.value)
						})] })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "كما في تاريخ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: asOf,
							onChange: (e) => setAsOf(e.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "مركز التكلفة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: costCenterId,
							onChange: (e) => setCostCenterId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "كل مراكز التكلفة"
							}), ccList.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: c.id,
								children: [
									c.code,
									" - ",
									c.name
								]
							}, c.id))]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "المشروع"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: projectId,
							onChange: (e) => setProjectId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "كل المشاريع"
							}), projectList.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))]
						})] })
					]
				})
			})
		]
	})] });
}
function DateField({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-muted-foreground whitespace-nowrap",
			children: [label, ":"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "date",
			className: "rounded-lg border bg-background px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring min-h-[36px]",
			value,
			onChange: (e) => onChange(e.target.value)
		})]
	});
}
function TrialBalanceView({ data }) {
	if (data.rows.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "لا توجد بيانات",
		description: "لم يتم ترحيل أي قيود في هذه الفترة. قم بإضافة وترحيل القيود أولاً.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileChartColumnIncreasing, { size: 28 })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-4 lg:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "ميزان المراجعة",
				hint: `من ${data.rows.length} حساب · ${data.totals.balanced ? "متوازن ✓" : "غير متوازن ⚠"}`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: data.totals.balanced ? "success" : "destructive",
					children: data.totals.balanced ? "متوازن" : "غير متوازن"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الرمز",
					"الحساب",
					"النوع",
					"مدين",
					"دائن",
					"الرصيد"
				],
				rows: data.rows,
				renderRow: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: r.accountCode
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: r.accountName }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: typeTone(r.accountType),
						children: r.accountType
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums",
						children: fmtSAR(r.totalDebit)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums",
						children: fmtSAR(r.totalCredit)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums font-bold",
						children: r.isDebit ? fmtSAR(r.balance) : fmtSAR(r.balance)
					})
				] }),
				mobileCard: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2 mb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-xs text-muted-foreground",
								children: r.accountCode
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold truncate",
								children: r.accountName
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: typeTone(r.accountType),
							children: r.accountType
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "مدين"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums",
									children: fmtSAR(r.totalDebit)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "دائن"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums",
									children: fmtSAR(r.totalCredit)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "الرصيد"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums",
									children: fmtSAR(r.balance)
								})]
							})
						]
					})]
				}, r.accountId)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-3 gap-3 p-3 rounded-lg bg-primary/10 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "إجمالي المدين"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold tabular-nums",
							children: fmtSAR(data.totals.totalDebit)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "إجمالي الدائن"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold tabular-nums",
							children: fmtSAR(data.totals.totalCredit)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "الفرق"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `font-bold tabular-nums ${data.totals.balanced ? "text-success" : "text-destructive"}`,
							children: fmtSAR(Math.abs(data.totals.variance))
						})]
					})
				]
			})
		]
	});
}
function IncomeExpenseView({ data }) {
	if (data.revenues.length === 0 && data.expenses.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "لا توجد إيرادات أو مصروفات",
		description: "لم يتم ترحيل أي قيود إيرادات/مصروفات في هذه الفترة",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileChartColumnIncreasing, { size: 28 })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4 lg:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						title: "الإيرادات",
						hint: `${data.revenues.length} حساب إيرادات`
					}),
					data.revenues.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground py-4 text-center",
						children: "لا توجد إيرادات مرحّلة في هذه الفترة"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
						columns: [
							"الرمز",
							"الحساب",
							"المبلغ"
						],
						rows: data.revenues,
						renderRow: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
								className: "font-mono text-xs",
								children: r.accountCode
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: r.accountName }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
								className: "tabular-nums font-bold text-success",
								children: fmtSAR(Math.max(0, r.netAmount))
							})
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 p-3 rounded-lg bg-success/10 text-sm flex justify-between items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold",
							children: "إجمالي الإيرادات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold tabular-nums text-success text-lg",
							children: fmtSAR(data.totals.totalRevenue)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4 lg:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						title: "المصروفات",
						hint: `${data.expenses.length} حساب مصروفات`
					}),
					data.expenses.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground py-4 text-center",
						children: "لا توجد مصروفات مرحّلة في هذه الفترة"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
						columns: [
							"الرمز",
							"الحساب",
							"المبلغ"
						],
						rows: data.expenses,
						renderRow: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
								className: "font-mono text-xs",
								children: r.accountCode
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: r.accountName }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
								className: "tabular-nums font-bold text-destructive",
								children: fmtSAR(Math.max(0, r.netAmount))
							})
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 p-3 rounded-lg bg-destructive/10 text-sm flex justify-between items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold",
							children: "إجمالي المصروفات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold tabular-nums text-destructive text-lg",
							children: fmtSAR(data.totals.totalExpense)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: `p-4 lg:p-6 ${data.totals.deficit ? "bg-destructive/10" : "bg-success/10"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: data.totals.deficit ? "عجز الفترة" : "فائض الفترة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-2xl font-extrabold tabular-nums",
						children: fmtSAR(Math.abs(data.totals.surplus))
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: data.totals.deficit ? "destructive" : "success",
						children: data.totals.deficit ? "عجز" : "فائض"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground mt-2",
					children: [
						"الإيرادات (",
						fmtSAR(data.totals.totalRevenue),
						") − المصروفات (",
						fmtSAR(data.totals.totalExpense),
						")"
					]
				})]
			})
		]
	});
}
function FinancialPositionView({ data }) {
	if (data.assets.length === 0 && data.liabilities.length === 0 && data.equity.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "لا توجد أرصدة",
		description: "لا توجد حسابات أصول أو التزامات أو حقوق ملكية مرحّلة في هذه الفترة",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileChartColumnIncreasing, { size: 28 })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PositionSection, {
				title: "الأصول",
				tone: "success",
				rows: data.assets,
				total: data.totals.totalAssets
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PositionSection, {
				title: "الالتزامات",
				tone: "destructive",
				rows: data.liabilities,
				total: data.totals.totalLiabilities
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PositionSection, {
				title: "حقوق الملكية",
				tone: "info",
				rows: data.equity,
				total: data.totals.totalEquity
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4 lg:p-6 bg-primary/10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { title: "ملخص قائمة المركز المالي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
							label: "إجمالي الأصول",
							value: fmtSAR(data.totals.totalAssets),
							tone: "success"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
							label: "إجمالي الالتزامات",
							value: fmtSAR(data.totals.totalLiabilities),
							tone: "destructive"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
							label: "إجمالي حقوق الملكية",
							value: fmtSAR(data.totals.totalEquity)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
							label: data.periodSurplus >= 0 ? "فائض الفترة المضاف" : "عجز الفترة المخصوم",
							value: fmtSAR(Math.abs(data.periodSurplus)),
							tone: data.periodSurplus >= 0 ? "success" : "destructive"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
							label: "إجمالي الالتزامات وحقوق الملكية",
							value: fmtSAR(data.totals.totalLiabilitiesAndEquity),
							bold: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
							label: "الحالة",
							value: data.totals.balanced ? "متوازن ✓" : "غير متوازن ⚠",
							tone: data.totals.balanced ? "success" : "destructive",
							bold: true
						})
					]
				})]
			})
		]
	});
}
function PositionSection({ title, tone, rows, total }) {
	if (rows.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-4 lg:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted-foreground py-4 text-center",
			children: "لا توجد حسابات في هذه الفئة"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "p-4 lg:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title,
				hint: `${rows.length} حساب`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الرمز",
					"الحساب",
					"الرصيد"
				],
				rows,
				renderRow: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: r.accountCode
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: r.accountName }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums font-bold",
						children: fmtSAR(r.balance)
					})
				] }),
				mobileCard: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-xs text-muted-foreground",
								children: r.accountCode
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold truncate",
								children: r.accountName
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold tabular-nums",
							children: fmtSAR(r.balance)
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `mt-3 p-3 rounded-lg text-sm flex justify-between items-center bg-${tone}/10`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "font-bold",
					children: ["إجمالي ", title]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `font-bold tabular-nums text-${tone} text-lg`,
					children: fmtSAR(total)
				})]
			})
		]
	});
}
function SummaryRow({ label, value, tone, bold }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `tabular-nums ${bold ? "font-extrabold text-base" : "font-bold"} ${tone === "success" ? "text-success" : tone === "destructive" ? "text-destructive" : ""}`,
			children: value
		})]
	});
}
function BudgetVsActualView({ data }) {
	if (data.budgets.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		title: "لا توجد موازنات معتمدة",
		description: "لم يتم اعتماد أي موازنة بعد. اعتمد موازنة أولاً لمقارنة الفعلي بها.",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileChartColumnIncreasing, { size: 28 })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4",
		children: data.budgets.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-4 lg:p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					title: b.budget.name,
					hint: `سنة ${b.budget.year} · ${b.budget.status}`,
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(b.budget.status),
						children: b.budget.status
					})
				}),
				b.lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground py-4 text-center",
					children: "لا توجد سطور في هذه الموازنة"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
					columns: [
						"#",
						"المخطط",
						"الفعلي",
						"الفرق",
						"الاستخدام"
					],
					rows: b.lines,
					renderRow: (l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "font-mono text-xs",
							children: l.lineNumber
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "tabular-nums",
							children: fmtSAR(l.plannedAmount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "tabular-nums font-bold",
							children: fmtSAR(l.actualAmount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: `tabular-nums ${l.variance < 0 ? "text-destructive font-bold" : "text-warning"}`,
							children: fmtSAR(l.variance)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 min-w-[120px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 flex-1 rounded-full bg-muted overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-full ${l.utilization > 90 ? "bg-destructive" : l.utilization > 70 ? "bg-warning" : "bg-success"}`,
									style: { width: `${Math.min(100, l.utilization)}%` }
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs tabular-nums",
								children: [l.utilization, "%"]
							})]
						}) })
					] }),
					mobileCard: (l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: ["سطر ", l.lineNumber]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs font-bold tabular-nums",
									children: [l.utilization, "%"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 rounded-full bg-muted overflow-hidden mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-full ${l.utilization > 90 ? "bg-destructive" : l.utilization > 70 ? "bg-warning" : "bg-success"}`,
									style: { width: `${Math.min(100, l.utilization)}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "المخطط"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold tabular-nums",
										children: fmtSAR(l.plannedAmount)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "الفعلي"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold tabular-nums",
										children: fmtSAR(l.actualAmount)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "الفرق"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `font-bold tabular-nums ${l.variance < 0 ? "text-destructive" : "text-warning"}`,
										children: fmtSAR(l.variance)
									})] })
								]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-4 gap-3 p-3 rounded-lg bg-primary/10 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground",
								children: "المخطط"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold tabular-nums",
								children: fmtSAR(b.totals.planned)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground",
								children: "الفعلي"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold tabular-nums text-success",
								children: fmtSAR(b.totals.actual)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground",
								children: "الفرق"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `font-bold tabular-nums ${b.totals.variance < 0 ? "text-destructive" : "text-warning"}`,
								children: fmtSAR(b.totals.variance)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground",
								children: "الاستخدام"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-bold tabular-nums",
								children: [b.totals.utilization, "%"]
							})]
						})
					]
				})
			]
		}, b.budget.id))
	});
}
function typeTone(type) {
	if (type === "إيراد") return "success";
	if (type === "مصروف") return "destructive";
	if (type === "أصل") return "info";
	if (type === "التزام") return "warning";
	if (type === "حقوق ملكية") return "primary";
	return "muted";
}
//#endregion
export { Page as component };
