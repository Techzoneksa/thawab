import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { a as createPurchaseRequest, t as REQUEST_PRIORITIES } from "./purchase-requests-CdC7mUrc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.requests.new-xsu1BfF3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEPARTMENTS = [
	"إدارة المساعدات",
	"تقنية المعلومات",
	"إدارة المشاريع",
	"الإدارة المالية",
	"المشتريات"
];
function NewRequestPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const [subject, setSubject] = (0, import_react.useState)("");
	const [department, setDepartment] = (0, import_react.useState)("إدارة المساعدات");
	const [priority, setPriority] = (0, import_react.useState)("متوسطة");
	const [requester, setRequester] = (0, import_react.useState)(user?.name || "");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [deliveryDate, setDeliveryDate] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const handleSave = async (andClose) => {
		const errs = [];
		if (!subject.trim()) errs.push("موضوع الطلب مطلوب");
		if (!department.trim()) errs.push("الإدارة مطلوبة");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			const created = await createPurchaseRequest({
				subject: subject.trim(),
				department,
				priority,
				requester: requester || void 0,
				amount: parseFloat(amount) || 0,
				deliveryDate: deliveryDate || void 0,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			showToast(`تم إنشاء طلب الشراء`, "success");
			if (andClose) navigate({ to: "/procurement/requests" });
			else navigate({
				to: "/procurement/requests/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const tabs = [{
		id: "basic",
		label: "بيانات الطلب",
		content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
			title: "بيانات طلب الشراء",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "موضوع الطلب",
					required: true,
					error: errors[0],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: subject,
						onChange: (e) => setSubject(e.target.value),
						placeholder: "مثال: مستلزمات سلال غذائية لشهر ربيع الأول"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الإدارة",
					required: true,
					error: errors[1],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
						value: department,
						onChange: (e) => setDepartment(e.target.value),
						children: DEPARTMENTS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: d,
							children: d
						}, d))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الأولوية",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
						value: priority,
						onChange: (e) => setPriority(e.target.value),
						children: REQUEST_PRIORITIES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p,
							children: p
						}, p))
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "مقدم الطلب",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: requester,
						onChange: (e) => setRequester(e.target.value),
						placeholder: "اسم مقدم الطلب"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "المبلغ التقديري",
					hint: "ر.س",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						min: "0",
						step: "0.01",
						value: amount,
						onChange: (e) => setAmount(e.target.value),
						dir: "ltr",
						placeholder: "0.00"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "تاريخ التوريد المطلوب",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "date",
						value: deliveryDate,
						onChange: (e) => setDeliveryDate(e.target.value),
						dir: "ltr"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 4
					})
				})
			]
		})
	}];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "طلبات الشراء",
		breadcrumb: [
			"المشتريات",
			"طلبات الشراء",
			"جديد"
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المشتريات",
					to: "/procurement/requests"
				},
				{
					label: "طلبات الشراء",
					to: "/procurement/requests"
				},
				{ label: "طلب جديد" }
			],
			title: "طلب شراء جديد",
			subtitle: subject || "أدخل بيانات الطلب",
			draftNumber: "مسودة جديدة",
			status: {
				label: "مسودة",
				tone: "muted"
			},
			tabs,
			defaultTab: "basic",
			loading: saving,
			validationErrors: errors,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/procurement/requests" })
		})
	});
}
//#endregion
export { NewRequestPage as component };
