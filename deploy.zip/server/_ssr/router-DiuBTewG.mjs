import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as useRouter, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { i as useQueryClient, r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { Gt as CircleAlert, Mt as EyeOff, jt as Eye, lt as Lock, st as Mail } from "../_libs/lucide-react.mjs";
import { M as cn, N as showToast, o as Button, r as AuthProvider } from "./actions-qTEe1ygX.mjs";
import { t as Route$93 } from "./assets._id.edit-4UdN5357.mjs";
import { t as Route$94 } from "./beneficiaries._id-BFV4YTRB.mjs";
import { t as Route$95 } from "./donors._id-sb3qfshX.mjs";
import { t as Route$96 } from "./inventory.items._id.edit-5VQs2kwA.mjs";
import { t as Route$97 } from "./inventory.stocktake._id.edit-DIMCiGd7.mjs";
import { t as Route$98 } from "./inventory.warehouses._id.edit-mWhrLiIz.mjs";
import { t as Route$99 } from "./procurement.orders._id.edit-CBUFb_Ds.mjs";
import { t as Route$100 } from "./procurement.quotes._id.edit-BtuJe6Av.mjs";
import { t as Route$101 } from "./procurement.requests._id.edit-BZPrk1_u.mjs";
import { t as Route$102 } from "./procurement.suppliers._id.edit-BQrBo6wP.mjs";
import { t as Route$103 } from "./projects._id-CRFKJ5jo.mjs";
import { S as src_default, _ as text$1, a as integer, b as boolean, c as and, d as inArray, f as like, g as pgTable, h as or, i as real, l as eq, m as ne, n as sqliteTable, o as drizzle, p as lte, r as text, s as desc, t as drizzle$1, u as gte, v as integer$1, x as sql, y as doublePrecision } from "../_libs/drizzle-orm+postgres.mjs";
import { t as createClient } from "../_libs/@libsql/client.mjs";
import { t as createSyncFn } from "../_libs/synckit.mjs";
import { existsSync, mkdirSync } from "fs";
import { dirname } from "path";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DiuBTewG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var styles_default = "/assets/styles-DVum2KZY.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold",
					children: "الصفحة غير موجودة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "الصفحة التي تبحث عنها غير متوفرة أو تم نقلها."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "mt-6 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90",
					children: "العودة للرئيسية"
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold",
					children: "تعذّر تحميل الصفحة"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "حدث خطأ غير متوقع. حاول مرة أخرى."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground",
						children: "إعادة المحاولة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "rounded-md border px-4 py-2 text-sm",
						children: "الرئيسية"
					})]
				})
			]
		})
	});
}
var Route$92 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover, maximum-scale=1, user-scalable=no"
			},
			{
				name: "apple-mobile-web-app-capable",
				content: "yes"
			},
			{
				name: "apple-mobile-web-app-status-bar-style",
				content: "black-translucent"
			},
			{
				name: "theme-color",
				content: "#ffffff"
			},
			{
				name: "mobile-web-app-capable",
				content: "yes"
			},
			{ title: "ثواب — نظام إدارة الجمعيات والجهات الخيرية" },
			{
				name: "description",
				content: "نظام خاص لإدارة الجمعيات والجهات الخيرية في المملكة العربية السعودية."
			},
			{
				name: "author",
				content: "Techzone"
			},
			{
				property: "og:title",
				content: "ثواب — نظام إدارة الجمعيات والجهات الخيرية"
			},
			{
				property: "og:description",
				content: "نظام خاص لإدارة الجمعيات والجهات الخيرية في المملكة العربية السعودية."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:title",
				content: "ثواب — نظام إدارة الجمعيات والجهات الخيرية"
			},
			{
				name: "twitter:description",
				content: "نظام خاص لإدارة الجمعيات والجهات الخيرية في المملكة العربية السعودية."
			},
			{
				property: "og:image",
				content: ""
			},
			{
				name: "twitter:image",
				content: ""
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ar",
		dir: "rtl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$92.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) })
	});
}
var $$splitComponentImporter$67 = () => import("./workflows-Bz6j76yM.mjs");
var Route$91 = createFileRoute("/workflows")({
	head: () => ({ meta: [{ title: "سير العمل — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$67, "component")
});
var $$splitComponentImporter$66 = () => import("./reports-Cjr5Kd0w.mjs");
var Route$90 = createFileRoute("/reports")({
	head: () => ({ meta: [{ title: "مركز التقارير — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$66, "component")
});
var $$splitComponentImporter$65 = () => import("./recurring-KiAVs6d6.mjs");
var Route$89 = createFileRoute("/recurring")({
	head: () => ({ meta: [{ title: "التبرعات المتكررة — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$65, "component")
});
var $$splitComponentImporter$64 = () => import("./receipts-V3TMKoM5.mjs");
var Route$88 = createFileRoute("/receipts")({
	head: () => ({ meta: [{ title: "الإيصالات الإلكترونية — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$64, "component")
});
var $$splitComponentImporter$63 = () => import("./projects-BlXBdnSS.mjs");
var Route$87 = createFileRoute("/projects")({
	head: () => ({ meta: [{ title: "المشاريع والبرامج — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$63, "component")
});
var $$splitComponentImporter$62 = () => import("./permissions-B9N0yo2j.mjs");
var Route$86 = createFileRoute("/permissions")({
	head: () => ({ meta: [{ title: "الصلاحيات — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$62, "component")
});
var $$splitComponentImporter$61 = () => import("./notifications-D86srV14.mjs");
var Route$85 = createFileRoute("/notifications")({
	head: () => ({ meta: [{ title: "التنبيهات — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$61, "component")
});
var $$splitComponentImporter$60 = () => import("./memberships-t3-DCSUl.mjs");
var Route$84 = createFileRoute("/memberships")({
	head: () => ({ meta: [{ title: "العضويات — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$60, "component")
});
var $$splitComponentImporter$59 = () => import("./meetings-AzFhFPGW.mjs");
var Route$83 = createFileRoute("/meetings")({
	head: () => ({ meta: [{ title: "الاجتماعات — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$59, "component")
});
var Card = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("rounded-xl border bg-card text-card-foreground shadow", className),
	...props
}));
Card.displayName = "Card";
var CardHeader = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex flex-col space-y-1.5 p-6", className),
	...props
}));
CardHeader.displayName = "CardHeader";
var CardTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("font-semibold leading-none tracking-tight", className),
	...props
}));
CardTitle.displayName = "CardTitle";
var CardDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
CardDescription.displayName = "CardDescription";
var CardContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("p-6 pt-0", className),
	...props
}));
CardContent.displayName = "CardContent";
var CardFooter = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	ref,
	className: cn("flex items-center p-6 pt-0", className),
	...props
}));
CardFooter.displayName = "CardFooter";
var API = "/api/auth";
var Route$82 = createFileRoute("/login")({
	head: () => ({ meta: [{ title: "تسجيل الدخول — ثواب" }] }),
	component: LoginPage
});
function LoginPage() {
	const queryClient = useQueryClient();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [isLoading, setIsLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const handleLogin = async (e) => {
		e.preventDefault();
		setError("");
		setIsLoading(true);
		try {
			const res = await fetch(API, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					email,
					password
				})
			});
			const data = await res.json();
			if (!res.ok || data.error) {
				setError(data.error || "حدث خطأ أثناء تسجيل الدخول");
				setIsLoading(false);
				return;
			}
			localStorage.setItem("session_token", data.token);
			queryClient.setQueryData(["currentUser"], data.user);
			showToast(`مرحباً ${data.user.name}!`, "success");
			window.location.href = "/";
		} catch {
			setError("حدث خطأ في الاتصال بالخادم");
			setIsLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-background flex items-center justify-center p-4",
		dir: "rtl",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center mb-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-extrabold text-primary",
					children: "ثواب"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mt-1",
					children: "نظام إدارة الجمعيات والجهات الخيرية"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-6 lg:p-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold text-center mb-6",
						children: "تسجيل الدخول"
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 p-3 mb-4 rounded-lg bg-destructive/10 text-destructive text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { size: 16 }), error]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleLogin,
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold text-muted-foreground block mb-1.5",
								children: "البريد الإلكتروني"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
									size: 15,
									className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "email",
									required: true,
									value: email,
									onChange: (e) => setEmail(e.target.value),
									className: "w-full rounded-lg border bg-background py-3 pr-10 pl-3 text-sm",
									placeholder: "example@domain.sa",
									dir: "ltr"
								})]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold text-muted-foreground block mb-1.5",
								children: "كلمة المرور"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
										size: 15,
										className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: showPassword ? "text" : "password",
										required: true,
										value: password,
										onChange: (e) => setPassword(e.target.value),
										className: "w-full rounded-lg border bg-background py-3 pr-10 pl-3 text-sm",
										placeholder: "••••••••",
										dir: "ltr"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setShowPassword(!showPassword),
										className: "absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground",
										children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 15 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 15 })
									})
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								disabled: isLoading,
								className: "w-full h-12 text-base font-semibold",
								children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-5 w-5 border-2 border-white border-t-transparent rounded-full" }), "جاري التسجيل..."]
								}) : "تسجيل الدخول"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 p-4 rounded-lg bg-muted/50 text-xs space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-semibold text-muted-foreground mb-2",
							children: "بيانات الدخول التجريبية:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مدير النظام:" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									children: "saud@albir.org.sa / admin123"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "محاسب:" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									children: "sara@albir.org.sa / acc123"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "مدير:" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									children: "mohammed@albir.org.sa / mgr123"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "موظف تبرعات:" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									children: "noura@albir.org.sa / don123"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "منسق مشاريع:" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									children: "fahad@albir.org.sa / proj123"
								})
							]
						})]
					})
				]
			})]
		})
	});
}
var $$splitComponentImporter$58 = () => import("./hr-B12ZJnm7.mjs");
var Route$81 = createFileRoute("/hr")({
	head: () => ({ meta: [{ title: "الموارد البشرية — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$58, "component")
});
var $$splitComponentImporter$57 = () => import("./grants-BQezCja0.mjs");
var Route$80 = createFileRoute("/grants")({
	head: () => ({ meta: [{ title: "المنح — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$57, "component")
});
var $$splitComponentImporter$56 = () => import("./endowments-B_aUZ9mR.mjs");
var Route$79 = createFileRoute("/endowments")({
	head: () => ({ meta: [{ title: "الأوقاف — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$56, "component")
});
var $$splitComponentImporter$55 = () => import("./endowment-returns-D5MrNtC_.mjs");
var Route$78 = createFileRoute("/endowment-returns")({
	head: () => ({ meta: [{ title: "عوائد الأوقاف — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$55, "component")
});
var $$splitComponentImporter$54 = () => import("./donors-BNpWkonB.mjs");
var Route$77 = createFileRoute("/donors")({
	head: () => ({ meta: [{ title: "المتبرعون — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$54, "component")
});
var $$splitComponentImporter$53 = () => import("./donor-orgs-KaRjZA4z.mjs");
var Route$76 = createFileRoute("/donor-orgs")({
	head: () => ({ meta: [{ title: "الجهات المانحة — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$53, "component")
});
var $$splitComponentImporter$52 = () => import("./donations-B77HjJTT.mjs");
var Route$75 = createFileRoute("/donations")({
	head: () => ({ meta: [{ title: "إدارة التبرعات — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$52, "component")
});
var $$splitComponentImporter$51 = () => import("./distribution-Dcbfvxex.mjs");
var Route$74 = createFileRoute("/distribution")({
	head: () => ({ meta: [{ title: "تقارير التوزيع — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$51, "component")
});
var $$splitComponentImporter$50 = () => import("./campaigns-C1XxIFpn.mjs");
var Route$73 = createFileRoute("/campaigns")({
	head: () => ({ meta: [{ title: "حملات التبرع — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$50, "component")
});
var $$splitComponentImporter$49 = () => import("./beneficiaries-CwUYDYMv.mjs");
var Route$72 = createFileRoute("/beneficiaries")({
	head: () => ({ meta: [{ title: "المستفيدون — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$49, "component")
});
var $$splitComponentImporter$48 = () => import("./audit-B-jyStyX.mjs");
var Route$71 = createFileRoute("/audit")({
	head: () => ({ meta: [{ title: "سجل التدقيق — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$48, "component")
});
var $$splitComponentImporter$47 = () => import("./assets-DYk0uJtx.mjs");
var Route$70 = createFileRoute("/assets")({
	head: () => ({ meta: [{ title: "الأصول الثابتة — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$47, "component")
});
var $$splitComponentImporter$46 = () => import("./approvals-WBIIMlHj.mjs");
var Route$69 = createFileRoute("/approvals")({
	head: () => ({ meta: [{ title: "صندوق الموافقات — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$46, "component")
});
var $$splitComponentImporter$45 = () => import("./aid-a4Dwguwe.mjs");
var Route$68 = createFileRoute("/aid")({
	head: () => ({ meta: [{ title: "المساعدات — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$45, "component")
});
var $$splitComponentImporter$44 = () => import("./routes-nX4YoaD6.mjs");
var Route$67 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "لوحة المعلومات التنفيذية — ثواب" }, {
		name: "description",
		content: "لوحة معلومات تنفيذية للجمعيات الخيرية تعرض التبرعات والمصروفات والمشاريع والمستفيدين."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$44, "component")
});
var $$splitComponentImporter$43 = () => import("./settings.users-DzLXDC-r.mjs");
var Route$66 = createFileRoute("/settings/users")({
	head: () => ({ meta: [{ title: "المستخدمون — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$43, "component")
});
var $$splitComponentImporter$42 = () => import("./settings.system-ChVE4Tou.mjs");
var Route$65 = createFileRoute("/settings/system")({
	head: () => ({ meta: [{ title: "إعدادات النظام — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$42, "component")
});
var $$splitComponentImporter$41 = () => import("./settings.org-CG8Zm6cU.mjs");
var Route$64 = createFileRoute("/settings/org")({
	head: () => ({ meta: [{ title: "إعدادات الجمعية — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$41, "component")
});
var $$splitComponentImporter$40 = () => import("./settings.integrations-BRByKzom.mjs");
var Route$63 = createFileRoute("/settings/integrations")({
	head: () => ({ meta: [{ title: "التكاملات — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$40, "component")
});
var $$splitComponentImporter$39 = () => import("./settings.branches-CGmFl2me.mjs");
var Route$62 = createFileRoute("/settings/branches")({
	head: () => ({ meta: [{ title: "الفروع — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$39, "component")
});
var $$splitComponentImporter$38 = () => import("./settings.backup-DrnlzK39.mjs");
var Route$61 = createFileRoute("/settings/backup")({
	head: () => ({ meta: [{ title: "النسخ الاحتياطي — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$38, "component")
});
var $$splitComponentImporter$37 = () => import("./projects.new-BcGoVj5s.mjs");
var Route$60 = createFileRoute("/projects/new")({
	head: () => ({ meta: [{ title: "مشروع جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$37, "component")
});
var $$splitComponentImporter$36 = () => import("./procurement.suppliers-bnsypqqn.mjs");
var Route$59 = createFileRoute("/procurement/suppliers")({
	head: () => ({ meta: [{ title: "الموردون — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$36, "component")
});
var $$splitComponentImporter$35 = () => import("./procurement.requests-LCPKpb8r.mjs");
var Route$58 = createFileRoute("/procurement/requests")({
	head: () => ({ meta: [{ title: "طلبات الشراء — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$35, "component")
});
var $$splitComponentImporter$34 = () => import("./procurement.quotes-C0MDzgJU.mjs");
var Route$57 = createFileRoute("/procurement/quotes")({
	head: () => ({ meta: [{ title: "عروض الأسعار — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$34, "component")
});
var $$splitComponentImporter$33 = () => import("./procurement.orders-CTxKy8tD.mjs");
var Route$56 = createFileRoute("/procurement/orders")({
	head: () => ({ meta: [{ title: "أوامر الشراء — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$33, "component")
});
var $$splitComponentImporter$32 = () => import("./inventory.warehouses-C9jtAVkW.mjs");
var Route$55 = createFileRoute("/inventory/warehouses")({
	head: () => ({ meta: [{ title: "المستودعات — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$32, "component")
});
var $$splitComponentImporter$31 = () => import("./inventory.stocktake-DsM2_iaX.mjs");
var Route$54 = createFileRoute("/inventory/stocktake")({
	head: () => ({ meta: [{ title: "الجرد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$31, "component")
});
var $$splitComponentImporter$30 = () => import("./inventory.items-CpO7W_7B.mjs");
var Route$53 = createFileRoute("/inventory/items")({
	head: () => ({ meta: [{ title: "الأصناف — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$30, "component")
});
var $$splitComponentImporter$29 = () => import("./finance.statements-l7rvrtp_.mjs");
var Route$52 = createFileRoute("/finance/statements")({
	head: () => ({ meta: [{ title: "القوائم المالية — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$29, "component")
});
var $$splitComponentImporter$28 = () => import("./finance.ledger-CaA-J-zt.mjs");
var Route$51 = createFileRoute("/finance/ledger")({
	head: () => ({ meta: [{ title: "دفتر الأستاذ — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$28, "component")
});
var $$splitComponentImporter$27 = () => import("./finance.journal-BSqMWYEc.mjs");
var Route$50 = createFileRoute("/finance/journal")({
	head: () => ({ meta: [{ title: "قيود اليومية — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$27, "component")
});
var $$splitComponentImporter$26 = () => import("./finance.cost-centers-BlaoiX47.mjs");
var Route$49 = createFileRoute("/finance/cost-centers")({
	head: () => ({ meta: [{ title: "مراكز التكلفة — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$26, "component")
});
var $$splitComponentImporter$25 = () => import("./finance.closing-DHhKJ7Km.mjs");
var Route$48 = createFileRoute("/finance/closing")({
	head: () => ({ meta: [{ title: "الإقفال المالي — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$25, "component")
});
var $$splitComponentImporter$24 = () => import("./finance.budgets-p7zDTY8W.mjs");
var Route$47 = createFileRoute("/finance/budgets")({
	head: () => ({ meta: [{ title: "الموازنات — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$24, "component")
});
var $$splitComponentImporter$23 = () => import("./finance.accounts-CRYcd78x.mjs");
var Route$46 = createFileRoute("/finance/accounts")({
	head: () => ({ meta: [{ title: "دليل الحسابات — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$23, "component")
});
var $$splitComponentImporter$22 = () => import("./donors.new-pt77EYqX.mjs");
var Route$45 = createFileRoute("/donors/new")({
	head: () => ({ meta: [{ title: "متبرع جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$22, "component")
});
var $$splitComponentImporter$21 = () => import("./donations.new-CVBQ0Nka.mjs");
var Route$44 = createFileRoute("/donations/new")({
	head: () => ({ meta: [{ title: "تبرع جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$21, "component")
});
var $$splitComponentImporter$20 = () => import("./beneficiaries.new-CXOCKVEy.mjs");
var Route$43 = createFileRoute("/beneficiaries/new")({
	head: () => ({ meta: [{ title: "مستفيد جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$20, "component")
});
var $$splitComponentImporter$19 = () => import("./assets.new-DX48DgiX.mjs");
var Route$42 = createFileRoute("/assets/new")({
	head: () => ({ meta: [{ title: "أصل جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$19, "component")
});
var schema_sqlite_exports = /* @__PURE__ */ __exportAll({
	accounts: () => accounts$2,
	aidRecords: () => aidRecords$2,
	approvals: () => approvals$2,
	assetDepreciations: () => assetDepreciations$2,
	assetMovements: () => assetMovements$2,
	auditLog: () => auditLog$2,
	beneficiaries: () => beneficiaries$2,
	branches: () => branches$2,
	budgetLines: () => budgetLines$2,
	budgets: () => budgets$2,
	campaigns: () => campaigns$2,
	costCenters: () => costCenters$2,
	donations: () => donations$2,
	donors: () => donors$2,
	endowments: () => endowments$2,
	fiscalPeriods: () => fiscalPeriods$2,
	fixedAssets: () => fixedAssets$2,
	grants: () => grants$2,
	inventoryItems: () => inventoryItems$2,
	journalEntries: () => journalEntries$2,
	journalLines: () => journalLines$2,
	meetings: () => meetings$2,
	memberships: () => memberships$2,
	projects: () => projects$2,
	purchaseOrderLines: () => purchaseOrderLines$2,
	purchaseOrders: () => purchaseOrders$2,
	purchaseRequests: () => purchaseRequests$2,
	quotes: () => quotes$2,
	receipts: () => receipts$2,
	roles: () => roles$2,
	sessions: () => sessions$2,
	stockMovements: () => stockMovements$2,
	stocktakeLines: () => stocktakeLines$2,
	stocktakes: () => stocktakes$2,
	suppliers: () => suppliers$2,
	users: () => users$2,
	warehouses: () => warehouses$2
});
var users$2 = sqliteTable("users", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	email: text("email").notNull().unique(),
	password: text("password").notNull(),
	phone: text("phone"),
	role: text("role").notNull().default("employee"),
	branchId: text("branch_id"),
	status: text("status").notNull().default("active"),
	avatar: text("avatar"),
	createdAt: text("created_at").notNull().default(""),
	lastLogin: text("last_login")
});
var roles$2 = sqliteTable("roles", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	description: text("description"),
	permissions: text("permissions").notNull().default("[]"),
	createdAt: text("created_at").notNull().default("")
});
var sessions$2 = sqliteTable("sessions", {
	id: text("id").primaryKey(),
	userId: text("user_id").notNull().references(() => users$2.id),
	token: text("token").notNull().unique(),
	expiresAt: text("expires_at").notNull(),
	createdAt: text("created_at").notNull().default("")
});
var branches$2 = sqliteTable("branches", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	city: text("city").notNull(),
	manager: text("manager"),
	phone: text("phone"),
	email: text("email"),
	status: text("status").notNull().default("active"),
	createdAt: text("created_at").notNull().default("")
});
var donors$2 = sqliteTable("donors", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	type: text("type").notNull().default("فرد"),
	email: text("email"),
	phone: text("phone"),
	city: text("city").default(""),
	address: text("address").default(""),
	tag: text("tag").default("برونزي"),
	totalDonations: real("total_donations").notNull().default(0),
	donationCount: integer("donation_count").notNull().default(0),
	lastDonation: text("last_donation"),
	recurring: integer("recurring", { mode: "boolean" }).notNull().default(false),
	notes: text("notes").default(""),
	status: text("status").notNull().default("نشط"),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var campaigns$2 = sqliteTable("campaigns", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	goal: real("goal").notNull().default(0),
	raised: real("raised").notNull().default(0),
	startDate: text("start_date").default(""),
	endDate: text("end_date").default(""),
	status: text("status").notNull().default("مخطط"),
	description: text("description").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default("")
});
var projects$2 = sqliteTable("projects", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	code: text("code").default(""),
	type: text("type").default(""),
	category: text("category").default(""),
	branch: text("branch").default(""),
	manager: text("manager").notNull(),
	budget: real("budget").notNull().default(0),
	spent: real("spent").notNull().default(0),
	donations: real("donations").notNull().default(0),
	beneficiaryCount: integer("beneficiary_count").notNull().default(0),
	progress: integer("progress").notNull().default(0),
	status: text("status").notNull().default("مخطط"),
	startDate: text("start_date").default(""),
	endDate: text("end_date").default(""),
	description: text("description").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var donations$2 = sqliteTable("donations", {
	id: text("id").primaryKey(),
	donorId: text("donor_id").notNull().references(() => donors$2.id),
	projectId: text("project_id").references(() => projects$2.id),
	campaignId: text("campaign_id").references(() => campaigns$2.id),
	amount: real("amount").notNull(),
	method: text("method").notNull().default("نقدي"),
	channel: text("channel").notNull().default("مباشر"),
	status: text("status").notNull().default("مسودة"),
	receiptId: text("receipt_id"),
	notes: text("notes").default(""),
	date: text("date").notNull().default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var beneficiaries$2 = sqliteTable("beneficiaries", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	fileNumber: text("file_number").default(""),
	idNumber: text("id_number").default(""),
	phone: text("phone"),
	city: text("city").default(""),
	address: text("address").default(""),
	category: text("category").notNull().default("أسر محتاجة"),
	status: text("status").notNull().default("جديد"),
	familyMembers: integer("family_members").notNull().default(1),
	monthlyIncome: real("monthly_income").notNull().default(0),
	maritalStatus: text("marital_status").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var aidRecords$2 = sqliteTable("aid_records", {
	id: text("id").primaryKey(),
	beneficiaryId: text("beneficiary_id").notNull().references(() => beneficiaries$2.id),
	projectId: text("project_id").references(() => projects$2.id),
	type: text("type").notNull().default("مساعدة عاجلة"),
	amount: real("amount").notNull().default(0),
	status: text("status").notNull().default("بانتظار الموافقة"),
	date: text("date").notNull().default(""),
	approvedBy: text("approved_by").references(() => users$2.id),
	approvedAt: text("approved_at"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default(""),
	deliveredAt: text("delivered_at"),
	deliveredBy: text("delivered_by").references(() => users$2.id),
	deliveryMethod: text("delivery_method").default(""),
	deliveryNotes: text("delivery_notes").default("")
});
var receipts$2 = sqliteTable("receipts", {
	id: text("id").primaryKey(),
	donationId: text("donation_id").references(() => donations$2.id),
	number: text("number").notNull().unique(),
	amount: real("amount").notNull(),
	date: text("date").notNull().default(""),
	type: text("type").notNull().default("تبرع"),
	status: text("status").notNull().default("مرحّل"),
	printed: integer("printed", { mode: "boolean" }).notNull().default(false),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default("")
});
var accounts$2 = sqliteTable("accounts", {
	id: text("id").primaryKey(),
	code: text("code").notNull(),
	name: text("name").notNull(),
	type: text("type").notNull().default("تفصيلي"),
	level: integer("level").notNull().default(1),
	parentId: text("parent_id"),
	currency: text("currency").notNull().default("SAR"),
	balance: real("balance").notNull().default(0),
	postable: integer("postable", { mode: "boolean" }).notNull().default(true),
	status: text("status").notNull().default("نشط"),
	description: text("description").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var journalEntries$2 = sqliteTable("journal_entries", {
	id: text("id").primaryKey(),
	number: text("number").notNull().unique(),
	date: text("date").notNull().default(""),
	description: text("description").notNull().default(""),
	debitAccount: text("debit_account").notNull(),
	creditAccount: text("credit_account").notNull(),
	amount: real("amount").notNull().default(0),
	fund: text("fund").notNull().default("مقيد"),
	currency: text("currency").notNull().default("SAR"),
	projectId: text("project_id").references(() => projects$2.id),
	sourceType: text("source_type"),
	sourceId: text("source_id"),
	status: text("status").notNull().default("مسودة"),
	postedBy: text("posted_by").references(() => users$2.id),
	postedAt: text("posted_at"),
	reversedBy: text("reversed_by"),
	reversedAt: text("reversed_at"),
	reversedOf: text("reversed_of"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var journalLines$2 = sqliteTable("journal_lines", {
	id: text("id").primaryKey(),
	journalEntryId: text("journal_entry_id").notNull().references(() => journalEntries$2.id, { onDelete: "cascade" }),
	lineNumber: integer("line_number").notNull(),
	accountId: text("account_id").notNull().references(() => accounts$2.id),
	description: text("description").default(""),
	debit: real("debit").notNull().default(0),
	credit: real("credit").notNull().default(0),
	costCenterId: text("cost_center_id").references(() => costCenters$2.id),
	projectId: text("project_id").references(() => projects$2.id),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
var costCenters$2 = sqliteTable("cost_centers", {
	id: text("id").primaryKey(),
	code: text("code").notNull(),
	name: text("name").notNull(),
	manager: text("manager").default(""),
	budget: real("budget").notNull().default(0),
	spent: real("spent").notNull().default(0),
	status: text("status").notNull().default("نشط"),
	description: text("description").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var budgets$2 = sqliteTable("budgets", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	year: text("year").notNull(),
	amount: real("amount").notNull(),
	spent: real("spent").notNull().default(0),
	department: text("department").default(""),
	status: text("status").notNull().default("مخطط"),
	currency: text("currency").notNull().default("SAR"),
	description: text("description").default(""),
	notes: text("notes").default(""),
	approvedBy: text("approved_by").references(() => users$2.id),
	approvedAt: text("approved_at"),
	lockedBy: text("locked_by").references(() => users$2.id),
	lockedAt: text("locked_at"),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var budgetLines$2 = sqliteTable("budget_lines", {
	id: text("id").primaryKey(),
	budgetId: text("budget_id").notNull().references(() => budgets$2.id, { onDelete: "cascade" }),
	lineNumber: integer("line_number").notNull(),
	accountId: text("account_id").references(() => accounts$2.id),
	costCenterId: text("cost_center_id").references(() => costCenters$2.id),
	projectId: text("project_id").references(() => projects$2.id),
	plannedAmount: real("planned_amount").notNull().default(0),
	actualAmount: real("actual_amount").notNull().default(0),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
var fiscalPeriods$2 = sqliteTable("fiscal_periods", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	startDate: text("start_date").notNull().default(""),
	endDate: text("end_date").notNull().default(""),
	status: text("status").notNull().default("مفتوحة"),
	closedAt: text("closed_at"),
	closedById: text("closed_by_id"),
	closedByName: text("closed_by_name"),
	reopenedAt: text("reopened_at"),
	reopenedById: text("reopened_by_id"),
	reopenedByName: text("reopened_by_name"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var approvals$2 = sqliteTable("approvals", {
	id: text("id").primaryKey(),
	type: text("type").notNull(),
	subject: text("subject").notNull(),
	requester: text("requester").notNull(),
	amount: real("amount").notNull().default(0),
	status: text("status").notNull().default("بانتظار موافقتي"),
	priority: text("priority").notNull().default("متوسطة"),
	level: integer("level").notNull().default(1),
	projectId: text("project_id").references(() => projects$2.id),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
var suppliers$2 = sqliteTable("suppliers", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	activity: text("activity").default(""),
	phone: text("phone"),
	email: text("email"),
	taxNumber: text("tax_number").default(""),
	contactPerson: text("contact_person").default(""),
	address: text("address").default(""),
	rating: real("rating").notNull().default(0),
	balance: real("balance").notNull().default(0),
	notes: text("notes").default(""),
	status: text("status").notNull().default("نشط"),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var purchaseRequests$2 = sqliteTable("purchase_requests", {
	id: text("id").primaryKey(),
	subject: text("subject").notNull(),
	department: text("department").notNull(),
	priority: text("priority").notNull().default("متوسطة"),
	status: text("status").notNull().default("مسودة"),
	requester: text("requester").default(""),
	amount: real("amount").notNull().default(0),
	deliveryDate: text("delivery_date").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var purchaseOrders$2 = sqliteTable("purchase_orders", {
	id: text("id").primaryKey(),
	supplierId: text("supplier_id").references(() => suppliers$2.id),
	requestId: text("request_id").references(() => purchaseRequests$2.id),
	subject: text("subject").notNull(),
	date: text("date").notNull().default(""),
	deliveryDate: text("delivery_date").default(""),
	status: text("status").notNull().default("مسودة"),
	total: real("total").notNull().default(0),
	receivedAmount: real("received_amount").notNull().default(0),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var purchaseOrderLines$2 = sqliteTable("purchase_order_lines", {
	id: text("id").primaryKey(),
	orderId: text("order_id").notNull().references(() => purchaseOrders$2.id, { onDelete: "cascade" }),
	lineNumber: integer("line_number").notNull(),
	itemId: text("item_id").references(() => inventoryItems$2.id),
	description: text("description").notNull().default(""),
	quantity: real("quantity").notNull().default(0),
	unitPrice: real("unit_price").notNull().default(0),
	receivedQuantity: real("received_quantity").notNull().default(0),
	unit: text("unit").default(""),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
var quotes$2 = sqliteTable("quotes", {
	id: text("id").primaryKey(),
	requestId: text("request_id").references(() => purchaseRequests$2.id),
	supplierId: text("supplier_id").references(() => suppliers$2.id),
	supplier: text("supplier").notNull(),
	price: real("price").notNull().default(0),
	delivery: text("delivery").default(""),
	warranty: text("warranty").default(""),
	rating: real("rating").notNull().default(0),
	winner: integer("winner", { mode: "boolean" }).notNull().default(false),
	status: text("status").notNull().default("بانتظار"),
	validUntil: text("valid_until").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var inventoryItems$2 = sqliteTable("inventory_items", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	sku: text("sku").default(""),
	unit: text("unit").notNull().default("قطعة"),
	category: text("category").default(""),
	warehouseId: text("warehouse_id"),
	quantity: real("quantity").notNull().default(0),
	minQuantity: real("min_quantity").notNull().default(0),
	price: real("price").notNull().default(0),
	status: text("status").notNull().default("نشط"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var warehouses$2 = sqliteTable("warehouses", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	location: text("location").default(""),
	manager: text("manager").default(""),
	capacity: real("capacity").notNull().default(0),
	occupancy: real("occupancy").notNull().default(0),
	status: text("status").notNull().default("نشط"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var stockMovements$2 = sqliteTable("stock_movements", {
	id: text("id").primaryKey(),
	itemId: text("item_id").notNull().references(() => inventoryItems$2.id),
	warehouseId: text("warehouse_id").references(() => warehouses$2.id),
	type: text("type").notNull(),
	quantity: real("quantity").notNull().default(0),
	balanceAfter: real("balance_after").notNull().default(0),
	relatedWarehouseId: text("related_warehouse_id").references(() => warehouses$2.id),
	relatedStocktakeId: text("related_stocktake_id"),
	sourceType: text("source_type"),
	sourceId: text("source_id"),
	reference: text("reference").default(""),
	date: text("date").notNull().default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default("")
});
var stocktakes$2 = sqliteTable("stocktakes", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	warehouseId: text("warehouse_id").references(() => warehouses$2.id),
	date: text("date").notNull().default(""),
	status: text("status").notNull().default("مسودة"),
	approvedBy: text("approved_by").references(() => users$2.id),
	approvedAt: text("approved_at"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var stocktakeLines$2 = sqliteTable("stocktake_lines", {
	id: text("id").primaryKey(),
	stocktakeId: text("stocktake_id").notNull().references(() => stocktakes$2.id, { onDelete: "cascade" }),
	itemId: text("item_id").notNull().references(() => inventoryItems$2.id),
	systemQuantity: real("system_quantity").notNull().default(0),
	countedQuantity: real("counted_quantity").notNull().default(0),
	difference: real("difference").notNull().default(0),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
var grants$2 = sqliteTable("grants", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	donor: text("donor").notNull(),
	amount: real("amount").notNull().default(0),
	status: text("status").notNull().default("معلق"),
	startDate: text("start_date").default(""),
	endDate: text("end_date").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default("")
});
var endowments$2 = sqliteTable("endowments", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	type: text("type").notNull().default("وقف عام"),
	value: real("value").notNull().default(0),
	returns: real("returns").notNull().default(0),
	status: text("status").notNull().default("نشط"),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
var memberships$2 = sqliteTable("memberships", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	role: text("role").notNull().default("عضو"),
	type: text("type").notNull().default("مجلس إدارة"),
	phone: text("phone"),
	email: text("email"),
	status: text("status").notNull().default("نشط"),
	joinedAt: text("joined_at").default(""),
	createdAt: text("created_at").notNull().default("")
});
var meetings$2 = sqliteTable("meetings", {
	id: text("id").primaryKey(),
	title: text("title").notNull(),
	date: text("date").notNull().default(""),
	location: text("location").default(""),
	attendees: text("attendees").default("[]"),
	status: text("status").notNull().default("مجدول"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default("")
});
var auditLog$2 = sqliteTable("audit_log", {
	id: text("id").primaryKey(),
	userId: text("user_id").references(() => users$2.id),
	userName: text("user_name").notNull().default(""),
	action: text("action").notNull(),
	entityType: text("entity_type").notNull(),
	entityId: text("entity_id").notNull(),
	description: text("description").default(""),
	before: text("before"),
	after: text("after"),
	ip: text("ip").default(""),
	timestamp: text("timestamp").notNull().default("")
});
var fixedAssets$2 = sqliteTable("fixed_assets", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	code: text("code").default(""),
	category: text("category").default(""),
	location: text("location").default(""),
	cost: real("cost").notNull().default(0),
	salvageValue: real("salvage_value").notNull().default(0),
	usefulLifeMonths: integer("useful_life_months").notNull().default(60),
	accumulatedDepreciation: real("accumulated_depreciation").notNull().default(0),
	depreciationMethod: text("depreciation_method").notNull().default("قسط ثابت"),
	status: text("status").notNull().default("نشط"),
	condition: text("condition").default("جيد"),
	purchaseDate: text("purchase_date").default(""),
	supplierId: text("supplier_id").references(() => suppliers$2.id),
	serialNumber: text("serial_number").default(""),
	responsiblePerson: text("responsible_person").default(""),
	sourceType: text("source_type"),
	sourceId: text("source_id"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var assetDepreciations$2 = sqliteTable("asset_depreciations", {
	id: text("id").primaryKey(),
	assetId: text("asset_id").notNull().references(() => fixedAssets$2.id, { onDelete: "cascade" }),
	date: text("date").notNull().default(""),
	amount: real("amount").notNull().default(0),
	bookValueAfter: real("book_value_after").notNull().default(0),
	method: text("method").notNull().default("قسط ثابت"),
	notes: text("notes").default(""),
	sourceType: text("source_type"),
	sourceId: text("source_id"),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default("")
});
var assetMovements$2 = sqliteTable("asset_movements", {
	id: text("id").primaryKey(),
	assetId: text("asset_id").notNull().references(() => fixedAssets$2.id, { onDelete: "cascade" }),
	type: text("type").notNull(),
	fromLocation: text("from_location").default(""),
	toLocation: text("to_location").default(""),
	fromResponsible: text("from_responsible").default(""),
	toResponsible: text("to_responsible").default(""),
	cost: real("cost").notNull().default(0),
	date: text("date").notNull().default(""),
	reason: text("reason").default(""),
	notes: text("notes").default(""),
	sourceType: text("source_type"),
	sourceId: text("source_id"),
	createdBy: text("created_by").references(() => users$2.id),
	createdAt: text("created_at").notNull().default("")
});
var schema_pg_exports = /* @__PURE__ */ __exportAll({
	accounts: () => accounts$1,
	aidRecords: () => aidRecords$1,
	approvals: () => approvals$1,
	assetDepreciations: () => assetDepreciations$1,
	assetMovements: () => assetMovements$1,
	auditLog: () => auditLog$1,
	beneficiaries: () => beneficiaries$1,
	branches: () => branches$1,
	budgetLines: () => budgetLines$1,
	budgets: () => budgets$1,
	campaigns: () => campaigns$1,
	costCenters: () => costCenters$1,
	donations: () => donations$1,
	donors: () => donors$1,
	endowments: () => endowments$1,
	fiscalPeriods: () => fiscalPeriods$1,
	fixedAssets: () => fixedAssets$1,
	grants: () => grants$1,
	inventoryItems: () => inventoryItems$1,
	journalEntries: () => journalEntries$1,
	journalLines: () => journalLines$1,
	meetings: () => meetings$1,
	memberships: () => memberships$1,
	projects: () => projects$1,
	purchaseOrderLines: () => purchaseOrderLines$1,
	purchaseOrders: () => purchaseOrders$1,
	purchaseRequests: () => purchaseRequests$1,
	quotes: () => quotes$1,
	receipts: () => receipts$1,
	roles: () => roles$1,
	sessions: () => sessions$1,
	stockMovements: () => stockMovements$1,
	stocktakeLines: () => stocktakeLines$1,
	stocktakes: () => stocktakes$1,
	suppliers: () => suppliers$1,
	users: () => users$1,
	warehouses: () => warehouses$1
});
var users$1 = pgTable("users", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	email: text$1("email").notNull().unique(),
	password: text$1("password").notNull(),
	phone: text$1("phone"),
	role: text$1("role").notNull().default("employee"),
	branchId: text$1("branch_id"),
	status: text$1("status").notNull().default("active"),
	avatar: text$1("avatar"),
	createdAt: text$1("created_at").notNull().default(""),
	lastLogin: text$1("last_login")
});
var roles$1 = pgTable("roles", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	description: text$1("description"),
	permissions: text$1("permissions").notNull().default("[]"),
	createdAt: text$1("created_at").notNull().default("")
});
var sessions$1 = pgTable("sessions", {
	id: text$1("id").primaryKey(),
	userId: text$1("user_id").notNull().references(() => users$1.id),
	token: text$1("token").notNull().unique(),
	expiresAt: text$1("expires_at").notNull(),
	createdAt: text$1("created_at").notNull().default("")
});
var branches$1 = pgTable("branches", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	city: text$1("city").notNull(),
	manager: text$1("manager"),
	phone: text$1("phone"),
	email: text$1("email"),
	status: text$1("status").notNull().default("active"),
	createdAt: text$1("created_at").notNull().default("")
});
var donors$1 = pgTable("donors", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	type: text$1("type").notNull().default("فرد"),
	email: text$1("email"),
	phone: text$1("phone"),
	city: text$1("city").default(""),
	address: text$1("address").default(""),
	tag: text$1("tag").default("برونزي"),
	totalDonations: doublePrecision("total_donations").notNull().default(0),
	donationCount: integer$1("donation_count").notNull().default(0),
	lastDonation: text$1("last_donation"),
	recurring: boolean("recurring").notNull().default(false),
	notes: text$1("notes").default(""),
	status: text$1("status").notNull().default("نشط"),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var campaigns$1 = pgTable("campaigns", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	goal: doublePrecision("goal").notNull().default(0),
	raised: doublePrecision("raised").notNull().default(0),
	startDate: text$1("start_date").default(""),
	endDate: text$1("end_date").default(""),
	status: text$1("status").notNull().default("مخطط"),
	description: text$1("description").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default("")
});
var projects$1 = pgTable("projects", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	code: text$1("code").default(""),
	type: text$1("type").default(""),
	category: text$1("category").default(""),
	branch: text$1("branch").default(""),
	manager: text$1("manager").notNull(),
	budget: doublePrecision("budget").notNull().default(0),
	spent: doublePrecision("spent").notNull().default(0),
	donations: doublePrecision("donations").notNull().default(0),
	beneficiaryCount: integer$1("beneficiary_count").notNull().default(0),
	progress: integer$1("progress").notNull().default(0),
	status: text$1("status").notNull().default("مخطط"),
	startDate: text$1("start_date").default(""),
	endDate: text$1("end_date").default(""),
	description: text$1("description").default(""),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var donations$1 = pgTable("donations", {
	id: text$1("id").primaryKey(),
	donorId: text$1("donor_id").notNull().references(() => donors$1.id),
	projectId: text$1("project_id").references(() => projects$1.id),
	campaignId: text$1("campaign_id").references(() => campaigns$1.id),
	amount: doublePrecision("amount").notNull(),
	method: text$1("method").notNull().default("نقدي"),
	channel: text$1("channel").notNull().default("مباشر"),
	status: text$1("status").notNull().default("مسودة"),
	receiptId: text$1("receipt_id"),
	notes: text$1("notes").default(""),
	date: text$1("date").notNull().default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var beneficiaries$1 = pgTable("beneficiaries", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	fileNumber: text$1("file_number").default(""),
	idNumber: text$1("id_number").default(""),
	phone: text$1("phone"),
	city: text$1("city").default(""),
	address: text$1("address").default(""),
	category: text$1("category").notNull().default("أسر محتاجة"),
	status: text$1("status").notNull().default("جديد"),
	familyMembers: integer$1("family_members").notNull().default(1),
	monthlyIncome: doublePrecision("monthly_income").notNull().default(0),
	maritalStatus: text$1("marital_status").default(""),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var aidRecords$1 = pgTable("aid_records", {
	id: text$1("id").primaryKey(),
	beneficiaryId: text$1("beneficiary_id").notNull().references(() => beneficiaries$1.id),
	projectId: text$1("project_id").references(() => projects$1.id),
	type: text$1("type").notNull().default("مساعدة عاجلة"),
	amount: doublePrecision("amount").notNull().default(0),
	status: text$1("status").notNull().default("بانتظار الموافقة"),
	date: text$1("date").notNull().default(""),
	approvedBy: text$1("approved_by").references(() => users$1.id),
	approvedAt: text$1("approved_at"),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default(""),
	deliveredAt: text$1("delivered_at"),
	deliveredBy: text$1("delivered_by").references(() => users$1.id),
	deliveryMethod: text$1("delivery_method").default(""),
	deliveryNotes: text$1("delivery_notes").default("")
});
var receipts$1 = pgTable("receipts", {
	id: text$1("id").primaryKey(),
	donationId: text$1("donation_id").references(() => donations$1.id),
	number: text$1("number").notNull().unique(),
	amount: doublePrecision("amount").notNull(),
	date: text$1("date").notNull().default(""),
	type: text$1("type").notNull().default("تبرع"),
	status: text$1("status").notNull().default("مرحّل"),
	printed: boolean("printed").notNull().default(false),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default("")
});
var accounts$1 = pgTable("accounts", {
	id: text$1("id").primaryKey(),
	code: text$1("code").notNull(),
	name: text$1("name").notNull(),
	type: text$1("type").notNull().default("تفصيلي"),
	level: integer$1("level").notNull().default(1),
	parentId: text$1("parent_id"),
	currency: text$1("currency").notNull().default("SAR"),
	balance: doublePrecision("balance").notNull().default(0),
	postable: boolean("postable").notNull().default(true),
	status: text$1("status").notNull().default("نشط"),
	description: text$1("description").default(""),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var journalEntries$1 = pgTable("journal_entries", {
	id: text$1("id").primaryKey(),
	number: text$1("number").notNull().unique(),
	date: text$1("date").notNull().default(""),
	description: text$1("description").notNull().default(""),
	debitAccount: text$1("debit_account").notNull(),
	creditAccount: text$1("credit_account").notNull(),
	amount: doublePrecision("amount").notNull().default(0),
	fund: text$1("fund").notNull().default("مقيد"),
	currency: text$1("currency").notNull().default("SAR"),
	projectId: text$1("project_id").references(() => projects$1.id),
	sourceType: text$1("source_type"),
	sourceId: text$1("source_id"),
	status: text$1("status").notNull().default("مسودة"),
	postedBy: text$1("posted_by").references(() => users$1.id),
	postedAt: text$1("posted_at"),
	reversedBy: text$1("reversed_by"),
	reversedAt: text$1("reversed_at"),
	reversedOf: text$1("reversed_of"),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var journalLines$1 = pgTable("journal_lines", {
	id: text$1("id").primaryKey(),
	journalEntryId: text$1("journal_entry_id").notNull().references(() => journalEntries$1.id, { onDelete: "cascade" }),
	lineNumber: integer$1("line_number").notNull(),
	accountId: text$1("account_id").notNull().references(() => accounts$1.id),
	description: text$1("description").default(""),
	debit: doublePrecision("debit").notNull().default(0),
	credit: doublePrecision("credit").notNull().default(0),
	costCenterId: text$1("cost_center_id").references(() => costCenters$1.id),
	projectId: text$1("project_id").references(() => projects$1.id),
	notes: text$1("notes").default(""),
	createdAt: text$1("created_at").notNull().default("")
});
var costCenters$1 = pgTable("cost_centers", {
	id: text$1("id").primaryKey(),
	code: text$1("code").notNull(),
	name: text$1("name").notNull(),
	manager: text$1("manager").default(""),
	budget: doublePrecision("budget").notNull().default(0),
	spent: doublePrecision("spent").notNull().default(0),
	status: text$1("status").notNull().default("نشط"),
	description: text$1("description").default(""),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var budgets$1 = pgTable("budgets", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	year: text$1("year").notNull(),
	amount: doublePrecision("amount").notNull(),
	spent: doublePrecision("spent").notNull().default(0),
	department: text$1("department").default(""),
	status: text$1("status").notNull().default("مخطط"),
	currency: text$1("currency").notNull().default("SAR"),
	description: text$1("description").default(""),
	notes: text$1("notes").default(""),
	approvedBy: text$1("approved_by").references(() => users$1.id),
	approvedAt: text$1("approved_at"),
	lockedBy: text$1("locked_by").references(() => users$1.id),
	lockedAt: text$1("locked_at"),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var budgetLines$1 = pgTable("budget_lines", {
	id: text$1("id").primaryKey(),
	budgetId: text$1("budget_id").notNull().references(() => budgets$1.id, { onDelete: "cascade" }),
	lineNumber: integer$1("line_number").notNull(),
	accountId: text$1("account_id").references(() => accounts$1.id),
	costCenterId: text$1("cost_center_id").references(() => costCenters$1.id),
	projectId: text$1("project_id").references(() => projects$1.id),
	plannedAmount: doublePrecision("planned_amount").notNull().default(0),
	actualAmount: doublePrecision("actual_amount").notNull().default(0),
	notes: text$1("notes").default(""),
	createdAt: text$1("created_at").notNull().default("")
});
var fiscalPeriods$1 = pgTable("fiscal_periods", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	startDate: text$1("start_date").notNull().default(""),
	endDate: text$1("end_date").notNull().default(""),
	status: text$1("status").notNull().default("مفتوحة"),
	closedAt: text$1("closed_at"),
	closedById: text$1("closed_by_id"),
	closedByName: text$1("closed_by_name"),
	reopenedAt: text$1("reopened_at"),
	reopenedById: text$1("reopened_by_id"),
	reopenedByName: text$1("reopened_by_name"),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var approvals$1 = pgTable("approvals", {
	id: text$1("id").primaryKey(),
	type: text$1("type").notNull(),
	subject: text$1("subject").notNull(),
	requester: text$1("requester").notNull(),
	amount: doublePrecision("amount").notNull().default(0),
	status: text$1("status").notNull().default("بانتظار موافقتي"),
	priority: text$1("priority").notNull().default("متوسطة"),
	level: integer$1("level").notNull().default(1),
	projectId: text$1("project_id").references(() => projects$1.id),
	notes: text$1("notes").default(""),
	createdAt: text$1("created_at").notNull().default("")
});
var suppliers$1 = pgTable("suppliers", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	activity: text$1("activity").default(""),
	phone: text$1("phone"),
	email: text$1("email"),
	taxNumber: text$1("tax_number").default(""),
	contactPerson: text$1("contact_person").default(""),
	address: text$1("address").default(""),
	rating: doublePrecision("rating").notNull().default(0),
	balance: doublePrecision("balance").notNull().default(0),
	notes: text$1("notes").default(""),
	status: text$1("status").notNull().default("نشط"),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var purchaseRequests$1 = pgTable("purchase_requests", {
	id: text$1("id").primaryKey(),
	subject: text$1("subject").notNull(),
	department: text$1("department").notNull(),
	priority: text$1("priority").notNull().default("متوسطة"),
	status: text$1("status").notNull().default("مسودة"),
	requester: text$1("requester").default(""),
	amount: doublePrecision("amount").notNull().default(0),
	deliveryDate: text$1("delivery_date").default(""),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var purchaseOrders$1 = pgTable("purchase_orders", {
	id: text$1("id").primaryKey(),
	supplierId: text$1("supplier_id").references(() => suppliers$1.id),
	requestId: text$1("request_id").references(() => purchaseRequests$1.id),
	subject: text$1("subject").notNull(),
	date: text$1("date").notNull().default(""),
	deliveryDate: text$1("delivery_date").default(""),
	status: text$1("status").notNull().default("مسودة"),
	total: doublePrecision("total").notNull().default(0),
	receivedAmount: doublePrecision("received_amount").notNull().default(0),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var purchaseOrderLines$1 = pgTable("purchase_order_lines", {
	id: text$1("id").primaryKey(),
	orderId: text$1("order_id").notNull().references(() => purchaseOrders$1.id, { onDelete: "cascade" }),
	lineNumber: integer$1("line_number").notNull(),
	itemId: text$1("item_id").references(() => inventoryItems$1.id),
	description: text$1("description").notNull().default(""),
	quantity: doublePrecision("quantity").notNull().default(0),
	unitPrice: doublePrecision("unit_price").notNull().default(0),
	receivedQuantity: doublePrecision("received_quantity").notNull().default(0),
	unit: text$1("unit").default(""),
	notes: text$1("notes").default(""),
	createdAt: text$1("created_at").notNull().default("")
});
var quotes$1 = pgTable("quotes", {
	id: text$1("id").primaryKey(),
	requestId: text$1("request_id").references(() => purchaseRequests$1.id),
	supplierId: text$1("supplier_id").references(() => suppliers$1.id),
	supplier: text$1("supplier").notNull(),
	price: doublePrecision("price").notNull().default(0),
	delivery: text$1("delivery").default(""),
	warranty: text$1("warranty").default(""),
	rating: doublePrecision("rating").notNull().default(0),
	winner: boolean("winner").notNull().default(false),
	status: text$1("status").notNull().default("بانتظار"),
	validUntil: text$1("valid_until").default(""),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var inventoryItems$1 = pgTable("inventory_items", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	sku: text$1("sku").default(""),
	unit: text$1("unit").notNull().default("قطعة"),
	category: text$1("category").default(""),
	warehouseId: text$1("warehouse_id"),
	quantity: doublePrecision("quantity").notNull().default(0),
	minQuantity: doublePrecision("min_quantity").notNull().default(0),
	price: doublePrecision("price").notNull().default(0),
	status: text$1("status").notNull().default("نشط"),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var warehouses$1 = pgTable("warehouses", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	location: text$1("location").default(""),
	manager: text$1("manager").default(""),
	capacity: doublePrecision("capacity").notNull().default(0),
	occupancy: doublePrecision("occupancy").notNull().default(0),
	status: text$1("status").notNull().default("نشط"),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var stockMovements$1 = pgTable("stock_movements", {
	id: text$1("id").primaryKey(),
	itemId: text$1("item_id").notNull().references(() => inventoryItems$1.id),
	warehouseId: text$1("warehouse_id").references(() => warehouses$1.id),
	type: text$1("type").notNull(),
	quantity: doublePrecision("quantity").notNull().default(0),
	balanceAfter: doublePrecision("balance_after").notNull().default(0),
	relatedWarehouseId: text$1("related_warehouse_id").references(() => warehouses$1.id),
	relatedStocktakeId: text$1("related_stocktake_id"),
	sourceType: text$1("source_type"),
	sourceId: text$1("source_id"),
	reference: text$1("reference").default(""),
	date: text$1("date").notNull().default(""),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default("")
});
var stocktakes$1 = pgTable("stocktakes", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	warehouseId: text$1("warehouse_id").references(() => warehouses$1.id),
	date: text$1("date").notNull().default(""),
	status: text$1("status").notNull().default("مسودة"),
	approvedBy: text$1("approved_by").references(() => users$1.id),
	approvedAt: text$1("approved_at"),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var stocktakeLines$1 = pgTable("stocktake_lines", {
	id: text$1("id").primaryKey(),
	stocktakeId: text$1("stocktake_id").notNull().references(() => stocktakes$1.id, { onDelete: "cascade" }),
	itemId: text$1("item_id").notNull().references(() => inventoryItems$1.id),
	systemQuantity: doublePrecision("system_quantity").notNull().default(0),
	countedQuantity: doublePrecision("counted_quantity").notNull().default(0),
	difference: doublePrecision("difference").notNull().default(0),
	notes: text$1("notes").default(""),
	createdAt: text$1("created_at").notNull().default("")
});
var grants$1 = pgTable("grants", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	donor: text$1("donor").notNull(),
	amount: doublePrecision("amount").notNull().default(0),
	status: text$1("status").notNull().default("معلق"),
	startDate: text$1("start_date").default(""),
	endDate: text$1("end_date").default(""),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default("")
});
var endowments$1 = pgTable("endowments", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	type: text$1("type").notNull().default("وقف عام"),
	value: doublePrecision("value").notNull().default(0),
	returns: doublePrecision("returns").notNull().default(0),
	status: text$1("status").notNull().default("نشط"),
	notes: text$1("notes").default(""),
	createdAt: text$1("created_at").notNull().default("")
});
var memberships$1 = pgTable("memberships", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	role: text$1("role").notNull().default("عضو"),
	type: text$1("type").notNull().default("مجلس إدارة"),
	phone: text$1("phone"),
	email: text$1("email"),
	status: text$1("status").notNull().default("نشط"),
	joinedAt: text$1("joined_at").default(""),
	createdAt: text$1("created_at").notNull().default("")
});
var meetings$1 = pgTable("meetings", {
	id: text$1("id").primaryKey(),
	title: text$1("title").notNull(),
	date: text$1("date").notNull().default(""),
	location: text$1("location").default(""),
	attendees: text$1("attendees").default("[]"),
	status: text$1("status").notNull().default("مجدول"),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default("")
});
var auditLog$1 = pgTable("audit_log", {
	id: text$1("id").primaryKey(),
	userId: text$1("user_id").references(() => users$1.id),
	userName: text$1("user_name").notNull().default(""),
	action: text$1("action").notNull(),
	entityType: text$1("entity_type").notNull(),
	entityId: text$1("entity_id").notNull(),
	description: text$1("description").default(""),
	before: text$1("before"),
	after: text$1("after"),
	ip: text$1("ip").default(""),
	timestamp: text$1("timestamp").notNull().default("")
});
var fixedAssets$1 = pgTable("fixed_assets", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	code: text$1("code").default(""),
	category: text$1("category").default(""),
	location: text$1("location").default(""),
	cost: doublePrecision("cost").notNull().default(0),
	salvageValue: doublePrecision("salvage_value").notNull().default(0),
	usefulLifeMonths: integer$1("useful_life_months").notNull().default(60),
	accumulatedDepreciation: doublePrecision("accumulated_depreciation").notNull().default(0),
	depreciationMethod: text$1("depreciation_method").notNull().default("قسط ثابت"),
	status: text$1("status").notNull().default("نشط"),
	condition: text$1("condition").default("جيد"),
	purchaseDate: text$1("purchase_date").default(""),
	supplierId: text$1("supplier_id").references(() => suppliers$1.id),
	serialNumber: text$1("serial_number").default(""),
	responsiblePerson: text$1("responsible_person").default(""),
	sourceType: text$1("source_type"),
	sourceId: text$1("source_id"),
	notes: text$1("notes").default(""),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default(""),
	updatedAt: text$1("updated_at").notNull().default("")
});
var assetDepreciations$1 = pgTable("asset_depreciations", {
	id: text$1("id").primaryKey(),
	assetId: text$1("asset_id").notNull().references(() => fixedAssets$1.id, { onDelete: "cascade" }),
	date: text$1("date").notNull().default(""),
	amount: doublePrecision("amount").notNull().default(0),
	bookValueAfter: doublePrecision("book_value_after").notNull().default(0),
	method: text$1("method").notNull().default("قسط ثابت"),
	notes: text$1("notes").default(""),
	sourceType: text$1("source_type"),
	sourceId: text$1("source_id"),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default("")
});
var assetMovements$1 = pgTable("asset_movements", {
	id: text$1("id").primaryKey(),
	assetId: text$1("asset_id").notNull().references(() => fixedAssets$1.id, { onDelete: "cascade" }),
	type: text$1("type").notNull(),
	fromLocation: text$1("from_location").default(""),
	toLocation: text$1("to_location").default(""),
	fromResponsible: text$1("from_responsible").default(""),
	toResponsible: text$1("to_responsible").default(""),
	cost: doublePrecision("cost").notNull().default(0),
	date: text$1("date").notNull().default(""),
	reason: text$1("reason").default(""),
	notes: text$1("notes").default(""),
	sourceType: text$1("source_type"),
	sourceId: text$1("source_id"),
	createdBy: text$1("created_by").references(() => users$1.id),
	createdAt: text$1("created_at").notNull().default("")
});
var DB_PATH = "./data/thawab.db";
var DATABASE_URL = process.env.DATABASE_URL;
function isPgUrl(url) {
	if (!url) return false;
	return url.startsWith("postgres://") || url.startsWith("postgresql://");
}
function isMysqlUrl(url) {
	if (!url) return false;
	return url.startsWith("mysql://") || url.startsWith("mysql2://");
}
function isFileUrl(url) {
	if (!url) return false;
	return url.startsWith("file:");
}
var _dialect;
var _db;
var _pgExecSync = null;
var _libsqlExecSync = null;
function createPgSyncDb() {
	_pgExecSync = createSyncFn(new URL("./pg-worker.mjs", import.meta.url));
	return wrapSync(drizzle(src_default(DATABASE_URL, {
		max: 1,
		prepare: false
	}), { schema: schema_pg_exports }));
}
function createSqliteDb() {
	const dir = dirname(DB_PATH);
	if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
	_libsqlExecSync = createSyncFn(new URL("./libsql-worker.mjs", import.meta.url));
	return wrapSync(drizzle$1(createClient({ url: `file:${DB_PATH}` }), { schema: schema_sqlite_exports }));
}
function wrapSync(realDb) {
	const execSync = _pgExecSync ?? _libsqlExecSync;
	const proxyCache = /* @__PURE__ */ new WeakMap();
	const wrap = (qb) => {
		if (qb == null || typeof qb !== "object" && typeof qb !== "function") return qb;
		if (qb.__thawabProxy) return qb.__thawabProxy;
		const existing = proxyCache.get(qb);
		if (existing) return existing;
		const proxy = new Proxy(qb, { get(target, prop) {
			if (prop === "all") return () => {
				if (typeof target.toSQL !== "function") throw new Error("Drizzle query has no toSQL(): cannot run sync");
				const compiled = target.toSQL();
				const result = execSync(compiled.sql, compiled.params ?? []);
				return Array.isArray(result) ? result : [];
			};
			if (prop === "run") return () => {
				if (typeof target.toSQL !== "function") return void 0;
				const compiled = target.toSQL();
				execSync(compiled.sql, compiled.params ?? []);
			};
			if (prop === "get") return () => {
				if (typeof target.toSQL !== "function") return void 0;
				const compiled = target.toSQL();
				const result = execSync(compiled.sql, compiled.params ?? []);
				return Array.isArray(result) ? result[0] : void 0;
			};
			const val = target[prop];
			if (typeof val === "function") return (...args) => {
				return wrap(val.apply(target, args));
			};
			return val;
		} });
		proxyCache.set(qb, proxy);
		proxy.__thawabProxy = proxy;
		return proxy;
	};
	return {
		select: (...args) => wrap(realDb.select(...args)),
		insert: (table) => wrap(realDb.insert(table)),
		update: (table) => wrap(realDb.update(table)),
		delete: (table) => wrap(realDb.delete(table)),
		_: realDb._
	};
}
if (isMysqlUrl(DATABASE_URL)) throw new Error("MySQL is not supported in this build. Set DATABASE_URL to a PostgreSQL URL (postgres://...) or leave it unset to use local SQLite for development.");
else if (isPgUrl(DATABASE_URL)) {
	_dialect = "postgres";
	_db = createPgSyncDb();
} else if (isFileUrl(DATABASE_URL)) {
	_dialect = "sqlite";
	_db = createSqliteDb();
} else {
	_dialect = "sqlite";
	_db = createSqliteDb();
}
var dialect = _dialect;
var db = _db;
function runRawSql(sql) {
	if (_dialect === "sqlite") {
		if (!_libsqlExecSync) throw new Error("libsql synckit not initialized");
		_libsqlExecSync(sql);
	} else if (_dialect === "postgres") {
		if (!_pgExecSync) throw new Error("pg synckit not initialized");
		_pgExecSync(sql);
	}
}
var users = sqliteTable("users", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	email: text("email").notNull().unique(),
	password: text("password").notNull(),
	phone: text("phone"),
	role: text("role").notNull().default("employee"),
	branchId: text("branch_id"),
	status: text("status").notNull().default("active"),
	avatar: text("avatar"),
	createdAt: text("created_at").notNull().default(""),
	lastLogin: text("last_login")
});
sqliteTable("roles", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	description: text("description"),
	permissions: text("permissions").notNull().default("[]"),
	createdAt: text("created_at").notNull().default("")
});
var sessions = sqliteTable("sessions", {
	id: text("id").primaryKey(),
	userId: text("user_id").notNull().references(() => users.id),
	token: text("token").notNull().unique(),
	expiresAt: text("expires_at").notNull(),
	createdAt: text("created_at").notNull().default("")
});
sqliteTable("branches", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	city: text("city").notNull(),
	manager: text("manager"),
	phone: text("phone"),
	email: text("email"),
	status: text("status").notNull().default("active"),
	createdAt: text("created_at").notNull().default("")
});
var donors = sqliteTable("donors", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	type: text("type").notNull().default("فرد"),
	email: text("email"),
	phone: text("phone"),
	city: text("city").default(""),
	address: text("address").default(""),
	tag: text("tag").default("برونزي"),
	totalDonations: real("total_donations").notNull().default(0),
	donationCount: integer("donation_count").notNull().default(0),
	lastDonation: text("last_donation"),
	recurring: integer("recurring", { mode: "boolean" }).notNull().default(false),
	notes: text("notes").default(""),
	status: text("status").notNull().default("نشط"),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var campaigns = sqliteTable("campaigns", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	goal: real("goal").notNull().default(0),
	raised: real("raised").notNull().default(0),
	startDate: text("start_date").default(""),
	endDate: text("end_date").default(""),
	status: text("status").notNull().default("مخطط"),
	description: text("description").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default("")
});
var projects = sqliteTable("projects", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	code: text("code").default(""),
	type: text("type").default(""),
	category: text("category").default(""),
	branch: text("branch").default(""),
	manager: text("manager").notNull(),
	budget: real("budget").notNull().default(0),
	spent: real("spent").notNull().default(0),
	donations: real("donations").notNull().default(0),
	beneficiaryCount: integer("beneficiary_count").notNull().default(0),
	progress: integer("progress").notNull().default(0),
	status: text("status").notNull().default("مخطط"),
	startDate: text("start_date").default(""),
	endDate: text("end_date").default(""),
	description: text("description").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var donations = sqliteTable("donations", {
	id: text("id").primaryKey(),
	donorId: text("donor_id").notNull().references(() => donors.id),
	projectId: text("project_id").references(() => projects.id),
	campaignId: text("campaign_id").references(() => campaigns.id),
	amount: real("amount").notNull(),
	method: text("method").notNull().default("نقدي"),
	channel: text("channel").notNull().default("مباشر"),
	status: text("status").notNull().default("مسودة"),
	receiptId: text("receipt_id"),
	notes: text("notes").default(""),
	date: text("date").notNull().default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var beneficiaries = sqliteTable("beneficiaries", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	fileNumber: text("file_number").default(""),
	idNumber: text("id_number").default(""),
	phone: text("phone"),
	city: text("city").default(""),
	address: text("address").default(""),
	category: text("category").notNull().default("أسر محتاجة"),
	status: text("status").notNull().default("جديد"),
	familyMembers: integer("family_members").notNull().default(1),
	monthlyIncome: real("monthly_income").notNull().default(0),
	maritalStatus: text("marital_status").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var aidRecords = sqliteTable("aid_records", {
	id: text("id").primaryKey(),
	beneficiaryId: text("beneficiary_id").notNull().references(() => beneficiaries.id),
	projectId: text("project_id").references(() => projects.id),
	type: text("type").notNull().default("مساعدة عاجلة"),
	amount: real("amount").notNull().default(0),
	status: text("status").notNull().default("بانتظار الموافقة"),
	date: text("date").notNull().default(""),
	approvedBy: text("approved_by").references(() => users.id),
	approvedAt: text("approved_at"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default(""),
	deliveredAt: text("delivered_at"),
	deliveredBy: text("delivered_by").references(() => users.id),
	deliveryMethod: text("delivery_method").default(""),
	deliveryNotes: text("delivery_notes").default("")
});
var receipts = sqliteTable("receipts", {
	id: text("id").primaryKey(),
	donationId: text("donation_id").references(() => donations.id),
	number: text("number").notNull().unique(),
	amount: real("amount").notNull(),
	date: text("date").notNull().default(""),
	type: text("type").notNull().default("تبرع"),
	status: text("status").notNull().default("مرحّل"),
	printed: integer("printed", { mode: "boolean" }).notNull().default(false),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default("")
});
var accounts = sqliteTable("accounts", {
	id: text("id").primaryKey(),
	code: text("code").notNull(),
	name: text("name").notNull(),
	type: text("type").notNull().default("تفصيلي"),
	level: integer("level").notNull().default(1),
	parentId: text("parent_id"),
	currency: text("currency").notNull().default("SAR"),
	balance: real("balance").notNull().default(0),
	postable: integer("postable", { mode: "boolean" }).notNull().default(true),
	status: text("status").notNull().default("نشط"),
	description: text("description").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var journalEntries = sqliteTable("journal_entries", {
	id: text("id").primaryKey(),
	number: text("number").notNull().unique(),
	date: text("date").notNull().default(""),
	description: text("description").notNull().default(""),
	debitAccount: text("debit_account").notNull(),
	creditAccount: text("credit_account").notNull(),
	amount: real("amount").notNull().default(0),
	fund: text("fund").notNull().default("مقيد"),
	currency: text("currency").notNull().default("SAR"),
	projectId: text("project_id").references(() => projects.id),
	sourceType: text("source_type"),
	sourceId: text("source_id"),
	status: text("status").notNull().default("مسودة"),
	postedBy: text("posted_by").references(() => users.id),
	postedAt: text("posted_at"),
	reversedBy: text("reversed_by"),
	reversedAt: text("reversed_at"),
	reversedOf: text("reversed_of"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var journalLines = sqliteTable("journal_lines", {
	id: text("id").primaryKey(),
	journalEntryId: text("journal_entry_id").notNull().references(() => journalEntries.id, { onDelete: "cascade" }),
	lineNumber: integer("line_number").notNull(),
	accountId: text("account_id").notNull().references(() => accounts.id),
	description: text("description").default(""),
	debit: real("debit").notNull().default(0),
	credit: real("credit").notNull().default(0),
	costCenterId: text("cost_center_id").references(() => costCenters.id),
	projectId: text("project_id").references(() => projects.id),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
var costCenters = sqliteTable("cost_centers", {
	id: text("id").primaryKey(),
	code: text("code").notNull(),
	name: text("name").notNull(),
	manager: text("manager").default(""),
	budget: real("budget").notNull().default(0),
	spent: real("spent").notNull().default(0),
	status: text("status").notNull().default("نشط"),
	description: text("description").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var budgets = sqliteTable("budgets", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	year: text("year").notNull(),
	amount: real("amount").notNull(),
	spent: real("spent").notNull().default(0),
	department: text("department").default(""),
	status: text("status").notNull().default("مخطط"),
	currency: text("currency").notNull().default("SAR"),
	description: text("description").default(""),
	notes: text("notes").default(""),
	approvedBy: text("approved_by").references(() => users.id),
	approvedAt: text("approved_at"),
	lockedBy: text("locked_by").references(() => users.id),
	lockedAt: text("locked_at"),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var budgetLines = sqliteTable("budget_lines", {
	id: text("id").primaryKey(),
	budgetId: text("budget_id").notNull().references(() => budgets.id, { onDelete: "cascade" }),
	lineNumber: integer("line_number").notNull(),
	accountId: text("account_id").references(() => accounts.id),
	costCenterId: text("cost_center_id").references(() => costCenters.id),
	projectId: text("project_id").references(() => projects.id),
	plannedAmount: real("planned_amount").notNull().default(0),
	actualAmount: real("actual_amount").notNull().default(0),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
var fiscalPeriods = sqliteTable("fiscal_periods", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	startDate: text("start_date").notNull().default(""),
	endDate: text("end_date").notNull().default(""),
	status: text("status").notNull().default("مفتوحة"),
	closedAt: text("closed_at"),
	closedById: text("closed_by_id"),
	closedByName: text("closed_by_name"),
	reopenedAt: text("reopened_at"),
	reopenedById: text("reopened_by_id"),
	reopenedByName: text("reopened_by_name"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
sqliteTable("approvals", {
	id: text("id").primaryKey(),
	type: text("type").notNull(),
	subject: text("subject").notNull(),
	requester: text("requester").notNull(),
	amount: real("amount").notNull().default(0),
	status: text("status").notNull().default("بانتظار موافقتي"),
	priority: text("priority").notNull().default("متوسطة"),
	level: integer("level").notNull().default(1),
	projectId: text("project_id").references(() => projects.id),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
var suppliers = sqliteTable("suppliers", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	activity: text("activity").default(""),
	phone: text("phone"),
	email: text("email"),
	taxNumber: text("tax_number").default(""),
	contactPerson: text("contact_person").default(""),
	address: text("address").default(""),
	rating: real("rating").notNull().default(0),
	balance: real("balance").notNull().default(0),
	notes: text("notes").default(""),
	status: text("status").notNull().default("نشط"),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var purchaseRequests = sqliteTable("purchase_requests", {
	id: text("id").primaryKey(),
	subject: text("subject").notNull(),
	department: text("department").notNull(),
	priority: text("priority").notNull().default("متوسطة"),
	status: text("status").notNull().default("مسودة"),
	requester: text("requester").default(""),
	amount: real("amount").notNull().default(0),
	deliveryDate: text("delivery_date").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var purchaseOrders = sqliteTable("purchase_orders", {
	id: text("id").primaryKey(),
	supplierId: text("supplier_id").references(() => suppliers.id),
	requestId: text("request_id").references(() => purchaseRequests.id),
	subject: text("subject").notNull(),
	date: text("date").notNull().default(""),
	deliveryDate: text("delivery_date").default(""),
	status: text("status").notNull().default("مسودة"),
	total: real("total").notNull().default(0),
	receivedAmount: real("received_amount").notNull().default(0),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var purchaseOrderLines = sqliteTable("purchase_order_lines", {
	id: text("id").primaryKey(),
	orderId: text("order_id").notNull().references(() => purchaseOrders.id, { onDelete: "cascade" }),
	lineNumber: integer("line_number").notNull(),
	itemId: text("item_id").references(() => inventoryItems.id),
	description: text("description").notNull().default(""),
	quantity: real("quantity").notNull().default(0),
	unitPrice: real("unit_price").notNull().default(0),
	receivedQuantity: real("received_quantity").notNull().default(0),
	unit: text("unit").default(""),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
var quotes = sqliteTable("quotes", {
	id: text("id").primaryKey(),
	requestId: text("request_id").references(() => purchaseRequests.id),
	supplierId: text("supplier_id").references(() => suppliers.id),
	supplier: text("supplier").notNull(),
	price: real("price").notNull().default(0),
	delivery: text("delivery").default(""),
	warranty: text("warranty").default(""),
	rating: real("rating").notNull().default(0),
	winner: integer("winner", { mode: "boolean" }).notNull().default(false),
	status: text("status").notNull().default("بانتظار"),
	validUntil: text("valid_until").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var inventoryItems = sqliteTable("inventory_items", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	sku: text("sku").default(""),
	unit: text("unit").notNull().default("قطعة"),
	category: text("category").default(""),
	warehouseId: text("warehouse_id"),
	quantity: real("quantity").notNull().default(0),
	minQuantity: real("min_quantity").notNull().default(0),
	price: real("price").notNull().default(0),
	status: text("status").notNull().default("نشط"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var warehouses = sqliteTable("warehouses", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	location: text("location").default(""),
	manager: text("manager").default(""),
	capacity: real("capacity").notNull().default(0),
	occupancy: real("occupancy").notNull().default(0),
	status: text("status").notNull().default("نشط"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var stockMovements = sqliteTable("stock_movements", {
	id: text("id").primaryKey(),
	itemId: text("item_id").notNull().references(() => inventoryItems.id),
	warehouseId: text("warehouse_id").references(() => warehouses.id),
	type: text("type").notNull(),
	quantity: real("quantity").notNull().default(0),
	balanceAfter: real("balance_after").notNull().default(0),
	relatedWarehouseId: text("related_warehouse_id").references(() => warehouses.id),
	relatedStocktakeId: text("related_stocktake_id"),
	sourceType: text("source_type"),
	sourceId: text("source_id"),
	reference: text("reference").default(""),
	date: text("date").notNull().default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default("")
});
var stocktakes = sqliteTable("stocktakes", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	warehouseId: text("warehouse_id").references(() => warehouses.id),
	date: text("date").notNull().default(""),
	status: text("status").notNull().default("مسودة"),
	approvedBy: text("approved_by").references(() => users.id),
	approvedAt: text("approved_at"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var stocktakeLines = sqliteTable("stocktake_lines", {
	id: text("id").primaryKey(),
	stocktakeId: text("stocktake_id").notNull().references(() => stocktakes.id, { onDelete: "cascade" }),
	itemId: text("item_id").notNull().references(() => inventoryItems.id),
	systemQuantity: real("system_quantity").notNull().default(0),
	countedQuantity: real("counted_quantity").notNull().default(0),
	difference: real("difference").notNull().default(0),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
sqliteTable("grants", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	donor: text("donor").notNull(),
	amount: real("amount").notNull().default(0),
	status: text("status").notNull().default("معلق"),
	startDate: text("start_date").default(""),
	endDate: text("end_date").default(""),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default("")
});
sqliteTable("endowments", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	type: text("type").notNull().default("وقف عام"),
	value: real("value").notNull().default(0),
	returns: real("returns").notNull().default(0),
	status: text("status").notNull().default("نشط"),
	notes: text("notes").default(""),
	createdAt: text("created_at").notNull().default("")
});
sqliteTable("memberships", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	role: text("role").notNull().default("عضو"),
	type: text("type").notNull().default("مجلس إدارة"),
	phone: text("phone"),
	email: text("email"),
	status: text("status").notNull().default("نشط"),
	joinedAt: text("joined_at").default(""),
	createdAt: text("created_at").notNull().default("")
});
sqliteTable("meetings", {
	id: text("id").primaryKey(),
	title: text("title").notNull(),
	date: text("date").notNull().default(""),
	location: text("location").default(""),
	attendees: text("attendees").default("[]"),
	status: text("status").notNull().default("مجدول"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default("")
});
var auditLog = sqliteTable("audit_log", {
	id: text("id").primaryKey(),
	userId: text("user_id").references(() => users.id),
	userName: text("user_name").notNull().default(""),
	action: text("action").notNull(),
	entityType: text("entity_type").notNull(),
	entityId: text("entity_id").notNull(),
	description: text("description").default(""),
	before: text("before"),
	after: text("after"),
	ip: text("ip").default(""),
	timestamp: text("timestamp").notNull().default("")
});
var fixedAssets = sqliteTable("fixed_assets", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	code: text("code").default(""),
	category: text("category").default(""),
	location: text("location").default(""),
	cost: real("cost").notNull().default(0),
	salvageValue: real("salvage_value").notNull().default(0),
	usefulLifeMonths: integer("useful_life_months").notNull().default(60),
	accumulatedDepreciation: real("accumulated_depreciation").notNull().default(0),
	depreciationMethod: text("depreciation_method").notNull().default("قسط ثابت"),
	status: text("status").notNull().default("نشط"),
	condition: text("condition").default("جيد"),
	purchaseDate: text("purchase_date").default(""),
	supplierId: text("supplier_id").references(() => suppliers.id),
	serialNumber: text("serial_number").default(""),
	responsiblePerson: text("responsible_person").default(""),
	sourceType: text("source_type"),
	sourceId: text("source_id"),
	notes: text("notes").default(""),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default(""),
	updatedAt: text("updated_at").notNull().default("")
});
var assetDepreciations = sqliteTable("asset_depreciations", {
	id: text("id").primaryKey(),
	assetId: text("asset_id").notNull().references(() => fixedAssets.id, { onDelete: "cascade" }),
	date: text("date").notNull().default(""),
	amount: real("amount").notNull().default(0),
	bookValueAfter: real("book_value_after").notNull().default(0),
	method: text("method").notNull().default("قسط ثابت"),
	notes: text("notes").default(""),
	sourceType: text("source_type"),
	sourceId: text("source_id"),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default("")
});
var assetMovements = sqliteTable("asset_movements", {
	id: text("id").primaryKey(),
	assetId: text("asset_id").notNull().references(() => fixedAssets.id, { onDelete: "cascade" }),
	type: text("type").notNull(),
	fromLocation: text("from_location").default(""),
	toLocation: text("to_location").default(""),
	fromResponsible: text("from_responsible").default(""),
	toResponsible: text("to_responsible").default(""),
	cost: real("cost").notNull().default(0),
	date: text("date").notNull().default(""),
	reason: text("reason").default(""),
	notes: text("notes").default(""),
	sourceType: text("source_type"),
	sourceId: text("source_id"),
	createdBy: text("created_by").references(() => users.id),
	createdAt: text("created_at").notNull().default("")
});
var SQLITE_DDL = `
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL,
      phone TEXT,
      role TEXT NOT NULL DEFAULT 'employee',
      branch_id TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      avatar TEXT,
      created_at TEXT NOT NULL DEFAULT '',
      last_login TEXT
    );

    CREATE TABLE IF NOT EXISTS roles (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      permissions TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      token TEXT NOT NULL UNIQUE,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS branches (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      city TEXT NOT NULL,
      manager TEXT,
      phone TEXT,
      email TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS donors (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'فرد',
      email TEXT,
      phone TEXT,
      city TEXT DEFAULT '',
      address TEXT DEFAULT '',
      tag TEXT DEFAULT 'برونزي',
      total_donations REAL NOT NULL DEFAULT 0,
      donation_count INTEGER NOT NULL DEFAULT 0,
      last_donation TEXT,
      recurring INTEGER NOT NULL DEFAULT 0,
      notes TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'نشط',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS campaigns (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      goal REAL NOT NULL DEFAULT 0,
      raised REAL NOT NULL DEFAULT 0,
      start_date TEXT DEFAULT '',
      end_date TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'مخطط',
      description TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      code TEXT DEFAULT '',
      type TEXT DEFAULT '',
      category TEXT DEFAULT '',
      branch TEXT DEFAULT '',
      manager TEXT NOT NULL,
      budget REAL NOT NULL DEFAULT 0,
      spent REAL NOT NULL DEFAULT 0,
      donations REAL NOT NULL DEFAULT 0,
      beneficiary_count INTEGER NOT NULL DEFAULT 0,
      progress INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'مخطط',
      start_date TEXT DEFAULT '',
      end_date TEXT DEFAULT '',
      description TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS donations (
      id TEXT PRIMARY KEY,
      donor_id TEXT NOT NULL REFERENCES donors(id),
      project_id TEXT REFERENCES projects(id),
      campaign_id TEXT REFERENCES campaigns(id),
      amount REAL NOT NULL,
      method TEXT NOT NULL DEFAULT 'نقدي',
      channel TEXT NOT NULL DEFAULT 'مباشر',
      status TEXT NOT NULL DEFAULT 'مسودة',
      receipt_id TEXT,
      notes TEXT DEFAULT '',
      date TEXT NOT NULL DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS beneficiaries (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      file_number TEXT DEFAULT '',
      id_number TEXT DEFAULT '',
      phone TEXT,
      city TEXT DEFAULT '',
      address TEXT DEFAULT '',
      category TEXT NOT NULL DEFAULT 'أسر محتاجة',
      status TEXT NOT NULL DEFAULT 'جديد',
      family_members INTEGER NOT NULL DEFAULT 1,
      monthly_income REAL NOT NULL DEFAULT 0,
      marital_status TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS aid_records (
      id TEXT PRIMARY KEY,
      beneficiary_id TEXT NOT NULL REFERENCES beneficiaries(id),
      project_id TEXT REFERENCES projects(id),
      type TEXT NOT NULL DEFAULT 'مساعدة عاجلة',
      amount REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'بانتظار الموافقة',
      date TEXT NOT NULL DEFAULT '',
      approved_by TEXT REFERENCES users(id),
      approved_at TEXT,
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS receipts (
      id TEXT PRIMARY KEY,
      donation_id TEXT REFERENCES donations(id),
      number TEXT NOT NULL UNIQUE,
      amount REAL NOT NULL,
      date TEXT NOT NULL DEFAULT '',
      type TEXT NOT NULL DEFAULT 'تبرع',
      status TEXT NOT NULL DEFAULT 'مرحّل',
      printed INTEGER NOT NULL DEFAULT 0,
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS accounts (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'تفصيلي',
      level INTEGER NOT NULL DEFAULT 1,
      parent_id TEXT,
      currency TEXT NOT NULL DEFAULT 'SAR',
      balance REAL NOT NULL DEFAULT 0,
      postable INTEGER NOT NULL DEFAULT 1,
      status TEXT NOT NULL DEFAULT 'نشط',
      description TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS journal_entries (
      id TEXT PRIMARY KEY,
      number TEXT NOT NULL UNIQUE,
      date TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      debit_account TEXT NOT NULL DEFAULT '',
      credit_account TEXT NOT NULL DEFAULT '',
      amount REAL NOT NULL DEFAULT 0,
      fund TEXT NOT NULL DEFAULT 'مقيد',
      currency TEXT NOT NULL DEFAULT 'SAR',
      project_id TEXT REFERENCES projects(id),
      source_type TEXT,
      source_id TEXT,
      status TEXT NOT NULL DEFAULT 'مسودة',
      posted_by TEXT REFERENCES users(id),
      posted_at TEXT,
      reversed_by TEXT,
      reversed_at TEXT,
      reversed_of TEXT,
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS journal_lines (
      id TEXT PRIMARY KEY,
      journal_entry_id TEXT NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE,
      line_number INTEGER NOT NULL,
      account_id TEXT NOT NULL REFERENCES accounts(id),
      description TEXT DEFAULT '',
      debit REAL NOT NULL DEFAULT 0,
      credit REAL NOT NULL DEFAULT 0,
      cost_center_id TEXT REFERENCES cost_centers(id),
      project_id TEXT REFERENCES projects(id),
      notes TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS cost_centers (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL,
      name TEXT NOT NULL,
      manager TEXT DEFAULT '',
      budget REAL NOT NULL DEFAULT 0,
      spent REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'نشط',
      description TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS budgets (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      year TEXT NOT NULL,
      amount REAL NOT NULL,
      spent REAL NOT NULL DEFAULT 0,
      department TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'مخطط',
      currency TEXT NOT NULL DEFAULT 'SAR',
      description TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      approved_by TEXT REFERENCES users(id),
      approved_at TEXT,
      locked_by TEXT REFERENCES users(id),
      locked_at TEXT,
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS budget_lines (
      id TEXT PRIMARY KEY,
      budget_id TEXT NOT NULL REFERENCES budgets(id) ON DELETE CASCADE,
      line_number INTEGER NOT NULL,
      account_id TEXT REFERENCES accounts(id),
      cost_center_id TEXT REFERENCES cost_centers(id),
      project_id TEXT REFERENCES projects(id),
      planned_amount REAL NOT NULL DEFAULT 0,
      actual_amount REAL NOT NULL DEFAULT 0,
      notes TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS fiscal_periods (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      start_date TEXT NOT NULL DEFAULT '',
      end_date TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'مفتوحة',
      closed_at TEXT,
      closed_by_id TEXT,
      closed_by_name TEXT,
      reopened_at TEXT,
      reopened_by_id TEXT,
      reopened_by_name TEXT,
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS approvals (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      subject TEXT NOT NULL,
      requester TEXT NOT NULL,
      amount REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'بانتظار موافقتي',
      priority TEXT NOT NULL DEFAULT 'متوسطة',
      level INTEGER NOT NULL DEFAULT 1,
      project_id TEXT REFERENCES projects(id),
      notes TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS suppliers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      activity TEXT DEFAULT '',
      phone TEXT,
      email TEXT,
      tax_number TEXT DEFAULT '',
      contact_person TEXT DEFAULT '',
      address TEXT DEFAULT '',
      rating REAL NOT NULL DEFAULT 0,
      balance REAL NOT NULL DEFAULT 0,
      notes TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'نشط',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS purchase_requests (
      id TEXT PRIMARY KEY,
      subject TEXT NOT NULL,
      department TEXT NOT NULL,
      priority TEXT NOT NULL DEFAULT 'متوسطة',
      status TEXT NOT NULL DEFAULT 'مسودة',
      requester TEXT DEFAULT '',
      amount REAL NOT NULL DEFAULT 0,
      delivery_date TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS purchase_orders (
      id TEXT PRIMARY KEY,
      supplier_id TEXT REFERENCES suppliers(id),
      request_id TEXT REFERENCES purchase_requests(id),
      subject TEXT NOT NULL,
      date TEXT NOT NULL DEFAULT '',
      delivery_date TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'مسودة',
      total REAL NOT NULL DEFAULT 0,
      received_amount REAL NOT NULL DEFAULT 0,
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS purchase_order_lines (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
      line_number INTEGER NOT NULL,
      item_id TEXT REFERENCES inventory_items(id),
      description TEXT NOT NULL DEFAULT '',
      quantity REAL NOT NULL DEFAULT 0,
      unit_price REAL NOT NULL DEFAULT 0,
      received_quantity REAL NOT NULL DEFAULT 0,
      unit TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS quotes (
      id TEXT PRIMARY KEY,
      request_id TEXT REFERENCES purchase_requests(id),
      supplier_id TEXT REFERENCES suppliers(id),
      supplier TEXT NOT NULL,
      price REAL NOT NULL DEFAULT 0,
      delivery TEXT DEFAULT '',
      warranty TEXT DEFAULT '',
      rating REAL NOT NULL DEFAULT 0,
      winner INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'بانتظار',
      valid_until TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS inventory_items (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      sku TEXT DEFAULT '',
      unit TEXT NOT NULL DEFAULT 'قطعة',
      category TEXT DEFAULT '',
      warehouse_id TEXT,
      quantity REAL NOT NULL DEFAULT 0,
      min_quantity REAL NOT NULL DEFAULT 0,
      price REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'نشط',
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS warehouses (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      location TEXT DEFAULT '',
      manager TEXT DEFAULT '',
      capacity REAL NOT NULL DEFAULT 0,
      occupancy REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'نشط',
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS stock_movements (
      id TEXT PRIMARY KEY,
      item_id TEXT NOT NULL REFERENCES inventory_items(id),
      warehouse_id TEXT REFERENCES warehouses(id),
      type TEXT NOT NULL,
      quantity REAL NOT NULL DEFAULT 0,
      balance_after REAL NOT NULL DEFAULT 0,
      related_warehouse_id TEXT REFERENCES warehouses(id),
      related_stocktake_id TEXT,
      source_type TEXT,
      source_id TEXT,
      reference TEXT DEFAULT '',
      date TEXT NOT NULL DEFAULT '',
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS stocktakes (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      warehouse_id TEXT REFERENCES warehouses(id),
      date TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'مسودة',
      approved_by TEXT REFERENCES users(id),
      approved_at TEXT,
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS stocktake_lines (
      id TEXT PRIMARY KEY,
      stocktake_id TEXT NOT NULL REFERENCES stocktakes(id) ON DELETE CASCADE,
      item_id TEXT NOT NULL REFERENCES inventory_items(id),
      system_quantity REAL NOT NULL DEFAULT 0,
      counted_quantity REAL NOT NULL DEFAULT 0,
      difference REAL NOT NULL DEFAULT 0,
      notes TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS grants (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      donor TEXT NOT NULL,
      amount REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'معلق',
      start_date TEXT DEFAULT '',
      end_date TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS endowments (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      type TEXT NOT NULL DEFAULT 'وقف عام',
      value REAL NOT NULL DEFAULT 0,
      returns REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'نشط',
      notes TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS memberships (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'عضو',
      type TEXT NOT NULL DEFAULT 'مجلس إدارة',
      phone TEXT,
      email TEXT,
      status TEXT NOT NULL DEFAULT 'نشط',
      joined_at TEXT DEFAULT '',
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS meetings (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      date TEXT NOT NULL DEFAULT '',
      location TEXT DEFAULT '',
      attendees TEXT DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'مجدول',
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS audit_log (
      id TEXT PRIMARY KEY,
      user_id TEXT REFERENCES users(id),
      user_name TEXT NOT NULL DEFAULT '',
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id TEXT NOT NULL,
      description TEXT DEFAULT '',
      before TEXT,
      after TEXT,
      ip TEXT DEFAULT '',
      timestamp TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS fixed_assets (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      code TEXT DEFAULT '',
      category TEXT DEFAULT '',
      location TEXT DEFAULT '',
      cost REAL NOT NULL DEFAULT 0,
      salvage_value REAL NOT NULL DEFAULT 0,
      useful_life_months INTEGER NOT NULL DEFAULT 60,
      accumulated_depreciation REAL NOT NULL DEFAULT 0,
      depreciation_method TEXT NOT NULL DEFAULT 'قسط ثابت',
      status TEXT NOT NULL DEFAULT 'نشط',
      condition TEXT DEFAULT 'جيد',
      purchase_date TEXT DEFAULT '',
      supplier_id TEXT REFERENCES suppliers(id),
      serial_number TEXT DEFAULT '',
      responsible_person TEXT DEFAULT '',
      source_type TEXT,
      source_id TEXT,
      notes TEXT DEFAULT '',
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT '',
      updated_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS asset_depreciations (
      id TEXT PRIMARY KEY,
      asset_id TEXT NOT NULL REFERENCES fixed_assets(id) ON DELETE CASCADE,
      date TEXT NOT NULL DEFAULT '',
      amount REAL NOT NULL DEFAULT 0,
      book_value_after REAL NOT NULL DEFAULT 0,
      method TEXT NOT NULL DEFAULT 'قسط ثابت',
      notes TEXT DEFAULT '',
      source_type TEXT,
      source_id TEXT,
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS asset_movements (
      id TEXT PRIMARY KEY,
      asset_id TEXT NOT NULL REFERENCES fixed_assets(id) ON DELETE CASCADE,
      type TEXT NOT NULL,
      from_location TEXT DEFAULT '',
      to_location TEXT DEFAULT '',
      from_responsible TEXT DEFAULT '',
      to_responsible TEXT DEFAULT '',
      cost REAL NOT NULL DEFAULT 0,
      date TEXT NOT NULL DEFAULT '',
      reason TEXT DEFAULT '',
      notes TEXT DEFAULT '',
      source_type TEXT,
      source_id TEXT,
      created_by TEXT REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT ''
    );
`;
var SQLITE_MIGRATIONS = [
	`ALTER TABLE aid_records ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE aid_records ADD COLUMN delivered_at TEXT`,
	`ALTER TABLE aid_records ADD COLUMN delivered_by TEXT REFERENCES users(id)`,
	`ALTER TABLE aid_records ADD COLUMN delivery_method TEXT DEFAULT ''`,
	`ALTER TABLE aid_records ADD COLUMN delivery_notes TEXT DEFAULT ''`,
	`ALTER TABLE projects ADD COLUMN code TEXT DEFAULT ''`,
	`ALTER TABLE projects ADD COLUMN type TEXT DEFAULT ''`,
	`ALTER TABLE projects ADD COLUMN category TEXT DEFAULT ''`,
	`ALTER TABLE projects ADD COLUMN branch TEXT DEFAULT ''`,
	`ALTER TABLE projects ADD COLUMN notes TEXT DEFAULT ''`,
	`ALTER TABLE beneficiaries ADD COLUMN file_number TEXT DEFAULT ''`,
	`ALTER TABLE beneficiaries ADD COLUMN family_members INTEGER NOT NULL DEFAULT 1`,
	`ALTER TABLE beneficiaries ADD COLUMN monthly_income REAL NOT NULL DEFAULT 0`,
	`ALTER TABLE beneficiaries ADD COLUMN marital_status TEXT DEFAULT ''`,
	`ALTER TABLE accounts ADD COLUMN level INTEGER NOT NULL DEFAULT 1`,
	`ALTER TABLE accounts ADD COLUMN postable INTEGER NOT NULL DEFAULT 1`,
	`ALTER TABLE accounts ADD COLUMN description TEXT DEFAULT ''`,
	`ALTER TABLE accounts ADD COLUMN notes TEXT DEFAULT ''`,
	`ALTER TABLE accounts ADD COLUMN created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE accounts ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE journal_entries ADD COLUMN currency TEXT NOT NULL DEFAULT 'SAR'`,
	`ALTER TABLE journal_entries ADD COLUMN reversed_of TEXT`,
	`ALTER TABLE journal_entries ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE cost_centers ADD COLUMN description TEXT DEFAULT ''`,
	`ALTER TABLE cost_centers ADD COLUMN notes TEXT DEFAULT ''`,
	`ALTER TABLE cost_centers ADD COLUMN created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE cost_centers ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE budgets ADD COLUMN currency TEXT NOT NULL DEFAULT 'SAR'`,
	`ALTER TABLE budgets ADD COLUMN description TEXT DEFAULT ''`,
	`ALTER TABLE budgets ADD COLUMN approved_by TEXT REFERENCES users(id)`,
	`ALTER TABLE budgets ADD COLUMN approved_at TEXT`,
	`ALTER TABLE budgets ADD COLUMN locked_by TEXT REFERENCES users(id)`,
	`ALTER TABLE budgets ADD COLUMN locked_at TEXT`,
	`ALTER TABLE budgets ADD COLUMN created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE budgets ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE suppliers ADD COLUMN contact_person TEXT DEFAULT ''`,
	`ALTER TABLE suppliers ADD COLUMN address TEXT DEFAULT ''`,
	`ALTER TABLE suppliers ADD COLUMN rating REAL NOT NULL DEFAULT 0`,
	`ALTER TABLE suppliers ADD COLUMN balance REAL NOT NULL DEFAULT 0`,
	`ALTER TABLE suppliers ADD COLUMN notes TEXT DEFAULT ''`,
	`ALTER TABLE suppliers ADD COLUMN created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE suppliers ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE purchase_requests ADD COLUMN requester TEXT DEFAULT ''`,
	`ALTER TABLE purchase_requests ADD COLUMN amount REAL NOT NULL DEFAULT 0`,
	`ALTER TABLE purchase_requests ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE purchase_orders ADD COLUMN request_id TEXT REFERENCES purchase_requests(id)`,
	`ALTER TABLE purchase_orders ADD COLUMN received_amount REAL NOT NULL DEFAULT 0`,
	`ALTER TABLE purchase_orders ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE quotes ADD COLUMN supplier_id TEXT REFERENCES suppliers(id)`,
	`ALTER TABLE quotes ADD COLUMN valid_until TEXT DEFAULT ''`,
	`ALTER TABLE quotes ADD COLUMN notes TEXT DEFAULT ''`,
	`ALTER TABLE quotes ADD COLUMN created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE quotes ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE inventory_items ADD COLUMN notes TEXT DEFAULT ''`,
	`ALTER TABLE inventory_items ADD COLUMN created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE inventory_items ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE warehouses ADD COLUMN capacity REAL NOT NULL DEFAULT 0`,
	`ALTER TABLE warehouses ADD COLUMN occupancy REAL NOT NULL DEFAULT 0`,
	`ALTER TABLE warehouses ADD COLUMN notes TEXT DEFAULT ''`,
	`ALTER TABLE warehouses ADD COLUMN created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE warehouses ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE fixed_assets ADD COLUMN code TEXT DEFAULT ''`,
	`ALTER TABLE fixed_assets ADD COLUMN salvage_value REAL NOT NULL DEFAULT 0`,
	`ALTER TABLE fixed_assets ADD COLUMN useful_life_months INTEGER NOT NULL DEFAULT 60`,
	`ALTER TABLE fixed_assets ADD COLUMN depreciation_method TEXT NOT NULL DEFAULT 'قسط ثابت'`,
	`ALTER TABLE fixed_assets ADD COLUMN condition TEXT DEFAULT 'جيد'`,
	`ALTER TABLE fixed_assets ADD COLUMN supplier_id TEXT REFERENCES suppliers(id)`,
	`ALTER TABLE fixed_assets ADD COLUMN serial_number TEXT DEFAULT ''`,
	`ALTER TABLE fixed_assets ADD COLUMN responsible_person TEXT DEFAULT ''`,
	`ALTER TABLE fixed_assets ADD COLUMN source_type TEXT`,
	`ALTER TABLE fixed_assets ADD COLUMN source_id TEXT`,
	`ALTER TABLE fixed_assets ADD COLUMN notes TEXT DEFAULT ''`,
	`ALTER TABLE fixed_assets ADD COLUMN created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE fixed_assets ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''`
];
var PG_DDL = `
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    phone TEXT,
    role TEXT NOT NULL DEFAULT 'employee',
    branch_id TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    avatar TEXT,
    created_at TEXT NOT NULL DEFAULT '',
    last_login TEXT
  );

  CREATE TABLE IF NOT EXISTS roles (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    permissions TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    token TEXT NOT NULL UNIQUE,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS branches (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    manager TEXT,
    phone TEXT,
    email TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS donors (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'فرد',
    email TEXT,
    phone TEXT,
    city TEXT DEFAULT '',
    address TEXT DEFAULT '',
    tag TEXT DEFAULT 'برونزي',
    total_donations DOUBLE PRECISION NOT NULL DEFAULT 0,
    donation_count INTEGER NOT NULL DEFAULT 0,
    last_donation TEXT,
    recurring BOOLEAN NOT NULL DEFAULT FALSE,
    notes TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'نشط',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS campaigns (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    goal DOUBLE PRECISION NOT NULL DEFAULT 0,
    raised DOUBLE PRECISION NOT NULL DEFAULT 0,
    start_date TEXT DEFAULT '',
    end_date TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'مخطط',
    description TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT DEFAULT '',
    type TEXT DEFAULT '',
    category TEXT DEFAULT '',
    branch TEXT DEFAULT '',
    manager TEXT NOT NULL,
    budget DOUBLE PRECISION NOT NULL DEFAULT 0,
    spent DOUBLE PRECISION NOT NULL DEFAULT 0,
    donations DOUBLE PRECISION NOT NULL DEFAULT 0,
    beneficiary_count INTEGER NOT NULL DEFAULT 0,
    progress INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'مخطط',
    start_date TEXT DEFAULT '',
    end_date TEXT DEFAULT '',
    description TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS donations (
    id TEXT PRIMARY KEY,
    donor_id TEXT NOT NULL REFERENCES donors(id),
    project_id TEXT REFERENCES projects(id),
    campaign_id TEXT REFERENCES campaigns(id),
    amount DOUBLE PRECISION NOT NULL,
    method TEXT NOT NULL DEFAULT 'نقدي',
    channel TEXT NOT NULL DEFAULT 'مباشر',
    status TEXT NOT NULL DEFAULT 'مسودة',
    receipt_id TEXT,
    notes TEXT DEFAULT '',
    date TEXT NOT NULL DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS beneficiaries (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    file_number TEXT DEFAULT '',
    id_number TEXT DEFAULT '',
    phone TEXT,
    city TEXT DEFAULT '',
    address TEXT DEFAULT '',
    category TEXT NOT NULL DEFAULT 'أسر محتاجة',
    status TEXT NOT NULL DEFAULT 'جديد',
    family_members INTEGER NOT NULL DEFAULT 1,
    monthly_income DOUBLE PRECISION NOT NULL DEFAULT 0,
    marital_status TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS aid_records (
    id TEXT PRIMARY KEY,
    beneficiary_id TEXT NOT NULL REFERENCES beneficiaries(id),
    project_id TEXT REFERENCES projects(id),
    type TEXT NOT NULL DEFAULT 'مساعدة عاجلة',
    amount DOUBLE PRECISION NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'بانتظار الموافقة',
    date TEXT NOT NULL DEFAULT '',
    approved_by TEXT REFERENCES users(id),
    approved_at TEXT,
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT '',
    delivered_at TEXT,
    delivered_by TEXT REFERENCES users(id),
    delivery_method TEXT DEFAULT '',
    delivery_notes TEXT DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS receipts (
    id TEXT PRIMARY KEY,
    donation_id TEXT REFERENCES donations(id),
    number TEXT NOT NULL UNIQUE,
    amount DOUBLE PRECISION NOT NULL,
    date TEXT NOT NULL DEFAULT '',
    type TEXT NOT NULL DEFAULT 'تبرع',
    status TEXT NOT NULL DEFAULT 'مرحّل',
    printed BOOLEAN NOT NULL DEFAULT FALSE,
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'تفصيلي',
    level INTEGER NOT NULL DEFAULT 1,
    parent_id TEXT,
    currency TEXT NOT NULL DEFAULT 'SAR',
    balance DOUBLE PRECISION NOT NULL DEFAULT 0,
    postable BOOLEAN NOT NULL DEFAULT TRUE,
    status TEXT NOT NULL DEFAULT 'نشط',
    description TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS journal_entries (
    id TEXT PRIMARY KEY,
    number TEXT NOT NULL UNIQUE,
    date TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    debit_account TEXT NOT NULL DEFAULT '',
    credit_account TEXT NOT NULL DEFAULT '',
    amount DOUBLE PRECISION NOT NULL DEFAULT 0,
    fund TEXT NOT NULL DEFAULT 'مقيد',
    currency TEXT NOT NULL DEFAULT 'SAR',
    project_id TEXT REFERENCES projects(id),
    source_type TEXT,
    source_id TEXT,
    status TEXT NOT NULL DEFAULT 'مسودة',
    posted_by TEXT REFERENCES users(id),
    posted_at TEXT,
    reversed_by TEXT,
    reversed_at TEXT,
    reversed_of TEXT,
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS journal_lines (
    id TEXT PRIMARY KEY,
    journal_entry_id TEXT NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE,
    line_number INTEGER NOT NULL,
    account_id TEXT NOT NULL REFERENCES accounts(id),
    description TEXT DEFAULT '',
    debit DOUBLE PRECISION NOT NULL DEFAULT 0,
    credit DOUBLE PRECISION NOT NULL DEFAULT 0,
    cost_center_id TEXT REFERENCES cost_centers(id),
    project_id TEXT REFERENCES projects(id),
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS cost_centers (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL,
    name TEXT NOT NULL,
    manager TEXT DEFAULT '',
    budget DOUBLE PRECISION NOT NULL DEFAULT 0,
    spent DOUBLE PRECISION NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'نشط',
    description TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS budgets (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    year TEXT NOT NULL,
    amount DOUBLE PRECISION NOT NULL,
    spent DOUBLE PRECISION NOT NULL DEFAULT 0,
    department TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'مخطط',
    currency TEXT NOT NULL DEFAULT 'SAR',
    description TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    approved_by TEXT REFERENCES users(id),
    approved_at TEXT,
    locked_by TEXT REFERENCES users(id),
    locked_at TEXT,
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS budget_lines (
    id TEXT PRIMARY KEY,
    budget_id TEXT NOT NULL REFERENCES budgets(id) ON DELETE CASCADE,
    line_number INTEGER NOT NULL,
    account_id TEXT REFERENCES accounts(id),
    cost_center_id TEXT REFERENCES cost_centers(id),
    project_id TEXT REFERENCES projects(id),
    planned_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
    actual_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS fiscal_periods (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    start_date TEXT NOT NULL DEFAULT '',
    end_date TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'مفتوحة',
    closed_at TEXT,
    closed_by_id TEXT,
    closed_by_name TEXT,
    reopened_at TEXT,
    reopened_by_id TEXT,
    reopened_by_name TEXT,
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS approvals (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    subject TEXT NOT NULL,
    requester TEXT NOT NULL,
    amount DOUBLE PRECISION NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'بانتظار موافقتي',
    priority TEXT NOT NULL DEFAULT 'متوسطة',
    level INTEGER NOT NULL DEFAULT 1,
    project_id TEXT REFERENCES projects(id),
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS suppliers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    activity TEXT DEFAULT '',
    phone TEXT,
    email TEXT,
    tax_number TEXT DEFAULT '',
    contact_person TEXT DEFAULT '',
    address TEXT DEFAULT '',
    rating DOUBLE PRECISION NOT NULL DEFAULT 0,
    balance DOUBLE PRECISION NOT NULL DEFAULT 0,
    notes TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'نشط',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS purchase_requests (
    id TEXT PRIMARY KEY,
    subject TEXT NOT NULL,
    department TEXT NOT NULL,
    priority TEXT NOT NULL DEFAULT 'متوسطة',
    status TEXT NOT NULL DEFAULT 'مسودة',
    requester TEXT DEFAULT '',
    amount DOUBLE PRECISION NOT NULL DEFAULT 0,
    delivery_date TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS purchase_orders (
    id TEXT PRIMARY KEY,
    supplier_id TEXT REFERENCES suppliers(id),
    request_id TEXT REFERENCES purchase_requests(id),
    subject TEXT NOT NULL,
    date TEXT NOT NULL DEFAULT '',
    delivery_date TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'مسودة',
    total DOUBLE PRECISION NOT NULL DEFAULT 0,
    received_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS purchase_order_lines (
    id TEXT PRIMARY KEY,
    order_id TEXT NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
    line_number INTEGER NOT NULL,
    item_id TEXT REFERENCES inventory_items(id),
    description TEXT NOT NULL DEFAULT '',
    quantity DOUBLE PRECISION NOT NULL DEFAULT 0,
    unit_price DOUBLE PRECISION NOT NULL DEFAULT 0,
    received_quantity DOUBLE PRECISION NOT NULL DEFAULT 0,
    unit TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS quotes (
    id TEXT PRIMARY KEY,
    request_id TEXT REFERENCES purchase_requests(id),
    supplier_id TEXT REFERENCES suppliers(id),
    supplier TEXT NOT NULL,
    price DOUBLE PRECISION NOT NULL DEFAULT 0,
    delivery TEXT DEFAULT '',
    warranty TEXT DEFAULT '',
    rating DOUBLE PRECISION NOT NULL DEFAULT 0,
    winner BOOLEAN NOT NULL DEFAULT FALSE,
    status TEXT NOT NULL DEFAULT 'بانتظار',
    valid_until TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS inventory_items (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    sku TEXT DEFAULT '',
    unit TEXT NOT NULL DEFAULT 'قطعة',
    category TEXT DEFAULT '',
    warehouse_id TEXT,
    quantity DOUBLE PRECISION NOT NULL DEFAULT 0,
    min_quantity DOUBLE PRECISION NOT NULL DEFAULT 0,
    price DOUBLE PRECISION NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'نشط',
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS warehouses (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    location TEXT DEFAULT '',
    manager TEXT DEFAULT '',
    capacity DOUBLE PRECISION NOT NULL DEFAULT 0,
    occupancy DOUBLE PRECISION NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'نشط',
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS stock_movements (
    id TEXT PRIMARY KEY,
    item_id TEXT NOT NULL REFERENCES inventory_items(id),
    warehouse_id TEXT REFERENCES warehouses(id),
    type TEXT NOT NULL,
    quantity DOUBLE PRECISION NOT NULL DEFAULT 0,
    balance_after DOUBLE PRECISION NOT NULL DEFAULT 0,
    related_warehouse_id TEXT REFERENCES warehouses(id),
    related_stocktake_id TEXT,
    source_type TEXT,
    source_id TEXT,
    reference TEXT DEFAULT '',
    date TEXT NOT NULL DEFAULT '',
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS stocktakes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    warehouse_id TEXT REFERENCES warehouses(id),
    date TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'مسودة',
    approved_by TEXT REFERENCES users(id),
    approved_at TEXT,
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS stocktake_lines (
    id TEXT PRIMARY KEY,
    stocktake_id TEXT NOT NULL REFERENCES stocktakes(id) ON DELETE CASCADE,
    item_id TEXT NOT NULL REFERENCES inventory_items(id),
    system_quantity DOUBLE PRECISION NOT NULL DEFAULT 0,
    counted_quantity DOUBLE PRECISION NOT NULL DEFAULT 0,
    difference DOUBLE PRECISION NOT NULL DEFAULT 0,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS grants (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    donor TEXT NOT NULL,
    amount DOUBLE PRECISION NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'معلق',
    start_date TEXT DEFAULT '',
    end_date TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS endowments (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'وقف عام',
    value DOUBLE PRECISION NOT NULL DEFAULT 0,
    returns DOUBLE PRECISION NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'نشط',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS memberships (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'عضو',
    type TEXT NOT NULL DEFAULT 'مجلس إدارة',
    phone TEXT,
    email TEXT,
    status TEXT NOT NULL DEFAULT 'نشط',
    joined_at TEXT DEFAULT '',
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS meetings (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    date TEXT NOT NULL DEFAULT '',
    location TEXT DEFAULT '',
    attendees TEXT DEFAULT '[]',
    status TEXT NOT NULL DEFAULT 'مجدول',
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS audit_log (
    id TEXT PRIMARY KEY,
    user_id TEXT REFERENCES users(id),
    user_name TEXT NOT NULL DEFAULT '',
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    description TEXT DEFAULT '',
    before TEXT,
    after TEXT,
    ip TEXT DEFAULT '',
    timestamp TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS fixed_assets (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT DEFAULT '',
    category TEXT DEFAULT '',
    location TEXT DEFAULT '',
    cost DOUBLE PRECISION NOT NULL DEFAULT 0,
    salvage_value DOUBLE PRECISION NOT NULL DEFAULT 0,
    useful_life_months INTEGER NOT NULL DEFAULT 60,
    accumulated_depreciation DOUBLE PRECISION NOT NULL DEFAULT 0,
    depreciation_method TEXT NOT NULL DEFAULT 'قسط ثابت',
    status TEXT NOT NULL DEFAULT 'نشط',
    condition TEXT DEFAULT 'جيد',
    purchase_date TEXT DEFAULT '',
    supplier_id TEXT REFERENCES suppliers(id),
    serial_number TEXT DEFAULT '',
    responsible_person TEXT DEFAULT '',
    source_type TEXT,
    source_id TEXT,
    notes TEXT DEFAULT '',
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS asset_depreciations (
    id TEXT PRIMARY KEY,
    asset_id TEXT NOT NULL REFERENCES fixed_assets(id) ON DELETE CASCADE,
    date TEXT NOT NULL DEFAULT '',
    amount DOUBLE PRECISION NOT NULL DEFAULT 0,
    book_value_after DOUBLE PRECISION NOT NULL DEFAULT 0,
    method TEXT NOT NULL DEFAULT 'قسط ثابت',
    notes TEXT DEFAULT '',
    source_type TEXT,
    source_id TEXT,
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS asset_movements (
    id TEXT PRIMARY KEY,
    asset_id TEXT NOT NULL REFERENCES fixed_assets(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    from_location TEXT DEFAULT '',
    to_location TEXT DEFAULT '',
    from_responsible TEXT DEFAULT '',
    to_responsible TEXT DEFAULT '',
    cost DOUBLE PRECISION NOT NULL DEFAULT 0,
    date TEXT NOT NULL DEFAULT '',
    reason TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    source_type TEXT,
    source_id TEXT,
    created_by TEXT REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT ''
  );
`;
var PG_MIGRATIONS = [
	`ALTER TABLE aid_records ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE aid_records ADD COLUMN IF NOT EXISTS delivered_at TEXT`,
	`ALTER TABLE aid_records ADD COLUMN IF NOT EXISTS delivered_by TEXT REFERENCES users(id)`,
	`ALTER TABLE aid_records ADD COLUMN IF NOT EXISTS delivery_method TEXT DEFAULT ''`,
	`ALTER TABLE aid_records ADD COLUMN IF NOT EXISTS delivery_notes TEXT DEFAULT ''`,
	`ALTER TABLE projects ADD COLUMN IF NOT EXISTS code TEXT DEFAULT ''`,
	`ALTER TABLE projects ADD COLUMN IF NOT EXISTS type TEXT DEFAULT ''`,
	`ALTER TABLE projects ADD COLUMN IF NOT EXISTS category TEXT DEFAULT ''`,
	`ALTER TABLE projects ADD COLUMN IF NOT EXISTS branch TEXT DEFAULT ''`,
	`ALTER TABLE projects ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT ''`,
	`ALTER TABLE beneficiaries ADD COLUMN IF NOT EXISTS file_number TEXT DEFAULT ''`,
	`ALTER TABLE beneficiaries ADD COLUMN IF NOT EXISTS family_members INTEGER NOT NULL DEFAULT 1`,
	`ALTER TABLE beneficiaries ADD COLUMN IF NOT EXISTS monthly_income DOUBLE PRECISION NOT NULL DEFAULT 0`,
	`ALTER TABLE beneficiaries ADD COLUMN IF NOT EXISTS marital_status TEXT DEFAULT ''`,
	`ALTER TABLE accounts ADD COLUMN IF NOT EXISTS level INTEGER NOT NULL DEFAULT 1`,
	`ALTER TABLE accounts ADD COLUMN IF NOT EXISTS postable BOOLEAN NOT NULL DEFAULT TRUE`,
	`ALTER TABLE accounts ADD COLUMN IF NOT EXISTS description TEXT DEFAULT ''`,
	`ALTER TABLE accounts ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT ''`,
	`ALTER TABLE accounts ADD COLUMN IF NOT EXISTS created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE accounts ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE journal_entries ADD COLUMN IF NOT EXISTS currency TEXT NOT NULL DEFAULT 'SAR'`,
	`ALTER TABLE journal_entries ADD COLUMN IF NOT EXISTS reversed_of TEXT`,
	`ALTER TABLE journal_entries ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE cost_centers ADD COLUMN IF NOT EXISTS description TEXT DEFAULT ''`,
	`ALTER TABLE cost_centers ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT ''`,
	`ALTER TABLE cost_centers ADD COLUMN IF NOT EXISTS created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE cost_centers ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE budgets ADD COLUMN IF NOT EXISTS currency TEXT NOT NULL DEFAULT 'SAR'`,
	`ALTER TABLE budgets ADD COLUMN IF NOT EXISTS description TEXT DEFAULT ''`,
	`ALTER TABLE budgets ADD COLUMN IF NOT EXISTS approved_by TEXT REFERENCES users(id)`,
	`ALTER TABLE budgets ADD COLUMN IF NOT EXISTS approved_at TEXT`,
	`ALTER TABLE budgets ADD COLUMN IF NOT EXISTS locked_by TEXT REFERENCES users(id)`,
	`ALTER TABLE budgets ADD COLUMN IF NOT EXISTS locked_at TEXT`,
	`ALTER TABLE budgets ADD COLUMN IF NOT EXISTS created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE budgets ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS contact_person TEXT DEFAULT ''`,
	`ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS address TEXT DEFAULT ''`,
	`ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS rating DOUBLE PRECISION NOT NULL DEFAULT 0`,
	`ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS balance DOUBLE PRECISION NOT NULL DEFAULT 0`,
	`ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT ''`,
	`ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE purchase_requests ADD COLUMN IF NOT EXISTS requester TEXT DEFAULT ''`,
	`ALTER TABLE purchase_requests ADD COLUMN IF NOT EXISTS amount DOUBLE PRECISION NOT NULL DEFAULT 0`,
	`ALTER TABLE purchase_requests ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE purchase_orders ADD COLUMN IF NOT EXISTS request_id TEXT REFERENCES purchase_requests(id)`,
	`ALTER TABLE purchase_orders ADD COLUMN IF NOT EXISTS received_amount DOUBLE PRECISION NOT NULL DEFAULT 0`,
	`ALTER TABLE purchase_orders ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE quotes ADD COLUMN IF NOT EXISTS supplier_id TEXT REFERENCES suppliers(id)`,
	`ALTER TABLE quotes ADD COLUMN IF NOT EXISTS valid_until TEXT DEFAULT ''`,
	`ALTER TABLE quotes ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT ''`,
	`ALTER TABLE quotes ADD COLUMN IF NOT EXISTS created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE quotes ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE inventory_items ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT ''`,
	`ALTER TABLE inventory_items ADD COLUMN IF NOT EXISTS created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE inventory_items ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS capacity DOUBLE PRECISION NOT NULL DEFAULT 0`,
	`ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS occupancy DOUBLE PRECISION NOT NULL DEFAULT 0`,
	`ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT ''`,
	`ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE warehouses ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS code TEXT DEFAULT ''`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS salvage_value DOUBLE PRECISION NOT NULL DEFAULT 0`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS useful_life_months INTEGER NOT NULL DEFAULT 60`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS depreciation_method TEXT NOT NULL DEFAULT 'قسط ثابت'`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS condition TEXT DEFAULT 'جيد'`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS supplier_id TEXT REFERENCES suppliers(id)`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS serial_number TEXT DEFAULT ''`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS responsible_person TEXT DEFAULT ''`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS source_type TEXT`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS source_id TEXT`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS notes TEXT DEFAULT ''`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS created_by TEXT REFERENCES users(id)`,
	`ALTER TABLE fixed_assets ADD COLUMN IF NOT EXISTS updated_at TEXT NOT NULL DEFAULT ''`
];
function initDB() {
	try {
		runRawSql(SQLITE_DDL);
		for (const migration of SQLITE_MIGRATIONS) try {
			runRawSql(migration);
		} catch {}
		if (dialect === "postgres") {
			runRawSql(PG_DDL);
			for (const migration of PG_MIGRATIONS) try {
				runRawSql(migration);
			} catch {}
		}
		console.log("[db] init OK");
	} catch (e) {
		console.error("[db] init failed:", e instanceof Error ? e.message : e);
	}
}
initDB();
function now() {
	return (/* @__PURE__ */ new Date()).toLocaleString("ar-SA", { hour12: false });
}
function genId(prefix = "") {
	const num = Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
	return prefix ? `${prefix}-${num}` : num;
}
function addAudit(action, entityType, entityId, description, userId, userName = "نظام", before, after) {
	db.insert(auditLog).values({
		id: genId("AUD"),
		userId: userId || null,
		userName,
		action,
		entityType,
		entityId,
		description,
		before: before || null,
		after: after || null,
		timestamp: now()
	}).run();
}
async function __handler_GET$22({ request }) {
	const donationId = new URL(request.url).searchParams.get("donationId");
	const baseQuery = db.select().from(receipts).orderBy(desc(receipts.createdAt));
	const enriched = (donationId ? baseQuery.where(eq(receipts.donationId, donationId)).all() : baseQuery.all()).map((receipt) => {
		let donation = null;
		let donor = null;
		if (receipt.donationId) {
			donation = db.select().from(donations).where(eq(donations.id, receipt.donationId)).limit(1).all()[0];
			if (donation?.donorId) donor = db.select().from(donors).where(eq(donors.id, donation.donorId)).limit(1).all()[0];
		}
		return {
			...receipt,
			donation,
			donor
		};
	});
	return Response.json({
		items: enriched,
		total: enriched.length
	});
}
async function __handler_POST$19({ request }) {
	const { donationId, number, amount, date, type, status, userId, userName } = await request.json();
	if (!donationId) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„طھط¨ط±ط¹ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) return Response.json({ error: "ظ‚ظٹظ…ط© ط§ظ„ط¥ظٹطµط§ظ„ ظٹط¬ط¨ ط£ظ† طھظƒظˆظ† ط±ظ‚ظ…ط§ظ‹ ظ…ظˆط¬ط¨ط§ظ‹" }, { status: 400 });
	const donation = db.select().from(donations).where(eq(donations.id, donationId)).limit(1).all()[0];
	if (!donation) return Response.json({ error: "ط§ظ„طھط¨ط±ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const id = genId("REC");
	const ts = now();
	const finalNumber = number || `REC-${Date.now()}-${Math.floor(Math.random() * 1e3)}`;
	db.insert(receipts).values({
		id,
		donationId,
		number: finalNumber,
		amount: Number(amount),
		date: date || ts,
		type: type || "ط¥ظٹطµط§ظ„ طھط¨ط±ط¹",
		status: status || "طµط§ط¯ط±",
		printed: false,
		createdBy: userId || null,
		createdAt: ts
	}).run();
	const donor = db.select().from(donors).where(eq(donors.id, donation.donorId)).limit(1).all()[0];
	addAudit("ط¥ط¶ط§ظپط©", "ط¥ظٹطµط§ظ„", id, `طھظ… ط¥طµط¯ط§ط± ط¥ظٹطµط§ظ„ ط±ظ‚ظ… ${finalNumber} ط¨ظ…ط¨ظ„ط؛ ${amount} ظ„ظ„ظ…طھط¨ط±ط¹ ${donor?.name || donation.donorName || ""}`, userId, userName);
	const created = db.select().from(receipts).where(eq(receipts.id, id)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$17({ request }) {
	const { id, action, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط¥ظٹطµط§ظ„ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(receipts).where(eq(receipts.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ط¥ظٹطµط§ظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (action === "void") {
		db.update(receipts).set({ status: "ظ…ظ„ط؛ظٹ" }).where(eq(receipts.id, id)).run();
		addAudit("طھط¹ط¯ظٹظ„", "ط¥ظٹطµط§ظ„", id, `طھظ… ط¥ظ„ط؛ط§ط، ط§ظ„ط¥ظٹطµط§ظ„ ط±ظ‚ظ… ${existing.number}`, userId, userName);
	} else if (action === "reprint") {
		db.update(receipts).set({ printed: true }).where(eq(receipts.id, id)).run();
		addAudit("طھط¹ط¯ظٹظ„", "ط¥ظٹطµط§ظ„", id, `طھظ… ط¥ط¹ط§ط¯ط© ط·ط¨ط§ط¹ط© ط§ظ„ط¥ظٹطµط§ظ„ ط±ظ‚ظ… ${existing.number}`, userId, userName);
	}
	const updated = db.select().from(receipts).where(eq(receipts.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$18({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط¥ظٹطµط§ظ„ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(receipts).where(eq(receipts.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ط¥ظٹطµط§ظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	db.delete(receipts).where(eq(receipts.id, id)).run();
	addAudit("ط­ط°ظپ", "ط¥ظٹطµط§ظ„", id, `طھظ… ط­ط°ظپ ط§ظ„ط¥ظٹطµط§ظ„ ط±ظ‚ظ… ${existing.number}`, userId, userName);
	return Response.json({ success: true });
}
var Route$41 = createFileRoute("/api/receipts")({ server: { handlers: {
	GET: __handler_GET$22,
	POST: __handler_POST$19,
	PUT: __handler_PUT$17,
	DELETE: __handler_DELETE$18
} } });
async function __handler_GET$21({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const summary = url.searchParams.get("summary");
	if (id) {
		const project = db.select().from(projects).where(eq(projects.id, id)).limit(1).all()[0];
		if (!project) return Response.json({ error: "ط§ظ„ظ…ط´ط±ظˆط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const totalDonations = db.select().from(donations).where(and(eq(donations.projectId, id), eq(donations.status, "ظ…ط¤ظƒط¯"))).all().reduce((s, d) => s + d.amount, 0);
		const projAid = db.select().from(aidRecords).where(and(eq(aidRecords.projectId, id), eq(aidRecords.status, "طھظ… ط§ظ„طھط³ظ„ظٹظ…"))).all();
		const totalAid = projAid.reduce((s, a) => s + a.amount, 0);
		const beneficiaryCount = projAid.length;
		const remainingBudget = project.budget - project.spent;
		if (summary === "true") return Response.json({ item: {
			...project,
			totalDonations,
			totalAid,
			aidCount: projAid.length,
			remainingBudget,
			beneficiaryCount,
			progressPercentage: project.progress,
			utilizationPercent: project.budget > 0 ? Math.round(project.spent / project.budget * 100) : 0,
			donationsPercent: project.budget > 0 ? Math.round(totalDonations / project.budget * 100) : 0
		} });
		const linkedDonations = db.select().from(donations).where(eq(donations.projectId, id)).orderBy(desc(donations.createdAt)).limit(20).all();
		const linkedAid = db.select().from(aidRecords).where(eq(aidRecords.projectId, id)).orderBy(desc(aidRecords.createdAt)).limit(20).all();
		const linkedBeneficiaryIds = Array.from(new Set(linkedAid.map((a) => a.beneficiaryId).filter(Boolean)));
		const linkedBeneficiaries = linkedBeneficiaryIds.length > 0 ? db.select().from(beneficiaries).where(or(...linkedBeneficiaryIds.map((bid) => eq(beneficiaries.id, bid)))).limit(20).all() : [];
		return Response.json({
			item: {
				...project,
				totalDonations,
				totalAid,
				aidCount: projAid.length,
				remainingBudget,
				beneficiaryCount
			},
			donations: linkedDonations,
			aid: linkedAid,
			beneficiaries: linkedBeneficiaries
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const category = url.searchParams.get("category") || "";
	const branch = url.searchParams.get("branch") || "";
	const page = parseInt(url.searchParams.get("page") || "1");
	const limit = parseInt(url.searchParams.get("limit") || "50");
	const offset = (page - 1) * limit;
	const conditions = [];
	if (search) conditions.push(or(like(projects.name, `%${search}%`), like(projects.manager, `%${search}%`), like(projects.code, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(projects.status, status));
	if (category && category !== "ط§ظ„ظƒظ„") conditions.push(eq(projects.category, category));
	if (branch && branch !== "ط§ظ„ظƒظ„") conditions.push(eq(projects.branch, branch));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const allQuery = db.select().from(projects).$dynamic();
	const total = (whereClause ? allQuery.where(whereClause).orderBy(desc(projects.createdAt)).all() : allQuery.orderBy(desc(projects.createdAt)).all()).length;
	const itemsQuery = db.select().from(projects).$dynamic();
	const items = whereClause ? itemsQuery.where(whereClause).orderBy(desc(projects.createdAt)).limit(limit).offset(offset).all() : itemsQuery.orderBy(desc(projects.createdAt)).limit(limit).offset(offset).all();
	return Response.json({
		items,
		total,
		page,
		limit
	});
}
async function __handler_POST$18({ request }) {
	const body = await request.json();
	const { action, id, userId, userName } = body;
	if (action === "activate" || action === "pause" || action === "complete" || action === "cancel") {
		const newStatus = {
			activate: "ظ†ط´ط·",
			pause: "ظ…طھظˆظ‚ظپ",
			complete: "ظ…ظƒطھظ…ظ„",
			cancel: "ظ…ظ„ط؛ظٹ"
		}[action];
		const project = db.select().from(projects).where(eq(projects.id, id)).limit(1).all()[0];
		if (!project) return Response.json({ error: "ط§ظ„ظ…ط´ط±ظˆط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (action === "activate" && project.status === "ظ…ظƒطھظ…ظ„") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھظپط¹ظٹظ„ ظ…ط´ط±ظˆط¹ ظ…ظƒطھظ…ظ„. ط£ظ†ط´ط¦ ظ…ط´ط±ظˆط¹ط§ظ‹ ط¬ط¯ظٹط¯ط§ظ‹ ط¨ط¯ظ„ط§ظ‹ ظ…ظ† ط°ظ„ظƒ." }, { status: 400 });
		if (action === "complete" && project.status === "ظ…ظ„ط؛ظٹ") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط¥ظƒظ…ط§ظ„ ظ…ط´ط±ظˆط¹ ظ…ظ„ط؛ظٹ." }, { status: 400 });
		const before = JSON.stringify(project);
		const ts = now();
		db.update(projects).set({
			status: newStatus,
			updatedAt: ts
		}).where(eq(projects.id, id)).run();
		const actionLabel = action === "activate" ? "طھظپط¹ظٹظ„" : action === "pause" ? "ط¥ظٹظ‚ط§ظپ" : action === "complete" ? "ط¥ظƒظ…ط§ظ„" : "ط¥ظ„ط؛ط§ط،";
		addAudit(actionLabel, "ظ…ط´ط±ظˆط¹", id, `طھظ… ${actionLabel} ط§ظ„ظ…ط´ط±ظˆط¹: ${project.name} (ط§ظ„ط­ط§ظ„ط©: ${newStatus})`, userId, userName, before);
		const updated = db.select().from(projects).where(eq(projects.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "status") {
		const { status } = body;
		const project = db.select().from(projects).where(eq(projects.id, id)).limit(1).all()[0];
		if (!project) return Response.json({ error: "ط§ظ„ظ…ط´ط±ظˆط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const before = JSON.stringify(project);
		db.update(projects).set({
			status,
			updatedAt: now()
		}).where(eq(projects.id, id)).run();
		addAudit("طھط؛ظٹظٹط± ط§ظ„ط­ط§ظ„ط©", "ظ…ط´ط±ظˆط¹", id, `طھظ… طھط؛ظٹظٹط± ط­ط§ظ„ط© ط§ظ„ظ…ط´ط±ظˆط¹ ط¥ظ„ظ‰: ${status}`, userId, userName, before);
		const updated = db.select().from(projects).where(eq(projects.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { name, code, type, category, branch, manager, budget, startDate, endDate, description, notes, status, progress, userId: uid, userName: uname } = body;
	if (!name?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„ظ…ط´ط±ظˆط¹ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const projectId = genId("PRJ");
	const ts = now();
	db.insert(projects).values({
		id: projectId,
		name: name.trim(),
		code: code || "",
		type: type || "",
		category: category || "",
		branch: branch || "",
		manager: manager || "",
		budget: parseFloat(budget) || 0,
		spent: 0,
		donations: 0,
		beneficiaryCount: 0,
		progress: parseInt(progress) || 0,
		status: status || "ظ…ط®ط·ط·",
		startDate: startDate || "",
		endDate: endDate || "",
		description: description || "",
		notes: notes || "",
		createdBy: uid || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ظ…ط´ط±ظˆط¹", projectId, `طھظ… ط¥ط¶ط§ظپط© ظ…ط´ط±ظˆط¹ ط¬ط¯ظٹط¯: ${name}`, uid, uname);
	const created = db.select().from(projects).where(eq(projects.id, projectId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$16({ request }) {
	const { id, name, code, type, category, branch, manager, budget, startDate, endDate, description, notes, status, progress, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…ط´ط±ظˆط¹ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(projects).where(eq(projects.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…ط´ط±ظˆط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (existing.status === "ظ…ظƒطھظ…ظ„" || existing.status === "ظ…ظ„ط؛ظٹ") return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† طھط¹ط¯ظٹظ„ ظ…ط´ط±ظˆط¹ ط¨ط­ط§ظ„ط©: ${existing.status}` }, { status: 400 });
	const before = JSON.stringify(existing);
	const ts = now();
	db.update(projects).set({
		name: name?.trim() ?? existing.name,
		code: code ?? existing.code,
		type: type ?? existing.type,
		category: category ?? existing.category,
		branch: branch ?? existing.branch,
		manager: manager ?? existing.manager,
		budget: budget !== void 0 ? parseFloat(budget) : existing.budget,
		startDate: startDate ?? existing.startDate,
		endDate: endDate ?? existing.endDate,
		description: description ?? existing.description,
		notes: notes ?? existing.notes,
		status: status ?? existing.status,
		progress: progress !== void 0 ? parseInt(progress) : existing.progress,
		updatedAt: ts
	}).where(eq(projects.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ظ…ط´ط±ظˆط¹", id, `طھظ… طھط­ط¯ظٹط« ط¨ظٹط§ظ†ط§طھ ط§ظ„ظ…ط´ط±ظˆط¹: ${name || existing.name}`, userId, userName, before);
	const updated = db.select().from(projects).where(eq(projects.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$17({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…ط´ط±ظˆط¹ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(projects).where(eq(projects.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…ط´ط±ظˆط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const linkedDonations = db.select().from(donations).where(eq(donations.projectId, id)).limit(1).all();
	const linkedAid = db.select().from(aidRecords).where(eq(aidRecords.projectId, id)).limit(1).all();
	if (linkedDonations.length > 0 || linkedAid.length > 0) return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ظ…ط´ط±ظˆط¹ ظ…ط±طھط¨ط· ط¨طھط¨ط±ط¹ط§طھ ط£ظˆ ظ…ط³ط§ط¹ط¯ط§طھ. ظٹظ…ظƒظ† ط¥ظٹظ‚ط§ظپظ‡ ظپظ‚ط·." }, { status: 400 });
	const before = JSON.stringify(existing);
	db.delete(projects).where(eq(projects.id, id)).run();
	addAudit("ط­ط°ظپ", "ظ…ط´ط±ظˆط¹", id, `طھظ… ط­ط°ظپ ط§ظ„ظ…ط´ط±ظˆط¹: ${existing.name}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$40 = createFileRoute("/api/projects")({ server: { handlers: {
	GET: __handler_GET$21,
	POST: __handler_POST$18,
	PUT: __handler_PUT$16,
	DELETE: __handler_DELETE$17
} } });
async function __handler_GET$20({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const donor = db.select().from(donors).where(eq(donors.id, id)).limit(1).all()[0];
		if (!donor) return Response.json({ error: "ط§ظ„ظ…طھط¨ط±ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		return Response.json({ item: donor });
	}
	const search = url.searchParams.get("search") || "";
	const type = url.searchParams.get("type") || "";
	const tag = url.searchParams.get("tag") || "";
	const city = url.searchParams.get("city") || "";
	const page = parseInt(url.searchParams.get("page") || "1");
	const limit = parseInt(url.searchParams.get("limit") || "50");
	const offset = (page - 1) * limit;
	const conditions = [];
	if (search) conditions.push(or(like(donors.name, `%${search}%`), like(donors.phone, `%${search}%`), like(donors.email, `%${search}%`)));
	if (type && type !== "ط§ظ„ظƒظ„") conditions.push(eq(donors.type, type));
	if (tag && tag !== "ط§ظ„ظƒظ„") conditions.push(eq(donors.tag, tag));
	if (city && city !== "ط§ظ„ظƒظ„") conditions.push(eq(donors.city, city));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const allQuery = db.select().from(donors);
	const total = (whereClause ? allQuery.where(whereClause).orderBy(desc(donors.createdAt)).all() : allQuery.orderBy(desc(donors.createdAt)).all()).length;
	const itemsQuery = db.select().from(donors);
	const items = whereClause ? itemsQuery.where(whereClause).orderBy(desc(donors.createdAt)).limit(limit).offset(offset).all() : itemsQuery.orderBy(desc(donors.createdAt)).limit(limit).offset(offset).all();
	return Response.json({
		items,
		total,
		page,
		limit
	});
}
async function __handler_POST$17({ request }) {
	const { name, type, email, phone, city, address, tag, notes, userId, userName } = await request.json();
	if (!name?.trim()) return Response.json({ error: "ط§ظ„ط§ط³ظ… ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const id = genId("D");
	const ts = now();
	db.insert(donors).values({
		id,
		name: name.trim(),
		type: type || "ظپط±ط¯",
		email: email || null,
		phone: phone || null,
		city: city || "",
		address: address || "",
		tag: tag || "ط¨ط±ظˆظ†ط²ظٹ",
		totalDonations: 0,
		donationCount: 0,
		recurring: false,
		notes: notes || "",
		status: "ظ†ط´ط·",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ظ…طھط¨ط±ط¹", id, `طھظ… ط¥ط¶ط§ظپط© ظ…طھط¨ط±ط¹ ط¬ط¯ظٹط¯: ${name}`, userId, userName);
	const created = db.select().from(donors).where(eq(donors.id, id)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$15({ request }) {
	const { id, name, type, email, phone, city, address, tag, notes, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…طھط¨ط±ط¹ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(donors).where(eq(donors.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…طھط¨ط±ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const before = JSON.stringify(existing);
	const ts = now();
	db.update(donors).set({
		name: name?.trim() ?? existing.name,
		type: type ?? existing.type,
		email: email ?? existing.email,
		phone: phone ?? existing.phone,
		city: city ?? existing.city,
		address: address ?? existing.address,
		tag: tag ?? existing.tag,
		notes: notes ?? existing.notes,
		updatedAt: ts
	}).where(eq(donors.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ظ…طھط¨ط±ط¹", id, `طھظ… طھط­ط¯ظٹط« ط¨ظٹط§ظ†ط§طھ ط§ظ„ظ…طھط¨ط±ط¹: ${name || existing.name}`, userId, userName, before);
	const updated = db.select().from(donors).where(eq(donors.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$16({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…طھط¨ط±ط¹ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(donors).where(eq(donors.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…طھط¨ط±ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	db.update(donors).set({
		status: "ط؛ظٹط± ظ†ط´ط·",
		updatedAt: now()
	}).where(eq(donors.id, id)).run();
	addAudit("ط­ط°ظپ", "ظ…طھط¨ط±ط¹", id, `طھظ… ط­ط°ظپ ط§ظ„ظ…طھط¨ط±ط¹: ${existing.name}`, userId, userName);
	return Response.json({ success: true });
}
var Route$39 = createFileRoute("/api/donors")({ server: { handlers: {
	GET: __handler_GET$20,
	POST: __handler_POST$17,
	PUT: __handler_PUT$15,
	DELETE: __handler_DELETE$16
} } });
async function __handler_GET$19({ request }) {
	const url = new URL(request.url);
	const donorId = url.searchParams.get("donorId");
	const campaignId = url.searchParams.get("campaignId");
	const status = url.searchParams.get("status");
	const dateFrom = url.searchParams.get("dateFrom");
	const dateTo = url.searchParams.get("dateTo");
	const search = url.searchParams.get("search");
	const stats = url.searchParams.get("stats");
	const conditions = [];
	if (donorId) conditions.push(eq(donations.donorId, donorId));
	if (campaignId) conditions.push(eq(donations.campaignId, campaignId));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(donations.status, status));
	if (dateFrom) conditions.push(gte(donations.date, dateFrom));
	if (dateTo) conditions.push(lte(donations.date, dateTo));
	if (search) conditions.push(like(donations.notes, `%${search}%`));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const baseQuery = db.select().from(donations).orderBy(desc(donations.date));
	if (stats === "1") {
		const all = whereClause ? baseQuery.where(whereClause).all() : baseQuery.all();
		const totalAmount = all.reduce((sum, d) => sum + (d.amount || 0), 0);
		const totalCount = all.length;
		const byChannel = {};
		const byCampaign = {};
		const byDonor = {};
		for (const d of all) {
			const amount = d.amount || 0;
			const channel = d.channel || "ط£ط®ط±ظ‰";
			byChannel[channel] = (byChannel[channel] || 0) + amount;
			if (d.campaignId) {
				const name = db.select().from(campaigns).where(eq(campaigns.id, d.campaignId)).limit(1).all()[0]?.name || "ط؛ظٹط± ظ…ط­ط¯ط¯";
				byCampaign[name] = (byCampaign[name] || 0) + amount;
			}
			if (d.donorId) {
				const name = db.select().from(donors).where(eq(donors.id, d.donorId)).limit(1).all()[0]?.name || "ط؛ظٹط± ظ…ط­ط¯ط¯";
				if (!byDonor[d.donorId]) byDonor[d.donorId] = {
					name,
					total: 0,
					count: 0
				};
				byDonor[d.donorId].total += amount;
				byDonor[d.donorId].count += 1;
			}
		}
		return Response.json({
			totalAmount,
			totalCount,
			averageAmount: totalCount > 0 ? totalAmount / totalCount : 0,
			byChannel,
			byCampaign,
			topDonors: Object.entries(byDonor).sort(([, a], [, b]) => b.total - a.total).slice(0, 10).map(([id, info]) => ({
				id,
				...info
			}))
		});
	}
	const items = whereClause ? baseQuery.where(whereClause).all() : baseQuery.all();
	const total = items.length;
	return Response.json({
		items,
		total
	});
}
async function __handler_POST$16({ request }) {
	const { donorId, amount, channel, campaignId, projectId, notes, date, status, method, userId, userName } = await request.json();
	if (!donorId) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…طھط¨ط±ط¹ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const donor = db.select().from(donors).where(eq(donors.id, donorId)).limit(1).all()[0];
	if (!donor) return Response.json({ error: "ط§ظ„ظ…طھط¨ط±ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) return Response.json({ error: "ظ‚ظٹظ…ط© ط§ظ„طھط¨ط±ط¹ ظٹط¬ط¨ ط£ظ† طھظƒظˆظ† ط±ظ‚ظ…ط§ظ‹ ظ…ظˆط¬ط¨ط§ظ‹" }, { status: 400 });
	const id = genId("DON");
	const ts = now();
	const amountNum = Number(amount);
	db.insert(donations).values({
		id,
		donorId,
		amount: amountNum,
		method: method || "ظ†ظ‚ط¯ظٹ",
		channel: channel || "ظ†ظ‚ط¯ظٹ",
		status: status || "ظ…ظƒطھظ…ظ„",
		campaignId: campaignId || null,
		projectId: projectId || null,
		notes: notes || "",
		date: date || ts,
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	const newTotal = (donor.totalDonations || 0) + amountNum;
	const newCount = (donor.donationCount || 0) + 1;
	let newTag = donor.tag || "ط¨ط±ظˆظ†ط²ظٹ";
	if (newTotal >= 1e5) newTag = "ط°ظ‡ط¨ظٹ";
	else if (newTotal >= 5e4) newTag = "ظپط¶ظٹ";
	else if (newTotal >= 1e4) newTag = "ط¨ط±ظˆظ†ط²ظٹ";
	db.update(donors).set({
		totalDonations: newTotal,
		donationCount: newCount,
		tag: newTag,
		lastDonation: date || ts,
		updatedAt: ts
	}).where(eq(donors.id, donorId)).run();
	if (campaignId) {
		const campaign = db.select().from(campaigns).where(eq(campaigns.id, campaignId)).limit(1).all()[0];
		if (campaign) db.update(campaigns).set({
			raised: (campaign.raised || 0) + amountNum,
			updatedAt: ts
		}).where(eq(campaigns.id, campaignId)).run();
	}
	if (projectId) {
		const project = db.select().from(projects).where(eq(projects.id, projectId)).limit(1).all()[0];
		if (project) db.update(projects).set({
			donations: (project.donations || 0) + amountNum,
			updatedAt: ts
		}).where(eq(projects.id, projectId)).run();
	}
	addAudit("ط¥ط¶ط§ظپط©", "طھط¨ط±ط¹", id, `طھظ… طھط³ط¬ظٹظ„ طھط¨ط±ط¹ ط¬ط¯ظٹط¯ ط¨ظ…ط¨ظ„ط؛ ${amountNum} ظ…ظ† ${donor.name}`, userId, userName);
	const created = db.select().from(donations).where(eq(donations.id, id)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_DELETE$15({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„طھط¨ط±ط¹ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const donation = db.select().from(donations).where(eq(donations.id, id)).limit(1).all()[0];
	if (!donation) return Response.json({ error: "ط§ظ„طھط¨ط±ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const refundAmount = donation.amount || 0;
	db.update(donations).set({
		status: "ظ…ظ„ط؛ظٹ",
		updatedAt: now()
	}).where(eq(donations.id, id)).run();
	if (donation.donorId) {
		const donor = db.select().from(donors).where(eq(donors.id, donation.donorId)).limit(1).all()[0];
		if (donor) {
			const newTotal = Math.max(0, (donor.totalDonations || 0) - refundAmount);
			const newCount = Math.max(0, (donor.donationCount || 0) - 1);
			let newTag = "ط¨ط±ظˆظ†ط²ظٹ";
			if (newTotal >= 1e5) newTag = "ط°ظ‡ط¨ظٹ";
			else if (newTotal >= 5e4) newTag = "ظپط¶ظٹ";
			else if (newTotal >= 1e4) newTag = "ط¨ط±ظˆظ†ط²ظٹ";
			db.update(donors).set({
				totalDonations: newTotal,
				donationCount: newCount,
				tag: newTag,
				updatedAt: now()
			}).where(eq(donors.id, donation.donorId)).run();
		}
	}
	if (donation.campaignId) {
		const campaign = db.select().from(campaigns).where(eq(campaigns.id, donation.campaignId)).limit(1).all()[0];
		if (campaign) db.update(campaigns).set({
			raised: Math.max(0, (campaign.raised || 0) - refundAmount),
			updatedAt: now()
		}).where(eq(campaigns.id, donation.campaignId)).run();
	}
	addAudit("ط­ط°ظپ", "طھط¨ط±ط¹", id, `طھظ… ط¥ظ„ط؛ط§ط، ط§ظ„طھط¨ط±ط¹ ط¨ظ…ط¨ظ„ط؛ ${refundAmount}`, userId, userName);
	return Response.json({ success: true });
}
var Route$38 = createFileRoute("/api/donations")({ server: { handlers: {
	GET: __handler_GET$19,
	POST: __handler_POST$16,
	DELETE: __handler_DELETE$15
} } });
async function __handler_GET$18({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const summary = url.searchParams.get("summary");
	if (id) {
		const beneficiary = db.select().from(beneficiaries).where(eq(beneficiaries.id, id)).limit(1).all()[0];
		if (!beneficiary) return Response.json({ error: "ط§ظ„ظ…ط³طھظپظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const aidHistory = db.select().from(aidRecords).where(eq(aidRecords.beneficiaryId, id)).orderBy(desc(aidRecords.createdAt)).all();
		const totalAid = aidHistory.filter((a) => a.status === "طھظ… ط§ظ„طھط³ظ„ظٹظ…").reduce((s, a) => s + a.amount, 0);
		const aidCount = aidHistory.filter((a) => a.status === "طھظ… ط§ظ„طھط³ظ„ظٹظ…").length;
		const pendingAidCount = aidHistory.filter((a) => a.status === "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ظ…ظˆط§ظپظ‚ط©" || a.status === "ظ…ط¹طھظ…ط¯").length;
		const lastAidDate = aidHistory.length > 0 ? aidHistory[0].createdAt : null;
		const linkedProjectIds = Array.from(new Set(aidHistory.map((a) => a.projectId).filter((id) => Boolean(id))));
		const linkedProjects = linkedProjectIds.length > 0 ? db.select().from(projects).where(or(...linkedProjectIds.map((pid) => eq(projects.id, pid)))).all() : [];
		const linkedProjectsCount = linkedProjects.length;
		if (summary === "true") return Response.json({ item: {
			...beneficiary,
			totalAid,
			aidCount,
			pendingAidCount,
			lastAidDate,
			linkedProjectsCount,
			eligibilityStatus: beneficiary.status
		} });
		const enrichedAidHistory = aidHistory.map((a) => {
			const project = linkedProjects.find((p) => p.id === a.projectId);
			return {
				...a,
				projectName: project?.name || ""
			};
		});
		return Response.json({
			item: {
				...beneficiary,
				totalAid,
				aidCount,
				pendingAidCount,
				lastAidDate
			},
			aidHistory: enrichedAidHistory,
			linkedProjects
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const category = url.searchParams.get("category") || "";
	const city = url.searchParams.get("city") || "";
	const page = parseInt(url.searchParams.get("page") || "1");
	const limit = parseInt(url.searchParams.get("limit") || "50");
	const offset = (page - 1) * limit;
	const conditions = [];
	if (search) conditions.push(or(like(beneficiaries.name, `%${search}%`), like(beneficiaries.idNumber, `%${search}%`), like(beneficiaries.phone, `%${search}%`), like(beneficiaries.fileNumber, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(beneficiaries.status, status));
	if (category && category !== "ط§ظ„ظƒظ„") conditions.push(eq(beneficiaries.category, category));
	if (city && city !== "ط§ظ„ظƒظ„") conditions.push(eq(beneficiaries.city, city));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const allQuery = db.select().from(beneficiaries).$dynamic();
	const total = (whereClause ? allQuery.where(whereClause).orderBy(desc(beneficiaries.createdAt)).all() : allQuery.orderBy(desc(beneficiaries.createdAt)).all()).length;
	const itemsQuery = db.select().from(beneficiaries).$dynamic();
	const items = whereClause ? itemsQuery.where(whereClause).orderBy(desc(beneficiaries.createdAt)).limit(limit).offset(offset).all() : itemsQuery.orderBy(desc(beneficiaries.createdAt)).limit(limit).offset(offset).all();
	return Response.json({
		items,
		total,
		page,
		limit
	});
}
async function __handler_POST$15({ request }) {
	const body = await request.json();
	const { action, id, userId, userName } = body;
	if (action === "review" || action === "qualify" || action === "disqualify" || action === "suspend" || action === "reactivate") {
		const newStatus = {
			review: "ظ‚ظٹط¯ ط§ظ„ظ…ط±ط§ط¬ط¹ط©",
			qualify: "ظ…ط¤ظ‡ظ„",
			disqualify: "ط؛ظٹط± ظ…ط¤ظ‡ظ„",
			suspend: "ظ…ظˆظ‚ظˆظپ",
			reactivate: "ظ…ط¤ظ‡ظ„"
		}[action];
		const beneficiary = db.select().from(beneficiaries).where(eq(beneficiaries.id, id)).limit(1).all()[0];
		if (!beneficiary) return Response.json({ error: "ط§ظ„ظ…ط³طھظپظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (action === "qualify" && beneficiary.status === "ظ…ظˆظ‚ظˆظپ") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط£ظ‡ظٹظ„ ظ…ط³طھظپظٹط¯ ظ…ظˆظ‚ظˆظپ. ط£ط¹ط¯ طھظپط¹ظٹظ„ظ‡ ط£ظˆظ„ط§ظ‹." }, { status: 400 });
		if (action === "reactivate" && beneficiary.status !== "ظ…ظˆظ‚ظˆظپ") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط¥ط¹ط§ط¯ط© طھظپط¹ظٹظ„ ظ…ط³طھظپظٹط¯ ط؛ظٹط± ظ…ظˆظ‚ظˆظپ." }, { status: 400 });
		if (action === "suspend" && beneficiary.status === "ط؛ظٹط± ظ…ط¤ظ‡ظ„") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط¥ظٹظ‚ط§ظپ ظ…ط³طھظپظٹط¯ ط؛ظٹط± ظ…ط¤ظ‡ظ„." }, { status: 400 });
		const before = JSON.stringify(beneficiary);
		const ts = now();
		db.update(beneficiaries).set({
			status: newStatus,
			updatedAt: ts
		}).where(eq(beneficiaries.id, id)).run();
		const actionLabels = {
			review: "ط¥ط±ط³ط§ظ„ ظ„ظ„ظ…ط±ط§ط¬ط¹ط©",
			qualify: "طھط£ظ‡ظٹظ„",
			disqualify: "ط¹ط¯ظ… طھط£ظ‡ظٹظ„",
			suspend: "ط¥ظٹظ‚ط§ظپ",
			reactivate: "ط¥ط¹ط§ط¯ط© طھظپط¹ظٹظ„"
		};
		addAudit(actionLabels[action], "ظ…ط³طھظپظٹط¯", id, `طھظ… ${actionLabels[action]} ط§ظ„ظ…ط³طھظپظٹط¯: ${beneficiary.name} (ط§ظ„ط­ط§ظ„ط©: ${newStatus})`, userId, userName, before);
		const updated = db.select().from(beneficiaries).where(eq(beneficiaries.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "status") {
		const { status } = body;
		const beneficiary = db.select().from(beneficiaries).where(eq(beneficiaries.id, id)).limit(1).all()[0];
		if (!beneficiary) return Response.json({ error: "ط§ظ„ظ…ط³طھظپظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const before = JSON.stringify(beneficiary);
		db.update(beneficiaries).set({
			status,
			updatedAt: now()
		}).where(eq(beneficiaries.id, id)).run();
		addAudit("طھط؛ظٹظٹط± ط§ظ„ط­ط§ظ„ط©", "ظ…ط³طھظپظٹط¯", id, `طھظ… طھط؛ظٹظٹط± ط­ط§ظ„ط© ط§ظ„ظ…ط³طھظپظٹط¯ ط¥ظ„ظ‰: ${status}`, userId, userName, before);
		const updated = db.select().from(beneficiaries).where(eq(beneficiaries.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { name, fileNumber, idNumber, phone, city, address, category, status, familyMembers, monthlyIncome, maritalStatus, notes, userId: uid, userName: uname } = body;
	if (!name?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„ظ…ط³طھظپظٹط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const benId = genId("BEN");
	const ts = now();
	db.insert(beneficiaries).values({
		id: benId,
		name: name.trim(),
		fileNumber: fileNumber || "",
		idNumber: idNumber || "",
		phone: phone || "",
		city: city || "",
		address: address || "",
		category: category || "ط£ط³ط± ظ…ط­طھط§ط¬ط©",
		status: status || "ط¬ط¯ظٹط¯",
		familyMembers: parseInt(familyMembers) || 1,
		monthlyIncome: parseFloat(monthlyIncome) || 0,
		maritalStatus: maritalStatus || "",
		notes: notes || "",
		createdBy: uid || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ظ…ط³طھظپظٹط¯", benId, `طھظ… ط¥ط¶ط§ظپط© ظ…ط³طھظپظٹط¯ ط¬ط¯ظٹط¯: ${name}`, uid, uname);
	const created = db.select().from(beneficiaries).where(eq(beneficiaries.id, benId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$14({ request }) {
	const { id, name, fileNumber, idNumber, phone, city, address, category, status, familyMembers, monthlyIncome, maritalStatus, notes, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…ط³طھظپظٹط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(beneficiaries).where(eq(beneficiaries.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…ط³طھظپظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (status === "ظ…ط¤ظ‡ظ„" && existing.status === "ظ…ظˆظ‚ظˆظپ") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط£ظ‡ظٹظ„ ظ…ط³طھظپظٹط¯ ظ…ظˆظ‚ظˆظپ. ط£ط¹ط¯ طھظپط¹ظٹظ„ظ‡ ط£ظˆظ„ط§ظ‹." }, { status: 400 });
	const before = JSON.stringify(existing);
	const ts = now();
	db.update(beneficiaries).set({
		name: name?.trim() ?? existing.name,
		fileNumber: fileNumber ?? existing.fileNumber,
		idNumber: idNumber ?? existing.idNumber,
		phone: phone ?? existing.phone,
		city: city ?? existing.city,
		address: address ?? existing.address,
		category: category ?? existing.category,
		status: status ?? existing.status,
		familyMembers: familyMembers !== void 0 ? parseInt(familyMembers) : existing.familyMembers,
		monthlyIncome: monthlyIncome !== void 0 ? parseFloat(monthlyIncome) : existing.monthlyIncome,
		maritalStatus: maritalStatus ?? existing.maritalStatus,
		notes: notes ?? existing.notes,
		updatedAt: ts
	}).where(eq(beneficiaries.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ظ…ط³طھظپظٹط¯", id, `طھظ… طھط­ط¯ظٹط« ط¨ظٹط§ظ†ط§طھ ط§ظ„ظ…ط³طھظپظٹط¯: ${name || existing.name}`, userId, userName, before);
	const updated = db.select().from(beneficiaries).where(eq(beneficiaries.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$14({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…ط³طھظپظٹط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(beneficiaries).where(eq(beneficiaries.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…ط³طھظپظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (db.select().from(aidRecords).where(and(eq(aidRecords.beneficiaryId, id), eq(aidRecords.status, "طھظ… ط§ظ„طھط³ظ„ظٹظ…"))).limit(1).all().length > 0) return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ظ…ط³طھظپظٹط¯ ظ„ظ‡ ظ…ط³ط§ط¹ط¯ط§طھ ظ…ط³طھظ„ظ…ط©. ظٹظ…ظƒظ† ط¥ظٹظ‚ط§ظپظ‡ ظپظ‚ط·." }, { status: 400 });
	if (db.select().from(aidRecords).where(and(eq(aidRecords.beneficiaryId, id), or(eq(aidRecords.status, "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ظ…ظˆط§ظپظ‚ط©"), eq(aidRecords.status, "ظ…ط¹طھظ…ط¯")))).limit(1).all().length > 0) return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ظ…ط³طھظپظٹط¯ ظ„ظ‡ ظ…ط³ط§ط¹ط¯ط§طھ ظ‚ظٹط¯ ط§ظ„ظ…ط¹ط§ظ„ط¬ط©. ط¹ط§ظ„ط¬ ط§ظ„ظ…ط³ط§ط¹ط¯ط§طھ ط£ظˆظ„ط§ظ‹ ط£ظˆ ط£ظˆظ‚ظپ ط§ظ„ظ…ط³طھظپظٹط¯." }, { status: 400 });
	const before = JSON.stringify(existing);
	db.delete(beneficiaries).where(eq(beneficiaries.id, id)).run();
	addAudit("ط­ط°ظپ", "ظ…ط³طھظپظٹط¯", id, `طھظ… ط­ط°ظپ ط§ظ„ظ…ط³طھظپظٹط¯: ${existing.name}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$37 = createFileRoute("/api/beneficiaries")({ server: { handlers: {
	GET: __handler_GET$18,
	POST: __handler_POST$15,
	PUT: __handler_PUT$14,
	DELETE: __handler_DELETE$14
} } });
function verifyPassword(p, hash) {
	return Buffer.from(p).toString("base64") === hash;
}
function createSession(userId) {
	const token = genId("sess");
	const expires = new Date(Date.now() + 10080 * 60 * 1e3).toISOString();
	db.insert(sessions).values({
		id: genId("S"),
		userId,
		token,
		expiresAt: expires,
		createdAt: now()
	}).run();
	return token;
}
function getCurrentUser(token) {
	if (!token) return null;
	const session = db.select().from(sessions).where(eq(sessions.token, token)).limit(1).all()[0];
	if (!session) return null;
	if (new Date(session.expiresAt) < /* @__PURE__ */ new Date()) {
		db.delete(sessions).where(eq(sessions.id, session.id)).run();
		return null;
	}
	const user = db.select().from(users).where(eq(users.id, session.userId)).limit(1).all()[0];
	if (!user || user.status !== "نشط") return null;
	const { password, ...safeUser } = user;
	return safeUser;
}
function login(email, password) {
	const user = db.select().from(users).where(eq(users.email, email)).limit(1).all()[0];
	if (!user) return { error: "المستخدم غير موجود" };
	if (!verifyPassword(password, user.password)) return { error: "كلمة المرور غير صحيحة" };
	if (user.status !== "نشط") return { error: "الحساب غير نشط" };
	db.update(users).set({ lastLogin: now() }).where(eq(users.id, user.id)).run();
	const token = createSession(user.id);
	const { password: _, ...safeUser } = user;
	return {
		user: safeUser,
		token
	};
}
function logout(token) {
	db.delete(sessions).where(eq(sessions.token, token)).run();
}
async function __handler_POST$14({ request }) {
	const { email, password, action } = await request.json();
	if (action === "logout") {
		const token = request.headers.get("x-session-token");
		if (token) logout(token);
		return Response.json({ success: true });
	}
	if (!email || !password) return Response.json({ error: "ط§ظ„ط¨ط±ظٹط¯ ط§ظ„ط¥ظ„ظƒطھط±ظˆظ†ظٹ ظˆظƒظ„ظ…ط© ط§ظ„ظ…ط±ظˆط± ظ…ط·ظ„ظˆط¨ط§ظ†" }, { status: 400 });
	const result = login(email, password);
	if (result.error) return Response.json({ error: result.error }, { status: 401 });
	return Response.json({
		user: result.user,
		token: result.token
	});
}
async function __handler_GET$17({ request }) {
	const token = request.headers.get("x-session-token");
	if (!token) return Response.json({ user: null });
	const user = getCurrentUser(token);
	return Response.json({ user });
}
var Route$36 = createFileRoute("/api/auth")({ server: { handlers: {
	POST: __handler_POST$14,
	GET: __handler_GET$17
} } });
async function __handler_GET$16({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const entry = db.select().from(auditLog).where(eq(auditLog.id, id)).limit(1).all()[0];
		if (!entry) return Response.json({ error: "ط§ظ„ط³ط¬ظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		let beforeParsed = null;
		let afterParsed = null;
		try {
			beforeParsed = entry.before ? JSON.parse(entry.before) : null;
		} catch {
			beforeParsed = entry.before;
		}
		try {
			afterParsed = entry.after ? JSON.parse(entry.after) : null;
		} catch {
			afterParsed = entry.after;
		}
		return Response.json({
			item: entry,
			before: beforeParsed,
			after: afterParsed
		});
	}
	const search = url.searchParams.get("search") || "";
	const userName = url.searchParams.get("userName") || "";
	const action = url.searchParams.get("action") || "";
	const entityType = url.searchParams.get("entityType") || "";
	const entityId = url.searchParams.get("entityId") || "";
	const dateFrom = url.searchParams.get("dateFrom") || "";
	const dateTo = url.searchParams.get("dateTo") || "";
	const page = parseInt(url.searchParams.get("page") || "1");
	const limit = parseInt(url.searchParams.get("limit") || "50");
	const offset = (page - 1) * limit;
	const conditions = [];
	if (search) conditions.push(or(like(auditLog.userName, `%${search}%`), like(auditLog.action, `%${search}%`), like(auditLog.entityType, `%${search}%`), like(auditLog.entityId, `%${search}%`), like(auditLog.description, `%${search}%`)));
	if (userName && userName !== "ط§ظ„ظƒظ„") conditions.push(eq(auditLog.userName, userName));
	if (action && action !== "ط§ظ„ظƒظ„") conditions.push(eq(auditLog.action, action));
	if (entityType && entityType !== "ط§ظ„ظƒظ„") conditions.push(eq(auditLog.entityType, entityType));
	if (entityId) conditions.push(eq(auditLog.entityId, entityId));
	if (dateFrom) conditions.push(sql`${auditLog.timestamp} >= ${dateFrom}`);
	if (dateTo) conditions.push(sql`${auditLog.timestamp} <= ${dateTo}`);
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const allQuery = db.select().from(auditLog).$dynamic();
	const total = (whereClause ? allQuery.where(whereClause).orderBy(desc(auditLog.timestamp)).all() : allQuery.orderBy(desc(auditLog.timestamp)).all()).length;
	const itemsQuery = db.select().from(auditLog).$dynamic();
	const items = whereClause ? itemsQuery.where(whereClause).orderBy(desc(auditLog.timestamp)).limit(limit).offset(offset).all() : itemsQuery.orderBy(desc(auditLog.timestamp)).limit(limit).offset(offset).all();
	const allEntries = db.select().from(auditLog).all();
	const userOptions = Array.from(new Set(allEntries.map((e) => e.userName).filter((u) => Boolean(u)))).sort();
	const actionOptions = Array.from(new Set(allEntries.map((e) => e.action))).sort();
	const entityOptions = Array.from(new Set(allEntries.map((e) => e.entityType))).sort();
	return Response.json({
		items,
		total,
		page,
		limit,
		options: {
			users: userOptions,
			actions: actionOptions,
			entities: entityOptions
		}
	});
}
var Route$35 = createFileRoute("/api/audit")({ server: { handlers: { GET: __handler_GET$16 } } });
var READ_ONLY_STATUSES$1 = [
	"ظ…ط³طھط¨ط¹ط¯",
	"ظ…ط¨ط§ط¹",
	"ظ…ظ„ط؛ظٹ"
];
async function __handler_GET$15({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const asset = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		if (!asset) return Response.json({ error: "ط§ظ„ط£طµظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const depCount = db.select({ count: sql`count(*)` }).from(assetDepreciations).where(eq(assetDepreciations.assetId, id)).all()[0]?.count || 0;
		const mvCount = db.select({ count: sql`count(*)` }).from(assetMovements).where(eq(assetMovements.assetId, id)).all()[0]?.count || 0;
		return Response.json({
			item: asset,
			depreciationCount: depCount,
			movementCount: mvCount,
			hasHistory: depCount > 0 || mvCount > 0,
			bookValue: asset.cost - asset.accumulatedDepreciation
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const category = url.searchParams.get("category") || "";
	const conditions = [];
	if (search) conditions.push(or(like(fixedAssets.name, `%${search}%`), like(fixedAssets.code, `%${search}%`), like(fixedAssets.serialNumber, `%${search}%`), like(fixedAssets.category, `%${search}%`), like(fixedAssets.location, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(fixedAssets.status, status));
	if (category && category !== "ط§ظ„ظƒظ„") conditions.push(eq(fixedAssets.category, category));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(fixedAssets).where(whereClause).orderBy(desc(fixedAssets.createdAt)).all() : db.select().from(fixedAssets).orderBy(desc(fixedAssets.createdAt)).all();
	return Response.json({
		items,
		total: items.length
	});
}
async function __handler_POST$13({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "transfer") {
		const { id, toLocation, toResponsible, date, reason, notes, userId, userName } = body;
		const existing = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ط£طµظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (READ_ONLY_STATUSES$1.includes(existing.status)) return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ظ†ظ‚ظ„ ط£طµظ„ ظپظٹ ط­ط§ظ„ط© ${existing.status}` }, { status: 400 });
		const before = JSON.stringify(existing);
		const ts = now();
		db.update(fixedAssets).set({
			location: toLocation || existing.location,
			responsiblePerson: toResponsible || existing.responsiblePerson,
			status: "ظ…ظ†ظ‚ظˆظ„",
			updatedAt: ts
		}).where(eq(fixedAssets.id, id)).run();
		db.insert(assetMovements).values({
			id: genId("AMV"),
			assetId: id,
			type: "طھط­ظˆظٹظ„",
			fromLocation: existing.location || "",
			toLocation: toLocation || "",
			fromResponsible: existing.responsiblePerson || "",
			toResponsible: toResponsible || "",
			date: date || ts,
			reason: reason || "",
			notes: notes || "",
			createdBy: userId || null,
			createdAt: ts
		}).run();
		addAudit("طھط­ظˆظٹظ„", "ط£طµظ„ ط«ط§ط¨طھ", id, `طھظ… ظ†ظ‚ظ„ ط§ظ„ط£طµظ„ ${existing.name} ظ…ظ† ${existing.location || "â€”"} ط¥ظ„ظ‰ ${toLocation || "â€”"}`, userId, userName, before);
		const updated = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "maintain") {
		const { id, date, cost, reason, notes, userId, userName } = body;
		const existing = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ط£طµظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (READ_ONLY_STATUSES$1.includes(existing.status)) return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† طھط³ط¬ظٹظ„ طµظٹط§ظ†ط© ط¹ظ„ظ‰ ط£طµظ„ ظپظٹ ط­ط§ظ„ط© ${existing.status}` }, { status: 400 });
		const before = JSON.stringify(existing);
		const ts = now();
		db.insert(assetMovements).values({
			id: genId("AMV"),
			assetId: id,
			type: "طµظٹط§ظ†ط©",
			cost: parseFloat(cost) || 0,
			date: date || ts,
			reason: reason || "",
			notes: notes || "",
			createdBy: userId || null,
			createdAt: ts
		}).run();
		db.update(fixedAssets).set({
			status: "طھط­طھ ط§ظ„طµظٹط§ظ†ط©",
			updatedAt: ts
		}).where(eq(fixedAssets.id, id)).run();
		addAudit("طµظٹط§ظ†ط©", "ط£طµظ„ ط«ط§ط¨طھ", id, `طھظ… طھط³ط¬ظٹظ„ طµظٹط§ظ†ط© ظ„ظ„ط£طµظ„ ${existing.name} ط¨طھظƒظ„ظپط© ${cost || 0}`, userId, userName, before);
		const updated = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "returnFromMaintenance") {
		const { id, condition, userId, userName } = body;
		const existing = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ط£طµظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status !== "طھط­طھ ط§ظ„طµظٹط§ظ†ط©") return Response.json({ error: "ط§ظ„ط£طµظ„ ظ„ظٹط³ طھط­طھ ط§ظ„طµظٹط§ظ†ط©" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(fixedAssets).set({
			status: "ظ†ط´ط·",
			condition: condition || existing.condition,
			updatedAt: now()
		}).where(eq(fixedAssets.id, id)).run();
		addAudit("ط¥ظ†ظ‡ط§ط، طµظٹط§ظ†ط©", "ط£طµظ„ ط«ط§ط¨طھ", id, `طھظ… ط¥ظ†ظ‡ط§ط، طµظٹط§ظ†ط© ط§ظ„ط£طµظ„ ${existing.name} (ط§ظ„ط­ط§ظ„ط©: ${condition || existing.condition})`, userId, userName, before);
		const updated = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "depreciate") {
		const { id, amount, date, notes, userId, userName } = body;
		const existing = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ط£طµظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (READ_ONLY_STATUSES$1.includes(existing.status)) return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ط¥ظ‡ظ„ط§ظƒ ط£طµظ„ ظپظٹ ط­ط§ظ„ط© ${existing.status}` }, { status: 400 });
		const depAmount = parseFloat(amount) || 0;
		if (depAmount <= 0) return Response.json({ error: "ظ…ط¨ظ„ط؛ ط§ظ„ط¥ظ‡ظ„ط§ظƒ ظٹط¬ط¨ ط£ظ† ظٹظƒظˆظ† ط£ظƒط¨ط± ظ…ظ† طµظپط±" }, { status: 400 });
		const newAccumulated = (existing.accumulated_depreciation ?? 0) + depAmount;
		const bookValue = existing.cost - newAccumulated;
		if (bookValue < -1e-4) return Response.json({ error: `Ø§Ù„Ø¥Ù‡Ù„Ø§Ùƒ Ø³ÙŠØ¬Ø¹Ù„ Ø§Ù„Ù‚ÙŠÙ…Ø© Ø§Ù„Ø¯ÙØªØ±ÙŠØ© Ø³Ø§Ù„Ø¨Ø©. Ø§Ù„ØØ¯ Ø§Ù„Ø£Ù‚ØµÙ‰ Ù„Ù„Ø¥Ù‡Ù„Ø§Ùƒ: ${existing.cost - (existing.accumulated_depreciation ?? 0) - (existing.salvage_value || 0)}` }, { status: 400 });
		const maxDepreciable = existing.cost - (existing.salvage_value || 0);
		if (newAccumulated > maxDepreciable + 1e-4) return Response.json({ error: `Ø¥Ø¬Ù…Ø§Ù„ÙŠ Ø§Ù„Ø¥Ù‡Ù„Ø§Ùƒ Ø³ÙŠØªØ¬Ø§ÙˆØ² (Ø§Ù„ØªÙƒÙ„ÙØ© - Ø§Ù„Ù‚ÙŠÙ…Ø© Ø§Ù„Ù…ØªØ¨Ù‚ÙŠØ©). Ø§Ù„ØØ¯ Ø§Ù„Ù…ØªØ¨Ù‚ÙŠ: ${maxDepreciable - (existing.accumulated_depreciation ?? 0)}` }, { status: 400 });
		const before = JSON.stringify(existing);
		const ts = now();
		db.insert(assetDepreciations).values({
			id: genId("DEP"),
			assetId: id,
			date: date || ts,
			amount: depAmount,
			bookValueAfter: bookValue,
			method: existing.depreciation_method,
			notes: notes || "",
			createdBy: userId || null,
			createdAt: ts
		}).run();
		db.update(fixedAssets).set({
			accumulatedDepreciation: newAccumulated,
			updatedAt: ts
		}).where(eq(fixedAssets.id, id)).run();
		addAudit("ط¥ظ‡ظ„ط§ظƒ", "ط£طµظ„ ط«ط§ط¨طھ", id, `طھظ… طھط³ط¬ظٹظ„ ط¥ظ‡ظ„ط§ظƒ ${depAmount} ظ„ظ„ط£طµظ„ ${existing.name} (ط§ظ„ظ‚ظٹظ…ط© ط§ظ„ط¯ظپطھط±ظٹط© ط¨ط¹ط¯: ${bookValue.toFixed(2)})`, userId, userName, before);
		const updated = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "dispose") {
		const { id, date, reason, notes, userId, userName } = body;
		const existing = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ط£طµظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (READ_ONLY_STATUSES$1.includes(existing.status)) return Response.json({ error: `ط§ظ„ط£طµظ„ ط¨ط§ظ„ظپط¹ظ„ ظپظٹ ط­ط§ظ„ط© ${existing.status}` }, { status: 400 });
		const before = JSON.stringify(existing);
		const ts = now();
		db.update(fixedAssets).set({
			status: "ظ…ط³طھط¨ط¹ط¯",
			updatedAt: ts
		}).where(eq(fixedAssets.id, id)).run();
		db.insert(assetMovements).values({
			id: genId("AMV"),
			assetId: id,
			type: "ط§ط³طھط¨ط¹ط§ط¯",
			date: date || ts,
			reason: reason || "",
			notes: notes || "",
			createdBy: userId || null,
			createdAt: ts
		}).run();
		addAudit("ط§ط³طھط¨ط¹ط§ط¯", "ط£طµظ„ ط«ط§ط¨طھ", id, `طھظ… ط§ط³طھط¨ط¹ط§ط¯ ط§ظ„ط£طµظ„ ${existing.name}${reason ? ` â€” ط§ظ„ط³ط¨ط¨: ${reason}` : ""}`, userId, userName, before);
		const updated = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "sell") {
		const { id, salePrice, date, buyer, notes, userId, userName } = body;
		const existing = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ط£طµظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (READ_ONLY_STATUSES$1.includes(existing.status)) return Response.json({ error: `ط§ظ„ط£طµظ„ ط¨ط§ظ„ظپط¹ظ„ ظپظٹ ط­ط§ظ„ط© ${existing.status}` }, { status: 400 });
		const before = JSON.stringify(existing);
		const ts = now();
		db.update(fixedAssets).set({
			status: "ظ…ط¨ط§ط¹",
			updatedAt: ts
		}).where(eq(fixedAssets.id, id)).run();
		db.insert(assetMovements).values({
			id: genId("AMV"),
			assetId: id,
			type: "ط¨ظٹط¹",
			cost: parseFloat(salePrice) || 0,
			date: date || ts,
			reason: buyer ? `ط§ظ„ظ…ط´طھط±ظٹ: ${buyer}` : "",
			notes: notes || "",
			createdBy: userId || null,
			createdAt: ts
		}).run();
		addAudit("ط¨ظٹط¹", "ط£طµظ„ ط«ط§ط¨طھ", id, `طھظ… ط¨ظٹط¹ ط§ظ„ط£طµظ„ ${existing.name} ط¨ط³ط¹ط± ${salePrice || 0}`, userId, userName, before);
		const updated = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { name, code, category, location, cost, salvageValue, usefulLifeMonths, depreciationMethod, condition, purchaseDate, supplierId, serialNumber, responsiblePerson, notes, userId, userName } = body;
	if (!name?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„ط£طµظ„ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (supplierId) {
		if (!db.select().from(suppliers).where(eq(suppliers.id, supplierId)).limit(1).all()[0]) return Response.json({ error: "ط§ظ„ظ…ظˆط±ط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 400 });
	}
	const assetId = genId("AST");
	const ts = now();
	db.insert(fixedAssets).values({
		id: assetId,
		name: name.trim(),
		code: code || "",
		category: category || "",
		location: location || "",
		cost: parseFloat(cost) || 0,
		salvageValue: parseFloat(salvageValue) || 0,
		usefulLifeMonths: parseInt(usefulLifeMonths) || 60,
		accumulatedDepreciation: 0,
		depreciationMethod: depreciationMethod || "ظ‚ط³ط· ط«ط§ط¨طھ",
		status: "ظ†ط´ط·",
		condition: condition || "ط¬ظٹط¯",
		purchaseDate: purchaseDate || "",
		supplierId: supplierId || null,
		serialNumber: serialNumber || "",
		responsiblePerson: responsiblePerson || "",
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ط£طµظ„ ط«ط§ط¨طھ", assetId, `طھظ… ط¥ط¶ط§ظپط© ط£طµظ„: ${name} (ط§ظ„طھظƒظ„ظپط© ${cost || 0})`, userId, userName);
	const created = db.select().from(fixedAssets).where(eq(fixedAssets.id, assetId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$13({ request }) {
	const { id, name, code, category, location, cost, salvageValue, usefulLifeMonths, depreciationMethod, condition, purchaseDate, supplierId, serialNumber, responsiblePerson, notes, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط£طµظ„ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ط£طµظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (READ_ONLY_STATUSES$1.includes(existing.status)) return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† طھط¹ط¯ظٹظ„ ط£طµظ„ ظپظٹ ط­ط§ظ„ط© ${existing.status}` }, { status: 400 });
	const before = JSON.stringify(existing);
	db.update(fixedAssets).set({
		name: name?.trim() ?? existing.name,
		code: code ?? existing.code,
		category: category ?? existing.category,
		location: location ?? existing.location,
		cost: cost !== void 0 ? parseFloat(cost) : existing.cost,
		salvageValue: salvageValue !== void 0 ? parseFloat(salvageValue) : existing.salvageValue,
		usefulLifeMonths: usefulLifeMonths !== void 0 ? parseInt(usefulLifeMonths) : existing.usefulLifeMonths,
		depreciationMethod: depreciationMethod ?? existing.depreciationMethod,
		condition: condition ?? existing.condition,
		purchaseDate: purchaseDate ?? existing.purchaseDate,
		supplierId: supplierId ?? existing.supplierId,
		serialNumber: serialNumber ?? existing.serialNumber,
		responsiblePerson: responsiblePerson ?? existing.responsiblePerson,
		notes: notes ?? existing.notes,
		updatedAt: now()
	}).where(eq(fixedAssets.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ط£طµظ„ ط«ط§ط¨طھ", id, `طھظ… طھط­ط¯ظٹط« ط§ظ„ط£طµظ„: ${existing.name}`, userId, userName, before);
	const updated = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$13({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط£طµظ„ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(fixedAssets).where(eq(fixedAssets.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ط£طµظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const depCount = db.select({ count: sql`count(*)` }).from(assetDepreciations).where(eq(assetDepreciations.assetId, id)).all()[0]?.count || 0;
	const mvCount = db.select({ count: sql`count(*)` }).from(assetMovements).where(eq(assetMovements.assetId, id)).all()[0]?.count || 0;
	if (depCount > 0 || mvCount > 0) {
		const parts = [];
		if (depCount > 0) parts.push(`${depCount} ظ‚ظٹط¯ ط¥ظ‡ظ„ط§ظƒ`);
		if (mvCount > 0) parts.push(`${mvCount} ط­ط±ظƒط©`);
		return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ط§ظ„ط£طµظ„ ظ„ط§ط±طھط¨ط§ط·ظ‡ ط¨ظ€ ${parts.join(" ظˆ ")}. ظ‚ظ… ط¨ط§ط³طھط¨ط¹ط§ط¯ ط§ظ„ط£طµظ„ ط¨ط¯ظ„ط§ظ‹ ظ…ظ† ط°ظ„ظƒ.` }, { status: 400 });
	}
	const before = JSON.stringify(existing);
	db.delete(fixedAssets).where(eq(fixedAssets.id, id)).run();
	addAudit("ط­ط°ظپ", "ط£طµظ„ ط«ط§ط¨طھ", id, `طھظ… ط­ط°ظپ ط§ظ„ط£طµظ„: ${existing.name}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$34 = createFileRoute("/api/assets")({ server: { handlers: {
	GET: __handler_GET$15,
	POST: __handler_POST$13,
	PUT: __handler_PUT$13,
	DELETE: __handler_DELETE$13
} } });
async function __handler_GET$14({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const aid = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
		if (!aid) return Response.json({ error: "ط§ظ„ط³ط¬ظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const beneficiary = db.select().from(beneficiaries).where(eq(beneficiaries.id, aid.beneficiaryId)).limit(1).all()[0];
		const project = aid.projectId ? db.select().from(projects).where(eq(projects.id, aid.projectId)).limit(1).all()[0] : null;
		return Response.json({ item: {
			...aid,
			beneficiaryName: beneficiary?.name || "",
			beneficiaryStatus: beneficiary?.status || "",
			projectName: project?.name || ""
		} });
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const type = url.searchParams.get("type") || "";
	const beneficiaryId = url.searchParams.get("beneficiaryId") || "";
	const projectId = url.searchParams.get("projectId") || "";
	const page = parseInt(url.searchParams.get("page") || "1");
	const limit = parseInt(url.searchParams.get("limit") || "50");
	const offset = (page - 1) * limit;
	const conditions = [];
	if (search) conditions.push(like(aidRecords.id, `%${search}%`));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(aidRecords.status, status));
	if (type && type !== "ط§ظ„ظƒظ„") conditions.push(eq(aidRecords.type, type));
	if (beneficiaryId) conditions.push(eq(aidRecords.beneficiaryId, beneficiaryId));
	if (projectId) conditions.push(eq(aidRecords.projectId, projectId));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const allQuery = db.select().from(aidRecords).$dynamic();
	const total = (whereClause ? allQuery.where(whereClause).orderBy(desc(aidRecords.createdAt)).all() : allQuery.orderBy(desc(aidRecords.createdAt)).all()).length;
	const itemsQuery = db.select().from(aidRecords).$dynamic();
	const enrichedItems = (whereClause ? itemsQuery.where(whereClause).orderBy(desc(aidRecords.createdAt)).limit(limit).offset(offset).all() : itemsQuery.orderBy(desc(aidRecords.createdAt)).limit(limit).offset(offset).all()).map((a) => {
		const beneficiary = db.select().from(beneficiaries).where(eq(beneficiaries.id, a.beneficiaryId)).limit(1).all()[0];
		const project = a.projectId ? db.select().from(projects).where(eq(projects.id, a.projectId)).limit(1).all()[0] : null;
		return {
			...a,
			beneficiaryName: beneficiary?.name || "",
			beneficiaryStatus: beneficiary?.status || "",
			projectName: project?.name || ""
		};
	});
	return Response.json({
		items: enrichedItems,
		total,
		page,
		limit
	});
}
async function __handler_POST$12({ request }) {
	const body = await request.json();
	const { action, id, userId, userName } = body;
	if (action === "approve") {
		const aid = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
		if (!aid) return Response.json({ error: "ط§ظ„ط³ط¬ظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (aid.status !== "ظ‚ظٹط¯ ط§ظ„ظ…ط±ط§ط¬ط¹ط©") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط§ط¹طھظ…ط§ط¯ ظ‡ط°ط§ ط§ظ„ط³ط¬ظ„" }, { status: 400 });
		const before = JSON.stringify(aid);
		db.update(aidRecords).set({
			status: "ظ…ط¹طھظ…ط¯",
			approvedBy: userId || null,
			approvedAt: now(),
			updatedAt: now()
		}).where(eq(aidRecords.id, id)).run();
		addAudit("ط§ط¹طھظ…ط§ط¯", "ظ…ط³ط§ط¹ط¯ط©", id, `طھظ… ط§ط¹طھظ…ط§ط¯ ط§ظ„ظ…ط³ط§ط¹ط¯ط©`, userId, userName, before);
		const updated = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "reject") {
		const aid = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
		if (!aid) return Response.json({ error: "ط§ظ„ط³ط¬ظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const before = JSON.stringify(aid);
		db.update(aidRecords).set({
			status: "ظ…ط±ظپظˆط¶",
			updatedAt: now()
		}).where(eq(aidRecords.id, id)).run();
		addAudit("ط±ظپط¶", "ظ…ط³ط§ط¹ط¯ط©", id, `طھظ… ط±ظپط¶ ط§ظ„ظ…ط³ط§ط¹ط¯ط©`, userId, userName, before);
		const updated = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "deliver") {
		const aid = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
		if (!aid) return Response.json({ error: "ط§ظ„ط³ط¬ظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const beneficiary = db.select().from(beneficiaries).where(eq(beneficiaries.id, aid.beneficiaryId)).limit(1).all()[0];
		if (!beneficiary) return Response.json({ error: "ط§ظ„ظ…ط³طھظپظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (beneficiary.status !== "ظ…ط¤ظ‡ظ„") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط³ظ„ظٹظ… ظ…ط³ط§ط¹ط¯ط© ظ„ظ…ط³طھظپظٹط¯ ط؛ظٹط± ظ…ط¤ظ‡ظ„" }, { status: 400 });
		if (aid.status !== "ظ…ط¹طھظ…ط¯") return Response.json({ error: "ظٹط¬ط¨ ط§ط¹طھظ…ط§ط¯ ط§ظ„ظ…ط³ط§ط¹ط¯ط© ط£ظˆظ„ط§ظ‹" }, { status: 400 });
		const before = JSON.stringify(aid);
		const ts = now();
		db.update(aidRecords).set({
			status: "طھظ… ط§ظ„طھط³ظ„ظٹظ…",
			updatedAt: ts,
			deliveredAt: ts,
			deliveredBy: userId || null,
			deliveryMethod: body.deliveryMethod || "",
			deliveryNotes: body.deliveryNotes || ""
		}).where(eq(aidRecords.id, id)).run();
		if (aid.projectId && aid.amount > 0) {
			const project = db.select().from(projects).where(eq(projects.id, aid.projectId)).limit(1).all()[0];
			if (project) db.update(projects).set({
				spent: project.spent + aid.amount,
				beneficiaryCount: project.beneficiaryCount + 1,
				updatedAt: now()
			}).where(eq(projects.id, aid.projectId)).run();
		}
		addAudit("طھط³ظ„ظٹظ…", "ظ…ط³ط§ط¹ط¯ط©", id, `طھظ… طھط³ظ„ظٹظ… ط§ظ„ظ…ط³ط§ط¹ط¯ط© ط¨ظ…ط¨ظ„ط؛ ${aid.amount} ط±.ط³`, userId, userName, before);
		const updated = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "return") {
		const aid = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
		if (!aid) return Response.json({ error: "ط§ظ„ط³ط¬ظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const before = JSON.stringify(aid);
		db.update(aidRecords).set({
			status: "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ظ…ظˆط§ظپظ‚ط©",
			updatedAt: now()
		}).where(eq(aidRecords.id, id)).run();
		addAudit("ط¥ط±ط¬ط§ط¹", "ظ…ط³ط§ط¹ط¯ط©", id, `طھظ… ط¥ط±ط¬ط§ط¹ ط§ظ„ظ…ط³ط§ط¹ط¯ط© ظ„ظ„طھط¹ط¯ظٹظ„`, userId, userName, before);
		const updated = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { beneficiaryId, projectId, type, amount, date, notes, userId: uid, userName: uname } = body;
	if (!beneficiaryId) return Response.json({ error: "ط§ظ„ظ…ط³طھظپظٹط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!type) return Response.json({ error: "ظ†ظˆط¹ ط§ظ„ظ…ط³ط§ط¹ط¯ط© ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const beneficiary = db.select().from(beneficiaries).where(eq(beneficiaries.id, beneficiaryId)).limit(1).all()[0];
	if (beneficiary && beneficiary.status !== "ظ…ط¤ظ‡ظ„") return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ط¥ط¶ط§ظپط© ظ…ط³ط§ط¹ط¯ط© ظ„ظ…ط³طھظپظٹط¯ ط¨ط­ط§ظ„ط©: ${beneficiary.status}` }, { status: 400 });
	const aidId = genId("AID");
	const ts = now();
	db.insert(aidRecords).values({
		id: aidId,
		beneficiaryId,
		projectId: projectId || null,
		type,
		amount: parseFloat(amount) || 0,
		status: "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ظ…ظˆط§ظپظ‚ط©",
		date: date || ts,
		approvedBy: null,
		approvedAt: null,
		notes: notes || "",
		createdBy: uid || null,
		createdAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ظ…ط³ط§ط¹ط¯ط©", aidId, `طھظ… ط¥ط¶ط§ظپط© ظ…ط³ط§ط¹ط¯ط© ط¬ط¯ظٹط¯ط©: ${type}`, uid, uname);
	const created = db.select().from(aidRecords).where(eq(aidRecords.id, aidId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$12({ request }) {
	const { id, beneficiaryId, projectId, type, amount, date, notes, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط³ط¬ظ„ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ط³ط¬ظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (existing.status === "طھظ… ط§ظ„طھط³ظ„ظٹظ…" || existing.status === "ظ…ط±ظپظˆط¶") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط¹ط¯ظٹظ„ ظ‡ط°ط§ ط§ظ„ط³ط¬ظ„" }, { status: 400 });
	const before = JSON.stringify(existing);
	const ts = now();
	db.update(aidRecords).set({
		beneficiaryId: beneficiaryId ?? existing.beneficiaryId,
		projectId: projectId !== void 0 ? projectId : existing.projectId,
		type: type ?? existing.type,
		amount: amount !== void 0 ? parseFloat(amount) : existing.amount,
		date: date ?? existing.date,
		notes: notes ?? existing.notes,
		updatedAt: ts
	}).where(eq(aidRecords.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ظ…ط³ط§ط¹ط¯ط©", id, `طھظ… طھط­ط¯ظٹط« ط¨ظٹط§ظ†ط§طھ ط§ظ„ظ…ط³ط§ط¹ط¯ط©`, userId, userName, before);
	const updated = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$12({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط³ط¬ظ„ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(aidRecords).where(eq(aidRecords.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ط³ط¬ظ„ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (existing.status === "طھظ… ط§ظ„طھط³ظ„ظٹظ…") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ظ…ط³ط§ط¹ط¯ط© طھظ… طھط³ظ„ظٹظ…ظ‡ط§" }, { status: 400 });
	const before = JSON.stringify(existing);
	db.delete(aidRecords).where(eq(aidRecords.id, id)).run();
	addAudit("ط­ط°ظپ", "ظ…ط³ط§ط¹ط¯ط©", id, `طھظ… ط­ط°ظپ ط§ظ„ظ…ط³ط§ط¹ط¯ط©`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$33 = createFileRoute("/api/aid")({ server: { handlers: {
	GET: __handler_GET$14,
	POST: __handler_POST$12,
	PUT: __handler_PUT$12,
	DELETE: __handler_DELETE$12
} } });
var $$splitComponentImporter$18 = () => import("./aid.new-B9e8qMcF.mjs");
var Route$32 = createFileRoute("/aid/new")({
	head: () => ({ meta: [{ title: "مساعدة جديدة — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component")
});
var $$splitComponentImporter$17 = () => import("./projects._id.edit-CpEisD4P.mjs");
var Route$31 = createFileRoute("/projects/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل مشروع — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component")
});
var $$splitComponentImporter$16 = () => import("./procurement.suppliers.new-C_mF_2pp.mjs");
var Route$30 = createFileRoute("/procurement/suppliers/new")({
	head: () => ({ meta: [{ title: "مورد جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("./procurement.requests.new-xsu1BfF3.mjs");
var Route$29 = createFileRoute("/procurement/requests/new")({
	head: () => ({ meta: [{ title: "طلب شراء جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./procurement.quotes.new-CjmzW_Rz.mjs");
var Route$28 = createFileRoute("/procurement/quotes/new")({
	head: () => ({ meta: [{ title: "عرض سعر جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./procurement.orders.new-4v9X8irw.mjs");
var Route$27 = createFileRoute("/procurement/orders/new")({
	head: () => ({ meta: [{ title: "أمر شراء جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./inventory.warehouses.new-C14bojCc.mjs");
var Route$26 = createFileRoute("/inventory/warehouses/new")({
	head: () => ({ meta: [{ title: "مستودع جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./inventory.stocktake.new-BRM432RO.mjs");
var Route$25 = createFileRoute("/inventory/stocktake/new")({
	head: () => ({ meta: [{ title: "جرد جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./inventory.items.new-BC1H79xE.mjs");
var Route$24 = createFileRoute("/inventory/items/new")({
	head: () => ({ meta: [{ title: "صنف جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./finance.journal.new-2Qck64cj.mjs");
var Route$23 = createFileRoute("/finance/journal/new")({
	head: () => ({ meta: [{ title: "قيد يومية جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./finance.budgets.new--b5A2xO5.mjs");
var Route$22 = createFileRoute("/finance/budgets/new")({
	head: () => ({ meta: [{ title: "موازنة جديدة — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./finance.accounts.new-SPipmmQ5.mjs");
var Route$21 = createFileRoute("/finance/accounts/new")({
	head: () => ({ meta: [{ title: "حساب جديد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./donors._id.edit-Dp02l0yU.mjs");
var Route$20 = createFileRoute("/donors/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل متبرع — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./donations._id.edit-BqIqCFpG.mjs");
var Route$19 = createFileRoute("/donations/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل تبرع — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./beneficiaries._id.edit-DjhNxcML.mjs");
var Route$18 = createFileRoute("/beneficiaries/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل مستفيد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
async function __handler_GET$13({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const supplier = db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1).all()[0];
		if (!supplier) return Response.json({ error: "ط§ظ„ظ…ظˆط±ط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const orderCount = db.select({ count: sql`count(*)` }).from(purchaseOrders).where(eq(purchaseOrders.supplierId, id)).all()[0]?.count || 0;
		const movementCount = db.select({ count: sql`count(*)` }).from(stockMovements).where(and(eq(stockMovements.sourceType, "supplier"), eq(stockMovements.sourceId, id))).all()[0]?.count || 0;
		const assetCount = db.select({ count: sql`count(*)` }).from(fixedAssets).where(eq(fixedAssets.supplierId, id)).all()[0]?.count || 0;
		const usage = orderCount + assetCount;
		return Response.json({
			item: supplier,
			orderCount,
			assetCount,
			movementCount,
			hasTransactions: usage > 0
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const conditions = [];
	if (search) conditions.push(or(like(suppliers.name, `%${search}%`), like(suppliers.activity, `%${search}%`), like(suppliers.phone, `%${search}%`), like(suppliers.taxNumber, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(suppliers.status, status));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(suppliers).where(whereClause).orderBy(desc(suppliers.createdAt)).all() : db.select().from(suppliers).orderBy(desc(suppliers.createdAt)).all();
	const total = items.length;
	return Response.json({
		items,
		total
	});
}
async function __handler_POST$11({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "activate" || action === "deactivate") {
		const { id, userId, userName } = body;
		const existing = db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ظ…ظˆط±ط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const newStatus = action === "activate" ? "ظ†ط´ط·" : "ظ…ظˆظ‚ظˆظپ";
		if (existing.status === newStatus) return Response.json({ error: `ط§ظ„ظ…ظˆط±ط¯ ${newStatus === "ظ†ط´ط·" ? "ظ†ط´ط·" : "ظ…ظˆظ‚ظˆظپ"} ط¨ط§ظ„ظپط¹ظ„` }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(suppliers).set({
			status: newStatus,
			updatedAt: now()
		}).where(eq(suppliers.id, id)).run();
		addAudit(action === "activate" ? "طھظپط¹ظٹظ„" : "طھط¹ط·ظٹظ„", "ظ…ظˆط±ط¯", id, `طھظ… ${action === "activate" ? "طھظپط¹ظٹظ„" : "طھط¹ط·ظٹظ„"} ط§ظ„ظ…ظˆط±ط¯: ${existing.name}`, userId, userName, before);
		const updated = db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { name, activity, phone, email, taxNumber, contactPerson, address, rating, notes, status, userId, userName } = body;
	if (!name?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„ظ…ظˆط±ط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const supId = genId("SUP");
	const ts = now();
	db.insert(suppliers).values({
		id: supId,
		name: name.trim(),
		activity: activity || "",
		phone: phone || null,
		email: email || null,
		taxNumber: taxNumber || "",
		contactPerson: contactPerson || "",
		address: address || "",
		rating: parseFloat(rating) || 0,
		notes: notes || "",
		status: status || "ظ†ط´ط·",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ظ…ظˆط±ط¯", supId, `طھظ… ط¥ط¶ط§ظپط© ظ…ظˆط±ط¯: ${name}`, userId, userName);
	const created = db.select().from(suppliers).where(eq(suppliers.id, supId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$11({ request }) {
	const { id, name, activity, phone, email, taxNumber, contactPerson, address, rating, notes, status, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…ظˆط±ط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…ظˆط±ط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const before = JSON.stringify(existing);
	const ts = now();
	db.update(suppliers).set({
		name: name?.trim() ?? existing.name,
		activity: activity ?? existing.activity,
		phone: phone ?? existing.phone,
		email: email ?? existing.email,
		taxNumber: taxNumber ?? existing.taxNumber,
		contactPerson: contactPerson ?? existing.contactPerson,
		address: address ?? existing.address,
		rating: rating !== void 0 ? parseFloat(rating) : existing.rating,
		notes: notes ?? existing.notes,
		status: status ?? existing.status,
		updatedAt: ts
	}).where(eq(suppliers.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ظ…ظˆط±ط¯", id, `طھظ… طھط­ط¯ظٹط« ط§ظ„ظ…ظˆط±ط¯: ${name || existing.name}`, userId, userName, before);
	const updated = db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$11({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…ظˆط±ط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…ظˆط±ط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const orderCount = db.select({ count: sql`count(*)` }).from(purchaseOrders).where(eq(purchaseOrders.supplierId, id)).all()[0]?.count || 0;
	const assetCount = db.select({ count: sql`count(*)` }).from(fixedAssets).where(eq(fixedAssets.supplierId, id)).all()[0]?.count || 0;
	if (orderCount > 0 || assetCount > 0) {
		const parts = [];
		if (orderCount > 0) parts.push(`${orderCount} ط£ظ…ط± ط´ط±ط§ط،`);
		if (assetCount > 0) parts.push(`${assetCount} ط£طµظ„`);
		return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ط§ظ„ظ…ظˆط±ط¯ ظ„ط§ط±طھط¨ط§ط·ظ‡ ط¨ظ€ ${parts.join(" ظˆ ")}. ظ‚ظ… ط¨طھط¹ط·ظٹظ„ ط§ظ„ظ…ظˆط±ط¯ ط¨ط¯ظ„ط§ظ‹ ظ…ظ† ط°ظ„ظƒ.` }, { status: 400 });
	}
	const before = JSON.stringify(existing);
	db.delete(suppliers).where(eq(suppliers.id, id)).run();
	addAudit("ط­ط°ظپ", "ظ…ظˆط±ط¯", id, `طھظ… ط­ط°ظپ ط§ظ„ظ…ظˆط±ط¯: ${existing.name}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$17 = createFileRoute("/api/procurement/suppliers")({ server: { handlers: {
	GET: __handler_GET$13,
	POST: __handler_POST$11,
	PUT: __handler_PUT$11,
	DELETE: __handler_DELETE$11
} } });
var TERMINAL_STATUSES = ["ظ…ط­ظˆظ„ ط¥ظ„ظ‰ ط£ظ…ط± ط´ط±ط§ط،", "ظ…ظ„ط؛ظٹ"];
async function __handler_GET$12({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const req = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
		if (!req) return Response.json({ error: "ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const orderCount = db.select({ count: sql`count(*)` }).from(purchaseOrders).where(eq(purchaseOrders.requestId, id)).all()[0]?.count || 0;
		return Response.json({
			item: req,
			orderCount
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const department = url.searchParams.get("department") || "";
	const conditions = [];
	if (search) conditions.push(or(like(purchaseRequests.subject, `%${search}%`), like(purchaseRequests.department, `%${search}%`), like(purchaseRequests.requester, `%${search}%`), like(purchaseRequests.notes, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(purchaseRequests.status, status));
	if (department && department !== "ط§ظ„ظƒظ„") conditions.push(eq(purchaseRequests.department, department));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(purchaseRequests).where(whereClause).orderBy(desc(purchaseRequests.createdAt)).all() : db.select().from(purchaseRequests).orderBy(desc(purchaseRequests.createdAt)).all();
	const total = items.length;
	return Response.json({
		items,
		total
	});
}
async function __handler_POST$10({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "submit") {
		const { id, userId, userName } = body;
		const existing = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status !== "ظ…ط³ظˆط¯ط©") return Response.json({ error: "ظٹظ…ظƒظ† ط¥ط±ط³ط§ظ„ ط§ظ„ظ…ط³ظˆط¯ط© ظپظ‚ط·" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(purchaseRequests).set({
			status: "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ظ…ظˆط§ظپظ‚ط©",
			updatedAt: now()
		}).where(eq(purchaseRequests.id, id)).run();
		addAudit("ط¥ط±ط³ط§ظ„ ظ„ظ„ظ…ظˆط§ظپظ‚ط©", "ط·ظ„ط¨ ط´ط±ط§ط،", id, `طھظ… ط¥ط±ط³ط§ظ„ ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ظ„ظ„ظ…ظˆط§ظپظ‚ط©: ${existing.subject}`, userId, userName, before);
		const updated = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "approve") {
		const { id, userId, userName } = body;
		const existing = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status !== "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ظ…ظˆط§ظپظ‚ط©") return Response.json({ error: "ط§ظ„ط·ظ„ط¨ ظ„ظٹط³ ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ظ…ظˆط§ظپظ‚ط©" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(purchaseRequests).set({
			status: "ظ…ط¹طھظ…ط¯",
			updatedAt: now()
		}).where(eq(purchaseRequests.id, id)).run();
		addAudit("ط§ط¹طھظ…ط§ط¯", "ط·ظ„ط¨ ط´ط±ط§ط،", id, `طھظ… ط§ط¹طھظ…ط§ط¯ ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط،: ${existing.subject}`, userId, userName, before);
		const updated = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "reject") {
		const { id, reason, userId, userName } = body;
		const existing = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status !== "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ظ…ظˆط§ظپظ‚ط©") return Response.json({ error: "ط§ظ„ط·ظ„ط¨ ظ„ظٹط³ ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ظ…ظˆط§ظپظ‚ط©" }, { status: 400 });
		const before = JSON.stringify(existing);
		const newNotes = reason ? `${existing.notes || ""}\n[ط±ظپط¶: ${reason}]`.trim() : existing.notes;
		db.update(purchaseRequests).set({
			status: "ظ…ط±ظپظˆط¶",
			notes: newNotes,
			updatedAt: now()
		}).where(eq(purchaseRequests.id, id)).run();
		addAudit("ط±ظپط¶", "ط·ظ„ط¨ ط´ط±ط§ط،", id, `طھظ… ط±ظپط¶ ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط،: ${existing.subject}${reason ? ` â€” ط§ظ„ط³ط¨ط¨: ${reason}` : ""}`, userId, userName, before);
		const updated = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "returnToDraft") {
		const { id, userId, userName } = body;
		const existing = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status === "ظ…ط³ظˆط¯ط©") return Response.json({ error: "ط§ظ„ط·ظ„ط¨ ظ…ط³ظˆط¯ط© ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		if (TERMINAL_STATUSES.includes(existing.status)) return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط¥ط±ط¬ط§ط¹ ط·ظ„ط¨ ظ…ط­ظˆظ‘ظ„ ط£ظˆ ظ…ظ„ط؛ظٹ ط¥ظ„ظ‰ ط§ظ„ظ…ط³ظˆط¯ط©" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(purchaseRequests).set({
			status: "ظ…ط³ظˆط¯ط©",
			updatedAt: now()
		}).where(eq(purchaseRequests.id, id)).run();
		addAudit("ط¥ط¹ط§ط¯ط© ظ„ظ…ط³ظˆط¯ط©", "ط·ظ„ط¨ ط´ط±ط§ط،", id, `طھظ… ط¥ط±ط¬ط§ط¹ ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ظ„ظ„ظ…ط³ظˆط¯ط©: ${existing.subject}`, userId, userName, before);
		const updated = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "cancel") {
		const { id, userId, userName } = body;
		const existing = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status === "ظ…ظ„ط؛ظٹ") return Response.json({ error: "ط§ظ„ط·ظ„ط¨ ظ…ظ„ط؛ظٹ ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		if (existing.status === "ظ…ط­ظˆظ„ ط¥ظ„ظ‰ ط£ظ…ط± ط´ط±ط§ط،") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط¥ظ„ط؛ط§ط، ط·ظ„ط¨ ظ…ط­ظˆظ‘ظ„ ط¥ظ„ظ‰ ط£ظ…ط± ط´ط±ط§ط،" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(purchaseRequests).set({
			status: "ظ…ظ„ط؛ظٹ",
			updatedAt: now()
		}).where(eq(purchaseRequests.id, id)).run();
		addAudit("ط¥ظ„ط؛ط§ط،", "ط·ظ„ط¨ ط´ط±ط§ط،", id, `طھظ… ط¥ظ„ط؛ط§ط، ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط،: ${existing.subject}`, userId, userName, before);
		const updated = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { subject, department, priority, requester, amount, deliveryDate, notes, userId, userName } = body;
	if (!subject?.trim()) return Response.json({ error: "ظ…ظˆط¶ظˆط¹ ط§ظ„ط·ظ„ط¨ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!department?.trim()) return Response.json({ error: "ط§ظ„ظ‚ط³ظ… ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const reqId = genId("PR");
	const ts = now();
	db.insert(purchaseRequests).values({
		id: reqId,
		subject: subject.trim(),
		department: department.trim(),
		priority: priority || "ظ…طھظˆط³ط·ط©",
		status: "ظ…ط³ظˆط¯ط©",
		requester: requester || "",
		amount: parseFloat(amount) || 0,
		deliveryDate: deliveryDate || "",
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ط·ظ„ط¨ ط´ط±ط§ط،", reqId, `طھظ… ط¥ط¶ط§ظپط© ط·ظ„ط¨ ط´ط±ط§ط،: ${subject}`, userId, userName);
	const created = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, reqId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$10({ request }) {
	const { id, subject, department, priority, requester, amount, deliveryDate, notes, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط·ظ„ط¨ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (existing.status !== "ظ…ط³ظˆط¯ط©" && existing.status !== "ظ…ط±ظپظˆط¶") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط¹ط¯ظٹظ„ ط·ظ„ط¨ ظپظٹ ط­ط§ظ„ط© ط­ط§ظ„ظٹط©. ط£ط¹ط¯ظ‡ ط¥ظ„ظ‰ ط§ظ„ظ…ط³ظˆط¯ط© ط£ظˆظ„ط§ظ‹." }, { status: 400 });
	const before = JSON.stringify(existing);
	db.update(purchaseRequests).set({
		subject: subject?.trim() ?? existing.subject,
		department: department?.trim() ?? existing.department,
		priority: priority ?? existing.priority,
		requester: requester ?? existing.requester,
		amount: amount !== void 0 ? parseFloat(amount) : existing.amount,
		deliveryDate: deliveryDate ?? existing.deliveryDate,
		notes: notes ?? existing.notes,
		updatedAt: now()
	}).where(eq(purchaseRequests.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ط·ظ„ط¨ ط´ط±ط§ط،", id, `طھظ… طھط­ط¯ظٹط« ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط،: ${existing.subject}`, userId, userName, before);
	const updated = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$10({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط·ظ„ط¨ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (existing.status === "ظ…ط¹طھظ…ط¯" || existing.status === "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ظ…ظˆط§ظپظ‚ط©") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ط·ظ„ط¨ ظ…ط¹طھظ…ط¯ ط£ظˆ ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ظ…ظˆط§ظپظ‚ط©. ط£ظ„ط؛ظگظ‡ ط£ظˆظ„ط§ظ‹." }, { status: 400 });
	if (existing.status === "ظ…ط­ظˆظ„ ط¥ظ„ظ‰ ط£ظ…ط± ط´ط±ط§ط،") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ط·ظ„ط¨ ظ…ط­ظˆظ‘ظ„ ط¥ظ„ظ‰ ط£ظ…ط± ط´ط±ط§ط،. ظٹط­طھظپط¸ ط§ظ„ظ†ط¸ط§ظ… ط¨ظ‡ ظ„ظ„ط³ط¬ظ„ ط§ظ„طھط§ط±ظٹط®ظٹ." }, { status: 400 });
	const before = JSON.stringify(existing);
	db.delete(purchaseRequests).where(eq(purchaseRequests.id, id)).run();
	addAudit("ط­ط°ظپ", "ط·ظ„ط¨ ط´ط±ط§ط،", id, `طھظ… ط­ط°ظپ ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط،: ${existing.subject}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$16 = createFileRoute("/api/procurement/requests")({ server: { handlers: {
	GET: __handler_GET$12,
	POST: __handler_POST$10,
	PUT: __handler_PUT$10,
	DELETE: __handler_DELETE$10
} } });
async function __handler_GET$11({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const quote = db.select().from(quotes).where(eq(quotes.id, id)).limit(1).all()[0];
		if (!quote) return Response.json({ error: "ط¹ط±ط¶ ط§ظ„ط³ط¹ط± ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		return Response.json({ item: quote });
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const requestId = url.searchParams.get("requestId") || "";
	const conditions = [];
	if (search) conditions.push(or(like(quotes.supplier, `%${search}%`), like(quotes.delivery, `%${search}%`), like(quotes.notes, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(quotes.status, status));
	if (requestId) conditions.push(eq(quotes.requestId, requestId));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(quotes).where(whereClause).orderBy(desc(quotes.createdAt)).all() : db.select().from(quotes).orderBy(desc(quotes.createdAt)).all();
	return Response.json({
		items,
		total: items.length
	});
}
async function __handler_POST$9({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "accept") {
		const { id, userId, userName } = body;
		const existing = db.select().from(quotes).where(eq(quotes.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط¹ط±ط¶ ط§ظ„ط³ط¹ط± ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status !== "ط¨ط§ظ†طھط¸ط§ط±") return Response.json({ error: "ظٹظ…ظƒظ† ظ‚ط¨ظˆظ„ ط§ظ„ط¹ط±ظˆط¶ ط¨ط§ظ†طھط¸ط§ط± ظپظ‚ط·" }, { status: 400 });
		const before = JSON.stringify(existing);
		if (existing.requestId) db.update(quotes).set({
			winner: false,
			updatedAt: now()
		}).where(and(eq(quotes.requestId, existing.requestId), ne(quotes.id, id))).run();
		db.update(quotes).set({
			status: "ظ…ظ‚ط¨ظˆظ„",
			winner: true,
			updatedAt: now()
		}).where(eq(quotes.id, id)).run();
		addAudit("ظ‚ط¨ظˆظ„", "ط¹ط±ط¶ ط³ط¹ط±", id, `طھظ… ظ‚ط¨ظˆظ„ ط¹ط±ط¶ ط§ظ„ط³ط¹ط± ظˆطھط­ط¯ظٹط¯ظ‡ ظƒظپط§ط¦ط²: ${existing.supplier} (${existing.price})`, userId, userName, before);
		const updated = db.select().from(quotes).where(eq(quotes.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "reject") {
		const { id, userId, userName } = body;
		const existing = db.select().from(quotes).where(eq(quotes.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط¹ط±ط¶ ط§ظ„ط³ط¹ط± ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status !== "ط¨ط§ظ†طھط¸ط§ط±") return Response.json({ error: "ظٹظ…ظƒظ† ط±ظپط¶ ط§ظ„ط¹ط±ظˆط¶ ط¨ط§ظ†طھط¸ط§ط± ظپظ‚ط·" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(quotes).set({
			status: "ظ…ط±ظپظˆط¶",
			winner: false,
			updatedAt: now()
		}).where(eq(quotes.id, id)).run();
		addAudit("ط±ظپط¶", "ط¹ط±ط¶ ط³ط¹ط±", id, `طھظ… ط±ظپط¶ ط¹ط±ط¶ ط§ظ„ط³ط¹ط±: ${existing.supplier}`, userId, userName, before);
		const updated = db.select().from(quotes).where(eq(quotes.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { requestId, supplierId, supplier, price, delivery, warranty, rating, validUntil, notes, userId, userName } = body;
	if (!supplier?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„ظ…ظˆط±ط¯/ط§ظ„ظ…ظˆط±ظ‘ط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (requestId) {
		if (!db.select().from(purchaseRequests).where(eq(purchaseRequests.id, requestId)).limit(1).all()[0]) return Response.json({ error: "ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	}
	const quoteId = genId("QT");
	const ts = now();
	db.insert(quotes).values({
		id: quoteId,
		requestId: requestId || null,
		supplierId: supplierId || null,
		supplier: supplier.trim(),
		price: parseFloat(price) || 0,
		delivery: delivery || "",
		warranty: warranty || "",
		rating: parseFloat(rating) || 0,
		winner: false,
		status: "ط¨ط§ظ†طھط¸ط§ط±",
		validUntil: validUntil || "",
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ط¹ط±ط¶ ط³ط¹ط±", quoteId, `طھظ… ط¥ط¶ط§ظپط© ط¹ط±ط¶ ط³ط¹ط± ظ…ظ† ${supplier} ط¨ط³ط¹ط± ${price}`, userId, userName);
	const created = db.select().from(quotes).where(eq(quotes.id, quoteId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$9({ request }) {
	const { id, supplier, price, delivery, warranty, rating, validUntil, notes, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط¹ط±ط¶ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(quotes).where(eq(quotes.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط¹ط±ط¶ ط§ظ„ط³ط¹ط± ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (existing.status !== "ط¨ط§ظ†طھط¸ط§ط±") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط¹ط¯ظٹظ„ ط¹ط±ط¶ طھظ… ط§ظ„ط¨طھ ظپظٹظ‡" }, { status: 400 });
	const before = JSON.stringify(existing);
	db.update(quotes).set({
		supplier: supplier?.trim() ?? existing.supplier,
		price: price !== void 0 ? parseFloat(price) : existing.price,
		delivery: delivery ?? existing.delivery,
		warranty: warranty ?? existing.warranty,
		rating: rating !== void 0 ? parseFloat(rating) : existing.rating,
		validUntil: validUntil ?? existing.validUntil,
		notes: notes ?? existing.notes,
		updatedAt: now()
	}).where(eq(quotes.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ط¹ط±ط¶ ط³ط¹ط±", id, `طھظ… طھط­ط¯ظٹط« ط¹ط±ط¶ ط§ظ„ط³ط¹ط±: ${existing.supplier}`, userId, userName, before);
	const updated = db.select().from(quotes).where(eq(quotes.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$9({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط¹ط±ط¶ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(quotes).where(eq(quotes.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط¹ط±ط¶ ط§ظ„ط³ط¹ط± ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const before = JSON.stringify(existing);
	db.delete(quotes).where(eq(quotes.id, id)).run();
	addAudit("ط­ط°ظپ", "ط¹ط±ط¶ ط³ط¹ط±", id, `طھظ… ط­ط°ظپ ط¹ط±ط¶ ط§ظ„ط³ط¹ط±: ${existing.supplier}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$15 = createFileRoute("/api/procurement/quotes")({ server: { handlers: {
	GET: __handler_GET$11,
	POST: __handler_POST$9,
	PUT: __handler_PUT$9,
	DELETE: __handler_DELETE$9
} } });
async function __handler_GET$10({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const order = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
		if (!order) return Response.json({ error: "ط£ظ…ط± ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const lines = db.select().from(purchaseOrderLines).where(eq(purchaseOrderLines.orderId, id)).orderBy(purchaseOrderLines.lineNumber).all();
		return Response.json({
			item: order,
			lines
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const supplierId = url.searchParams.get("supplierId") || "";
	const conditions = [];
	if (search) conditions.push(or(like(purchaseOrders.subject, `%${search}%`), like(purchaseOrders.notes, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(purchaseOrders.status, status));
	if (supplierId) conditions.push(eq(purchaseOrders.supplierId, supplierId));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(purchaseOrders).where(whereClause).orderBy(desc(purchaseOrders.createdAt)).all() : db.select().from(purchaseOrders).orderBy(desc(purchaseOrders.createdAt)).all();
	return Response.json({
		items,
		total: items.length
	});
}
async function __handler_POST$8({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "approve") {
		const { id, userId, userName } = body;
		const existing = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط£ظ…ط± ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status !== "ظ…ط³ظˆط¯ط©") return Response.json({ error: "ظٹظ…ظƒظ† ط§ط¹طھظ…ط§ط¯ ط§ظ„ظ…ط³ظˆط¯ط© ظپظ‚ط·" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(purchaseOrders).set({
			status: "ظ…ط¹طھظ…ط¯",
			updatedAt: now()
		}).where(eq(purchaseOrders.id, id)).run();
		addAudit("ط§ط¹طھظ…ط§ط¯", "ط£ظ…ط± ط´ط±ط§ط،", id, `طھظ… ط§ط¹طھظ…ط§ط¯ ط£ظ…ط± ط§ظ„ط´ط±ط§ط،: ${existing.subject}`, userId, userName, before);
		const updated = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "cancel") {
		const { id, userId, userName } = body;
		const existing = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط£ظ…ط± ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status === "ظ…ظ„ط؛ظٹ") return Response.json({ error: "ط§ظ„ط£ظ…ط± ظ…ظ„ط؛ظٹ ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		if (existing.status === "ظ…ط؛ظ„ظ‚") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط¥ظ„ط؛ط§ط، ط£ظ…ط± ظ…ط؛ظ„ظ‚" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(purchaseOrders).set({
			status: "ظ…ظ„ط؛ظٹ",
			updatedAt: now()
		}).where(eq(purchaseOrders.id, id)).run();
		if (existing.requestId) {
			const linked = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, existing.requestId)).limit(1).all()[0];
			if (linked && linked.status === "ظ…ط­ظˆظ„ ط¥ظ„ظ‰ ط£ظ…ط± ط´ط±ط§ط،") db.update(purchaseRequests).set({
				status: "ظ…ط¹طھظ…ط¯",
				updatedAt: now()
			}).where(eq(purchaseRequests.id, existing.requestId)).run();
		}
		addAudit("ط¥ظ„ط؛ط§ط،", "ط£ظ…ط± ط´ط±ط§ط،", id, `طھظ… ط¥ظ„ط؛ط§ط، ط£ظ…ط± ط§ظ„ط´ط±ط§ط،: ${existing.subject}`, userId, userName, before);
		const updated = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "receive") {
		const { id, receipts, userId, userName } = body;
		const order = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
		if (!order) return Response.json({ error: "ط£ظ…ط± ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (order.status !== "ظ…ط¹طھظ…ط¯" && order.status !== "طھظ… ط§ظ„ط§ط³طھظ„ط§ظ… ط¬ط²ط¦ظٹظ‹ط§") return Response.json({ error: "ظٹظ…ظƒظ† ط§ظ„ط§ط³طھظ„ط§ظ… ظپظ‚ط· ظ„ظ„ط£ظˆط§ظ…ط± ط§ظ„ظ…ط¹طھظ…ط¯ط© ط£ظˆ ط§ظ„ظ…ط³طھظ„ظ…ط© ط¬ط²ط¦ظٹط§ظ‹" }, { status: 400 });
		if (!receipts || !Array.isArray(receipts) || receipts.length === 0) return Response.json({ error: "ظٹط¬ط¨ طھط­ط¯ظٹط¯ ط§ظ„ظƒظ…ظٹط§طھ ط§ظ„ظ…ط³طھظ„ظ…ط©" }, { status: 400 });
		const lines = db.select().from(purchaseOrderLines).where(eq(purchaseOrderLines.orderId, id)).all();
		let anyReceived = false;
		let allComplete = true;
		const ts = now();
		const lineMap = new Map(lines.map((l) => [l.id, l]));
		for (const r of receipts) {
			const line = lineMap.get(r.lineId);
			if (!line) continue;
			const newReceived = (line.receivedQuantity || 0) + (r.receivedQty || 0);
			if (newReceived > line.quantity + 1e-4) return Response.json({ error: `ط§ظ„ظƒظ…ظٹط© ط§ظ„ظ…ط³طھظ„ظ…ط© ظ„ظ„ط³ط·ط± "${line.description}" طھطھط¬ط§ظˆط² ط§ظ„ظ…ط·ظ„ظˆط¨ (${line.quantity})` }, { status: 400 });
			db.update(purchaseOrderLines).set({ receivedQuantity: newReceived }).where(eq(purchaseOrderLines.id, line.id)).run();
			if (r.receivedQty > 0 && line.itemId) {
				anyReceived = true;
				const item = db.select().from(inventoryItems).where(eq(inventoryItems.id, line.itemId)).limit(1).all()[0];
				if (item) {
					const newQty = (item.quantity || 0) + r.receivedQty;
					db.update(inventoryItems).set({
						quantity: newQty,
						updatedAt: ts
					}).where(eq(inventoryItems.id, line.itemId)).run();
					db.insert(stockMovements).values({
						id: genId("MV"),
						itemId: line.itemId,
						warehouseId: item.warehouseId || null,
						type: "ط§ط³طھظ„ط§ظ…",
						quantity: r.receivedQty,
						balanceAfter: newQty,
						sourceType: "purchase_order",
						sourceId: order.id,
						reference: `PO ${order.id}`,
						date: ts,
						notes: `ط§ط³طھظ„ط§ظ… ظ…ظ† ط£ظ…ط± ط´ط±ط§ط، ${order.id}`,
						createdBy: userId || null,
						createdAt: ts
					}).run();
				}
			}
			if (newReceived < line.quantity - 1e-4) allComplete = false;
		}
		const before = JSON.stringify(order);
		const newStatus = allComplete ? "طھظ… ط§ظ„ط§ط³طھظ„ط§ظ…" : "طھظ… ط§ظ„ط§ط³طھظ„ط§ظ… ط¬ط²ط¦ظٹظ‹ط§";
		const totalReceived = lines.reduce((sum, l) => {
			const r = receipts.find((x) => x.lineId === l.id);
			return sum + (l.receivedQuantity || 0) + (r?.receivedQty || 0);
		}, 0);
		db.update(purchaseOrders).set({
			status: newStatus,
			receivedAmount: totalReceived,
			updatedAt: ts
		}).where(eq(purchaseOrders.id, id)).run();
		addAudit("ط§ط³طھظ„ط§ظ…", "ط£ظ…ط± ط´ط±ط§ط،", id, `طھظ… ط§ط³طھظ„ط§ظ… ${anyReceived ? "ط£طµظ†ط§ظپ" : "طھط­ط¯ظٹط«"} ظ„ط£ظ…ط± ط§ظ„ط´ط±ط§ط،: ${order.subject}`, userId, userName, before);
		const updated = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "close") {
		const { id, userId, userName } = body;
		const existing = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط£ظ…ط± ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status === "ظ…ط؛ظ„ظ‚") return Response.json({ error: "ط§ظ„ط£ظ…ط± ظ…ط؛ظ„ظ‚ ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(purchaseOrders).set({
			status: "ظ…ط؛ظ„ظ‚",
			updatedAt: now()
		}).where(eq(purchaseOrders.id, id)).run();
		addAudit("ط¥ط؛ظ„ط§ظ‚", "ط£ظ…ط± ط´ط±ط§ط،", id, `طھظ… ط¥ط؛ظ„ط§ظ‚ ط£ظ…ط± ط§ظ„ط´ط±ط§ط،: ${existing.subject}`, userId, userName, before);
		const updated = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { supplierId, requestId, subject, date, deliveryDate, notes, lines, userId, userName } = body;
	if (!subject?.trim()) return Response.json({ error: "ظ…ظˆط¶ظˆط¹ ط£ظ…ط± ط§ظ„ط´ط±ط§ط، ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!Array.isArray(lines) || lines.length === 0) return Response.json({ error: "ظٹط¬ط¨ ط¥ط¶ط§ظپط© ط³ط·ط± ظˆط§ط­ط¯ ط¹ظ„ظ‰ ط§ظ„ط£ظ‚ظ„" }, { status: 400 });
	if (requestId) {
		const req = db.select().from(purchaseRequests).where(eq(purchaseRequests.id, requestId)).limit(1).all()[0];
		if (!req) return Response.json({ error: "ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (req.status !== "ظ…ط¹طھظ…ط¯") return Response.json({ error: "ظٹط¬ط¨ ط£ظ† ظٹظƒظˆظ† ط·ظ„ط¨ ط§ظ„ط´ط±ط§ط، ظ…ط¹طھظ…ط¯ط§ظ‹ ظ‚ط¨ظ„ ط¥ظ†ط´ط§ط، ط£ظ…ط± ط´ط±ط§ط،" }, { status: 400 });
	}
	const orderId = genId("PO");
	const ts = now();
	let total = 0;
	for (const l of lines) total += (parseFloat(l.quantity) || 0) * (parseFloat(l.unitPrice) || 0);
	db.insert(purchaseOrders).values({
		id: orderId,
		supplierId: supplierId || null,
		requestId: requestId || null,
		subject: subject.trim(),
		date: date || ts,
		deliveryDate: deliveryDate || "",
		status: "ظ…ط³ظˆط¯ط©",
		total,
		receivedAmount: 0,
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	for (let i = 0; i < lines.length; i++) {
		const l = lines[i];
		db.insert(purchaseOrderLines).values({
			id: genId("POL"),
			orderId,
			lineNumber: i + 1,
			itemId: l.itemId || null,
			description: l.description || "",
			quantity: parseFloat(l.quantity) || 0,
			unitPrice: parseFloat(l.unitPrice) || 0,
			receivedQuantity: 0,
			unit: l.unit || "",
			notes: l.notes || "",
			createdAt: ts
		}).run();
	}
	if (requestId) db.update(purchaseRequests).set({
		status: "ظ…ط­ظˆظ„ ط¥ظ„ظ‰ ط£ظ…ط± ط´ط±ط§ط،",
		updatedAt: ts
	}).where(eq(purchaseRequests.id, requestId)).run();
	addAudit("ط¥ط¶ط§ظپط©", "ط£ظ…ط± ط´ط±ط§ط،", orderId, `طھظ… ط¥ط¶ط§ظپط© ط£ظ…ط± ط´ط±ط§ط،: ${subject} (${lines.length} ط³ط·ط±طŒ ط§ظ„ط¥ط¬ظ…ط§ظ„ظٹ ${total})`, userId, userName);
	const created = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, orderId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$8({ request }) {
	const { id, subject, date, deliveryDate, notes, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط£ظ…ط± ط§ظ„ط´ط±ط§ط، ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط£ظ…ط± ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (existing.status !== "ظ…ط³ظˆط¯ط©") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط¹ط¯ظٹظ„ ط£ظ…ط± ط´ط±ط§ط، ظپظٹ ط­ط§ظ„ط© ط­ط§ظ„ظٹط©" }, { status: 400 });
	const before = JSON.stringify(existing);
	db.update(purchaseOrders).set({
		subject: subject?.trim() ?? existing.subject,
		date: date ?? existing.date,
		deliveryDate: deliveryDate ?? existing.deliveryDate,
		notes: notes ?? existing.notes,
		updatedAt: now()
	}).where(eq(purchaseOrders.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ط£ظ…ط± ط´ط±ط§ط،", id, `طھظ… طھط­ط¯ظٹط« ط£ظ…ط± ط§ظ„ط´ط±ط§ط،: ${existing.subject}`, userId, userName, before);
	const updated = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$8({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط£ظ…ط± ط§ظ„ط´ط±ط§ط، ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(purchaseOrders).where(eq(purchaseOrders.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط£ظ…ط± ط§ظ„ط´ط±ط§ط، ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (existing.status !== "ظ…ط³ظˆط¯ط©") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ط£ظ…ط± ط´ط±ط§ط، ط؛ظٹط± ظ…ط³ظˆط¯ط©. ط£ظ„ط؛ظگظ‡ ط¨ط¯ظ„ط§ظ‹ ظ…ظ† ط°ظ„ظƒ." }, { status: 400 });
	const before = JSON.stringify(existing);
	if (existing.requestId) db.update(purchaseRequests).set({
		status: "ظ…ط¹طھظ…ط¯",
		updatedAt: now()
	}).where(eq(purchaseRequests.id, existing.requestId)).run();
	db.delete(purchaseOrders).where(eq(purchaseOrders.id, id)).run();
	addAudit("ط­ط°ظپ", "ط£ظ…ط± ط´ط±ط§ط،", id, `طھظ… ط­ط°ظپ ط£ظ…ط± ط§ظ„ط´ط±ط§ط،: ${existing.subject}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$14 = createFileRoute("/api/procurement/orders")({ server: { handlers: {
	GET: __handler_GET$10,
	POST: __handler_POST$8,
	PUT: __handler_PUT$8,
	DELETE: __handler_DELETE$8
} } });
async function __handler_GET$9({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const wh = db.select().from(warehouses).where(eq(warehouses.id, id)).limit(1).all()[0];
		if (!wh) return Response.json({ error: "ط§ظ„ظ…ط³طھظˆط¯ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const itemCount = db.select({ count: sql`count(*)` }).from(inventoryItems).where(eq(inventoryItems.warehouseId, id)).all()[0]?.count || 0;
		const movementCount = db.select({ count: sql`count(*)` }).from(stockMovements).where(eq(stockMovements.warehouseId, id)).all()[0]?.count || 0;
		const totalQty = db.select({ total: sql`coalesce(sum(${inventoryItems.quantity}), 0)` }).from(inventoryItems).where(eq(inventoryItems.warehouseId, id)).all()[0]?.total || 0;
		return Response.json({
			item: wh,
			itemCount,
			movementCount,
			totalQty,
			hasMovements: itemCount > 0 || movementCount > 0
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const conditions = [];
	if (search) conditions.push(or(like(warehouses.name, `%${search}%`), like(warehouses.location, `%${search}%`), like(warehouses.manager, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(warehouses.status, status));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(warehouses).where(whereClause).orderBy(desc(warehouses.createdAt)).all() : db.select().from(warehouses).orderBy(desc(warehouses.createdAt)).all();
	return Response.json({
		items,
		total: items.length
	});
}
async function __handler_POST$7({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "activate" || action === "deactivate") {
		const { id, userId, userName } = body;
		const existing = db.select().from(warehouses).where(eq(warehouses.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ظ…ط³طھظˆط¯ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const newStatus = action === "activate" ? "ظ†ط´ط·" : "ظ…ظˆظ‚ظˆظپ";
		if (existing.status === newStatus) return Response.json({ error: `ط§ظ„ظ…ط³طھظˆط¯ط¹ ${newStatus === "ظ†ط´ط·" ? "ظ†ط´ط·" : "ظ…ظˆظ‚ظˆظپ"} ط¨ط§ظ„ظپط¹ظ„` }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(warehouses).set({
			status: newStatus,
			updatedAt: now()
		}).where(eq(warehouses.id, id)).run();
		addAudit(action === "activate" ? "طھظپط¹ظٹظ„" : "طھط¹ط·ظٹظ„", "ظ…ط³طھظˆط¯ط¹", id, `طھظ… ${action === "activate" ? "طھظپط¹ظٹظ„" : "طھط¹ط·ظٹظ„"} ط§ظ„ظ…ط³طھظˆط¯ط¹: ${existing.name}`, userId, userName, before);
		const updated = db.select().from(warehouses).where(eq(warehouses.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { name, location, manager, capacity, occupancy, notes, status, userId, userName } = body;
	if (!name?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„ظ…ط³طھظˆط¯ط¹ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const whId = genId("WH");
	const ts = now();
	db.insert(warehouses).values({
		id: whId,
		name: name.trim(),
		location: location || "",
		manager: manager || "",
		capacity: parseFloat(capacity) || 0,
		occupancy: parseFloat(occupancy) || 0,
		notes: notes || "",
		status: status || "ظ†ط´ط·",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ظ…ط³طھظˆط¯ط¹", whId, `طھظ… ط¥ط¶ط§ظپط© ظ…ط³طھظˆط¯ط¹: ${name}`, userId, userName);
	const created = db.select().from(warehouses).where(eq(warehouses.id, whId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$7({ request }) {
	const { id, name, location, manager, capacity, occupancy, notes, status, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…ط³طھظˆط¯ط¹ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(warehouses).where(eq(warehouses.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…ط³طھظˆط¯ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const before = JSON.stringify(existing);
	db.update(warehouses).set({
		name: name?.trim() ?? existing.name,
		location: location ?? existing.location,
		manager: manager ?? existing.manager,
		capacity: capacity !== void 0 ? parseFloat(capacity) : existing.capacity,
		occupancy: occupancy !== void 0 ? parseFloat(occupancy) : existing.occupancy,
		notes: notes ?? existing.notes,
		status: status ?? existing.status,
		updatedAt: now()
	}).where(eq(warehouses.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ظ…ط³طھظˆط¯ط¹", id, `طھظ… طھط­ط¯ظٹط« ط§ظ„ظ…ط³طھظˆط¯ط¹: ${existing.name}`, userId, userName, before);
	const updated = db.select().from(warehouses).where(eq(warehouses.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$7({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…ط³طھظˆط¯ط¹ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(warehouses).where(eq(warehouses.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…ط³طھظˆط¯ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const itemCount = db.select({ count: sql`count(*)` }).from(inventoryItems).where(eq(inventoryItems.warehouseId, id)).all()[0]?.count || 0;
	const movementCount = db.select({ count: sql`count(*)` }).from(stockMovements).where(eq(stockMovements.warehouseId, id)).all()[0]?.count || 0;
	if (itemCount > 0 || movementCount > 0) {
		const parts = [];
		if (itemCount > 0) parts.push(`${itemCount} طµظ†ظپ`);
		if (movementCount > 0) parts.push(`${movementCount} ط­ط±ظƒط©`);
		return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ط§ظ„ظ…ط³طھظˆط¯ط¹ ظ„ط§ط±طھط¨ط§ط·ظ‡ ط¨ظ€ ${parts.join(" ظˆ ")}. ظ‚ظ… ط¨ط¥ظٹظ‚ط§ظپ ط§ظ„ظ…ط³طھظˆط¯ط¹ ط¨ط¯ظ„ط§ظ‹ ظ…ظ† ط°ظ„ظƒ.` }, { status: 400 });
	}
	const before = JSON.stringify(existing);
	db.delete(warehouses).where(eq(warehouses.id, id)).run();
	addAudit("ط­ط°ظپ", "ظ…ط³طھظˆط¯ط¹", id, `طھظ… ط­ط°ظپ ط§ظ„ظ…ط³طھظˆط¯ط¹: ${existing.name}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$13 = createFileRoute("/api/inventory/warehouses")({ server: { handlers: {
	GET: __handler_GET$9,
	POST: __handler_POST$7,
	PUT: __handler_PUT$7,
	DELETE: __handler_DELETE$7
} } });
var READ_ONLY_STATUSES = ["ظ…ط¹طھظ…ط¯", "ظ…ط؛ظ„ظ‚"];
async function __handler_GET$8({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const st = db.select().from(stocktakes).where(eq(stocktakes.id, id)).limit(1).all()[0];
		if (!st) return Response.json({ error: "ط§ظ„ط¬ط±ط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const lines = db.select().from(stocktakeLines).where(eq(stocktakeLines.stocktakeId, id)).all();
		return Response.json({
			item: st,
			lines
		});
	}
	const status = url.searchParams.get("status") || "";
	const conditions = [];
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(stocktakes.status, status));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(stocktakes).where(whereClause).orderBy(desc(stocktakes.createdAt)).all() : db.select().from(stocktakes).orderBy(desc(stocktakes.createdAt)).all();
	return Response.json({
		items,
		total: items.length
	});
}
async function __handler_POST$6({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "submit") {
		const { id, userId, userName } = body;
		const existing = db.select().from(stocktakes).where(eq(stocktakes.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ط¬ط±ط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status !== "ظ…ط³ظˆط¯ط©") return Response.json({ error: "ظٹظ…ظƒظ† ط¥ط±ط³ط§ظ„ ط§ظ„ظ…ط³ظˆط¯ط© ظپظ‚ط·" }, { status: 400 });
		const lines = db.select().from(stocktakeLines).where(eq(stocktakeLines.stocktakeId, id)).all();
		if (lines.length === 0) return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط¥ط±ط³ط§ظ„ ط¬ط±ط¯ ظپط§ط±ط؛" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(stocktakes).set({
			status: "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ط§ط¹طھظ…ط§ط¯",
			updatedAt: now()
		}).where(eq(stocktakes.id, id)).run();
		addAudit("ط¥ط±ط³ط§ظ„ ظ„ظ„ط§ط¹طھظ…ط§ط¯", "ط¬ط±ط¯", id, `طھظ… ط¥ط±ط³ط§ظ„ ط§ظ„ط¬ط±ط¯ ظ„ظ„ط§ط¹طھظ…ط§ط¯: ${existing.name} (${lines.length} ط³ط·ط±)`, userId, userName, before);
		const updated = db.select().from(stocktakes).where(eq(stocktakes.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "approve") {
		const { id, userId, userName } = body;
		const existing = db.select().from(stocktakes).where(eq(stocktakes.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ط¬ط±ط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status !== "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ط§ط¹طھظ…ط§ط¯") return Response.json({ error: "ط§ظ„ط¬ط±ط¯ ظ„ظٹط³ ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ط§ط¹طھظ…ط§ط¯" }, { status: 400 });
		const lines = db.select().from(stocktakeLines).where(eq(stocktakeLines.stocktakeId, id)).all();
		const ts = now();
		const before = JSON.stringify(existing);
		for (const line of lines) {
			if (Math.abs(line.difference) < 1e-4) continue;
			const item = db.select().from(inventoryItems).where(eq(inventoryItems.id, line.itemId)).limit(1).all()[0];
			if (!item) continue;
			const newQty = item.quantity + line.difference;
			db.update(inventoryItems).set({
				quantity: newQty,
				updatedAt: ts
			}).where(eq(inventoryItems.id, item.id)).run();
			db.insert(stockMovements).values({
				id: genId("MV"),
				itemId: item.id,
				warehouseId: existing.warehouseId || item.warehouseId || null,
				type: "طھط³ظˆظٹط©",
				quantity: line.difference,
				balanceAfter: newQty,
				relatedStocktakeId: id,
				sourceType: "stocktake",
				sourceId: id,
				reference: `ط¬ط±ط¯ ${existing.name}`,
				date: ts,
				notes: `طھط³ظˆظٹط© ط¬ط±ط¯: ط§ظ„ظپط±ظ‚ ${line.difference} (ط§ظ„ظ…ط¹ط¯ظˆط¯ ${line.countedQuantity}طŒ ط¨ط§ظ„ظ†ط¸ط§ظ… ${line.systemQuantity})`,
				createdBy: userId || null,
				createdAt: ts
			}).run();
		}
		db.update(stocktakes).set({
			status: "ظ…ط¹طھظ…ط¯",
			approvedBy: userId || null,
			approvedAt: ts,
			updatedAt: ts
		}).where(eq(stocktakes.id, id)).run();
		addAudit("ط§ط¹طھظ…ط§ط¯", "ط¬ط±ط¯", id, `طھظ… ط§ط¹طھظ…ط§ط¯ ط§ظ„ط¬ط±ط¯ ظˆط¥ظ†ط´ط§ط، طھط³ظˆظٹط§طھ طھظ„ظ‚ط§ط¦ظٹط©: ${existing.name} (${lines.length} ط³ط·ط±)`, userId, userName, before);
		const updated = db.select().from(stocktakes).where(eq(stocktakes.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "close") {
		const { id, userId, userName } = body;
		const existing = db.select().from(stocktakes).where(eq(stocktakes.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ط¬ط±ط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status !== "ظ…ط¹طھظ…ط¯") return Response.json({ error: "ظٹظ…ظƒظ† ط¥ط؛ظ„ط§ظ‚ ط§ظ„ط¬ط±ط¯ ط§ظ„ظ…ط¹طھظ…ط¯ ظپظ‚ط·" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(stocktakes).set({
			status: "ظ…ط؛ظ„ظ‚",
			updatedAt: now()
		}).where(eq(stocktakes.id, id)).run();
		addAudit("ط¥ط؛ظ„ط§ظ‚", "ط¬ط±ط¯", id, `طھظ… ط¥ط؛ظ„ط§ظ‚ ط§ظ„ط¬ط±ط¯: ${existing.name}`, userId, userName, before);
		const updated = db.select().from(stocktakes).where(eq(stocktakes.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { name, warehouseId, date, notes, lines, userId, userName } = body;
	if (!name?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„ط¬ط±ط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!date?.trim()) return Response.json({ error: "طھط§ط±ظٹط® ط§ظ„ط¬ط±ط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (warehouseId) {
		if (!db.select().from(warehouses).where(eq(warehouses.id, warehouseId)).limit(1).all()[0]) return Response.json({ error: "ط§ظ„ظ…ط³طھظˆط¯ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 400 });
	}
	const stId = genId("ST");
	const ts = now();
	db.insert(stocktakes).values({
		id: stId,
		name: name.trim(),
		warehouseId: warehouseId || null,
		date,
		status: "ظ…ط³ظˆط¯ط©",
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	if (Array.isArray(lines)) for (let i = 0; i < lines.length; i++) {
		const l = lines[i];
		const systemQty = db.select().from(inventoryItems).where(eq(inventoryItems.id, l.itemId)).limit(1).all()[0]?.quantity || 0;
		const countedQty = parseFloat(l.countedQuantity) || 0;
		db.insert(stocktakeLines).values({
			id: genId("STL"),
			stocktakeId: stId,
			itemId: l.itemId,
			systemQuantity: systemQty,
			countedQuantity: countedQty,
			difference: countedQty - systemQty,
			notes: l.notes || "",
			createdAt: ts
		}).run();
	}
	addAudit("ط¥ط¶ط§ظپط©", "ط¬ط±ط¯", stId, `طھظ… ط¥ط¶ط§ظپط© ط¬ط±ط¯: ${name} (${Array.isArray(lines) ? lines.length : 0} ط³ط·ط±)`, userId, userName);
	const created = db.select().from(stocktakes).where(eq(stocktakes.id, stId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$6({ request }) {
	const { id, name, warehouseId, date, notes, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط¬ط±ط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(stocktakes).where(eq(stocktakes.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ط¬ط±ط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (READ_ONLY_STATUSES.includes(existing.status)) return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط¹ط¯ظٹظ„ ط¬ط±ط¯ ظ…ط¹طھظ…ط¯ ط£ظˆ ظ…ط؛ظ„ظ‚" }, { status: 400 });
	const before = JSON.stringify(existing);
	db.update(stocktakes).set({
		name: name?.trim() ?? existing.name,
		warehouseId: warehouseId ?? existing.warehouseId,
		date: date ?? existing.date,
		notes: notes ?? existing.notes,
		updatedAt: now()
	}).where(eq(stocktakes.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ط¬ط±ط¯", id, `طھظ… طھط­ط¯ظٹط« ط§ظ„ط¬ط±ط¯: ${existing.name}`, userId, userName, before);
	const updated = db.select().from(stocktakes).where(eq(stocktakes.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$6({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط¬ط±ط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(stocktakes).where(eq(stocktakes.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ط¬ط±ط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (existing.status !== "ظ…ط³ظˆط¯ط©") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ط¬ط±ط¯ طھظ…طھ ظ…ط¹ط§ظ„ط¬طھظ‡. ظٹط­طھظپط¸ ط§ظ„ظ†ط¸ط§ظ… ط¨ظ‡ ظ„ظ„ط³ط¬ظ„ ط§ظ„طھط§ط±ظٹط®ظٹ." }, { status: 400 });
	const before = JSON.stringify(existing);
	db.delete(stocktakes).where(eq(stocktakes.id, id)).run();
	addAudit("ط­ط°ظپ", "ط¬ط±ط¯", id, `طھظ… ط­ط°ظپ ط§ظ„ط¬ط±ط¯: ${existing.name}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$12 = createFileRoute("/api/inventory/stocktake")({ server: { handlers: {
	GET: __handler_GET$8,
	POST: __handler_POST$6,
	PUT: __handler_PUT$6,
	DELETE: __handler_DELETE$6
} } });
async function __handler_GET$7({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const item = db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1).all()[0];
		if (!item) return Response.json({ error: "ط§ظ„طµظ†ظپ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const movementCount = db.select({ count: sql`count(*)` }).from(stockMovements).where(eq(stockMovements.itemId, id)).all()[0]?.count || 0;
		const poLineCount = db.select({ count: sql`count(*)` }).from(purchaseOrderLines).where(eq(purchaseOrderLines.itemId, id)).all()[0]?.count || 0;
		return Response.json({
			item,
			movementCount,
			poLineCount,
			hasMovements: movementCount > 0 || poLineCount > 0
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const category = url.searchParams.get("category") || "";
	const warehouseId = url.searchParams.get("warehouseId") || "";
	const conditions = [];
	if (search) conditions.push(or(like(inventoryItems.name, `%${search}%`), like(inventoryItems.sku, `%${search}%`), like(inventoryItems.category, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(inventoryItems.status, status));
	if (category && category !== "ط§ظ„ظƒظ„") conditions.push(eq(inventoryItems.category, category));
	if (warehouseId) conditions.push(eq(inventoryItems.warehouseId, warehouseId));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(inventoryItems).where(whereClause).orderBy(desc(inventoryItems.createdAt)).all() : db.select().from(inventoryItems).orderBy(desc(inventoryItems.createdAt)).all();
	return Response.json({
		items,
		total: items.length
	});
}
async function __handler_POST$5({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "activate" || action === "deactivate") {
		const { id, userId, userName } = body;
		const existing = db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„طµظ†ظپ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const newStatus = action === "activate" ? "ظ†ط´ط·" : "ظ…ظˆظ‚ظˆظپ";
		if (existing.status === newStatus) return Response.json({ error: `ط§ظ„طµظ†ظپ ${newStatus === "ظ†ط´ط·" ? "ظ†ط´ط·" : "ظ…ظˆظ‚ظˆظپ"} ط¨ط§ظ„ظپط¹ظ„` }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(inventoryItems).set({
			status: newStatus,
			updatedAt: now()
		}).where(eq(inventoryItems.id, id)).run();
		addAudit(action === "activate" ? "طھظپط¹ظٹظ„" : "طھط¹ط·ظٹظ„", "طµظ†ظپ", id, `طھظ… ${action === "activate" ? "طھظپط¹ظٹظ„" : "طھط¹ط·ظٹظ„"} ط§ظ„طµظ†ظپ: ${existing.name}`, userId, userName, before);
		const updated = db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "receive" || action === "issue" || action === "adjust") return handleStockMovement(body);
	if (action === "transfer") return handleTransfer(body);
	const { name, sku, unit, category, warehouseId, quantity, minQuantity, price, notes, status, userId, userName } = body;
	if (!name?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„طµظ†ظپ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!unit?.trim()) return Response.json({ error: "ط§ظ„ظˆط­ط¯ط© ظ…ط·ظ„ظˆط¨ط©" }, { status: 400 });
	if (warehouseId) {
		if (!db.select().from(warehouses).where(eq(warehouses.id, warehouseId)).limit(1).all()[0]) return Response.json({ error: "ط§ظ„ظ…ط³طھظˆط¯ط¹ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 400 });
	}
	const itemId = genId("INV");
	const ts = now();
	const qty = parseFloat(quantity) || 0;
	db.insert(inventoryItems).values({
		id: itemId,
		name: name.trim(),
		sku: sku || "",
		unit: unit.trim(),
		category: category || "",
		warehouseId: warehouseId || null,
		quantity: qty,
		minQuantity: parseFloat(minQuantity) || 0,
		price: parseFloat(price) || 0,
		notes: notes || "",
		status: status || "ظ†ط´ط·",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	if (qty > 0 && warehouseId) db.insert(stockMovements).values({
		id: genId("MV"),
		itemId,
		warehouseId,
		type: "ط§ط³طھظ„ط§ظ…",
		quantity: qty,
		balanceAfter: qty,
		sourceType: "manual",
		reference: "ط±طµظٹط¯ ط§ظپطھطھط§ط­ظٹ",
		date: ts,
		notes: "ط±طµظٹط¯ ط§ظپطھطھط§ط­ظٹ ط¹ظ†ط¯ ط¥ظ†ط´ط§ط، ط§ظ„طµظ†ظپ",
		createdBy: userId || null,
		createdAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "طµظ†ظپ", itemId, `طھظ… ط¥ط¶ط§ظپط© طµظ†ظپ: ${name}`, userId, userName);
	const created = db.select().from(inventoryItems).where(eq(inventoryItems.id, itemId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
function handleStockMovement(body) {
	const { id, action, warehouseId, quantity, notes, userId, userName } = body;
	const qty = parseFloat(String(quantity)) || 0;
	if (qty <= 0) return Response.json({ error: "ط§ظ„ظƒظ…ظٹط© ظٹط¬ط¨ ط£ظ† طھظƒظˆظ† ط£ظƒط¨ط± ظ…ظ† طµظپط±" }, { status: 400 });
	const item = db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1).all()[0];
	if (!item) return Response.json({ error: "ط§ظ„طµظ†ظپ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (item.status === "ظ…ط؛ظ„ظ‚") return Response.json({ error: "ط§ظ„طµظ†ظپ ظ…ط؛ظ„ظ‚. ظ„ط§ ظٹظ…ظƒظ† ط¥ط¬ط±ط§ط، ط­ط±ظƒط§طھ ط¹ظ„ظٹظ‡." }, { status: 400 });
	const movementType = action === "receive" ? "ط§ط³طھظ„ط§ظ…" : action === "issue" ? "طµط±ظپ" : "طھط³ظˆظٹط©";
	let newQty = item.quantity;
	if (movementType === "ط§ط³طھظ„ط§ظ…") newQty = item.quantity + qty;
	else if (movementType === "طµط±ظپ") {
		if (qty > item.quantity) return Response.json({ error: `ط§ظ„ظƒظ…ظٹط© ط؛ظٹط± ظƒط§ظپظٹط©. ط§ظ„ظ…طھط§ط­: ${item.quantity} ${item.unit}طŒ ط§ظ„ظ…ط·ظ„ظˆط¨: ${qty} ${item.unit}.` }, { status: 400 });
		newQty = item.quantity - qty;
	} else if (movementType === "طھط³ظˆظٹط©") newQty = qty;
	const whId = warehouseId || item.warehouseId;
	const ts = now();
	db.update(inventoryItems).set({
		quantity: newQty,
		warehouseId: whId || null,
		updatedAt: ts
	}).where(eq(inventoryItems.id, id)).run();
	db.insert(stockMovements).values({
		id: genId("MV"),
		itemId: id,
		warehouseId: whId || null,
		type: movementType,
		quantity: qty,
		balanceAfter: newQty,
		sourceType: "manual",
		reference: movementType,
		date: ts,
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts
	}).run();
	addAudit(movementType, "طµظ†ظپ", id, `ط­ط±ظƒط© ${movementType} ط¹ظ„ظ‰ ط§ظ„طµظ†ظپ ${item.name}: ${qty} ${item.unit} (ط§ظ„ط±طµظٹط¯ ${newQty})`, userId, userName);
	const updated = db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
function handleTransfer(body) {
	const { id, fromWarehouseId, toWarehouseId, quantity, notes, userId, userName } = body;
	const qty = parseFloat(String(quantity)) || 0;
	if (qty <= 0) return Response.json({ error: "ط§ظ„ظƒظ…ظٹط© ظٹط¬ط¨ ط£ظ† طھظƒظˆظ† ط£ظƒط¨ط± ظ…ظ† طµظپط±" }, { status: 400 });
	if (!fromWarehouseId || !toWarehouseId) return Response.json({ error: "ظٹط¬ط¨ طھط­ط¯ظٹط¯ ط§ظ„ظ…ط³طھظˆط¯ط¹ ط§ظ„ظ…طµط¯ط± ظˆط§ظ„ظ‡ط¯ظپ" }, { status: 400 });
	if (fromWarehouseId === toWarehouseId) return Response.json({ error: "ط§ظ„ظ…ط³طھظˆط¯ط¹ ط§ظ„ظ…طµط¯ط± ظˆط§ظ„ظ‡ط¯ظپ ظٹط¬ط¨ ط£ظ† ظٹظƒظˆظ†ط§ ظ…ط®طھظ„ظپظٹظ†" }, { status: 400 });
	const item = db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1).all()[0];
	if (!item) return Response.json({ error: "ط§ظ„طµظ†ظپ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (item.status === "ظ…ط؛ظ„ظ‚") return Response.json({ error: "ط§ظ„طµظ†ظپ ظ…ط؛ظ„ظ‚. ظ„ط§ ظٹظ…ظƒظ† ط¥ط¬ط±ط§ط، طھط­ظˆظٹظ„ ط¹ظ„ظٹظ‡." }, { status: 400 });
	if (qty > item.quantity) return Response.json({ error: `ط§ظ„ظƒظ…ظٹط© ط؛ظٹط± ظƒط§ظپظٹط© ظ„ظ„طھط­ظˆظٹظ„. ط§ظ„ظ…طھط§ط­: ${item.quantity} ${item.unit}طŒ ط§ظ„ظ…ط·ظ„ظˆط¨: ${qty} ${item.unit}.` }, { status: 400 });
	const ts = now();
	const mvId = genId("MV");
	const balanceAfter = item.quantity - qty;
	db.update(inventoryItems).set({
		quantity: balanceAfter,
		warehouseId: toWarehouseId,
		updatedAt: ts
	}).where(eq(inventoryItems.id, id)).run();
	db.insert(stockMovements).values({
		id: mvId,
		itemId: id,
		warehouseId: fromWarehouseId,
		type: "طھط­ظˆظٹظ„",
		quantity: -qty,
		balanceAfter,
		relatedWarehouseId: toWarehouseId,
		sourceType: "transfer",
		reference: "طھط­ظˆظٹظ„ طµط§ط¯ط±",
		date: ts,
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts
	}).run();
	db.insert(stockMovements).values({
		id: genId("MV"),
		itemId: id,
		warehouseId: toWarehouseId,
		type: "طھط­ظˆظٹظ„",
		quantity: qty,
		balanceAfter,
		relatedWarehouseId: fromWarehouseId,
		relatedStocktakeId: mvId,
		sourceType: "transfer",
		reference: "طھط­ظˆظٹظ„ ظˆط§ط±ط¯",
		date: ts,
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts
	}).run();
	addAudit("طھط­ظˆظٹظ„", "طµظ†ظپ", id, `طھظ… طھط­ظˆظٹظ„ ${qty} ${item.unit} ظ…ظ† ظ…ط³طھظˆط¯ط¹ ${fromWarehouseId} ط¥ظ„ظ‰ ${toWarehouseId} ظ„ظ„طµظ†ظپ ${item.name}`, userId, userName);
	const updated = db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_PUT$5({ request }) {
	const { id, name, sku, unit, category, warehouseId, minQuantity, price, notes, status, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„طµظ†ظپ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„طµظ†ظپ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const before = JSON.stringify(existing);
	db.update(inventoryItems).set({
		name: name?.trim() ?? existing.name,
		sku: sku ?? existing.sku,
		unit: unit ?? existing.unit,
		category: category ?? existing.category,
		warehouseId: warehouseId ?? existing.warehouseId,
		minQuantity: minQuantity !== void 0 ? parseFloat(minQuantity) : existing.minQuantity,
		price: price !== void 0 ? parseFloat(price) : existing.price,
		notes: notes ?? existing.notes,
		status: status ?? existing.status,
		updatedAt: now()
	}).where(eq(inventoryItems.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "طµظ†ظپ", id, `طھظ… طھط­ط¯ظٹط« ط§ظ„طµظ†ظپ: ${existing.name}`, userId, userName, before);
	const updated = db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$5({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„طµظ†ظپ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(inventoryItems).where(eq(inventoryItems.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„طµظ†ظپ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const movementCount = db.select({ count: sql`count(*)` }).from(stockMovements).where(eq(stockMovements.itemId, id)).all()[0]?.count || 0;
	const poLineCount = db.select({ count: sql`count(*)` }).from(purchaseOrderLines).where(eq(purchaseOrderLines.itemId, id)).all()[0]?.count || 0;
	if (movementCount > 0 || poLineCount > 0) {
		const parts = [];
		if (movementCount > 0) parts.push(`${movementCount} ط­ط±ظƒط© ظ…ط®ط²ظˆظ†`);
		if (poLineCount > 0) parts.push(`${poLineCount} ط³ط·ط± ط£ظ…ط± ط´ط±ط§ط،`);
		return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ط§ظ„طµظ†ظپ ظ„ط§ط±طھط¨ط§ط·ظ‡ ط¨ظ€ ${parts.join(" ظˆ ")}. ظ‚ظ… ط¨ط¥ظٹظ‚ط§ظپ ط§ظ„طµظ†ظپ ط¨ط¯ظ„ط§ظ‹ ظ…ظ† ط°ظ„ظƒ.` }, { status: 400 });
	}
	const before = JSON.stringify(existing);
	db.delete(inventoryItems).where(eq(inventoryItems.id, id)).run();
	addAudit("ط­ط°ظپ", "طµظ†ظپ", id, `طھظ… ط­ط°ظپ ط§ظ„طµظ†ظپ: ${existing.name}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$11 = createFileRoute("/api/inventory/items")({ server: { handlers: {
	GET: __handler_GET$7,
	POST: __handler_POST$5,
	PUT: __handler_PUT$5,
	DELETE: __handler_DELETE$5
} } });
async function __handler_GET$6({ request }) {
	const url = new URL(request.url);
	const type = url.searchParams.get("type") || "trial-balance";
	const startDate = url.searchParams.get("startDate") || "";
	const endDate = url.searchParams.get("endDate") || "";
	const asOf = url.searchParams.get("asOf") || endDate;
	const costCenterId = url.searchParams.get("costCenterId") || "";
	const projectId = url.searchParams.get("projectId") || "";
	const budgetId = url.searchParams.get("budgetId") || "";
	if (type === "trial-balance") return getTrialBalance({
		startDate,
		endDate,
		costCenterId,
		projectId
	});
	if (type === "income-expense") return getIncomeExpense({
		startDate,
		endDate,
		costCenterId,
		projectId
	});
	if (type === "financial-position") return getFinancialPosition({
		asOf,
		costCenterId,
		projectId
	});
	if (type === "budget-vs-actual") return getBudgetVsActual({
		budgetId,
		startDate,
		endDate
	});
	return Response.json({ error: "ظ†ظˆط¹ ط§ظ„طھظ‚ط±ظٹط± ط؛ظٹط± ظ…ط¹ط±ظˆظپ" }, { status: 400 });
}
function getTrialBalance(filters) {
	const conditions = [eq(journalEntries.status, "ظ…ط±ط­ظ‘ظ„")];
	if (filters.startDate) conditions.push(sql`${journalEntries.date} >= ${filters.startDate}`);
	if (filters.endDate) conditions.push(sql`${journalEntries.date} <= ${filters.endDate}`);
	if (filters.costCenterId) conditions.push(eq(journalLines.costCenterId, filters.costCenterId));
	if (filters.projectId) conditions.push(eq(journalLines.projectId, filters.projectId));
	const rows = db.select({
		accountId: journalLines.accountId,
		accountCode: accounts.code,
		accountName: accounts.name,
		accountType: accounts.type,
		totalDebit: sql`COALESCE(SUM(${journalLines.debit}), 0)`,
		totalCredit: sql`COALESCE(SUM(${journalLines.credit}), 0)`
	}).from(journalLines).innerJoin(journalEntries, eq(journalLines.journalEntryId, journalEntries.id)).innerJoin(accounts, eq(journalLines.accountId, accounts.id)).where(and(...conditions)).groupBy(journalLines.accountId, accounts.code, accounts.name, accounts.type).all();
	rows.sort((a, b) => a.accountCode.localeCompare(b.accountCode, "ar"));
	const enriched = rows.map((r) => ({
		...r,
		netDebit: r.totalDebit - r.totalCredit,
		balance: r.totalDebit > r.totalCredit ? r.totalDebit - r.totalCredit : r.totalCredit - r.totalDebit,
		isDebit: r.totalDebit >= r.totalCredit
	}));
	const totalDebit = enriched.reduce((s, r) => s + r.totalDebit, 0);
	const totalCredit = enriched.reduce((s, r) => s + r.totalCredit, 0);
	const balanced = Math.abs(totalDebit - totalCredit) < .01;
	return Response.json({
		type: "trial-balance",
		rows: enriched,
		totals: {
			totalDebit,
			totalCredit,
			balanced,
			variance: totalDebit - totalCredit
		}
	});
}
function getIncomeExpense(filters) {
	const conditions = [eq(journalEntries.status, "ظ…ط±ط­ظ‘ظ„"), inArray(accounts.type, ["ط¥ظٹط±ط§ط¯", "ظ…طµط±ظˆظپ"])];
	if (filters.startDate) conditions.push(sql`${journalEntries.date} >= ${filters.startDate}`);
	if (filters.endDate) conditions.push(sql`${journalEntries.date} <= ${filters.endDate}`);
	if (filters.costCenterId) conditions.push(eq(journalLines.costCenterId, filters.costCenterId));
	if (filters.projectId) conditions.push(eq(journalLines.projectId, filters.projectId));
	const enriched = db.select({
		accountId: journalLines.accountId,
		accountCode: accounts.code,
		accountName: accounts.name,
		accountType: accounts.type,
		totalDebit: sql`COALESCE(SUM(${journalLines.debit}), 0)`,
		totalCredit: sql`COALESCE(SUM(${journalLines.credit}), 0)`
	}).from(journalLines).innerJoin(journalEntries, eq(journalLines.journalEntryId, journalEntries.id)).innerJoin(accounts, eq(journalLines.accountId, accounts.id)).where(and(...conditions)).groupBy(journalLines.accountId, accounts.code, accounts.name, accounts.type).all().map((r) => {
		const net = r.accountType === "ط¥ظٹط±ط§ط¯" ? r.totalCredit - r.totalDebit : r.totalDebit - r.totalCredit;
		return {
			...r,
			netAmount: net
		};
	});
	enriched.sort((a, b) => a.accountCode.localeCompare(b.accountCode, "ar"));
	const revenues = enriched.filter((r) => r.accountType === "ط¥ظٹط±ط§ط¯");
	const expenses = enriched.filter((r) => r.accountType === "ظ…طµط±ظˆظپ");
	const totalRevenue = revenues.reduce((s, r) => s + Math.max(0, r.netAmount), 0);
	const totalExpense = expenses.reduce((s, r) => s + Math.max(0, r.netAmount), 0);
	const surplus = totalRevenue - totalExpense;
	return Response.json({
		type: "income-expense",
		revenues,
		expenses,
		totals: {
			totalRevenue,
			totalExpense,
			surplus,
			deficit: surplus < 0
		}
	});
}
function getFinancialPosition(filters) {
	const conditions = [eq(journalEntries.status, "ظ…ط±ط­ظ‘ظ„")];
	if (filters.asOf) conditions.push(sql`${journalEntries.date} <= ${filters.asOf}`);
	if (filters.costCenterId) conditions.push(eq(journalLines.costCenterId, filters.costCenterId));
	if (filters.projectId) conditions.push(eq(journalLines.projectId, filters.projectId));
	const enriched = db.select({
		accountId: journalLines.accountId,
		accountCode: accounts.code,
		accountName: accounts.name,
		accountType: accounts.type,
		accountLevel: accounts.level,
		parentId: accounts.parentId,
		totalDebit: sql`COALESCE(SUM(${journalLines.debit}), 0)`,
		totalCredit: sql`COALESCE(SUM(${journalLines.credit}), 0)`
	}).from(journalLines).innerJoin(journalEntries, eq(journalLines.journalEntryId, journalEntries.id)).innerJoin(accounts, eq(journalLines.accountId, accounts.id)).where(and(...conditions)).groupBy(journalLines.accountId, accounts.code, accounts.name, accounts.type, accounts.level, accounts.parentId).all().map((r) => {
		let balance;
		if (r.accountType === "ط£طµظ„") balance = r.totalDebit - r.totalCredit;
		else if (r.accountType === "ط§ظ„طھط²ط§ظ…" || r.accountType === "ط­ظ‚ظˆظ‚ ظ…ظ„ظƒظٹط©") balance = r.totalCredit - r.totalDebit;
		else balance = r.totalDebit - r.totalCredit;
		return {
			...r,
			balance
		};
	});
	const assets = enriched.filter((r) => r.accountType === "ط£طµظ„");
	const liabilities = enriched.filter((r) => r.accountType === "ط§ظ„طھط²ط§ظ…");
	const equity = enriched.filter((r) => r.accountType === "ط­ظ‚ظˆظ‚ ظ…ظ„ظƒظٹط©");
	const totalAssets = assets.reduce((s, r) => s + r.balance, 0);
	const totalLiabilities = liabilities.reduce((s, r) => s + r.balance, 0);
	const totalEquity = equity.reduce((s, r) => s + r.balance, 0);
	const surplusConditions = [eq(journalEntries.status, "ظ…ط±ط­ظ‘ظ„"), inArray(accounts.type, ["ط¥ظٹط±ط§ط¯", "ظ…طµط±ظˆظپ"])];
	if (filters.asOf) surplusConditions.push(sql`${journalEntries.date} <= ${filters.asOf}`);
	if (filters.costCenterId) surplusConditions.push(eq(journalLines.costCenterId, filters.costCenterId));
	if (filters.projectId) surplusConditions.push(eq(journalLines.projectId, filters.projectId));
	const surplusRows = db.select({
		accountType: accounts.type,
		totalDebit: sql`COALESCE(SUM(${journalLines.debit}), 0)`,
		totalCredit: sql`COALESCE(SUM(${journalLines.credit}), 0)`
	}).from(journalLines).innerJoin(journalEntries, eq(journalLines.journalEntryId, journalEntries.id)).innerJoin(accounts, eq(journalLines.accountId, accounts.id)).where(and(...surplusConditions)).groupBy(accounts.type).all();
	const revenueTotal = surplusRows.find((r) => r.accountType === "ط¥ظٹط±ط§ط¯");
	const expenseTotal = surplusRows.find((r) => r.accountType === "ظ…طµط±ظˆظپ");
	const periodSurplus = (revenueTotal?.totalCredit || 0) - (revenueTotal?.totalDebit || 0) - ((expenseTotal?.totalDebit || 0) - (expenseTotal?.totalCredit || 0));
	const totalEquityWithSurplus = totalEquity + periodSurplus;
	return Response.json({
		type: "financial-position",
		assets,
		liabilities,
		equity,
		periodSurplus,
		totals: {
			totalAssets,
			totalLiabilities,
			totalEquity,
			totalEquityWithSurplus,
			totalLiabilitiesAndEquity: totalLiabilities + totalEquityWithSurplus,
			balanced: Math.abs(totalAssets - (totalLiabilities + totalEquityWithSurplus)) < .01
		}
	});
}
function getBudgetVsActual(filters) {
	let targetBudgets;
	if (filters.budgetId) {
		targetBudgets = db.select().from(budgets).where(eq(budgets.id, filters.budgetId)).all();
		if (targetBudgets.length === 0) return Response.json({ error: "ط§ظ„ظ…ظˆط§ط²ظ†ط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
	} else targetBudgets = db.select().from(budgets).where(inArray(budgets.status, ["ظ…ط¹طھظ…ط¯", "ظ…ظ‚ظپظ„"])).all();
	const result = targetBudgets.map((budget) => {
		const lines = db.select().from(budgetLines).where(eq(budgetLines.budgetId, budget.id)).all();
		const enrichedLines = lines.map((line) => {
			const conditions = [eq(journalEntries.status, "ظ…ط±ط­ظ‘ظ„"), inArray(accounts.type, ["ط¥ظٹط±ط§ط¯", "ظ…طµط±ظˆظپ"])];
			if (line.accountId) conditions.push(eq(journalLines.accountId, line.accountId));
			if (line.costCenterId) conditions.push(eq(journalLines.costCenterId, line.costCenterId));
			if (line.projectId) conditions.push(eq(journalLines.projectId, line.projectId));
			if (filters.startDate) conditions.push(sql`${journalEntries.date} >= ${filters.startDate}`);
			if (filters.endDate) conditions.push(sql`${journalEntries.date} <= ${filters.endDate}`);
			const actuals = db.select({
				accountType: accounts.type,
				totalDebit: sql`COALESCE(SUM(${journalLines.debit}), 0)`,
				totalCredit: sql`COALESCE(SUM(${journalLines.credit}), 0)`
			}).from(journalLines).innerJoin(journalEntries, eq(journalLines.journalEntryId, journalEntries.id)).innerJoin(accounts, eq(journalLines.accountId, accounts.id)).where(and(...conditions)).groupBy(accounts.type).all();
			const revenueActual = (actuals.find((a) => a.accountType === "ط¥ظٹط±ط§ط¯")?.totalCredit || 0) - (actuals.find((a) => a.accountType === "ط¥ظٹط±ط§ط¯")?.totalDebit || 0);
			const expenseActual = (actuals.find((a) => a.accountType === "ظ…طµط±ظˆظپ")?.totalDebit || 0) - (actuals.find((a) => a.accountType === "ظ…طµط±ظˆظپ")?.totalCredit || 0);
			const actualAmount = (line.accountId ? db.select({ type: accounts.type }).from(accounts).where(eq(accounts.id, line.accountId)).limit(1).all()[0] : null)?.type === "ط¥ظٹط±ط§ط¯" ? revenueActual : expenseActual;
			return {
				...line,
				actualAmount,
				variance: line.plannedAmount - actualAmount,
				utilization: line.plannedAmount > 0 ? Math.round(actualAmount / line.plannedAmount * 100) : 0
			};
		});
		const totalPlanned = lines.reduce((s, l) => s + l.plannedAmount, 0);
		const totalActual = enrichedLines.reduce((s, l) => s + l.actualAmount, 0);
		return {
			budget: {
				id: budget.id,
				name: budget.name,
				year: budget.year,
				status: budget.status,
				currency: budget.currency
			},
			lines: enrichedLines,
			totals: {
				planned: totalPlanned,
				actual: totalActual,
				variance: totalPlanned - totalActual,
				utilization: totalPlanned > 0 ? Math.round(totalActual / totalPlanned * 100) : 0
			}
		};
	});
	return Response.json({
		type: "budget-vs-actual",
		budgets: result
	});
}
var Route$10 = createFileRoute("/api/finance/statements")({ server: { handlers: { GET: __handler_GET$6 } } });
async function __handler_GET$5({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const period = db.select().from(fiscalPeriods).where(eq(fiscalPeriods.id, id)).limit(1).all()[0];
		if (!period) return Response.json({ error: "ط§ظ„ظپطھط±ط© ط§ظ„ظ…ط§ظ„ظٹط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
		const entryCount = db.select({ count: sql`COUNT(*)` }).from(journalEntries).where(and(sql`${journalEntries.date} >= ${period.startDate}`, sql`${journalEntries.date} <= ${period.endDate}`)).all()[0]?.count || 0;
		const postedCount = db.select({ count: sql`COUNT(*)` }).from(journalEntries).where(and(sql`${journalEntries.date} >= ${period.startDate}`, sql`${journalEntries.date} <= ${period.endDate}`, eq(journalEntries.status, "ظ…ط±ط­ظ‘ظ„"))).all()[0]?.count || 0;
		const draftCount = db.select({ count: sql`COUNT(*)` }).from(journalEntries).where(and(sql`${journalEntries.date} >= ${period.startDate}`, sql`${journalEntries.date} <= ${period.endDate}`, eq(journalEntries.status, "ظ…ط³ظˆط¯ط©"))).all()[0]?.count || 0;
		return Response.json({
			item: period,
			stats: {
				totalEntries: entryCount,
				postedEntries: postedCount,
				draftEntries: draftCount
			}
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const conditions = [];
	if (search) conditions.push(like(fiscalPeriods.name, `%${search}%`));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(fiscalPeriods.status, status));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(fiscalPeriods).where(whereClause).orderBy(desc(fiscalPeriods.startDate)).all() : db.select().from(fiscalPeriods).orderBy(desc(fiscalPeriods.startDate)).all();
	const total = items.length;
	return Response.json({
		items,
		total
	});
}
async function __handler_POST$4({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "close") {
		const { id, userId, userName, notes } = body;
		const period = db.select().from(fiscalPeriods).where(eq(fiscalPeriods.id, id)).limit(1).all()[0];
		if (!period) return Response.json({ error: "ط§ظ„ظپطھط±ط© ط§ظ„ظ…ط§ظ„ظٹط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
		if (period.status === "ظ…ظ‚ظپظ„ط©") return Response.json({ error: "ط§ظ„ظپطھط±ط© ظ…ظ‚ظپظ„ط© ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		if (period.status === "ظ‚ظٹط¯ ط§ظ„ط¥ظ‚ظپط§ظ„") return Response.json({ error: "ط§ظ„ظپطھط±ط© ظ‚ظٹط¯ ط§ظ„ط¥ظ‚ظپط§ظ„ ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		const draftEntries = db.select().from(journalEntries).where(and(sql`${journalEntries.date} >= ${period.startDate}`, sql`${journalEntries.date} <= ${period.endDate}`, eq(journalEntries.status, "ظ…ط³ظˆط¯ط©"))).all();
		if (draftEntries.length > 0) return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ط¥ظ‚ظپط§ظ„ ط§ظ„ظپطھط±ط©: ظٹظˆط¬ط¯ ${draftEntries.length} ظ‚ظٹط¯ ظ…ط³ظˆط¯ط© ظپظٹ ظ‡ط°ظ‡ ط§ظ„ظپطھط±ط©. ظ‚ظ… ط¨طھط±ط­ظٹظ„ظ‡ط§ ط£ظˆ ط¥ظ„ط؛ط§ط¦ظ‡ط§ ط£ظˆظ„ط§ظ‹.` }, { status: 400 });
		const postedEntries = db.select().from(journalEntries).where(and(sql`${journalEntries.date} >= ${period.startDate}`, sql`${journalEntries.date} <= ${period.endDate}`, eq(journalEntries.status, "ظ…ط±ط­ظ‘ظ„"))).all();
		const unbalanced = [];
		for (const e of postedEntries) {
			const lines = db.select().from(journalLines).where(eq(journalLines.journalEntryId, e.id)).all();
			const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
			const totalCredit = lines.reduce((s, l) => s + l.credit, 0);
			if (Math.abs(totalDebit - totalCredit) >= .01) unbalanced.push(e.number);
		}
		if (unbalanced.length > 0) return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ط¥ظ‚ظپط§ظ„ ط§ظ„ظپطھط±ط©: ظٹظˆط¬ط¯ ${unbalanced.length} ظ‚ظٹط¯ ظ…ط±ط­ظ‘ظ„ ط؛ظٹط± ظ…طھظˆط§ط²ظ† (${unbalanced.slice(0, 3).join("طŒ ")}).` }, { status: 400 });
		const before = JSON.stringify(period);
		const ts = now();
		db.update(fiscalPeriods).set({
			status: "ظ…ظ‚ظپظ„ط©",
			closedAt: ts,
			closedById: userId || null,
			closedByName: userName || "",
			notes: notes ?? period.notes,
			updatedAt: ts
		}).where(eq(fiscalPeriods.id, id)).run();
		addAudit("ط¥ظ‚ظپط§ظ„", "ظپطھط±ط© ظ…ط§ظ„ظٹط©", id, `طھظ… ط¥ظ‚ظپط§ظ„ ط§ظ„ظپطھط±ط© ط§ظ„ظ…ط§ظ„ظٹط©: ${period.name} (ظ…ظ† ${period.startDate} ط¥ظ„ظ‰ ${period.endDate})`, userId, userName, before);
		const updated = db.select().from(fiscalPeriods).where(eq(fiscalPeriods.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "reopen") {
		const { id, userId, userName } = body;
		const period = db.select().from(fiscalPeriods).where(eq(fiscalPeriods.id, id)).limit(1).all()[0];
		if (!period) return Response.json({ error: "ط§ظ„ظپطھط±ط© ط§ظ„ظ…ط§ظ„ظٹط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
		if (period.status !== "ظ…ظ‚ظپظ„ط©") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط¥ط¹ط§ط¯ط© ظپطھط­ ظپطھط±ط© ط؛ظٹط± ظ…ظ‚ظپظ„ط©" }, { status: 400 });
		const before = JSON.stringify(period);
		const ts = now();
		db.update(fiscalPeriods).set({
			status: "ظ…ط¹ط§ط¯ ظپطھط­طھظ‡ط§",
			reopenedAt: ts,
			reopenedById: userId || null,
			reopenedByName: userName || "",
			updatedAt: ts
		}).where(eq(fiscalPeriods.id, id)).run();
		addAudit("ط¥ط¹ط§ط¯ط© ظپطھط­", "ظپطھط±ط© ظ…ط§ظ„ظٹط©", id, `طھظ… ط¥ط¹ط§ط¯ط© ظپطھط­ ط§ظ„ظپطھط±ط© ط§ظ„ظ…ط§ظ„ظٹط©: ${period.name}`, userId, userName, before);
		const updated = db.select().from(fiscalPeriods).where(eq(fiscalPeriods.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { name, startDate, endDate, notes, userId, userName } = body;
	if (!name?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„ظپطھط±ط© ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!startDate?.trim()) return Response.json({ error: "طھط§ط±ظٹط® ط§ظ„ط¨ط¯ط§ظٹط© ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!endDate?.trim()) return Response.json({ error: "طھط§ط±ظٹط® ط§ظ„ظ†ظ‡ط§ظٹط© ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (startDate > endDate) return Response.json({ error: "طھط§ط±ظٹط® ط§ظ„ط¨ط¯ط§ظٹط© ظٹط¬ط¨ ط£ظ† ظٹظƒظˆظ† ظ‚ط¨ظ„ طھط§ط±ظٹط® ط§ظ„ظ†ظ‡ط§ظٹط©" }, { status: 400 });
	if (db.select().from(fiscalPeriods).where(eq(fiscalPeriods.name, name.trim())).all().length > 0) return Response.json({ error: "ظٹظˆط¬ط¯ ظپطھط±ط© ظ…ط§ظ„ظٹط© ط¨ظ†ظپط³ ط§ظ„ط§ط³ظ… ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
	const periodId = genId("FP");
	const ts = now();
	db.insert(fiscalPeriods).values({
		id: periodId,
		name: name.trim(),
		startDate,
		endDate,
		status: "ظ…ظپطھظˆط­ط©",
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ظپطھط±ط© ظ…ط§ظ„ظٹط©", periodId, `طھظ… ط¥ط¶ط§ظپط© ظپطھط±ط© ظ…ط§ظ„ظٹط©: ${name} (ظ…ظ† ${startDate} ط¥ظ„ظ‰ ${endDate})`, userId, userName);
	const created = db.select().from(fiscalPeriods).where(eq(fiscalPeriods.id, periodId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$4({ request }) {
	const { id, name, startDate, endDate, notes, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظپطھط±ط© ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(fiscalPeriods).where(eq(fiscalPeriods.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظپطھط±ط© ط§ظ„ظ…ط§ظ„ظٹط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
	if (existing.status === "ظ…ظ‚ظپظ„ط©") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط¹ط¯ظٹظ„ ظپطھط±ط© ظ…ظ‚ظپظ„ط©. ط£ط¹ط¯ ظپطھط­ظ‡ط§ ط£ظˆظ„ط§ظ‹." }, { status: 400 });
	if (startDate && endDate && startDate > endDate) return Response.json({ error: "طھط§ط±ظٹط® ط§ظ„ط¨ط¯ط§ظٹط© ظٹط¬ط¨ ط£ظ† ظٹظƒظˆظ† ظ‚ط¨ظ„ طھط§ط±ظٹط® ط§ظ„ظ†ظ‡ط§ظٹط©" }, { status: 400 });
	const before = JSON.stringify(existing);
	db.update(fiscalPeriods).set({
		name: name?.trim() ?? existing.name,
		startDate: startDate ?? existing.startDate,
		endDate: endDate ?? existing.endDate,
		notes: notes ?? existing.notes,
		updatedAt: now()
	}).where(eq(fiscalPeriods.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ظپطھط±ط© ظ…ط§ظ„ظٹط©", id, `طھظ… طھط­ط¯ظٹط« ط§ظ„ظپطھط±ط© ط§ظ„ظ…ط§ظ„ظٹط©: ${existing.name}`, userId, userName, before);
	const updated = db.select().from(fiscalPeriods).where(eq(fiscalPeriods.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$4({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظپطھط±ط© ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(fiscalPeriods).where(eq(fiscalPeriods.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظپطھط±ط© ط§ظ„ظ…ط§ظ„ظٹط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
	if (existing.status !== "ظ…ظپطھظˆط­ط©") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ظپطھط±ط© ظ…ظ‚ظپظ„ط© ط£ظˆ ظ‚ظٹط¯ ط§ظ„ط¥ظ‚ظپط§ظ„. ظٹط­طھظپط¸ ط§ظ„ظ†ط¸ط§ظ… ط¨ط§ظ„ظپطھط±ط© ظ„ظ„ط³ط¬ظ„ ط§ظ„طھط§ط±ظٹط®ظٹ." }, { status: 400 });
	const before = JSON.stringify(existing);
	db.delete(fiscalPeriods).where(eq(fiscalPeriods.id, id)).run();
	addAudit("ط­ط°ظپ", "ظپطھط±ط© ظ…ط§ظ„ظٹط©", id, `طھظ… ط­ط°ظپ ط§ظ„ظپطھط±ط© ط§ظ„ظ…ط§ظ„ظٹط©: ${existing.name}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$9 = createFileRoute("/api/finance/periods")({ server: { handlers: {
	GET: __handler_GET$5,
	POST: __handler_POST$4,
	PUT: __handler_PUT$4,
	DELETE: __handler_DELETE$4
} } });
async function __handler_GET$4({ request }) {
	const url = new URL(request.url);
	const accountId = url.searchParams.get("accountId") || "";
	const costCenterId = url.searchParams.get("costCenterId") || "";
	const projectId = url.searchParams.get("projectId") || "";
	const dateFrom = url.searchParams.get("dateFrom") || "";
	const dateTo = url.searchParams.get("dateTo") || "";
	const search = url.searchParams.get("search") || "";
	const entryConditions = [eq(journalEntries.status, "ظ…ط±ط­ظ‘ظ„"), sql`${journalEntries.reversedAt} IS NULL`];
	if (dateFrom) entryConditions.push(gte(journalEntries.date, dateFrom));
	if (dateTo) entryConditions.push(lte(journalEntries.date, dateTo));
	if (projectId) entryConditions.push(eq(journalEntries.projectId, projectId));
	if (search) {
		const s = or(like(journalEntries.number, `%${search}%`), like(journalEntries.description, `%${search}%`), like(journalEntries.notes, `%${search}%`));
		if (s) entryConditions.push(s);
	}
	const entryWhere = and(...entryConditions);
	const matchingEntries = db.select().from(journalEntries).where(entryWhere).orderBy(journalEntries.date, journalEntries.number).all();
	const matchingEntryIds = matchingEntries.map((e) => e.id);
	const lineConditions = [sql`${journalLines.journalEntryId} IN (${sql.join(matchingEntryIds.map((id) => sql`${id}`), sql`, `)})`];
	if (accountId) lineConditions.push(eq(journalLines.accountId, accountId));
	if (costCenterId) lineConditions.push(eq(journalLines.costCenterId, costCenterId));
	if (projectId) lineConditions.push(eq(journalLines.projectId, projectId));
	const lineWhere = and(...lineConditions);
	const lines = db.select().from(journalLines).where(lineWhere).orderBy(journalLines.lineNumber).all();
	const accountList = db.select().from(accounts).all();
	const accountMap = new Map(accountList.map((a) => [a.id, a]));
	const ccList = db.select().from(costCenters).all();
	const ccMap = new Map(ccList.map((c) => [c.id, c]));
	const projList = db.select().from(projects).all();
	const projMap = new Map(projList.map((p) => [p.id, p]));
	const movements = lines.map((line) => {
		const entry = matchingEntries.find((e) => e.id === line.journalEntryId);
		const acc = accountMap.get(line.accountId);
		const cc = line.costCenterId ? ccMap.get(line.costCenterId) : null;
		const proj = line.projectId ? projMap.get(line.projectId) : entry?.projectId ? projMap.get(entry.projectId) : null;
		return {
			lineId: line.id,
			entryId: line.journalEntryId,
			entryNumber: entry?.number || "",
			date: entry?.date || "",
			description: entry?.description || "",
			accountId: line.accountId,
			accountCode: acc?.code || "",
			accountName: acc?.name || "",
			costCenterId: line.costCenterId || "",
			costCenterName: cc?.name || "",
			projectId: line.projectId || entry?.projectId || "",
			projectName: proj?.name || "",
			debit: line.debit,
			credit: line.credit,
			notes: line.notes || "",
			runningBalance: 0
		};
	});
	movements.sort((a, b) => {
		if (a.date !== b.date) return a.date < b.date ? -1 : 1;
		if (a.entryNumber !== b.entryNumber) return a.entryNumber < b.entryNumber ? -1 : 1;
		return a.lineId < b.lineId ? -1 : 1;
	});
	let openingBalance = 0;
	if (accountId && dateFrom) {
		const openingEntryConditions = [
			eq(journalEntries.status, "ظ…ط±ط­ظ‘ظ„"),
			sql`${journalEntries.reversedAt} IS NULL`,
			sql`${journalEntries.date} < ${dateFrom}`
		];
		const openingEntryIds = db.select().from(journalEntries).where(and(...openingEntryConditions)).all().map((e) => e.id);
		if (openingEntryIds.length > 0) openingBalance = db.select().from(journalLines).where(and(eq(journalLines.accountId, accountId), sql`${journalLines.journalEntryId} IN (${sql.join(openingEntryIds.map((id) => sql`${id}`), sql`, `)})`)).all().reduce((sum, l) => sum + (l.debit - l.credit), 0);
	}
	let running = openingBalance;
	let totalDebit = 0;
	let totalCredit = 0;
	for (const m of movements) {
		running += m.debit - m.credit;
		m.runningBalance = running;
		totalDebit += m.debit;
		totalCredit += m.credit;
	}
	const closingBalance = openingBalance + totalDebit - totalCredit;
	const options = {
		accounts: accountList.filter((a) => a.status === "ظ†ط´ط·").map((a) => ({
			id: a.id,
			code: a.code,
			name: a.name
		})),
		costCenters: ccList.filter((c) => c.status === "ظ†ط´ط·").map((c) => ({
			id: c.id,
			name: c.name
		})),
		projects: projList.map((p) => ({
			id: p.id,
			name: p.name
		}))
	};
	return Response.json({
		movements,
		totals: {
			debit: totalDebit,
			credit: totalCredit,
			net: totalDebit - totalCredit
		},
		balances: {
			opening: openingBalance,
			closing: closingBalance
		},
		count: movements.length,
		options
	});
}
var Route$8 = createFileRoute("/api/finance/ledger")({ server: { handlers: { GET: __handler_GET$4 } } });
async function __handler_GET$3({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const entry = db.select().from(journalEntries).where(eq(journalEntries.id, id)).limit(1).all()[0];
		if (!entry) return Response.json({ error: "ط§ظ„ظ‚ظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const lines = db.select().from(journalLines).where(eq(journalLines.journalEntryId, id)).orderBy(journalLines.lineNumber).all();
		const enrichedLines = lines.map((l) => {
			const account = db.select().from(accounts).where(eq(accounts.id, l.accountId)).limit(1).all()[0];
			const cc = l.costCenterId ? db.select().from(costCenters).where(eq(costCenters.id, l.costCenterId)).limit(1).all()[0] : null;
			const project = l.projectId ? db.select().from(projects).where(eq(projects.id, l.projectId)).limit(1).all()[0] : null;
			return {
				...l,
				accountCode: account?.code || "",
				accountName: account?.name || "",
				costCenterName: cc?.name || "",
				projectName: project?.name || ""
			};
		});
		const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
		const totalCredit = lines.reduce((s, l) => s + l.credit, 0);
		let reversedOf = null;
		if (entry.reversedOf) reversedOf = db.select().from(journalEntries).where(eq(journalEntries.id, entry.reversedOf)).limit(1).all()[0];
		const reversalEntries = db.select().from(journalEntries).where(eq(journalEntries.reversedOf, id)).all();
		return Response.json({
			item: entry,
			lines: enrichedLines,
			totals: {
				debit: totalDebit,
				credit: totalCredit,
				balanced: Math.abs(totalDebit - totalCredit) < .01
			},
			reversedOf,
			reversalEntries
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const fund = url.searchParams.get("fund") || "";
	const projectId = url.searchParams.get("projectId") || "";
	const page = parseInt(url.searchParams.get("page") || "1");
	const limit = parseInt(url.searchParams.get("limit") || "50");
	const offset = (page - 1) * limit;
	const conditions = [];
	if (search) conditions.push(or(like(journalEntries.number, `%${search}%`), like(journalEntries.description, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(journalEntries.status, status));
	if (fund && fund !== "ط§ظ„ظƒظ„") conditions.push(eq(journalEntries.fund, fund));
	if (projectId) conditions.push(eq(journalEntries.projectId, projectId));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const allQuery = db.select().from(journalEntries).$dynamic();
	const total = (whereClause ? allQuery.where(whereClause).orderBy(desc(journalEntries.createdAt)).all() : allQuery.orderBy(desc(journalEntries.createdAt)).all()).length;
	const itemsQuery = db.select().from(journalEntries).$dynamic();
	const enrichedItems = (whereClause ? itemsQuery.where(whereClause).orderBy(desc(journalEntries.createdAt)).limit(limit).offset(offset).all() : itemsQuery.orderBy(desc(journalEntries.createdAt)).limit(limit).offset(offset).all()).map((entry) => {
		const lines = db.select().from(journalLines).where(eq(journalLines.journalEntryId, entry.id)).all();
		const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
		const totalCredit = lines.reduce((s, l) => s + l.credit, 0);
		return {
			...entry,
			lineCount: lines.length,
			totalDebit,
			totalCredit
		};
	});
	return Response.json({
		items: enrichedItems,
		total,
		page,
		limit
	});
}
async function __handler_POST$3({ request }) {
	const body = await request.json();
	const { action, id, userId, userName } = body;
	if (action === "post") {
		const entry = db.select().from(journalEntries).where(eq(journalEntries.id, id)).limit(1).all()[0];
		if (!entry) return Response.json({ error: "ط§ظ„ظ‚ظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (entry.status === "ظ…ط±ط­ظ‘ظ„") return Response.json({ error: "ط§ظ„ظ‚ظٹط¯ ظ…ط±ط­ظ‘ظ„ ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		if (entry.status !== "ظ…ط³ظˆط¯ط©" && entry.status !== "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ط§ط¹طھظ…ط§ط¯") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط±ط­ظٹظ„ ظ‚ظٹط¯ ظ…ظ„ط؛ظ‰ ط£ظˆ ظ…ط¹ظƒظˆط³" }, { status: 400 });
		const lines = db.select().from(journalLines).where(eq(journalLines.journalEntryId, id)).all();
		if (lines.length === 0) return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط±ط­ظٹظ„ ظ‚ظٹط¯ ط¨ط¯ظˆظ† ط³ط·ظˆط±" }, { status: 400 });
		const totalDebit = lines.reduce((s, l) => s + l.debit, 0);
		const totalCredit = lines.reduce((s, l) => s + l.credit, 0);
		if (Math.abs(totalDebit - totalCredit) >= .01) return Response.json({ error: `ط§ظ„ظ‚ظٹط¯ ط؛ظٹط± ظ…طھظˆط§ط²ظ†: ظ…ط¬ظ…ظˆط¹ ط§ظ„ظ…ط¯ظٹظ† ${totalDebit} â‰  ظ…ط¬ظ…ظˆط¹ ط§ظ„ط¯ط§ط¦ظ† ${totalCredit}` }, { status: 400 });
		for (const line of lines) {
			const account = db.select().from(accounts).where(eq(accounts.id, line.accountId)).limit(1).all()[0];
			if (!account) return Response.json({ error: `ط§ظ„ط­ط³ط§ط¨ ظپظٹ ط§ظ„ط³ط·ط± ${line.lineNumber} ط؛ظٹط± ظ…ظˆط¬ظˆط¯` }, { status: 400 });
			if (!account.postable) return Response.json({ error: `ط§ظ„ط­ط³ط§ط¨ "${account.code} - ${account.name}" ط؛ظٹط± ظ‚ط§ط¨ظ„ ظ„ظ„طھط±ط­ظٹظ„. ط§ط®طھط± ط­ط³ط§ط¨ط§ظ‹ طھظپطµظٹظ„ظٹط§ظ‹.` }, { status: 400 });
			if (account.status !== "ظ†ط´ط·") return Response.json({ error: `ط§ظ„ط­ط³ط§ط¨ "${account.code}" ظ…ظˆظ‚ظˆظپ ظˆظ„ط§ ظٹظ…ظƒظ† ط§ط³طھط®ط¯ط§ظ…ظ‡ ظپظٹ ظ‚ظٹط¯.` }, { status: 400 });
		}
		const before = JSON.stringify(entry);
		const ts = now();
		db.update(journalEntries).set({
			status: "ظ…ط±ط­ظ‘ظ„",
			postedBy: userId || null,
			postedAt: ts,
			updatedAt: ts
		}).where(eq(journalEntries.id, id)).run();
		addAudit("طھط±ط­ظٹظ„", "ظ‚ظٹط¯ ظٹظˆظ…ظٹط©", id, `طھظ… طھط±ط­ظٹظ„ ط§ظ„ظ‚ظٹط¯: ${entry.number} ط¨ظ…ط¨ظ„ط؛ ${totalDebit} ط±.ط³`, userId, userName, before);
		const updated = db.select().from(journalEntries).where(eq(journalEntries.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "reverse") {
		const entry = db.select().from(journalEntries).where(eq(journalEntries.id, id)).limit(1).all()[0];
		if (!entry) return Response.json({ error: "ط§ظ„ظ‚ظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (entry.status !== "ظ…ط±ط­ظ‘ظ„") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط¹ظƒط³ ظ‚ظٹط¯ ط؛ظٹط± ظ…ط±ط­ظ‘ظ„" }, { status: 400 });
		const lines = db.select().from(journalLines).where(eq(journalLines.journalEntryId, id)).orderBy(journalLines.lineNumber).all();
		if (lines.length === 0) return Response.json({ error: "ط§ظ„ظ‚ظٹط¯ ط§ظ„ط£طµظ„ظٹ ظ„ط§ ظٹط­طھظˆظٹ ط¹ظ„ظ‰ ط³ط·ظˆط±" }, { status: 400 });
		const newNumber = generateJournalNumber();
		const reversalId = genId("JV");
		const ts = now();
		db.insert(journalEntries).values({
			id: reversalId,
			number: newNumber,
			date: ts.split(" ")[0],
			description: `ط¹ظƒط³ ط§ظ„ظ‚ظٹط¯: ${entry.number} - ${entry.description}`,
			debitAccount: lines[0].credit ? `${lines[0].accountId}` : "",
			creditAccount: lines[0].debit ? `${lines[0].accountId}` : "",
			amount: lines[0].debit || lines[0].credit || 0,
			fund: entry.fund,
			currency: entry.currency,
			projectId: entry.projectId,
			sourceType: "reversal",
			sourceId: entry.id,
			status: "ظ…ط±ط­ظ‘ظ„",
			postedBy: userId || null,
			postedAt: ts,
			reversedOf: entry.id,
			notes: entry.notes || "",
			createdBy: userId || null,
			createdAt: ts,
			updatedAt: ts
		}).run();
		let lineNum = 1;
		for (const line of lines) db.insert(journalLines).values({
			id: genId("JL"),
			journalEntryId: reversalId,
			lineNumber: lineNum++,
			accountId: line.accountId,
			description: line.description,
			debit: line.credit,
			credit: line.debit,
			costCenterId: line.costCenterId,
			projectId: line.projectId,
			notes: line.notes,
			createdAt: ts
		}).run();
		db.update(journalEntries).set({
			status: "ظ…ط¹ظƒظˆط³",
			updatedAt: ts
		}).where(eq(journalEntries.id, id)).run();
		addAudit("ط¹ظƒط³", "ظ‚ظٹط¯ ظٹظˆظ…ظٹط©", reversalId, `طھظ… ط¥ظ†ط´ط§ط، ظ‚ظٹط¯ ط¹ظƒط³ظٹ ${newNumber} ظ„ظ„ظ‚ظٹط¯ ${entry.number}`, userId, userName);
		addAudit("ط¹ظƒط³", "ظ‚ظٹط¯ ظٹظˆظ…ظٹط©", id, `طھظ… ط¹ظƒط³ ط§ظ„ظ‚ظٹط¯ ${entry.number} ط¨ظˆط§ط³ط·ط© ${newNumber}`, userId, userName);
		const created = db.select().from(journalEntries).where(eq(journalEntries.id, reversalId)).limit(1).all()[0];
		return Response.json({ item: created }, { status: 201 });
	}
	if (action === "cancel") {
		const entry = db.select().from(journalEntries).where(eq(journalEntries.id, id)).limit(1).all()[0];
		if (!entry) return Response.json({ error: "ط§ظ„ظ‚ظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (entry.status === "ظ…ط±ط­ظ‘ظ„" || entry.status === "ظ…ط¹ظƒظˆط³") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط¥ظ„ط؛ط§ط، ظ‚ظٹط¯ ظ…ط±ط­ظ‘ظ„ ط£ظˆ ظ…ط¹ظƒظˆط³. ط§ط³طھط®ط¯ظ… ط§ظ„ط¹ظƒط³." }, { status: 400 });
		const before = JSON.stringify(entry);
		db.update(journalEntries).set({
			status: "ظ…ظ„ط؛ظ‰",
			updatedAt: now()
		}).where(eq(journalEntries.id, id)).run();
		addAudit("ط¥ظ„ط؛ط§ط،", "ظ‚ظٹط¯ ظٹظˆظ…ظٹط©", id, `طھظ… ط¥ظ„ط؛ط§ط، ط§ظ„ظ‚ظٹط¯: ${entry.number}`, userId, userName, before);
		const updated = db.select().from(journalEntries).where(eq(journalEntries.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { number, date, description, fund, projectId, notes, lines, currency } = body;
	if (!description?.trim()) return Response.json({ error: "ظˆطµظپ ط§ظ„ظ‚ظٹط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!Array.isArray(lines) || lines.length < 2) return Response.json({ error: "ط§ظ„ظ‚ظٹط¯ ظٹط¬ط¨ ط£ظ† ظٹط­طھظˆظٹ ط¹ظ„ظ‰ ط³ط·ط±ظٹظ† ط¹ظ„ظ‰ ط§ظ„ط£ظ‚ظ„" }, { status: 400 });
	let totalDebit = 0;
	let totalCredit = 0;
	for (const [idx, line] of lines.entries()) {
		if (!line.accountId) return Response.json({ error: `ط§ظ„ط³ط·ط± ${idx + 1}: ط§ظ„ط­ط³ط§ط¨ ظ…ط·ظ„ظˆط¨` }, { status: 400 });
		const debit = parseFloat(line.debit) || 0;
		const credit = parseFloat(line.credit) || 0;
		if (debit === 0 && credit === 0) return Response.json({ error: `ط§ظ„ط³ط·ط± ${idx + 1}: ظٹط¬ط¨ ط¥ط¯ط®ط§ظ„ ظ…ط¯ظٹظ† ط£ظˆ ط¯ط§ط¦ظ†` }, { status: 400 });
		if (debit > 0 && credit > 0) return Response.json({ error: `ط§ظ„ط³ط·ط± ${idx + 1}: ظ„ط§ ظٹظ…ظƒظ† ط£ظ† ظٹظƒظˆظ† ظ…ط¯ظٹظ† ظˆط¯ط§ط¦ظ† ظپظٹ ظ†ظپط³ ط§ظ„ظˆظ‚طھ` }, { status: 400 });
		totalDebit += debit;
		totalCredit += credit;
		const account = db.select().from(accounts).where(eq(accounts.id, line.accountId)).limit(1).all()[0];
		if (!account) return Response.json({ error: `ط§ظ„ط³ط·ط± ${idx + 1}: ط§ظ„ط­ط³ط§ط¨ ط؛ظٹط± ظ…ظˆط¬ظˆط¯` }, { status: 400 });
		if (!account.postable) return Response.json({ error: `ط§ظ„ط³ط·ط± ${idx + 1}: ط§ظ„ط­ط³ط§ط¨ "${account.code} - ${account.name}" ط؛ظٹط± ظ‚ط§ط¨ظ„ ظ„ظ„طھط±ط­ظٹظ„. ط§ط®طھط± ط­ط³ط§ط¨ط§ظ‹ طھظپطµظٹظ„ظٹط§ظ‹.` }, { status: 400 });
		if (account.status !== "ظ†ط´ط·") return Response.json({ error: `ط§ظ„ط³ط·ط± ${idx + 1}: ط§ظ„ط­ط³ط§ط¨ "${account.code}" ظ…ظˆظ‚ظˆظپ.` }, { status: 400 });
	}
	if (Math.abs(totalDebit - totalCredit) >= .01) return Response.json({ error: `ط§ظ„ظ‚ظٹط¯ ط؛ظٹط± ظ…طھظˆط§ط²ظ†: ظ…ط¬ظ…ظˆط¹ ط§ظ„ظ…ط¯ظٹظ† ${totalDebit.toFixed(2)} â‰  ظ…ط¬ظ…ظˆط¹ ط§ظ„ط¯ط§ط¦ظ† ${totalCredit.toFixed(2)}` }, { status: 400 });
	const newNumber = number || generateJournalNumber();
	const newId = genId("JV");
	const ts = now();
	db.insert(journalEntries).values({
		id: newId,
		number: newNumber,
		date: date || ts.split(" ")[0],
		description: description.trim(),
		debitAccount: lines[0].accountId || "",
		creditAccount: lines[1]?.accountId || lines[0].accountId || "",
		amount: totalDebit,
		fund: fund || "ظ…ظ‚ظٹط¯",
		currency: currency || "SAR",
		projectId: projectId || null,
		status: "ظ…ط³ظˆط¯ط©",
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	let lineNum = 1;
	for (const line of lines) db.insert(journalLines).values({
		id: genId("JL"),
		journalEntryId: newId,
		lineNumber: lineNum++,
		accountId: line.accountId,
		description: line.description || "",
		debit: parseFloat(line.debit) || 0,
		credit: parseFloat(line.credit) || 0,
		costCenterId: line.costCenterId || null,
		projectId: line.projectId || null,
		notes: line.notes || "",
		createdAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ظ‚ظٹط¯ ظٹظˆظ…ظٹط©", newId, `طھظ… ط¥ط¶ط§ظپط© ظ‚ظٹط¯ ظٹظˆظ…ظٹط©: ${newNumber} ط¨ظ…ط¨ظ„ط؛ ${totalDebit.toFixed(2)} ط±.ط³`, userId, userName);
	const created = db.select().from(journalEntries).where(eq(journalEntries.id, newId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$3({ request }) {
	const { id, date, description, fund, projectId, notes, lines, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ‚ظٹط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const entry = db.select().from(journalEntries).where(eq(journalEntries.id, id)).limit(1).all()[0];
	if (!entry) return Response.json({ error: "ط§ظ„ظ‚ظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (entry.status !== "ظ…ط³ظˆط¯ط©" && entry.status !== "ط¨ط§ظ†طھط¸ط§ط± ط§ظ„ط§ط¹طھظ…ط§ط¯") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط¹ط¯ظٹظ„ ظ‚ظٹط¯ ظ…ط±ط­ظ‘ظ„ ط£ظˆ ظ…ط¹ظƒظˆط³ ط£ظˆ ظ…ظ„ط؛ظ‰" }, { status: 400 });
	if (Array.isArray(lines) && lines.length > 0) {
		if (lines.length < 2) return Response.json({ error: "ط§ظ„ظ‚ظٹط¯ ظٹط¬ط¨ ط£ظ† ظٹط­طھظˆظٹ ط¹ظ„ظ‰ ط³ط·ط±ظٹظ† ط¹ظ„ظ‰ ط§ظ„ط£ظ‚ظ„" }, { status: 400 });
		let totalDebit = 0;
		let totalCredit = 0;
		for (const [idx, line] of lines.entries()) {
			if (!line.accountId) return Response.json({ error: `ط§ظ„ط³ط·ط± ${idx + 1}: ط§ظ„ط­ط³ط§ط¨ ظ…ط·ظ„ظˆط¨` }, { status: 400 });
			const debit = parseFloat(line.debit) || 0;
			const credit = parseFloat(line.credit) || 0;
			if (debit === 0 && credit === 0) return Response.json({ error: `ط§ظ„ط³ط·ط± ${idx + 1}: ظٹط¬ط¨ ط¥ط¯ط®ط§ظ„ ظ…ط¯ظٹظ† ط£ظˆ ط¯ط§ط¦ظ†` }, { status: 400 });
			if (debit > 0 && credit > 0) return Response.json({ error: `ط§ظ„ط³ط·ط± ${idx + 1}: ظ„ط§ ظٹظ…ظƒظ† ط£ظ† ظٹظƒظˆظ† ظ…ط¯ظٹظ† ظˆط¯ط§ط¦ظ† ظپظٹ ظ†ظپط³ ط§ظ„ظˆظ‚طھ` }, { status: 400 });
			totalDebit += debit;
			totalCredit += credit;
		}
		if (Math.abs(totalDebit - totalCredit) >= .01) return Response.json({ error: `ط§ظ„ظ‚ظٹط¯ ط؛ظٹط± ظ…طھظˆط§ط²ظ†: ظ…ط¬ظ…ظˆط¹ ط§ظ„ظ…ط¯ظٹظ† ${totalDebit.toFixed(2)} â‰  ظ…ط¬ظ…ظˆط¹ ط§ظ„ط¯ط§ط¦ظ† ${totalCredit.toFixed(2)}` }, { status: 400 });
		db.delete(journalLines).where(eq(journalLines.journalEntryId, id)).run();
		let lineNum = 1;
		const ts = now();
		for (const line of lines) db.insert(journalLines).values({
			id: genId("JL"),
			journalEntryId: id,
			lineNumber: lineNum++,
			accountId: line.accountId,
			description: line.description || "",
			debit: parseFloat(line.debit) || 0,
			credit: parseFloat(line.credit) || 0,
			costCenterId: line.costCenterId || null,
			projectId: line.projectId || null,
			notes: line.notes || "",
			createdAt: ts
		}).run();
		db.update(journalEntries).set({
			amount: totalDebit,
			updatedAt: ts
		}).where(eq(journalEntries.id, id)).run();
	}
	const before = JSON.stringify(entry);
	db.update(journalEntries).set({
		date: date ?? entry.date,
		description: description?.trim() ?? entry.description,
		fund: fund ?? entry.fund,
		projectId: projectId ?? entry.projectId,
		notes: notes ?? entry.notes,
		updatedAt: now()
	}).where(eq(journalEntries.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ظ‚ظٹط¯ ظٹظˆظ…ظٹط©", id, `طھظ… طھط­ط¯ظٹط« ط§ظ„ظ‚ظٹط¯: ${entry.number}`, userId, userName, before);
	const updated = db.select().from(journalEntries).where(eq(journalEntries.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$3({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ‚ظٹط¯ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const entry = db.select().from(journalEntries).where(eq(journalEntries.id, id)).limit(1).all()[0];
	if (!entry) return Response.json({ error: "ط§ظ„ظ‚ظٹط¯ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	if (entry.status !== "ظ…ط³ظˆط¯ط©") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ظ‚ظٹط¯ ظ…ط±ط­ظ‘ظ„ ط£ظˆ ظ…ط¹ظƒظˆط³ ط£ظˆ ظ…ظ„ط؛ظ‰" }, { status: 400 });
	const before = JSON.stringify(entry);
	db.delete(journalEntries).where(eq(journalEntries.id, id)).run();
	addAudit("ط­ط°ظپ", "ظ‚ظٹط¯ ظٹظˆظ…ظٹط©", id, `طھظ… ط­ط°ظپ ط§ظ„ظ‚ظٹط¯: ${entry.number}`, userId, userName, before);
	return Response.json({ success: true });
}
function generateJournalNumber() {
	const year = (/* @__PURE__ */ new Date()).getFullYear().toString().slice(-2);
	return `JV-${year}-${(db.select().from(journalEntries).all().filter((e) => e.number.startsWith(`JV-${year}`)).reduce((max, e) => {
		const m = e.number.match(/-(\d+)$/);
		if (m) {
			const n = parseInt(m[1]);
			return n > max ? n : max;
		}
		return max;
	}, 0) + 1).toString().padStart(4, "0")}`;
}
var Route$7 = createFileRoute("/api/finance/journal")({ server: { handlers: {
	GET: __handler_GET$3,
	POST: __handler_POST$3,
	PUT: __handler_PUT$3,
	DELETE: __handler_DELETE$3
} } });
async function __handler_GET$2({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const cc = db.select().from(costCenters).where(eq(costCenters.id, id)).limit(1).all()[0];
		if (!cc) return Response.json({ error: "ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const journalUsage = db.select({ count: sql`count(*)` }).from(journalLines).where(eq(journalLines.costCenterId, id)).all()[0]?.count || 0;
		const budgetUsage = db.select({ count: sql`count(*)` }).from(budgetLines).where(eq(budgetLines.costCenterId, id)).all()[0]?.count || 0;
		return Response.json({
			item: cc,
			journalUsage,
			budgetUsage,
			hasUsage: journalUsage > 0 || budgetUsage > 0
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const conditions = [];
	if (search) conditions.push(or(like(costCenters.code, `%${search}%`), like(costCenters.name, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(costCenters.status, status));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(costCenters).where(whereClause).orderBy(costCenters.code).all() : db.select().from(costCenters).orderBy(costCenters.code).all();
	const total = items.length;
	return Response.json({
		items,
		total
	});
}
async function __handler_POST$2({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "deactivate") {
		const { id, userId, userName } = body;
		const existing = db.select().from(costCenters).where(eq(costCenters.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status === "ظ…ظˆظ‚ظˆظپ") return Response.json({ error: "ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط© ظ…ظˆظ‚ظˆظپ ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(costCenters).set({
			status: "ظ…ظˆظ‚ظˆظپ",
			updatedAt: now()
		}).where(eq(costCenters.id, id)).run();
		addAudit("ط¥ظٹظ‚ط§ظپ", "ظ…ط±ظƒط² طھظƒظ„ظپط©", id, `طھظ… ط¥ظٹظ‚ط§ظپ ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط©: ${existing.code} - ${existing.name}`, userId, userName, before);
		const updated = db.select().from(costCenters).where(eq(costCenters.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "activate") {
		const { id, userId, userName } = body;
		const existing = db.select().from(costCenters).where(eq(costCenters.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status === "ظ†ط´ط·") return Response.json({ error: "ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط© ظ†ط´ط· ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(costCenters).set({
			status: "ظ†ط´ط·",
			updatedAt: now()
		}).where(eq(costCenters.id, id)).run();
		addAudit("طھظپط¹ظٹظ„", "ظ…ط±ظƒط² طھظƒظ„ظپط©", id, `طھظ… طھظپط¹ظٹظ„ ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط©: ${existing.code} - ${existing.name}`, userId, userName, before);
		const updated = db.select().from(costCenters).where(eq(costCenters.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { code, name, manager, budget, spent, status, description, notes, userId, userName } = body;
	if (!code?.trim()) return Response.json({ error: "ط±ظ…ط² ط§ظ„ظ…ط±ظƒط² ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!name?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„ظ…ط±ظƒط² ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (db.select().from(costCenters).where(eq(costCenters.code, code.trim())).limit(1).all()[0]) return Response.json({ error: "ط±ظ…ط² ط§ظ„ظ…ط±ظƒط² ظ…ط³طھط®ط¯ظ… ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
	const ccId = genId("CC");
	const ts = now();
	db.insert(costCenters).values({
		id: ccId,
		code: code.trim(),
		name: name.trim(),
		manager: manager || "",
		budget: parseFloat(budget) || 0,
		spent: parseFloat(spent) || 0,
		status: status || "ظ†ط´ط·",
		description: description || "",
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ظ…ط±ظƒط² طھظƒظ„ظپط©", ccId, `طھظ… ط¥ط¶ط§ظپط© ظ…ط±ظƒط² طھظƒظ„ظپط©: ${code} - ${name}`, userId, userName);
	const created = db.select().from(costCenters).where(eq(costCenters.id, ccId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$2({ request }) {
	const { id, name, manager, budget, spent, status, description, notes, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط© ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(costCenters).where(eq(costCenters.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const before = JSON.stringify(existing);
	const ts = now();
	db.update(costCenters).set({
		name: name?.trim() ?? existing.name,
		manager: manager ?? existing.manager,
		budget: budget !== void 0 ? parseFloat(budget) : existing.budget,
		spent: spent !== void 0 ? parseFloat(spent) : existing.spent,
		status: status ?? existing.status,
		description: description ?? existing.description,
		notes: notes ?? existing.notes,
		updatedAt: ts
	}).where(eq(costCenters.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ظ…ط±ظƒط² طھظƒظ„ظپط©", id, `طھظ… طھط­ط¯ظٹط« ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط©: ${existing.code} - ${name || existing.name}`, userId, userName, before);
	const updated = db.select().from(costCenters).where(eq(costCenters.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$2({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط© ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(costCenters).where(eq(costCenters.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const journalUsage = db.select({ count: sql`count(*)` }).from(journalLines).where(eq(journalLines.costCenterId, id)).all()[0]?.count || 0;
	const budgetUsage = db.select({ count: sql`count(*)` }).from(budgetLines).where(eq(budgetLines.costCenterId, id)).all()[0]?.count || 0;
	if (journalUsage > 0 || budgetUsage > 0) return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ظ…ط±ظƒط² طھظƒظ„ظپط© ظ…ط³طھط®ط¯ظ… ظپظٹ ${journalUsage} ط³ط·ط± ظ‚ظٹط¯ ظˆ ${budgetUsage} ط³ط·ط± ظ…ظˆط§ط²ظ†ط©. ط£ظˆظ‚ظپ ط§ظ„ظ…ط±ظƒط² ط¨ط¯ظ„ط§ظ‹ ظ…ظ† ط°ظ„ظƒ.` }, { status: 400 });
	const before = JSON.stringify(existing);
	db.delete(costCenters).where(eq(costCenters.id, id)).run();
	addAudit("ط­ط°ظپ", "ظ…ط±ظƒط² طھظƒظ„ظپط©", id, `طھظ… ط­ط°ظپ ظ…ط±ظƒط² ط§ظ„طھظƒظ„ظپط©: ${existing.code} - ${existing.name}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$6 = createFileRoute("/api/finance/cost-centers")({ server: { handlers: {
	GET: __handler_GET$2,
	POST: __handler_POST$2,
	PUT: __handler_PUT$2,
	DELETE: __handler_DELETE$2
} } });
async function __handler_GET$1({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const budget = db.select().from(budgets).where(eq(budgets.id, id)).limit(1).all()[0];
		if (!budget) return Response.json({ error: "ط§ظ„ظ…ظˆط§ط²ظ†ط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
		const lines = db.select().from(budgetLines).where(eq(budgetLines.budgetId, id)).orderBy(budgetLines.lineNumber).all();
		const enrichedLines = await Promise.all(lines.map(async (l) => {
			const account = l.accountId ? db.select().from(accounts).where(eq(accounts.id, l.accountId)).limit(1).all()[0] : null;
			const cc = l.costCenterId ? db.select().from(costCenters).where(eq(costCenters.id, l.costCenterId)).limit(1).all()[0] : null;
			const project = l.projectId ? db.select().from(projects).where(eq(projects.id, l.projectId)).limit(1).all()[0] : null;
			let actual = 0;
			if (l.accountId) {
				const conditions = [eq(journalLines.accountId, l.accountId), eq(journalEntries.status, "ظ…ط±ط­ظ‘ظ„")];
				if (l.costCenterId) conditions.push(eq(journalLines.costCenterId, l.costCenterId));
				if (l.projectId) conditions.push(eq(journalLines.projectId, l.projectId));
				const actuals = db.select({
					debit: sql`COALESCE(SUM(${journalLines.debit}), 0)`,
					credit: sql`COALESCE(SUM(${journalLines.credit}), 0)`
				}).from(journalLines).innerJoin(journalEntries, eq(journalLines.journalEntryId, journalEntries.id)).where(and(...conditions)).all()[0];
				actual = (actuals?.debit || 0) - (actuals?.credit || 0);
			}
			return {
				...l,
				accountCode: account?.code || "",
				accountName: account?.name || "",
				costCenterName: cc?.name || "",
				projectName: project?.name || "",
				actualAmount: actual,
				variance: l.plannedAmount - actual,
				utilization: l.plannedAmount > 0 ? Math.round(actual / l.plannedAmount * 100) : 0
			};
		}));
		const totalPlanned = lines.reduce((s, l) => s + l.plannedAmount, 0);
		const totalActual = enrichedLines.reduce((s, l) => s + l.actualAmount, 0);
		return Response.json({
			item: budget,
			lines: enrichedLines,
			totals: {
				planned: totalPlanned,
				actual: totalActual,
				variance: totalPlanned - totalActual,
				utilization: totalPlanned > 0 ? Math.round(totalActual / totalPlanned * 100) : 0
			}
		});
	}
	const search = url.searchParams.get("search") || "";
	const status = url.searchParams.get("status") || "";
	const year = url.searchParams.get("year") || "";
	const conditions = [];
	if (search) conditions.push(or(like(budgets.name, `%${search}%`), like(budgets.department, `%${search}%`), like(budgets.year, `%${search}%`)));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(budgets.status, status));
	if (year && year !== "ط§ظ„ظƒظ„") conditions.push(eq(budgets.year, year));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(budgets).where(whereClause).orderBy(desc(budgets.year)).all() : db.select().from(budgets).orderBy(desc(budgets.year)).all();
	const total = items.length;
	return Response.json({
		items,
		total
	});
}
async function __handler_POST$1({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "approve") {
		const { id, userId, userName } = body;
		const existing = db.select().from(budgets).where(eq(budgets.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ظ…ظˆط§ط²ظ†ط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
		if (existing.status === "ظ…ط¹طھظ…ط¯") return Response.json({ error: "ط§ظ„ظ…ظˆط§ط²ظ†ط© ظ…ط¹طھظ…ط¯ط© ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		if (existing.status === "ظ…ظ‚ظپظ„") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط§ط¹طھظ…ط§ط¯ ظ…ظˆط§ط²ظ†ط© ظ…ظ‚ظپظ„ط©" }, { status: 400 });
		const before = JSON.stringify(existing);
		const ts = now();
		db.update(budgets).set({
			status: "ظ…ط¹طھظ…ط¯",
			approvedBy: userId || null,
			approvedAt: ts,
			updatedAt: ts
		}).where(eq(budgets.id, id)).run();
		addAudit("ط§ط¹طھظ…ط§ط¯", "ظ…ظˆط§ط²ظ†ط©", id, `طھظ… ط§ط¹طھظ…ط§ط¯ ط§ظ„ظ…ظˆط§ط²ظ†ط©: ${existing.name} (${existing.year})`, userId, userName, before);
		const updated = db.select().from(budgets).where(eq(budgets.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "lock") {
		const { id, userId, userName } = body;
		const existing = db.select().from(budgets).where(eq(budgets.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ظ…ظˆط§ط²ظ†ط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
		if (existing.status !== "ظ…ط¹طھظ…ط¯") return Response.json({ error: "ظٹط¬ط¨ ط§ط¹طھظ…ط§ط¯ ط§ظ„ظ…ظˆط§ط²ظ†ط© ظ‚ط¨ظ„ ظ‚ظپظ„ظ‡ط§" }, { status: 400 });
		const before = JSON.stringify(existing);
		const ts = now();
		db.update(budgets).set({
			status: "ظ…ظ‚ظپظ„",
			lockedBy: userId || null,
			lockedAt: ts,
			updatedAt: ts
		}).where(eq(budgets.id, id)).run();
		addAudit("ظ‚ظپظ„", "ظ…ظˆط§ط²ظ†ط©", id, `طھظ… ظ‚ظپظ„ ط§ظ„ظ…ظˆط§ط²ظ†ط©: ${existing.name} (${existing.year})`, userId, userName, before);
		const updated = db.select().from(budgets).where(eq(budgets.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "unlock") {
		const { id, userId, userName } = body;
		const existing = db.select().from(budgets).where(eq(budgets.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ظ…ظˆط§ط²ظ†ط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
		if (existing.status !== "ظ…ظ‚ظپظ„") return Response.json({ error: "ط§ظ„ظ…ظˆط§ط²ظ†ط© ظ„ظٹط³طھ ظ…ظ‚ظپظ„ط©" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(budgets).set({
			status: "ظ…ط¹طھظ…ط¯",
			updatedAt: now()
		}).where(eq(budgets.id, id)).run();
		addAudit("ظپطھط­ ظ‚ظپظ„", "ظ…ظˆط§ط²ظ†ط©", id, `طھظ… ظپطھط­ ظ‚ظپظ„ ط§ظ„ظ…ظˆط§ط²ظ†ط©: ${existing.name}`, userId, userName, before);
		const updated = db.select().from(budgets).where(eq(budgets.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { name, year, amount, department, status, currency, description, notes, lines, userId, userName } = body;
	if (!name?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„ظ…ظˆط§ط²ظ†ط© ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!year?.trim()) return Response.json({ error: "ط³ظ†ط© ط§ظ„ظ…ظˆط§ط²ظ†ط© ظ…ط·ظ„ظˆط¨ط©" }, { status: 400 });
	const budgetId = genId("BUD");
	const ts = now();
	db.insert(budgets).values({
		id: budgetId,
		name: name.trim(),
		year: year.trim(),
		amount: parseFloat(amount) || 0,
		department: department || "",
		status: status || "ظ…ط³ظˆط¯ط©",
		currency: currency || "SAR",
		description: description || "",
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	if (Array.isArray(lines) && lines.length > 0) {
		let lineNum = 1;
		let totalPlanned = 0;
		for (const line of lines) {
			const planned = parseFloat(line.plannedAmount) || 0;
			totalPlanned += planned;
			db.insert(budgetLines).values({
				id: genId("BL"),
				budgetId,
				lineNumber: lineNum++,
				accountId: line.accountId || null,
				costCenterId: line.costCenterId || null,
				projectId: line.projectId || null,
				plannedAmount: planned,
				actualAmount: 0,
				notes: line.notes || "",
				createdAt: ts
			}).run();
		}
		if (totalPlanned !== (parseFloat(amount) || 0)) db.update(budgets).set({
			amount: totalPlanned,
			updatedAt: ts
		}).where(eq(budgets.id, budgetId)).run();
	}
	addAudit("ط¥ط¶ط§ظپط©", "ظ…ظˆط§ط²ظ†ط©", budgetId, `طھظ… ط¥ط¶ط§ظپط© ظ…ظˆط§ط²ظ†ط©: ${name} (${year})`, userId, userName);
	const created = db.select().from(budgets).where(eq(budgets.id, budgetId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT$1({ request }) {
	const { id, name, year, amount, department, description, notes, lines, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…ظˆط§ط²ظ†ط© ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(budgets).where(eq(budgets.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…ظˆط§ط²ظ†ط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
	if (existing.status !== "ظ…ط³ظˆط¯ط©") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† طھط¹ط¯ظٹظ„ ظ…ظˆط§ط²ظ†ط© ظ…ط¹طھظ…ط¯ط© ط£ظˆ ظ…ظ‚ظپظ„ط©" }, { status: 400 });
	if (Array.isArray(lines) && lines.length > 0) {
		let totalPlanned = 0;
		for (const line of lines) totalPlanned += parseFloat(line.plannedAmount) || 0;
		db.delete(budgetLines).where(eq(budgetLines.budgetId, id)).run();
		let lineNum = 1;
		const ts = now();
		for (const line of lines) db.insert(budgetLines).values({
			id: genId("BL"),
			budgetId: id,
			lineNumber: lineNum++,
			accountId: line.accountId || null,
			costCenterId: line.costCenterId || null,
			projectId: line.projectId || null,
			plannedAmount: parseFloat(line.plannedAmount) || 0,
			actualAmount: 0,
			notes: line.notes || "",
			createdAt: ts
		}).run();
		db.update(budgets).set({
			amount: totalPlanned,
			updatedAt: ts
		}).where(eq(budgets.id, id)).run();
	}
	const before = JSON.stringify(existing);
	db.update(budgets).set({
		name: name?.trim() ?? existing.name,
		year: year?.trim() ?? existing.year,
		department: department ?? existing.department,
		description: description ?? existing.description,
		notes: notes ?? existing.notes,
		updatedAt: now()
	}).where(eq(budgets.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ظ…ظˆط§ط²ظ†ط©", id, `طھظ… طھط­ط¯ظٹط« ط§ظ„ظ…ظˆط§ط²ظ†ط©: ${existing.name}`, userId, userName, before);
	const updated = db.select().from(budgets).where(eq(budgets.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE$1({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ظ…ظˆط§ط²ظ†ط© ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(budgets).where(eq(budgets.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ظ…ظˆط§ط²ظ†ط© ط؛ظٹط± ظ…ظˆط¬ظˆط¯ط©" }, { status: 404 });
	if (existing.status !== "ظ…ط³ظˆط¯ط©") return Response.json({ error: "ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ظ…ظˆط§ط²ظ†ط© ظ…ط¹طھظ…ط¯ط© ط£ظˆ ظ…ظ‚ظپظ„ط©" }, { status: 400 });
	const before = JSON.stringify(existing);
	db.delete(budgets).where(eq(budgets.id, id)).run();
	addAudit("ط­ط°ظپ", "ظ…ظˆط§ط²ظ†ط©", id, `طھظ… ط­ط°ظپ ط§ظ„ظ…ظˆط§ط²ظ†ط©: ${existing.name}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$5 = createFileRoute("/api/finance/budgets")({ server: { handlers: {
	GET: __handler_GET$1,
	POST: __handler_POST$1,
	PUT: __handler_PUT$1,
	DELETE: __handler_DELETE$1
} } });
async function __handler_GET({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	if (id) {
		const account = db.select().from(accounts).where(eq(accounts.id, id)).limit(1).all()[0];
		if (!account) return Response.json({ error: "ط§ظ„ط­ط³ط§ط¨ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		const lineCount = db.select({ count: sql`count(*)` }).from(journalLines).where(eq(journalLines.accountId, id)).all()[0]?.count || 0;
		const childCount = db.select({ count: sql`count(*)` }).from(accounts).where(eq(accounts.parentId, id)).all()[0]?.count || 0;
		return Response.json({
			item: account,
			lineCount,
			childCount,
			hasTransactions: lineCount > 0
		});
	}
	const search = url.searchParams.get("search") || "";
	const type = url.searchParams.get("type") || "";
	const status = url.searchParams.get("status") || "";
	const conditions = [];
	if (search) conditions.push(or(like(accounts.code, `%${search}%`), like(accounts.name, `%${search}%`)));
	if (type && type !== "ط§ظ„ظƒظ„") conditions.push(eq(accounts.type, type));
	if (status && status !== "ط§ظ„ظƒظ„") conditions.push(eq(accounts.status, status));
	const whereClause = conditions.length > 0 ? and(...conditions) : void 0;
	const items = whereClause ? db.select().from(accounts).where(whereClause).orderBy(accounts.code).all() : db.select().from(accounts).orderBy(accounts.code).all();
	const total = items.length;
	return Response.json({
		items,
		total
	});
}
async function __handler_POST({ request }) {
	const body = await request.json();
	const { action } = body;
	if (action === "deactivate") {
		const { id, userId, userName } = body;
		const existing = db.select().from(accounts).where(eq(accounts.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ط­ط³ط§ط¨ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status === "ظ…ط؛ظ„ظ‚") return Response.json({ error: "ط§ظ„ط­ط³ط§ط¨ ظ…ط؛ظ„ظ‚ ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(accounts).set({
			status: "ظ…ظˆظ‚ظˆظپ",
			updatedAt: now()
		}).where(eq(accounts.id, id)).run();
		addAudit("ط¥ظٹظ‚ط§ظپ", "ط­ط³ط§ط¨", id, `طھظ… ط¥ظٹظ‚ط§ظپ ط§ظ„ط­ط³ط§ط¨: ${existing.code} - ${existing.name}`, userId, userName, before);
		const updated = db.select().from(accounts).where(eq(accounts.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	if (action === "activate") {
		const { id, userId, userName } = body;
		const existing = db.select().from(accounts).where(eq(accounts.id, id)).limit(1).all()[0];
		if (!existing) return Response.json({ error: "ط§ظ„ط­ط³ط§ط¨ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
		if (existing.status === "ظ†ط´ط·") return Response.json({ error: "ط§ظ„ط­ط³ط§ط¨ ظ†ط´ط· ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
		const before = JSON.stringify(existing);
		db.update(accounts).set({
			status: "ظ†ط´ط·",
			updatedAt: now()
		}).where(eq(accounts.id, id)).run();
		addAudit("طھظپط¹ظٹظ„", "ط­ط³ط§ط¨", id, `طھظ… طھظپط¹ظٹظ„ ط§ظ„ط­ط³ط§ط¨: ${existing.code} - ${existing.name}`, userId, userName, before);
		const updated = db.select().from(accounts).where(eq(accounts.id, id)).limit(1).all()[0];
		return Response.json({ item: updated });
	}
	const { code, name, type, parentId, currency, balance, postable, status, description, notes, userId, userName } = body;
	if (!code?.trim()) return Response.json({ error: "ط±ظ‚ظ… ط§ظ„ط­ط³ط§ط¨ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (!name?.trim()) return Response.json({ error: "ط§ط³ظ… ط§ظ„ط­ط³ط§ط¨ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	if (db.select().from(accounts).where(eq(accounts.code, code.trim())).limit(1).all()[0]) return Response.json({ error: "ط±ظ‚ظ… ط§ظ„ط­ط³ط§ط¨ ظ…ط³طھط®ط¯ظ… ط¨ط§ظ„ظپط¹ظ„" }, { status: 400 });
	const accId = genId("ACC");
	const ts = now();
	let level = 1;
	if (parentId) {
		const parent = db.select().from(accounts).where(eq(accounts.id, parentId)).limit(1).all()[0];
		if (parent) level = (parent.level || 1) + 1;
	}
	db.insert(accounts).values({
		id: accId,
		code: code.trim(),
		name: name.trim(),
		type: type || "طھظپطµظٹظ„ظٹ",
		level,
		parentId: parentId || null,
		currency: currency || "SAR",
		balance: parseFloat(balance) || 0,
		postable: postable !== false,
		status: status || "ظ†ط´ط·",
		description: description || "",
		notes: notes || "",
		createdBy: userId || null,
		createdAt: ts,
		updatedAt: ts
	}).run();
	addAudit("ط¥ط¶ط§ظپط©", "ط­ط³ط§ط¨", accId, `طھظ… ط¥ط¶ط§ظپط© ط­ط³ط§ط¨: ${code} - ${name}`, userId, userName);
	const created = db.select().from(accounts).where(eq(accounts.id, accId)).limit(1).all()[0];
	return Response.json({ item: created }, { status: 201 });
}
async function __handler_PUT({ request }) {
	const { id, name, type, parentId, currency, balance, postable, status, description, notes, userId, userName } = await request.json();
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط­ط³ط§ط¨ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(accounts).where(eq(accounts.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ط­ط³ط§ط¨ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const before = JSON.stringify(existing);
	const ts = now();
	db.update(accounts).set({
		name: name?.trim() ?? existing.name,
		type: type ?? existing.type,
		parentId: parentId ?? existing.parentId,
		currency: currency ?? existing.currency,
		balance: balance !== void 0 ? parseFloat(balance) : existing.balance,
		postable: postable !== void 0 ? postable : existing.postable,
		status: status ?? existing.status,
		description: description ?? existing.description,
		notes: notes ?? existing.notes,
		updatedAt: ts
	}).where(eq(accounts.id, id)).run();
	addAudit("طھط¹ط¯ظٹظ„", "ط­ط³ط§ط¨", id, `طھظ… طھط­ط¯ظٹط« ط§ظ„ط­ط³ط§ط¨: ${existing.code} - ${name || existing.name}`, userId, userName, before);
	const updated = db.select().from(accounts).where(eq(accounts.id, id)).limit(1).all()[0];
	return Response.json({ item: updated });
}
async function __handler_DELETE({ request }) {
	const url = new URL(request.url);
	const id = url.searchParams.get("id");
	const userId = url.searchParams.get("userId") || void 0;
	const userName = url.searchParams.get("userName") || "ظ…ط³طھط®ط¯ظ…";
	if (!id) return Response.json({ error: "ظ…ط¹ط±ظپ ط§ظ„ط­ط³ط§ط¨ ظ…ط·ظ„ظˆط¨" }, { status: 400 });
	const existing = db.select().from(accounts).where(eq(accounts.id, id)).limit(1).all()[0];
	if (!existing) return Response.json({ error: "ط§ظ„ط­ط³ط§ط¨ ط؛ظٹط± ظ…ظˆط¬ظˆط¯" }, { status: 404 });
	const children = db.select({ count: sql`count(*)` }).from(accounts).where(eq(accounts.parentId, id)).all()[0]?.count || 0;
	if (children > 0) return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ط­ط³ط§ط¨ ظ„ظ‡ ${children} ط­ط³ط§ط¨ ظپط±ط¹ظٹ. ط§ط­ط°ظپ ط§ظ„ظپط±ظˆط¹ ط£ظˆظ„ط§ظ‹ ط£ظˆ ط£ظˆظ‚ظپ ط§ظ„ط­ط³ط§ط¨.` }, { status: 400 });
	const usage = db.select({ count: sql`count(*)` }).from(journalLines).where(eq(journalLines.accountId, id)).all()[0]?.count || 0;
	if (usage > 0) return Response.json({ error: `ظ„ط§ ظٹظ…ظƒظ† ط­ط°ظپ ط­ط³ط§ط¨ ظ…ط³طھط®ط¯ظ… ظپظٹ ${usage} ط³ط·ط± ظ‚ظٹط¯. ط£ظˆظ‚ظپ ط§ظ„ط­ط³ط§ط¨ ط¨ط¯ظ„ط§ظ‹ ظ…ظ† ط°ظ„ظƒ.` }, { status: 400 });
	const before = JSON.stringify(existing);
	db.delete(accounts).where(eq(accounts.id, id)).run();
	addAudit("ط­ط°ظپ", "ط­ط³ط§ط¨", id, `طھظ… ط­ط°ظپ ط§ظ„ط­ط³ط§ط¨: ${existing.code} - ${existing.name}`, userId, userName, before);
	return Response.json({ success: true });
}
var Route$4 = createFileRoute("/api/finance/accounts")({ server: { handlers: {
	GET: __handler_GET,
	POST: __handler_POST,
	PUT: __handler_PUT,
	DELETE: __handler_DELETE
} } });
var $$splitComponentImporter$3 = () => import("./aid._id.edit-Bi1FM0T3.mjs");
var Route$3 = createFileRoute("/aid/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل مساعدة — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./finance.journal._id.edit-BTVbVAtt.mjs");
var Route$2 = createFileRoute("/finance/journal/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل قيد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./finance.budgets._id.edit-w_6XJAa3.mjs");
var Route$1 = createFileRoute("/finance/budgets/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل موازنة — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./finance.accounts._id.edit-SbAKpskL.mjs");
var Route = createFileRoute("/finance/accounts/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل حساب — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var WorkflowsRoute = Route$91.update({
	id: "/workflows",
	path: "/workflows",
	getParentRoute: () => Route$92
});
var ReportsRoute = Route$90.update({
	id: "/reports",
	path: "/reports",
	getParentRoute: () => Route$92
});
var RecurringRoute = Route$89.update({
	id: "/recurring",
	path: "/recurring",
	getParentRoute: () => Route$92
});
var ReceiptsRoute = Route$88.update({
	id: "/receipts",
	path: "/receipts",
	getParentRoute: () => Route$92
});
var ProjectsRoute = Route$87.update({
	id: "/projects",
	path: "/projects",
	getParentRoute: () => Route$92
});
var PermissionsRoute = Route$86.update({
	id: "/permissions",
	path: "/permissions",
	getParentRoute: () => Route$92
});
var NotificationsRoute = Route$85.update({
	id: "/notifications",
	path: "/notifications",
	getParentRoute: () => Route$92
});
var MembershipsRoute = Route$84.update({
	id: "/memberships",
	path: "/memberships",
	getParentRoute: () => Route$92
});
var MeetingsRoute = Route$83.update({
	id: "/meetings",
	path: "/meetings",
	getParentRoute: () => Route$92
});
var LoginRoute = Route$82.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$92
});
var HrRoute = Route$81.update({
	id: "/hr",
	path: "/hr",
	getParentRoute: () => Route$92
});
var GrantsRoute = Route$80.update({
	id: "/grants",
	path: "/grants",
	getParentRoute: () => Route$92
});
var EndowmentsRoute = Route$79.update({
	id: "/endowments",
	path: "/endowments",
	getParentRoute: () => Route$92
});
var EndowmentReturnsRoute = Route$78.update({
	id: "/endowment-returns",
	path: "/endowment-returns",
	getParentRoute: () => Route$92
});
var DonorsRoute = Route$77.update({
	id: "/donors",
	path: "/donors",
	getParentRoute: () => Route$92
});
var DonorOrgsRoute = Route$76.update({
	id: "/donor-orgs",
	path: "/donor-orgs",
	getParentRoute: () => Route$92
});
var DonationsRoute = Route$75.update({
	id: "/donations",
	path: "/donations",
	getParentRoute: () => Route$92
});
var DistributionRoute = Route$74.update({
	id: "/distribution",
	path: "/distribution",
	getParentRoute: () => Route$92
});
var CampaignsRoute = Route$73.update({
	id: "/campaigns",
	path: "/campaigns",
	getParentRoute: () => Route$92
});
var BeneficiariesRoute = Route$72.update({
	id: "/beneficiaries",
	path: "/beneficiaries",
	getParentRoute: () => Route$92
});
var AuditRoute = Route$71.update({
	id: "/audit",
	path: "/audit",
	getParentRoute: () => Route$92
});
var AssetsRoute = Route$70.update({
	id: "/assets",
	path: "/assets",
	getParentRoute: () => Route$92
});
var ApprovalsRoute = Route$69.update({
	id: "/approvals",
	path: "/approvals",
	getParentRoute: () => Route$92
});
var AidRoute = Route$68.update({
	id: "/aid",
	path: "/aid",
	getParentRoute: () => Route$92
});
var IndexRoute = Route$67.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$92
});
var SettingsUsersRoute = Route$66.update({
	id: "/settings/users",
	path: "/settings/users",
	getParentRoute: () => Route$92
});
var SettingsSystemRoute = Route$65.update({
	id: "/settings/system",
	path: "/settings/system",
	getParentRoute: () => Route$92
});
var SettingsOrgRoute = Route$64.update({
	id: "/settings/org",
	path: "/settings/org",
	getParentRoute: () => Route$92
});
var SettingsIntegrationsRoute = Route$63.update({
	id: "/settings/integrations",
	path: "/settings/integrations",
	getParentRoute: () => Route$92
});
var SettingsBranchesRoute = Route$62.update({
	id: "/settings/branches",
	path: "/settings/branches",
	getParentRoute: () => Route$92
});
var SettingsBackupRoute = Route$61.update({
	id: "/settings/backup",
	path: "/settings/backup",
	getParentRoute: () => Route$92
});
var ProjectsNewRoute = Route$60.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => ProjectsRoute
});
var ProjectsIdRoute = Route$103.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => ProjectsRoute
});
var ProcurementSuppliersRoute = Route$59.update({
	id: "/procurement/suppliers",
	path: "/procurement/suppliers",
	getParentRoute: () => Route$92
});
var ProcurementRequestsRoute = Route$58.update({
	id: "/procurement/requests",
	path: "/procurement/requests",
	getParentRoute: () => Route$92
});
var ProcurementQuotesRoute = Route$57.update({
	id: "/procurement/quotes",
	path: "/procurement/quotes",
	getParentRoute: () => Route$92
});
var ProcurementOrdersRoute = Route$56.update({
	id: "/procurement/orders",
	path: "/procurement/orders",
	getParentRoute: () => Route$92
});
var InventoryWarehousesRoute = Route$55.update({
	id: "/inventory/warehouses",
	path: "/inventory/warehouses",
	getParentRoute: () => Route$92
});
var InventoryStocktakeRoute = Route$54.update({
	id: "/inventory/stocktake",
	path: "/inventory/stocktake",
	getParentRoute: () => Route$92
});
var InventoryItemsRoute = Route$53.update({
	id: "/inventory/items",
	path: "/inventory/items",
	getParentRoute: () => Route$92
});
var FinanceStatementsRoute = Route$52.update({
	id: "/finance/statements",
	path: "/finance/statements",
	getParentRoute: () => Route$92
});
var FinanceLedgerRoute = Route$51.update({
	id: "/finance/ledger",
	path: "/finance/ledger",
	getParentRoute: () => Route$92
});
var FinanceJournalRoute = Route$50.update({
	id: "/finance/journal",
	path: "/finance/journal",
	getParentRoute: () => Route$92
});
var FinanceCostCentersRoute = Route$49.update({
	id: "/finance/cost-centers",
	path: "/finance/cost-centers",
	getParentRoute: () => Route$92
});
var FinanceClosingRoute = Route$48.update({
	id: "/finance/closing",
	path: "/finance/closing",
	getParentRoute: () => Route$92
});
var FinanceBudgetsRoute = Route$47.update({
	id: "/finance/budgets",
	path: "/finance/budgets",
	getParentRoute: () => Route$92
});
var FinanceAccountsRoute = Route$46.update({
	id: "/finance/accounts",
	path: "/finance/accounts",
	getParentRoute: () => Route$92
});
var DonorsNewRoute = Route$45.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => DonorsRoute
});
var DonorsIdRoute = Route$95.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => DonorsRoute
});
var DonationsNewRoute = Route$44.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => DonationsRoute
});
var BeneficiariesNewRoute = Route$43.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => BeneficiariesRoute
});
var BeneficiariesIdRoute = Route$94.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => BeneficiariesRoute
});
var AssetsNewRoute = Route$42.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => AssetsRoute
});
var ApiReceiptsRoute = Route$41.update({
	id: "/api/receipts",
	path: "/api/receipts",
	getParentRoute: () => Route$92
});
var ApiProjectsRoute = Route$40.update({
	id: "/api/projects",
	path: "/api/projects",
	getParentRoute: () => Route$92
});
var ApiDonorsRoute = Route$39.update({
	id: "/api/donors",
	path: "/api/donors",
	getParentRoute: () => Route$92
});
var ApiDonationsRoute = Route$38.update({
	id: "/api/donations",
	path: "/api/donations",
	getParentRoute: () => Route$92
});
var ApiBeneficiariesRoute = Route$37.update({
	id: "/api/beneficiaries",
	path: "/api/beneficiaries",
	getParentRoute: () => Route$92
});
var ApiAuthRoute = Route$36.update({
	id: "/api/auth",
	path: "/api/auth",
	getParentRoute: () => Route$92
});
var ApiAuditRoute = Route$35.update({
	id: "/api/audit",
	path: "/api/audit",
	getParentRoute: () => Route$92
});
var ApiAssetsRoute = Route$34.update({
	id: "/api/assets",
	path: "/api/assets",
	getParentRoute: () => Route$92
});
var ApiAidRoute = Route$33.update({
	id: "/api/aid",
	path: "/api/aid",
	getParentRoute: () => Route$92
});
var AidNewRoute = Route$32.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => AidRoute
});
var ProjectsIdEditRoute = Route$31.update({
	id: "/edit",
	path: "/edit",
	getParentRoute: () => ProjectsIdRoute
});
var ProcurementSuppliersNewRoute = Route$30.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => ProcurementSuppliersRoute
});
var ProcurementRequestsNewRoute = Route$29.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => ProcurementRequestsRoute
});
var ProcurementQuotesNewRoute = Route$28.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => ProcurementQuotesRoute
});
var ProcurementOrdersNewRoute = Route$27.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => ProcurementOrdersRoute
});
var InventoryWarehousesNewRoute = Route$26.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => InventoryWarehousesRoute
});
var InventoryStocktakeNewRoute = Route$25.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => InventoryStocktakeRoute
});
var InventoryItemsNewRoute = Route$24.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => InventoryItemsRoute
});
var FinanceJournalNewRoute = Route$23.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => FinanceJournalRoute
});
var FinanceBudgetsNewRoute = Route$22.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => FinanceBudgetsRoute
});
var FinanceAccountsNewRoute = Route$21.update({
	id: "/new",
	path: "/new",
	getParentRoute: () => FinanceAccountsRoute
});
var DonorsIdEditRoute = Route$20.update({
	id: "/edit",
	path: "/edit",
	getParentRoute: () => DonorsIdRoute
});
var DonationsIdEditRoute = Route$19.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => DonationsRoute
});
var BeneficiariesIdEditRoute = Route$18.update({
	id: "/edit",
	path: "/edit",
	getParentRoute: () => BeneficiariesIdRoute
});
var AssetsIdEditRoute = Route$93.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => AssetsRoute
});
var ApiProcurementSuppliersRoute = Route$17.update({
	id: "/api/procurement/suppliers",
	path: "/api/procurement/suppliers",
	getParentRoute: () => Route$92
});
var ApiProcurementRequestsRoute = Route$16.update({
	id: "/api/procurement/requests",
	path: "/api/procurement/requests",
	getParentRoute: () => Route$92
});
var ApiProcurementQuotesRoute = Route$15.update({
	id: "/api/procurement/quotes",
	path: "/api/procurement/quotes",
	getParentRoute: () => Route$92
});
var ApiProcurementOrdersRoute = Route$14.update({
	id: "/api/procurement/orders",
	path: "/api/procurement/orders",
	getParentRoute: () => Route$92
});
var ApiInventoryWarehousesRoute = Route$13.update({
	id: "/api/inventory/warehouses",
	path: "/api/inventory/warehouses",
	getParentRoute: () => Route$92
});
var ApiInventoryStocktakeRoute = Route$12.update({
	id: "/api/inventory/stocktake",
	path: "/api/inventory/stocktake",
	getParentRoute: () => Route$92
});
var ApiInventoryItemsRoute = Route$11.update({
	id: "/api/inventory/items",
	path: "/api/inventory/items",
	getParentRoute: () => Route$92
});
var ApiFinanceStatementsRoute = Route$10.update({
	id: "/api/finance/statements",
	path: "/api/finance/statements",
	getParentRoute: () => Route$92
});
var ApiFinancePeriodsRoute = Route$9.update({
	id: "/api/finance/periods",
	path: "/api/finance/periods",
	getParentRoute: () => Route$92
});
var ApiFinanceLedgerRoute = Route$8.update({
	id: "/api/finance/ledger",
	path: "/api/finance/ledger",
	getParentRoute: () => Route$92
});
var ApiFinanceJournalRoute = Route$7.update({
	id: "/api/finance/journal",
	path: "/api/finance/journal",
	getParentRoute: () => Route$92
});
var ApiFinanceCostCentersRoute = Route$6.update({
	id: "/api/finance/cost-centers",
	path: "/api/finance/cost-centers",
	getParentRoute: () => Route$92
});
var ApiFinanceBudgetsRoute = Route$5.update({
	id: "/api/finance/budgets",
	path: "/api/finance/budgets",
	getParentRoute: () => Route$92
});
var ApiFinanceAccountsRoute = Route$4.update({
	id: "/api/finance/accounts",
	path: "/api/finance/accounts",
	getParentRoute: () => Route$92
});
var AidIdEditRoute = Route$3.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => AidRoute
});
var ProcurementSuppliersIdEditRoute = Route$102.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => ProcurementSuppliersRoute
});
var ProcurementRequestsIdEditRoute = Route$101.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => ProcurementRequestsRoute
});
var ProcurementQuotesIdEditRoute = Route$100.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => ProcurementQuotesRoute
});
var ProcurementOrdersIdEditRoute = Route$99.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => ProcurementOrdersRoute
});
var InventoryWarehousesIdEditRoute = Route$98.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => InventoryWarehousesRoute
});
var InventoryStocktakeIdEditRoute = Route$97.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => InventoryStocktakeRoute
});
var InventoryItemsIdEditRoute = Route$96.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => InventoryItemsRoute
});
var FinanceJournalIdEditRoute = Route$2.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => FinanceJournalRoute
});
var FinanceBudgetsIdEditRoute = Route$1.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => FinanceBudgetsRoute
});
var FinanceAccountsIdEditRoute = Route.update({
	id: "/$id/edit",
	path: "/$id/edit",
	getParentRoute: () => FinanceAccountsRoute
});
var AidRouteChildren = {
	AidNewRoute,
	AidIdEditRoute
};
var AidRouteWithChildren = AidRoute._addFileChildren(AidRouteChildren);
var AssetsRouteChildren = {
	AssetsNewRoute,
	AssetsIdEditRoute
};
var AssetsRouteWithChildren = AssetsRoute._addFileChildren(AssetsRouteChildren);
var BeneficiariesIdRouteChildren = { BeneficiariesIdEditRoute };
var BeneficiariesRouteChildren = {
	BeneficiariesIdRoute: BeneficiariesIdRoute._addFileChildren(BeneficiariesIdRouteChildren),
	BeneficiariesNewRoute
};
var BeneficiariesRouteWithChildren = BeneficiariesRoute._addFileChildren(BeneficiariesRouteChildren);
var DonationsRouteChildren = {
	DonationsNewRoute,
	DonationsIdEditRoute
};
var DonationsRouteWithChildren = DonationsRoute._addFileChildren(DonationsRouteChildren);
var DonorsIdRouteChildren = { DonorsIdEditRoute };
var DonorsRouteChildren = {
	DonorsIdRoute: DonorsIdRoute._addFileChildren(DonorsIdRouteChildren),
	DonorsNewRoute
};
var DonorsRouteWithChildren = DonorsRoute._addFileChildren(DonorsRouteChildren);
var ProjectsIdRouteChildren = { ProjectsIdEditRoute };
var ProjectsRouteChildren = {
	ProjectsIdRoute: ProjectsIdRoute._addFileChildren(ProjectsIdRouteChildren),
	ProjectsNewRoute
};
var ProjectsRouteWithChildren = ProjectsRoute._addFileChildren(ProjectsRouteChildren);
var FinanceAccountsRouteChildren = {
	FinanceAccountsNewRoute,
	FinanceAccountsIdEditRoute
};
var FinanceAccountsRouteWithChildren = FinanceAccountsRoute._addFileChildren(FinanceAccountsRouteChildren);
var FinanceBudgetsRouteChildren = {
	FinanceBudgetsNewRoute,
	FinanceBudgetsIdEditRoute
};
var FinanceBudgetsRouteWithChildren = FinanceBudgetsRoute._addFileChildren(FinanceBudgetsRouteChildren);
var FinanceJournalRouteChildren = {
	FinanceJournalNewRoute,
	FinanceJournalIdEditRoute
};
var FinanceJournalRouteWithChildren = FinanceJournalRoute._addFileChildren(FinanceJournalRouteChildren);
var InventoryItemsRouteChildren = {
	InventoryItemsNewRoute,
	InventoryItemsIdEditRoute
};
var InventoryItemsRouteWithChildren = InventoryItemsRoute._addFileChildren(InventoryItemsRouteChildren);
var InventoryStocktakeRouteChildren = {
	InventoryStocktakeNewRoute,
	InventoryStocktakeIdEditRoute
};
var InventoryStocktakeRouteWithChildren = InventoryStocktakeRoute._addFileChildren(InventoryStocktakeRouteChildren);
var InventoryWarehousesRouteChildren = {
	InventoryWarehousesNewRoute,
	InventoryWarehousesIdEditRoute
};
var InventoryWarehousesRouteWithChildren = InventoryWarehousesRoute._addFileChildren(InventoryWarehousesRouteChildren);
var ProcurementOrdersRouteChildren = {
	ProcurementOrdersNewRoute,
	ProcurementOrdersIdEditRoute
};
var ProcurementOrdersRouteWithChildren = ProcurementOrdersRoute._addFileChildren(ProcurementOrdersRouteChildren);
var ProcurementQuotesRouteChildren = {
	ProcurementQuotesNewRoute,
	ProcurementQuotesIdEditRoute
};
var ProcurementQuotesRouteWithChildren = ProcurementQuotesRoute._addFileChildren(ProcurementQuotesRouteChildren);
var ProcurementRequestsRouteChildren = {
	ProcurementRequestsNewRoute,
	ProcurementRequestsIdEditRoute
};
var ProcurementRequestsRouteWithChildren = ProcurementRequestsRoute._addFileChildren(ProcurementRequestsRouteChildren);
var ProcurementSuppliersRouteChildren = {
	ProcurementSuppliersNewRoute,
	ProcurementSuppliersIdEditRoute
};
var rootRouteChildren = {
	IndexRoute,
	AidRoute: AidRouteWithChildren,
	ApprovalsRoute,
	AssetsRoute: AssetsRouteWithChildren,
	AuditRoute,
	BeneficiariesRoute: BeneficiariesRouteWithChildren,
	CampaignsRoute,
	DistributionRoute,
	DonationsRoute: DonationsRouteWithChildren,
	DonorOrgsRoute,
	DonorsRoute: DonorsRouteWithChildren,
	EndowmentReturnsRoute,
	EndowmentsRoute,
	GrantsRoute,
	HrRoute,
	LoginRoute,
	MeetingsRoute,
	MembershipsRoute,
	NotificationsRoute,
	PermissionsRoute,
	ProjectsRoute: ProjectsRouteWithChildren,
	ReceiptsRoute,
	RecurringRoute,
	ReportsRoute,
	WorkflowsRoute,
	ApiAidRoute,
	ApiAssetsRoute,
	ApiAuditRoute,
	ApiAuthRoute,
	ApiBeneficiariesRoute,
	ApiDonationsRoute,
	ApiDonorsRoute,
	ApiProjectsRoute,
	ApiReceiptsRoute,
	FinanceAccountsRoute: FinanceAccountsRouteWithChildren,
	FinanceBudgetsRoute: FinanceBudgetsRouteWithChildren,
	FinanceClosingRoute,
	FinanceCostCentersRoute,
	FinanceJournalRoute: FinanceJournalRouteWithChildren,
	FinanceLedgerRoute,
	FinanceStatementsRoute,
	InventoryItemsRoute: InventoryItemsRouteWithChildren,
	InventoryStocktakeRoute: InventoryStocktakeRouteWithChildren,
	InventoryWarehousesRoute: InventoryWarehousesRouteWithChildren,
	ProcurementOrdersRoute: ProcurementOrdersRouteWithChildren,
	ProcurementQuotesRoute: ProcurementQuotesRouteWithChildren,
	ProcurementRequestsRoute: ProcurementRequestsRouteWithChildren,
	ProcurementSuppliersRoute: ProcurementSuppliersRoute._addFileChildren(ProcurementSuppliersRouteChildren),
	SettingsBackupRoute,
	SettingsBranchesRoute,
	SettingsIntegrationsRoute,
	SettingsOrgRoute,
	SettingsSystemRoute,
	SettingsUsersRoute,
	ApiFinanceAccountsRoute,
	ApiFinanceBudgetsRoute,
	ApiFinanceCostCentersRoute,
	ApiFinanceJournalRoute,
	ApiFinanceLedgerRoute,
	ApiFinancePeriodsRoute,
	ApiFinanceStatementsRoute,
	ApiInventoryItemsRoute,
	ApiInventoryStocktakeRoute,
	ApiInventoryWarehousesRoute,
	ApiProcurementOrdersRoute,
	ApiProcurementQuotesRoute,
	ApiProcurementRequestsRoute,
	ApiProcurementSuppliersRoute
};
var routeTree = Route$92._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
