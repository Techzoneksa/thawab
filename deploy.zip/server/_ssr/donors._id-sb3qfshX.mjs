import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donors._id-sb3qfshX.js
var $$splitComponentImporter = () => import("./donors._id-yzxNDb78.mjs");
var Route = createFileRoute("/donors/$id")({
	head: () => ({ meta: [{ title: "ملف المتبرع — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
