import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { N as Send, Yt as Check, lt as Lock, pn as Archive } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, P as statusTone, c as ConfirmDialog, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { t as getAuditEntries } from "./audit-DP6UgtXG.mjs";
import { a as deleteStocktake, c as submitStocktake, l as updateStocktake, n as approveStocktake, o as getStocktake, r as closeStocktake } from "./stocktake-CPsewedU.mjs";
import { t as Route } from "./inventory.stocktake._id.edit-DIMCiGd7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.stocktake._id.edit-CRRjQT3u.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditStocktakePage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const detailQuery = useQuery({
		queryKey: ["stocktakeDetail", id],
		queryFn: () => getStocktake(id)
	});
	const item = detailQuery.data?.item;
	const lines = detailQuery.data?.lines ?? [];
	const [name, setName] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(null);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	if (item && !hydrated) {
		setName(item.name);
		setDate(item.date);
		setNotes(item.notes || "");
		setHydrated(true);
	}
	const isReadOnly = !!item && (item.status === "معتمد" || item.status === "مغلق");
	const canSubmit = item?.status === "مسودة";
	const canApprove = item?.status === "بانتظار الاعتماد";
	const canClose = item?.status === "معتمد";
	const stats = lines.reduce((acc, l) => {
		acc.sys += l.systemQuantity;
		acc.cnt += l.countedQuantity;
		acc.diff += l.difference;
		return acc;
	}, {
		sys: 0,
		cnt: 0,
		diff: 0
	});
	const diffLineCount = lines.filter((l) => l.difference !== 0).length;
	const handleSave = async () => {
		if (isReadOnly) {
			showToast("لا يمكن تعديل جرد معتمد أو مغلق", "error");
			return;
		}
		const errs = [];
		if (!name.trim()) errs.push("اسم الجرد مطلوب");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			await updateStocktake({
				id,
				name: name.trim(),
				date,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["stocktakes"] });
			queryClient.invalidateQueries({ queryKey: ["stocktakeDetail", id] });
			showToast("تم حفظ التعديلات", "success");
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const auditQuery = useQuery({
		queryKey: ["stocktakeAudit", id],
		queryFn: () => getAuditEntries({
			entityType: "جرد",
			entityId: id,
			limit: 50
		}),
		enabled: !!item
	});
	const tabs = [
		{
			id: "basic",
			label: "بيانات الجرد",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات الجرد",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم الجرد",
						required: true,
						error: errors[0],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "التاريخ",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المستودع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: item?.warehouseId ? "—" : "كل المستودعات",
							disabled: true
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value),
							rows: 3
						})
					})
				]
			})
		},
		{
			id: "lines",
			label: "بنود الجرد",
			badge: lines.length,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بنود الجرد",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-xl border bg-card overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "min-w-full text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-muted/60 text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground w-10",
											children: "#"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground",
											children: "الصنف"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground w-28",
											children: "نظامي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground w-28",
											children: "فعلي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground w-20",
											children: "الفرق"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground",
											children: "ملاحظات"
										})
									] })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 text-muted-foreground tabular-nums",
											children: i + 1
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 font-mono text-xs",
											children: l.itemId
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 tabular-nums",
											children: l.systemQuantity
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 tabular-nums font-bold",
											children: l.countedQuantity
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: `px-3 py-2 tabular-nums font-bold ${l.difference === 0 ? "text-muted-foreground" : l.difference > 0 ? "text-success" : "text-destructive"}`,
											children: l.difference > 0 ? `+${l.difference}` : l.difference
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 text-xs text-muted-foreground",
											children: l.notes || "—"
										})
									]
								}, l.id)) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t-2 bg-muted/30",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											colSpan: 2,
											className: "px-3 py-3 text-left font-semibold",
											children: "الإجمالي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-3 font-bold tabular-nums",
											children: stats.sys
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-3 font-bold tabular-nums",
											children: stats.cnt
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: `px-3 py-3 font-bold tabular-nums ${stats.diff === 0 ? "" : stats.diff > 0 ? "text-success" : "text-destructive"}`,
											children: stats.diff > 0 ? `+${stats.diff}` : stats.diff
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {})
									]
								}) })
							]
						})
					})
				}), diffLineCount > 0 && item?.status !== "معتمد" && item?.status !== "مغلق" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 rounded-lg bg-warning/10 border border-warning/30 px-3 py-2 text-xs text-warning-foreground",
					children: [
						"⚠ يوجد ",
						diffLineCount,
						" بندًا بفرق بين الكمية النظامية والفعلية. سيتم إنشاء حركة تسوية تلقائيًا عند الاعتماد."
					]
				})]
			})
		},
		{
			id: "summary",
			label: "ملخص",
			content: item ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ملخص الجرد",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "اسم الجرد",
						value: item.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الحالة",
						value: item.status,
						tone: statusTone(item.status)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "التاريخ",
						value: item.date
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "عدد الأصناف",
						value: String(lines.length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "إجمالي النظامي",
						value: String(stats.sys)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "إجمالي الفعلي",
						value: String(stats.cnt)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "إجمالي الفرق",
						value: stats.diff > 0 ? `+${stats.diff}` : String(stats.diff),
						tone: stats.diff === 0 ? "success" : "destructive"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "بنود بحاجة لتسوية",
						value: String(diffLineCount),
						tone: diffLineCount > 0 ? "warning" : "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "اعتمد بواسطة",
						value: item.approvedBy || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "تاريخ الاعتماد",
						value: item.approvedAt?.slice(0, 16).replace("T", " ") || "—"
					})
				]
			}) : null
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			badge: auditQuery.data?.items.length,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "سجل العمليات",
				children: auditQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "جاري التحميل..."
				}) : (auditQuery.data?.items ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "لا توجد عمليات مسجلة على هذا الجرد."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: (auditQuery.data?.items ?? []).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border bg-card px-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-foreground",
									children: e.action
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground font-mono",
									children: e.timestamp?.slice(0, 16).replace("T", " ")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground mt-0.5",
								children: e.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-muted-foreground mt-0.5",
								children: ["المستخدم: ", e.userName || "—"]
							})
						]
					}, e.id))
				})
			})
		}
	];
	const submitMut = useMutation({
		mutationFn: () => submitStocktake({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["stocktakes"] });
			queryClient.invalidateQueries({ queryKey: ["stocktakeDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["stocktakeAudit", id] });
			showToast("تم إرسال الجرد للاعتماد", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const approveMut = useMutation({
		mutationFn: () => approveStocktake({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["stocktakes"] });
			queryClient.invalidateQueries({ queryKey: ["stocktakeDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["stocktakeAudit", id] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			showToast("تم اعتماد الجرد. حركات التسوية أُنشئت تلقائيًا.", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const closeMut = useMutation({
		mutationFn: () => closeStocktake({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["stocktakes"] });
			queryClient.invalidateQueries({ queryKey: ["stocktakeDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["stocktakeAudit", id] });
			showToast("تم قفل الجرد", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMut = useMutation({
		mutationFn: () => deleteStocktake({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["stocktakes"] });
			showToast("تم حذف الجرد", "success");
			navigate({ to: "/inventory/stocktake" });
		},
		onError: (err) => showToast(err.message, "error")
	});
	if (detailQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الجرد",
		breadcrumb: ["المخزون", "الجرد"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الجرد",
		breadcrumb: ["المخزون", "الجرد"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-center py-12 text-muted-foreground",
			children: "الجرد غير موجود"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "الجرد",
		breadcrumb: [
			"المخزون",
			"الجرد",
			"تعديل"
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
				breadcrumb: [
					{
						label: "المخزون",
						to: "/inventory/items"
					},
					{
						label: "الجرد",
						to: "/inventory/stocktake"
					},
					{ label: item.name }
				],
				title: item.name,
				subtitle: `${lines.length} صنف · فرق ${stats.diff > 0 ? `+${stats.diff}` : stats.diff}`,
				draftNumber: item.id,
				status: {
					label: item.status,
					tone: statusTone(item.status)
				},
				isReadOnly,
				readonlyReason: isReadOnly ? `الجرد في حالة "${item.status}". لا يمكن تعديله.` : void 0,
				tabs,
				defaultTab: "basic",
				loading: saving,
				validationErrors: errors,
				primaryLabel: "حفظ التعديلات",
				secondaryLabel: "حفظ وإغلاق",
				showSecondary: false,
				extraActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					canSubmit && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("submit"),
						className: "inline-flex items-center gap-1.5 rounded-lg border border-primary/40 bg-primary/10 px-3 py-2 text-sm font-medium text-primary hover:bg-primary/20 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { size: 15 }), " إرسال للاعتماد"]
					}),
					canApprove && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("approve"),
						className: "inline-flex items-center gap-1.5 rounded-lg border border-success/40 bg-success/10 px-3 py-2 text-sm font-medium text-success hover:bg-success/20 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 15 }), " اعتماد"]
					}),
					canClose && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("close"),
						className: "inline-flex items-center gap-1.5 rounded-lg border border-info/40 bg-info/10 px-3 py-2 text-sm font-medium text-info hover:bg-info/20 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { size: 15 }), " قفل الجرد"]
					}),
					(item.status === "مسودة" || item.status === "بانتظار الاعتماد") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("delete"),
						className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { size: 15 }), " حذف"]
					})
				] }),
				onPrimary: handleSave,
				onCancel: () => navigate({ to: "/inventory/stocktake" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "submit",
				onClose: () => setConfirmAction(null),
				onConfirm: () => submitMut.mutate(),
				title: "إرسال للاعتماد",
				message: `هل تريد إرسال الجرد "${item.name}" للاعتماد؟ لن تستطيع تعديله بعد ذلك.`,
				confirmText: "إرسال",
				cancelText: "تراجع",
				loading: submitMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "approve",
				onClose: () => setConfirmAction(null),
				onConfirm: () => approveMut.mutate(),
				title: "اعتماد الجرد",
				message: `هل تريد اعتماد الجرد "${item.name}"؟ سيتم إنشاء حركة تسوية تلقائيًا لكل بند فيه فرق بين الكمية النظامية والفعلية.`,
				confirmText: "اعتماد",
				cancelText: "تراجع",
				loading: approveMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "close",
				onClose: () => setConfirmAction(null),
				onConfirm: () => closeMut.mutate(),
				title: "قفل الجرد",
				message: `هل تريد قفل الجرد "${item.name}"؟ بعد القفل يصبح نهائيًا.`,
				confirmText: "قفل",
				cancelText: "تراجع",
				loading: closeMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "delete",
				onClose: () => setConfirmAction(null),
				onConfirm: () => deleteMut.mutate(),
				title: "حذف الجرد",
				message: `هل تريد حذف الجرد "${item.name}"؟ هذا الإجراء لا يمكن التراجع عنه.`,
				confirmText: "حذف",
				cancelText: "تراجع",
				variant: "destructive",
				loading: deleteMut.isPending
			})
		]
	});
}
//#endregion
export { EditStocktakePage as component };
