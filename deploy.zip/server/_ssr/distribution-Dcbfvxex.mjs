import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { ot as MapPin } from "../_libs/lucide-react.mjs";
import { O as SectionTitle, S as MobilePageHeader, g as ExportButton, n as AppShell, s as Card } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/distribution-Dcbfvxex.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [regions] = (0, import_react.useState)([
		{
			n: "الرياض",
			b: 4120,
			v: 98e4
		},
		{
			n: "مكة المكرمة",
			b: 2840,
			v: 72e4
		},
		{
			n: "المدينة المنورة",
			b: 1240,
			v: 32e4
		},
		{
			n: "عسير",
			b: 1640,
			v: 41e4
		},
		{
			n: "الشرقية",
			b: 1420,
			v: 38e4
		},
		{
			n: "تبوك",
			b: 480,
			v: 12e4
		},
		{
			n: "حائل",
			b: 380,
			v: 9e4
		},
		{
			n: "جازان",
			b: 720,
			v: 18e4
		}
	]);
	const max = Math.max(...regions.map((r) => r.b));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المشاريع والمستفيدون",
			"تقارير التوزيع"
		],
		title: "تقارير التوزيع الجغرافي",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
			data: regions.map((r) => ({
				المنطقة: r.n,
				"عدد المستفيدين": r.b,
				"قيمة المساعدات": r.v
			})),
			filename: "distribution.csv"
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
			title: "تقارير التوزيع الجغرافي",
			count: `${regions.length} منطقة`
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 lg:grid-cols-2 gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					title: "توزيع المستفيدين حسب المنطقة",
					hint: "إجمالي 12,846 مستفيد"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-3",
					children: regions.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-xs mb-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-medium flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { size: 12 }), r.n]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								fmtNum(r.b),
								" مستفيد · ",
								fmtSAR(r.v)
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2.5 rounded-full bg-muted overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-gradient-to-l from-primary to-info",
							style: { width: `${r.b / max * 100}%` }
						})
					})] }, r.n))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { title: "توزيع المساعدات حسب الفئة" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [
						{
							n: "أيتام",
							v: 38,
							c: "bg-primary"
						},
						{
							n: "أسر متعففة",
							v: 24,
							c: "bg-info"
						},
						{
							n: "أرامل",
							v: 16,
							c: "bg-success"
						},
						{
							n: "مرضى",
							v: 12,
							c: "bg-warning"
						},
						{
							n: "أسر منتجة",
							v: 7,
							c: "bg-chart-5"
						},
						{
							n: "أخرى",
							v: 3,
							c: "bg-muted-foreground"
						}
					].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.n }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-bold tabular-nums",
								children: [r.v, "%"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-2 mt-2 rounded-full bg-muted overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `h-full ${r.c}`,
								style: { width: `${r.v}%` }
							})
						})]
					}, r.n))
				})]
			})]
		})]
	});
};
//#endregion
export { SplitComponent as component };
