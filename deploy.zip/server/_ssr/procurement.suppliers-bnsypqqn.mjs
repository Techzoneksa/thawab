import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { T as SquarePen, U as Plus, b as ToggleLeft, jt as Eye, v as Trash2, y as ToggleRight } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as deleteSupplier, i as deactivateSupplier, n as activateSupplier, s as getSuppliers } from "./suppliers-CkCPjZYa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.suppliers-bnsypqqn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const { data, isLoading, error } = useQuery({
		queryKey: ["suppliers", { search: searchQuery }],
		queryFn: () => getSuppliers({ search: searchQuery })
	});
	const detailQuery = useQuery({
		queryKey: ["supplierDetail", detailId],
		queryFn: async () => detailId ? await fetch(`/api/procurement/suppliers?id=${detailId}`).then((r) => r.json()) : null,
		enabled: !!detailId
	});
	const deleteMutation = useMutation({
		mutationFn: deleteSupplier,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["suppliers"] });
			showToast("تم حذف المورد", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const activateMutation = useMutation({
		mutationFn: activateSupplier,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["suppliers"] });
			showToast("تم تفعيل المورد", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deactivateMutation = useMutation({
		mutationFn: deactivateSupplier,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["suppliers"] });
			showToast("تم تعطيل المورد", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => {
		navigate({ to: "/procurement/suppliers/new" });
	};
	const openEdit = (s) => {
		navigate({
			to: "/procurement/suppliers/$id/edit",
			params: { id: s.id }
		});
	};
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleToggle = (s) => {
		if (s.status === "نشط") deactivateMutation.mutate({
			id: s.id,
			userId: user?.id,
			userName: user?.name
		});
		else activateMutation.mutate({
			id: s.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const items = data?.items || [];
	const total = data?.total || 0;
	const stats = {
		active: items.filter((s) => s.status === "نشط").length,
		inactive: items.filter((s) => s.status === "موقوف").length,
		total
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المشتريات",
			"الموردون"
		],
		title: "سجل الموردين",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
			data: items.map((s) => ({
				id: s.id,
				name: s.name,
				activity: s.activity,
				phone: s.phone || "",
				email: s.email || "",
				taxNumber: s.taxNumber,
				contactPerson: s.contactPerson,
				address: s.address,
				status: s.status,
				rating: s.rating,
				notes: s.notes
			})),
			filename: "suppliers.csv"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: openAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "إضافة مورد"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-3 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "إجمالي الموردين"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold tabular-nums",
							children: fmtSAR(stats.total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "نشط"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-success tabular-nums",
							children: fmtSAR(stats.active)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "موقوف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-muted-foreground tabular-nums",
							children: fmtSAR(stats.inactive)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "سجل الموردين",
				count: `${total} مورد`
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء جلب الموردين",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["suppliers"] }),
					children: "إعادة المحاولة"
				})
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا يوجد موردون",
				description: "ابدأ بإضافة أول مورد للتعامل مع المشتريات",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة مورد"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الرقم",
					"اسم المورد",
					"النشاط",
					"الجوال",
					"الحالة",
					""
				],
				rows: items,
				renderRow: (s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: s.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => navigate({
							to: "/procurement/suppliers/$id/edit",
							params: { id: s.id }
						}),
						className: "font-semibold hover:text-primary text-right",
						children: s.name
					}), s.contactPerson && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: s.contactPerson
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: s.activity ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "info",
						children: s.activity
					}) : "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs text-muted-foreground",
						children: s.phone || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(s.status),
						children: s.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getSupplierActions(s, setDetailId, openEdit, handleToggle, setDeleteTarget) }) })
				] }),
				mobileCard: (s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(s.status),
								children: s.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted-foreground",
								children: s.id
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => navigate({
								to: "/procurement/suppliers/$id/edit",
								params: { id: s.id }
							}),
							className: "font-semibold text-right hover:text-primary",
							children: s.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mt-1",
							children: s.phone || "—"
						}),
						s.activity && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "info",
							children: s.activity
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px]",
								onClick: () => openEdit(s),
								children: "تعديل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px]",
								onClick: () => handleToggle(s),
								children: s.status === "نشط" ? "تعطيل" : "تفعيل"
							})]
						})
					]
				}, s.id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailId,
				onClose: () => setDetailId(null),
				title: `تفاصيل المورد: ${detailQuery.data?.item?.name || ""}`,
				onSave: () => setDetailId(null),
				saveText: "إغلاق",
				children: detailQuery.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحالة",
									value: detailQuery.data.item.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "النشاط",
									value: detailQuery.data.item.activity || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الجوال",
									value: detailQuery.data.item.phone || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "البريد",
									value: detailQuery.data.item.email || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الرقم الضريبي",
									value: detailQuery.data.item.taxNumber || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "المسؤول",
									value: detailQuery.data.item.contactPerson || "—"
								})
							]
						}),
						detailQuery.data.item.address && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-1",
							children: "العنوان"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm",
							children: detailQuery.data.item.address
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-primary/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-muted-foreground mb-2",
								children: "ارتباطات المورد"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
									label: "أوامر شراء",
									value: fmtSAR(detailQuery.data.orderCount)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
									label: "أصول مرتبطة",
									value: fmtSAR(detailQuery.data.assetCount)
								})]
							})]
						}),
						detailQuery.data.item.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-1",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm",
							children: detailQuery.data.item.notes
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: handleDelete,
				title: "تأكيد الحذف",
				message: deleteTarget ? `هل تريد حذف المورد "${deleteTarget.name}"؟ لا يمكن الحذف إذا كان مرتبطاً بأوامر شراء أو أصول.` : "",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			})
		]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-semibold",
			children: value
		})]
	});
}
function StatBox({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-bold tabular-nums",
			children: value
		})]
	});
}
function getSupplierActions(s, setDetailId, openEdit, handleToggle, setDeleteTarget) {
	return [
		{
			label: "عرض التفاصيل",
			icon: Eye,
			onClick: () => setDetailId(s.id)
		},
		{
			label: "تعديل",
			icon: SquarePen,
			onClick: () => openEdit(s)
		},
		{
			label: s.status === "نشط" ? "تعطيل" : "تفعيل",
			icon: s.status === "نشط" ? ToggleLeft : ToggleRight,
			onClick: () => handleToggle(s)
		},
		{
			label: "حذف",
			icon: Trash2,
			variant: "destructive",
			onClick: () => setDeleteTarget(s)
		}
	];
}
//#endregion
export { Page as component };
