import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { s as getWarehouses } from "./warehouses-sU_fp7nA.mjs";
import { a as createInventoryItem, t as ITEM_STATUSES } from "./inventory-items-mo3tbFC9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.items.new-BC1H79xE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATEGORIES = [
	"مواد غذائية",
	"ملابس",
	"أجهزة إلكترونية",
	"أثاث",
	"مواد تنظيف",
	"أدوات مكتبية",
	"مستلزمات طبية",
	"أخرى"
];
function NewItemPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const warehouses = (useQuery({
		queryKey: ["warehouses-simple"],
		queryFn: () => getWarehouses({ limit: 1e3 })
	}).data?.items || []).filter((w) => w.status === "نشط");
	const [name, setName] = (0, import_react.useState)("");
	const [sku, setSku] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("");
	const [unit, setUnit] = (0, import_react.useState)("قطعة");
	const [warehouseId, setWarehouseId] = (0, import_react.useState)("");
	const [quantity, setQuantity] = (0, import_react.useState)("0");
	const [minQuantity, setMinQuantity] = (0, import_react.useState)("0");
	const [price, setPrice] = (0, import_react.useState)("0");
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const handleSave = async (andClose) => {
		const errs = [];
		if (!name.trim()) errs.push("اسم الصنف مطلوب");
		const qty = parseFloat(quantity) || 0;
		const min = parseFloat(minQuantity) || 0;
		if (qty < 0) errs.push("الكمية لا يمكن أن تكون سالبة");
		if (min < 0) errs.push("الحد الأدنى لا يمكن أن يكون سالبًا");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			const created = await createInventoryItem({
				name: name.trim(),
				sku: sku || void 0,
				category: category || void 0,
				unit,
				warehouseId: warehouseId || void 0,
				quantity: qty,
				minQuantity: min,
				price: parseFloat(price) || 0,
				status,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			showToast(`تم إضافة الصنف ${created.name}`, "success");
			if (andClose) navigate({ to: "/inventory/items" });
			else navigate({
				to: "/inventory/items/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const tabs = [{
		id: "basic",
		label: "بيانات الصنف",
		content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
			title: "بيانات الصنف",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "اسم الصنف",
					required: true,
					error: errors[0],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "مثال: سكر 1 كجم"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "رمز SKU",
					hint: "اختياري",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: sku,
						onChange: (e) => setSku(e.target.value),
						dir: "ltr",
						placeholder: "SKU-001"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "التصنيف",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
						value: category,
						onChange: (e) => setCategory(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "— اختر —"
						}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c,
							children: c
						}, c))]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "وحدة القياس",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: unit,
						onChange: (e) => setUnit(e.target.value),
						placeholder: "قطعة، كيلو، علبة..."
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "المستودع الافتراضي",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
						value: warehouseId,
						onChange: (e) => setWarehouseId(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "— لا يوجد —"
						}), warehouses.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: w.id,
							children: w.name
						}, w.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الكمية الحالية",
					error: errors[1],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						step: "0.01",
						value: quantity,
						onChange: (e) => setQuantity(e.target.value),
						dir: "ltr"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الحد الأدنى",
					hint: "للتنبيه",
					error: errors[2],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						min: "0",
						step: "0.01",
						value: minQuantity,
						onChange: (e) => setMinQuantity(e.target.value),
						dir: "ltr"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "سعر الوحدة",
					hint: "ر.س",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						min: "0",
						step: "0.01",
						value: price,
						onChange: (e) => setPrice(e.target.value),
						dir: "ltr"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الحالة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
						value: status,
						onChange: (e) => setStatus(e.target.value),
						children: ITEM_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 3
					})
				})
			]
		})
	}];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الأصناف",
		breadcrumb: [
			"المخزون",
			"الأصناف",
			"جديد"
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المخزون",
					to: "/inventory/items"
				},
				{
					label: "الأصناف",
					to: "/inventory/items"
				},
				{ label: "صنف جديد" }
			],
			title: "صنف جديد",
			subtitle: name || "أدخل بيانات الصنف",
			draftNumber: "مسودة جديدة",
			status: {
				label: status,
				tone: status === "نشط" ? "success" : "muted"
			},
			tabs,
			defaultTab: "basic",
			loading: saving,
			validationErrors: errors,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/inventory/items" })
		})
	});
}
//#endregion
export { NewItemPage as component };
