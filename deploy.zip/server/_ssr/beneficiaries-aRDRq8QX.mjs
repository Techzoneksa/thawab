//#region node_modules/.nitro/vite/services/ssr/assets/beneficiaries-aRDRq8QX.js
var API_BASE = "/api/beneficiaries";
var ELIGIBILITY_STATUSES = [
	"جديد",
	"قيد المراجعة",
	"مؤهل",
	"غير مؤهل",
	"موقوف"
];
var MARITAL_STATUSES = [
	"أعزب",
	"متزوج",
	"مطلق",
	"أرمل"
];
async function getBeneficiaries(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.category && filters.category !== "الكل") params.set("category", filters.category);
	if (filters.city && filters.city !== "الكل") params.set("city", filters.city);
	if (filters.page) params.set("page", String(filters.page));
	if (filters.limit) params.set("limit", String(filters.limit));
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب المستفيدين");
	return res.json();
}
async function getBeneficiary(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات المستفيد");
	const data = await res.json();
	return {
		item: data.item,
		aidHistory: data.aidHistory || [],
		linkedProjects: data.linkedProjects || []
	};
}
async function getBeneficiarySummary(id) {
	const res = await fetch(`${API_BASE}?id=${id}&summary=true`);
	if (!res.ok) throw new Error("فشل في جلب ملخص المستفيد");
	return (await res.json()).item;
}
async function createBeneficiary(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة المستفيد");
	}
	return (await res.json()).item;
}
async function updateBeneficiary(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث المستفيد");
	}
	return (await res.json()).item;
}
async function deleteBeneficiary(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف المستفيد");
	}
}
async function reviewBeneficiary(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "review"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إرسال المستفيد للمراجعة");
	}
	return (await res.json()).item;
}
async function qualifyBeneficiary(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "qualify"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تأهيل المستفيد");
	}
	return (await res.json()).item;
}
async function disqualifyBeneficiary(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "disqualify"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في عدم تأهيل المستفيد");
	}
	return (await res.json()).item;
}
async function suspendBeneficiary(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "suspend"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إيقاف المستفيد");
	}
	return (await res.json()).item;
}
async function reactivateBeneficiary(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "reactivate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إعادة تفعيل المستفيد");
	}
	return (await res.json()).item;
}
//#endregion
export { disqualifyBeneficiary as a, getBeneficiarySummary as c, reviewBeneficiary as d, suspendBeneficiary as f, deleteBeneficiary as i, qualifyBeneficiary as l, MARITAL_STATUSES as n, getBeneficiaries as o, updateBeneficiary as p, createBeneficiary as r, getBeneficiary as s, ELIGIBILITY_STATUSES as t, reactivateBeneficiary as u };
