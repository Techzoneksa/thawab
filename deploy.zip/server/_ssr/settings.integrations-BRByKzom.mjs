import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { J as Pencil, Ut as CircleCheck, W as Plug, a as Webhook, et as Network, jt as Eye, on as Ban } from "../_libs/lucide-react.mjs";
import { N as showToast, P as statusTone, S as MobilePageHeader, a as Btn, h as EntityFormDrawer, i as Badge, n as AppShell, s as Card, t as ActionMenu, y as MobileActionRow } from "./actions-qTEe1ygX.mjs";
import { d as INTEGRATIONS } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings.integrations-BRByKzom.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const [integrations, setIntegrations] = (0, import_react.useState)(INTEGRATIONS);
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [addWebhookOpen, setAddWebhookOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [editIdx, setEditIdx] = (0, import_react.useState)(null);
	const [formName, setFormName] = (0, import_react.useState)("");
	const [formCategory, setFormCategory] = (0, import_react.useState)("مدفوعات");
	const [formApi, setFormApi] = (0, import_react.useState)("");
	const [formKey, setFormKey] = (0, import_react.useState)("");
	const [formStatus, setFormStatus] = (0, import_react.useState)("نشط");
	const [formInfo, setFormInfo] = (0, import_react.useState)("");
	const [webhookName, setWebhookName] = (0, import_react.useState)("");
	const [webhookUrl, setWebhookUrl] = (0, import_react.useState)("");
	const [webhookEvent, setWebhookEvent] = (0, import_react.useState)("تبرع جديد");
	const categories = [
		"مدفوعات",
		"بنوك",
		"حكومي",
		"اتصالات",
		"تطوير"
	];
	const events = [
		"تبرع جديد",
		"مستفيد جديد",
		"مشروع جديد",
		"قيد يومية",
		"فاتورة"
	];
	function resetForm() {
		setFormName("");
		setFormCategory("مدفوعات");
		setFormApi("");
		setFormKey("");
		setFormStatus("نشط");
		setFormInfo("");
	}
	function handleAdd() {
		if (!formName.trim()) {
			showToast("يرجى إدخال اسم التكامل", "error");
			return;
		}
		const newInt = {
			name: formName,
			category: formCategory,
			status: formStatus,
			info: formInfo || "تمت الإضافة حديثاً"
		};
		setIntegrations([...integrations, newInt]);
		showToast(`تم إضافة التكامل ${formName} بنجاح`, "success");
		setAddOpen(false);
		resetForm();
	}
	function handleEdit(i) {
		const it = integrations[i];
		setEditIdx(i);
		setFormName(it.name);
		setFormCategory(it.category);
		setFormStatus(it.status);
		setFormInfo(it.info);
		setFormApi("");
		setFormKey("");
		setEditOpen(true);
	}
	function handleSaveEdit() {
		if (editIdx === null) return;
		const updated = [...integrations];
		updated[editIdx] = {
			...updated[editIdx],
			name: formName,
			category: formCategory,
			status: formStatus,
			info: formInfo
		};
		setIntegrations(updated);
		showToast(`تم تعديل التكامل ${formName} بنجاح`, "success");
		setEditOpen(false);
		setEditIdx(null);
		resetForm();
	}
	function toggleStatus(i) {
		const updated = [...integrations];
		updated[i] = {
			...updated[i],
			status: updated[i].status === "نشط" || updated[i].status === "متصل" ? "موقوف" : "نشط"
		};
		setIntegrations(updated);
		showToast(`تم ${updated[i].status === "نشط" ? "تفعيل" : "تعطيل"} ${updated[i].name}`, "success");
	}
	function testConnection(i) {
		showToast(`اختبار الاتصال بـ ${integrations[i].name}: تم الاتصال بنجاح ✓`, "success");
	}
	function showKeys(i) {
		showToast(`المفاتيح الخاصة بـ ${integrations[i].name}: sk_test_••••${Math.random().toString(36).slice(2, 8)}`, "info");
	}
	function handleAddWebhook() {
		if (!webhookName.trim() || !webhookUrl.trim()) {
			showToast("يرجى تعبئة الحقول المطلوبة", "error");
			return;
		}
		showToast(`تم إضافة Webhook "${webhookName}" بنجاح`, "success");
		setAddWebhookOpen(false);
		setWebhookName("");
		setWebhookUrl("");
		setWebhookEvent("تبرع جديد");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"الإعدادات",
			"التكاملات"
		],
		title: "مركز التكاملات",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => {
					setWebhookName("");
					setWebhookUrl("");
					setWebhookEvent("تبرع جديد");
					setAddWebhookOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Webhook, { size: 15 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden md:inline",
					children: "إضافة Webhook"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => {
					resetForm();
					setAddOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plug, { size: 15 }), "تكامل جديد"]
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "مركز التكاملات",
				count: `${integrations.length} تكامل`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MobileActionRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => {
					setWebhookName("");
					setWebhookUrl("");
					setWebhookEvent("تبرع جديد");
					setAddWebhookOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Webhook, { size: 15 }), " إضافة Webhook"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => {
					resetForm();
					setAddOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plug, { size: 15 }), " إضافة تكامل"]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 mt-3 lg:mt-0",
				children: integrations.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plug, { size: 20 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold truncate",
										children: it.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										children: it.category
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(it.status),
								children: it.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground mt-3",
							children: it.info
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center justify-between mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
								{
									label: "تعديل",
									icon: Pencil,
									onClick: () => handleEdit(i)
								},
								{
									label: it.status === "نشط" || it.status === "متصل" ? "تعطيل" : "تفعيل",
									icon: it.status === "نشط" || it.status === "متصل" ? Ban : CircleCheck,
									onClick: () => toggleStatus(i)
								},
								{
									label: "اختبار الاتصال",
									icon: Network,
									onClick: () => testConnection(i)
								},
								{
									label: "عرض المفاتيح",
									icon: Eye,
									onClick: () => showKeys(i)
								}
							] })
						})
					]
				}, it.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: addOpen,
				onClose: () => {
					setAddOpen(false);
					resetForm();
				},
				title: "إضافة تكامل جديد",
				onSave: handleAdd,
				saveText: "إضافة",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الاسم *"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formName,
						onChange: (e) => setFormName(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "النوع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formCategory,
						onChange: (e) => setFormCategory(e.target.value),
						children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "رابط API"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formApi,
						onChange: (e) => setFormApi(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "المفتاح"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formKey,
						onChange: (e) => setFormKey(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formStatus,
						onChange: (e) => setFormStatus(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "نشط" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "موقوف" })]
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: addWebhookOpen,
				onClose: () => setAddWebhookOpen(false),
				title: "إضافة Webhook",
				onSave: handleAddWebhook,
				saveText: "إضافة",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الاسم *"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: webhookName,
						onChange: (e) => setWebhookName(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "رابط Webhook URL *"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: webhookUrl,
						onChange: (e) => setWebhookUrl(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الحدث"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: webhookEvent,
						onChange: (e) => setWebhookEvent(e.target.value),
						children: events.map((ev) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: ev }, ev))
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: editOpen,
				onClose: () => {
					setEditOpen(false);
					setEditIdx(null);
					resetForm();
				},
				title: "تعديل التكامل",
				onSave: handleSaveEdit,
				saveText: "حفظ التغييرات",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الاسم"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formName,
						onChange: (e) => setFormName(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "النوع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formCategory,
						onChange: (e) => setFormCategory(e.target.value),
						children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formStatus,
						onChange: (e) => setFormStatus(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "نشط" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "موقوف" })]
					})] })
				]
			})
		]
	});
}
//#endregion
export { Page as component };
