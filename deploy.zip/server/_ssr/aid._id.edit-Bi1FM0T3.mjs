import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, y as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, P as statusTone, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { o as getBeneficiaries } from "./beneficiaries-aRDRq8QX.mjs";
import { a as getAidRecord, i as deliverAidRecord, l as updateAidRecord, s as rejectAidRecord, t as approveAidRecord } from "./aid-ytMo61mr.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { c as getProjects } from "./projects-fdUGDKDE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aid._id.edit-Bi1FM0T3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TYPES = [
	"مالية",
	"عينية",
	"غذائية",
	"طبية",
	"تعليمية",
	"إسكان",
	"كفالة"
];
function EditAidPage() {
	const { id } = useParams({ from: "/aid/$id/edit" });
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: aid, isLoading } = useQuery({
		queryKey: ["aid-record", id],
		queryFn: () => getAidRecord(id),
		enabled: !!id
	});
	const { data: benData } = useQuery({
		queryKey: ["beneficiaries-simple"],
		queryFn: () => getBeneficiaries({ limit: 500 })
	});
	const beneficiaries = benData?.items || [];
	const { data: projData } = useQuery({
		queryKey: ["projects-simple"],
		queryFn: () => getProjects({ limit: 200 })
	});
	const projects = projData?.items || [];
	const [beneficiaryId, setBeneficiaryId] = (0, import_react.useState)("");
	const [projectId, setProjectId] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("مالية");
	const [amount, setAmount] = (0, import_react.useState)("0");
	const [date, setDate] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (aid) {
			setBeneficiaryId(aid.beneficiaryId || "");
			setProjectId(aid.projectId || "");
			setType(aid.type || "مالية");
			setAmount(String(aid.amount || 0));
			setDate(aid.date || "");
			setNotes(aid.notes || "");
		}
	}, [aid]);
	const updateMutation = useMutation({
		mutationFn: (data) => updateAidRecord({
			id,
			...data
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["aid-record", id] });
			queryClient.invalidateQueries({ queryKey: ["aid"] });
			showToast("تم تحديث المساعدة بنجاح", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const approveMutation = useMutation({
		mutationFn: () => approveAidRecord({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["aid-record", id] });
			queryClient.invalidateQueries({ queryKey: ["aid"] });
			showToast("تم اعتماد المساعدة", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const rejectMutation = useMutation({
		mutationFn: () => rejectAidRecord({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["aid-record", id] });
			queryClient.invalidateQueries({ queryKey: ["aid"] });
			showToast("تم رفض المساعدة", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deliverMutation = useMutation({
		mutationFn: () => deliverAidRecord({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["aid-record", id] });
			queryClient.invalidateQueries({ queryKey: ["aid"] });
			showToast("تم تأكيد تسليم المساعدة", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleSave = async (andClose) => {
		setSaving(true);
		try {
			await updateMutation.mutateAsync({
				beneficiaryId,
				projectId: projectId || null,
				type,
				amount: parseFloat(amount) || 0,
				date,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			if (andClose) navigate({ to: "/aid" });
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المساعدات",
		breadcrumb: ["المساعدات", "تحميل..."],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!aid) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المساعدات",
		breadcrumb: ["المساعدات"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center py-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-base font-bold mb-2",
				children: "المساعدة غير موجودة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => navigate({ to: "/aid" }),
				className: "text-primary hover:underline text-sm",
				children: "العودة إلى المساعدات"
			})]
		})
	});
	const isApproved = aid.status === "معتمد" || aid.status === "تم التسليم";
	const isDelivered = aid.status === "تم التسليم";
	const tabs = [
		{
			id: "basic",
			label: "البيانات الأساسية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات المساعدة",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "المستفيد",
					required: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
						value: beneficiaryId,
						onChange: (e) => setBeneficiaryId(e.target.value),
						disabled: isApproved,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "— اختر —"
						}), beneficiaries.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: b.id,
							children: b.name
						}, b.id))]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "تاريخ المساعدة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "date",
						value: date,
						onChange: (e) => setDate(e.target.value),
						dir: "ltr",
						disabled: isApproved
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "نوع المساعدة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
						value: type,
						onChange: (e) => setType(e.target.value),
						disabled: isApproved,
						children: TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: t,
							children: t
						}, t))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "قيمة المساعدة (ر.س)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						step: "0.01",
						value: amount,
						onChange: (e) => setAmount(e.target.value),
						dir: "ltr",
						className: "font-mono tabular-nums",
						disabled: isApproved
					})
				})] })]
			})
		},
		{
			id: "allocation",
			label: "المشروع",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "تخصيص المساعدة",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "المشروع",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
						value: projectId,
						onChange: (e) => setProjectId(e.target.value),
						disabled: isApproved,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "— خارج مشروع —"
						}), projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p.id,
							children: p.name
						}, p.id))]
					})
				})
			})
		},
		{
			id: "notes",
			label: "الملاحظات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "ملاحظات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 6,
						disabled: isApproved
					})
				})
			})
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "الحالة والإجراءات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "الحالة",
							value: aid.status
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "اعتمد بواسطة",
							value: aid.approvedBy || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ الاعتماد",
							value: aid.approvedAt || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "سلم بواسطة",
							value: aid.deliveredBy || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ التسليم",
							value: aid.deliveredAt || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "طريقة التسليم",
							value: aid.deliveryMethod || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ التسجيل",
							value: aid.createdAt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "أنشأ بواسطة",
							value: aid.createdBy || "—"
						})
					]
				})
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المساعدات",
		breadcrumb: ["المساعدات", aid.id],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [{
				label: "المساعدات",
				to: "/aid"
			}, { label: aid.beneficiaryName || aid.id }],
			title: `مساعدة: ${aid.type}`,
			subtitle: `${aid.beneficiaryName} · ${fmtSAR(aid.amount)} · ${aid.date}`,
			draftNumber: aid.id,
			status: {
				label: aid.status,
				tone: statusTone(aid.status)
			},
			isReadOnly: isApproved,
			readonlyReason: isApproved ? "المساعدة معتمدة. يمكن فقط تأكيد التسليم." : "",
			tabs,
			defaultTab: "basic",
			loading: saving || updateMutation.isPending,
			primaryLabel: isApproved ? "غير قابل للتعديل" : "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: !isApproved,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/aid" }),
			extraActions: aid.status === "بانتظار الاعتماد" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => approveMutation.mutate(),
				disabled: approveMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg bg-success px-3 py-2 text-sm font-semibold text-success-foreground hover:opacity-90 transition-opacity min-h-[40px]",
				children: "اعتماد"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => rejectMutation.mutate(),
				disabled: rejectMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 text-destructive px-3 py-2 text-sm font-semibold hover:bg-destructive/20 transition-colors min-h-[40px]",
				children: "رفض"
			})] }) : aid.status === "معتمد" && !isDelivered ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => deliverMutation.mutate(),
				disabled: deliverMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90 transition-opacity min-h-[40px]",
				children: "تأكيد التسليم"
			}) : null
		})
	});
}
//#endregion
export { EditAidPage as component };
