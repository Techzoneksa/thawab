import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { N as Send, P as Search, Q as PackageSearch, U as Plus, Wt as CircleCheckBig, jt as Eye, lt as Lock, v as Trash2 } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { s as getWarehouses } from "./warehouses-sU_fp7nA.mjs";
import { l as getInventoryItems } from "./inventory-items-mo3tbFC9.mjs";
import { a as deleteStocktake, c as submitStocktake, n as approveStocktake, r as closeStocktake, s as getStocktakes, t as STOCKTAKE_STATUSES } from "./stocktake-CPsewedU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.stocktake-DsM2_iaX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [actionTarget, setActionTarget] = (0, import_react.useState)(null);
	const { data, isLoading, error } = useQuery({
		queryKey: ["stocktakes", {
			search: searchQuery,
			status: statusFilter
		}],
		queryFn: () => getStocktakes({ status: statusFilter })
	});
	const { data: warehousesData } = useQuery({
		queryKey: ["warehouses-all"],
		queryFn: () => getWarehouses({})
	});
	const { data: itemsData } = useQuery({
		queryKey: ["inventoryItems-all"],
		queryFn: () => getInventoryItems({})
	});
	const detailQuery = useQuery({
		queryKey: ["stocktakeDetail", detailId],
		queryFn: async () => detailId ? await fetch(`/api/inventory/stocktake?id=${detailId}`).then((r) => r.json()) : null,
		enabled: !!detailId
	});
	const submitMutation = useMutation({
		mutationFn: submitStocktake,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["stocktakes"] });
			showToast("تم إرسال الجرد للاعتماد", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const approveMutation = useMutation({
		mutationFn: approveStocktake,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["stocktakes"] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			showToast("تم اعتماد الجرد وإنشاء التسويات تلقائياً", "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const closeMutation = useMutation({
		mutationFn: closeStocktake,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["stocktakes"] });
			showToast("تم إغلاق الجرد", "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deleteStocktake,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["stocktakes"] });
			showToast("تم حذف الجرد", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => {
		navigate({ to: "/inventory/stocktake/new" });
	};
	const items = data?.items || [];
	const total = data?.total || 0;
	const warehouses = warehousesData?.items || [];
	const inventoryItems = itemsData?.items || [];
	const stats = {
		draft: items.filter((s) => s.status === "مسودة").length,
		pending: items.filter((s) => s.status === "بانتظار الاعتماد").length,
		approved: items.filter((s) => s.status === "معتمد").length,
		closed: items.filter((s) => s.status === "مغلق").length,
		total
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المخزون",
			"الجرد"
		],
		title: "عمليات الجرد",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
			data: items.map((s) => ({
				id: s.id,
				name: s.name,
				warehouseId: s.warehouseId || "",
				date: s.date,
				approvedBy: s.approvedBy || "",
				approvedAt: s.approvedAt || "",
				status: s.status
			})),
			filename: "stocktakes.csv"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: openAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "جرد جديد"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "إجمالي عمليات الجرد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold tabular-nums",
							children: fmtSAR(stats.total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "مسودة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-warning tabular-nums",
							children: fmtSAR(stats.draft)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "بانتظار الاعتماد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-info tabular-nums",
							children: fmtSAR(stats.pending)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "معتمد + مغلق"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-success tabular-nums",
							children: fmtSAR(stats.approved + stats.closed)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:flex items-center gap-2 mb-3 hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "rounded-lg border bg-background py-1.5 px-3 text-sm",
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), STOCKTAKE_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "عمليات الجرد",
				count: `${total} عملية`
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء جرد المخزون",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["stocktakes"] }),
					children: "إعادة المحاولة"
				})
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد عمليات جرد",
				description: "ابدأ بإنشاء أول عملية جرد لمطابقة المخزون الفعلي مع النظام",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "جرد جديد"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الاسم",
					"المستودع",
					"التاريخ",
					"الحالة",
					""
				],
				rows: items,
				renderRow: (s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => navigate({
							to: "/inventory/stocktake/$id/edit",
							params: { id: s.id }
						}),
						className: "font-semibold hover:text-primary text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageSearch, {
							size: 13,
							className: "inline ms-1 text-primary"
						}), s.name]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground font-mono",
						children: s.id
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-xs",
						children: warehouses.find((w) => w.id === s.warehouseId)?.name || "كل المستودعات"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: s.date
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(s.status),
						children: s.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getStocktakeActions(s, navigate, setActionTarget, setDeleteTarget) }) })
				] }),
				mobileCard: (s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(s.status),
								children: s.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted-foreground",
								children: s.id
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => navigate({
								to: "/inventory/stocktake/$id/edit",
								params: { id: s.id }
							}),
							className: "font-semibold text-right hover:text-primary",
							children: s.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground mt-1",
							children: [
								warehouses.find((w) => w.id === s.warehouseId)?.name || "كل المستودعات",
								" · ",
								s.date
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 mt-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px]",
									onClick: () => navigate({
										to: "/inventory/stocktake/$id/edit",
										params: { id: s.id }
									}),
									children: "تفاصيل"
								}),
								s.status === "مسودة" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg bg-primary/15 text-primary text-xs font-semibold py-2 min-h-[36px]",
									onClick: () => submitMutation.mutate({
										id: s.id,
										userId: user?.id,
										userName: user?.name
									}),
									children: "إرسال للاعتماد"
								}),
								s.status === "بانتظار الاعتماد" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg bg-success/15 text-success text-xs font-semibold py-2 min-h-[36px]",
									onClick: () => setActionTarget({
										st: s,
										action: "approve"
									}),
									children: "اعتماد"
								})
							]
						})
					]
				}, s.id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailId,
				onClose: () => setDetailId(null),
				title: `تفاصيل الجرد: ${detailQuery.data?.item?.name || ""}`,
				onSave: () => setDetailId(null),
				saveText: "إغلاق",
				children: detailQuery.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحالة",
									value: detailQuery.data.item.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "التاريخ",
									value: detailQuery.data.item.date
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "المستودع",
									value: warehouses.find((w) => w.id === detailQuery.data.item.warehouseId)?.name || "كل المستودعات"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "اعتمد بواسطة",
									value: detailQuery.data.item.approvedBy || "—"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-primary/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-muted-foreground mb-2",
								children: "سطور الجرد"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-1",
								children: detailQuery.data.lines.map((l) => {
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs py-1 border-b last:border-0 flex justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-semibold",
											children: inventoryItems.find((it) => it.id === l.itemId)?.name || l.itemId
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-muted-foreground",
											children: [
												"بالنظام: ",
												fmtSAR(l.systemQuantity),
												" · معدود: ",
												fmtSAR(l.countedQuantity)
											]
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-left",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `font-bold ${l.difference > 0 ? "text-success" : l.difference < 0 ? "text-destructive" : "text-muted-foreground"}`,
												children: [l.difference > 0 ? "+" : "", fmtSAR(l.difference)]
											})
										})]
									}, l.itemId);
								})
							})]
						}),
						detailQuery.data.item.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-1",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm",
							children: detailQuery.data.item.notes
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget && actionTarget.action === "submit",
				onClose: () => setActionTarget(null),
				onConfirm: () => {
					if (actionTarget) submitMutation.mutate({
						id: actionTarget.st.id,
						userId: user?.id,
						userName: user?.name
					});
					setActionTarget(null);
				},
				title: "إرسال للاعتماد",
				message: `هل تريد إرسال الجرد "${actionTarget?.st.name}" للاعتماد؟`,
				confirmText: "إرسال",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget && actionTarget.action === "approve",
				onClose: () => setActionTarget(null),
				onConfirm: () => {
					if (actionTarget) approveMutation.mutate({
						id: actionTarget.st.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "اعتماد الجرد",
				message: actionTarget ? `هل تريد اعتماد الجرد "${actionTarget.st.name}"؟ سيتم إنشاء تسويات تلقائية للأصناف التي بها فروق وتحديث المخزون.` : "",
				confirmText: "اعتماد",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget && actionTarget.action === "close",
				onClose: () => setActionTarget(null),
				onConfirm: () => {
					if (actionTarget) closeMutation.mutate({
						id: actionTarget.st.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "إغلاق الجرد",
				message: `هل تريد إغلاق الجرد "${actionTarget?.st.name}"؟`,
				confirmText: "إغلاق",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: () => {
					if (deleteTarget) deleteMutation.mutate({
						id: deleteTarget.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "تأكيد الحذف",
				message: deleteTarget ? `هل تريد حذف الجرد "${deleteTarget.name}"؟ يمكن حذف المسودات فقط.` : "",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			})
		]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-semibold",
			children: value
		})]
	});
}
function getStocktakeActions(s, navigate, setActionTarget, setDeleteTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => navigate({
			to: "/inventory/stocktake/$id/edit",
			params: { id: s.id }
		})
	}];
	if (s.status === "مسودة") {
		actions.push({
			label: "إرسال للاعتماد",
			icon: Send,
			onClick: () => setActionTarget({
				st: s,
				action: "submit"
			})
		});
		actions.push({
			label: "حذف",
			icon: Trash2,
			variant: "destructive",
			onClick: () => setDeleteTarget(s)
		});
	}
	if (s.status === "بانتظار الاعتماد") actions.push({
		label: "اعتماد",
		icon: CircleCheckBig,
		onClick: () => setActionTarget({
			st: s,
			action: "approve"
		})
	});
	if (s.status === "معتمد") actions.push({
		label: "إغلاق",
		icon: Lock,
		onClick: () => setActionTarget({
			st: s,
			action: "close"
		})
	});
	return actions;
}
//#endregion
export { Page as component };
