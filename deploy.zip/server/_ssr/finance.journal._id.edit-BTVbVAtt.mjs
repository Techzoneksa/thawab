import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, y as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { Gt as CircleAlert, U as Plus, v as Trash2 } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, P as statusTone, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { c as getProjects } from "./projects-fdUGDKDE.mjs";
import { c as getAccounts } from "./accounts-i45ITZyC.mjs";
import { c as postJournalEntry, l as reverseJournalEntry, r as cancelJournalEntry, s as getJournalEntry, t as JOURNAL_FUNDS, u as updateJournalEntry } from "./journal-Da8V5shh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.journal._id.edit-BTVbVAtt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function fromServerLine(l, key) {
	return {
		key,
		id: l.id,
		accountId: l.accountId,
		description: l.description || "",
		debit: l.debit || 0,
		credit: l.credit || 0
	};
}
function newLine(key) {
	return {
		key,
		accountId: "",
		description: "",
		debit: 0,
		credit: 0
	};
}
function EditJournalPage() {
	const { id } = useParams({ from: "/finance/journal/$id/edit" });
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: payload, isLoading } = useQuery({
		queryKey: ["journal-entry", id],
		queryFn: () => getJournalEntry(id),
		enabled: !!id
	});
	const { data: accData } = useQuery({
		queryKey: ["accounts-postable"],
		queryFn: () => getAccounts({ limit: 1e3 })
	});
	const accounts = (accData?.items || []).filter((a) => a.postable);
	const { data: projData } = useQuery({
		queryKey: ["projects-simple"],
		queryFn: () => getProjects({ limit: 200 })
	});
	const projects = projData?.items || [];
	const item = payload?.item;
	const serverLines = payload?.lines || [];
	const [date, setDate] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [fund, setFund] = (0, import_react.useState)("غير مقيد");
	const [projectId, setProjectId] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [lines, setLines] = (0, import_react.useState)([]);
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (item) {
			setDate(item.date || "");
			setDescription(item.description || "");
			setFund(item.fund);
			setProjectId(item.projectId || "");
			setNotes(item.notes || "");
			setLines(serverLines.length > 0 ? serverLines.map((l, i) => fromServerLine(l, `l${i}`)) : [newLine("l1"), newLine("l2")]);
		}
	}, [item, serverLines]);
	const totals = (0, import_react.useMemo)(() => {
		const debit = lines.reduce((s, l) => s + (l.debit || 0), 0);
		const credit = lines.reduce((s, l) => s + (l.credit || 0), 0);
		return {
			debit,
			credit,
			diff: debit - credit
		};
	}, [lines]);
	const isEditable = item?.status === "مسودة";
	const updateMutation = useMutation({
		mutationFn: (data) => updateJournalEntry({
			id,
			...data
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["journal-entry", id] });
			queryClient.invalidateQueries({ queryKey: ["journal"] });
			showToast("تم تحديث القيد", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const postMutation = useMutation({
		mutationFn: () => postJournalEntry({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["journal-entry", id] });
			queryClient.invalidateQueries({ queryKey: ["journal"] });
			showToast("تم ترحيل القيد", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const reverseMutation = useMutation({
		mutationFn: () => reverseJournalEntry({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["journal-entry", id] });
			queryClient.invalidateQueries({ queryKey: ["journal"] });
			showToast("تم عكس القيد", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const cancelMutation = useMutation({
		mutationFn: () => cancelJournalEntry({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["journal-entry", id] });
			queryClient.invalidateQueries({ queryKey: ["journal"] });
			showToast("تم إلغاء القيد", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleSave = async (andClose) => {
		if (!isEditable) {
			showToast("لا يمكن تعديل قيد مرحّل", "error");
			return;
		}
		if (Math.abs(totals.diff) > .001) {
			showToast(`القيد غير متوازن (الفرق ${fmtSAR(totals.diff)})`, "error");
			return;
		}
		setSaving(true);
		try {
			await updateMutation.mutateAsync({
				date,
				description: description.trim(),
				fund,
				projectId: projectId || null,
				notes,
				lines: lines.map((l) => ({
					accountId: l.accountId,
					description: l.description || void 0,
					debit: l.debit || 0,
					credit: l.credit || 0
				})),
				userId: user?.id,
				userName: user?.name
			});
			if (andClose) navigate({ to: "/finance/journal" });
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const addLine = () => setLines([...lines, newLine(`l${Date.now()}`)]);
	const removeLine = (key) => setLines(lines.length > 2 ? lines.filter((l) => l.key !== key) : lines);
	const updateLine = (key, patch) => setLines(lines.map((l) => l.key === key ? {
		...l,
		...patch
	} : l));
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "قيود اليومية",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "قيود اليومية",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center py-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-base font-bold mb-2",
				children: "القيد غير موجود"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => navigate({ to: "/finance/journal" }),
				className: "text-primary hover:underline text-sm",
				children: "العودة"
			})]
		})
	});
	const tabs = [
		{
			id: "lines",
			label: "بنود القيد",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بنود القيد",
				description: isEditable ? "يجب أن يتساوى إجمالي المدين مع إجمالي الدائن" : "للقراءة فقط — القيد مرحّل",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border bg-card overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "min-w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-muted/60 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-10",
										children: "#"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground",
										children: "الحساب"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground",
										children: "البيان"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-32",
										children: "مدين"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-32",
										children: "دائن"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-3 py-2 font-semibold text-muted-foreground w-10" })
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2 text-muted-foreground tabular-nums",
										children: i + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: l.accountId,
											onChange: (e) => updateLine(l.key, { accountId: e.target.value }),
											disabled: !isEditable,
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm min-h-[36px] disabled:opacity-60",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "— اختر —"
											}), accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: a.id,
												children: [
													a.code,
													" — ",
													a.name
												]
											}, a.id))]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: l.description,
											onChange: (e) => updateLine(l.key, { description: e.target.value }),
											disabled: !isEditable,
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm min-h-[36px] disabled:opacity-60"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											step: "0.01",
											value: l.debit || "",
											onChange: (e) => updateLine(l.key, {
												debit: parseFloat(e.target.value) || 0,
												credit: 0
											}),
											disabled: !isEditable,
											dir: "ltr",
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm font-mono tabular-nums min-h-[36px] disabled:opacity-60"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											step: "0.01",
											value: l.credit || "",
											onChange: (e) => updateLine(l.key, {
												credit: parseFloat(e.target.value) || 0,
												debit: 0
											}),
											disabled: !isEditable,
											dir: "ltr",
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm font-mono tabular-nums min-h-[36px] disabled:opacity-60"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => removeLine(l.key),
											disabled: !isEditable || lines.length <= 2,
											className: "grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive disabled:opacity-30 disabled:cursor-not-allowed transition-colors",
											title: "حذف السطر",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 14 })
										})
									})
								]
							}, l.key)) })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t bg-muted/30 px-3 py-3 flex items-center justify-between gap-3",
						children: [isEditable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: addLine,
							className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-1.5 text-xs font-semibold hover:bg-muted transition-colors min-h-[36px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), "إضافة سطر"]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4 text-sm font-bold tabular-nums",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["مدين: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground",
									children: fmtSAR(totals.debit)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["دائن: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-foreground",
									children: fmtSAR(totals.credit)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: totals.diff === 0 ? "text-success" : "text-destructive",
									children: ["فرق: ", fmtSAR(totals.diff)]
								})
							]
						})]
					})]
				}), isEditable && Math.abs(totals.diff) > .001 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive font-medium flex items-center gap-2 mt-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { size: 14 }), "القيد غير متوازن. يجب أن يتساوى إجمالي المدين مع إجمالي الدائن."]
				})]
			})
		},
		{
			id: "header",
			label: "بيانات القيد",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات القيد",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "رقم القيد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: item.number,
							disabled: true,
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "تاريخ القيد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value),
							dir: "ltr",
							disabled: !isEditable
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "نوع الصندوق",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: fund,
							onChange: (e) => setFund(e.target.value),
							disabled: !isEditable,
							children: JOURNAL_FUNDS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: f,
								children: f
							}, f))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المشروع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: projectId,
							onChange: (e) => setProjectId(e.target.value),
							disabled: !isEditable,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— خارج مشروع —"
							}), projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p.id,
								children: p.name
							}, p.id))]
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "وصف القيد",
						required: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: description,
							onChange: (e) => setDescription(e.target.value),
							disabled: !isEditable
						})
					})
				]
			})
		},
		{
			id: "notes",
			label: "الملاحظات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "ملاحظات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 5,
						disabled: !isEditable
					})
				})
			})
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "سجل التدقيق",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "الحالة",
							value: item.status
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "أنشأ بواسطة",
							value: item.createdBy || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ الإنشاء",
							value: item.createdAt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "آخر تحديث",
							value: item.updatedAt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "رحّل بواسطة",
							value: item.postedBy || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ الترحيل",
							value: item.postedAt || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "عكس بواسطة",
							value: item.reversedBy || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ العكس",
							value: item.reversedAt || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "عكس القيد",
							value: item.reversedOf || "—"
						})
					]
				}), payload?.reversedOf && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 rounded-lg border bg-muted/30 px-3 py-2 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "عكس القيد:"
						}),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-semibold",
							children: ["#", payload.reversedOf.number]
						}),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: ["— ", payload.reversedOf.description]
						})
					]
				})]
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "قيود اليومية",
		breadcrumb: [
			"المالية",
			"قيود اليومية",
			item.number
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المالية",
					to: "/finance/journal"
				},
				{
					label: "قيود اليومية",
					to: "/finance/journal"
				},
				{ label: item.number }
			],
			title: `قيد يومية: ${item.number}`,
			subtitle: `${description} · ${fmtSAR(item.amount)}`,
			draftNumber: item.number,
			status: {
				label: item.status,
				tone: statusTone(item.status)
			},
			isReadOnly: !isEditable,
			readonlyReason: !isEditable ? `القيد ${item.status} - يمكن فقط عكسه أو إلغاؤه` : "",
			tabs,
			defaultTab: "lines",
			loading: saving || updateMutation.isPending,
			primaryLabel: isEditable ? "حفظ ومتابعة" : "للقراءة فقط",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: isEditable,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/finance/journal" }),
			extraActions: isEditable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => postMutation.mutate(),
				disabled: postMutation.isPending || Math.abs(totals.diff) > .001,
				className: "inline-flex items-center justify-center gap-2 rounded-lg bg-success px-3 py-2 text-sm font-semibold text-success-foreground hover:opacity-90 transition-opacity min-h-[40px] disabled:opacity-50",
				children: "ترحيل القيد"
			}) : item.status === "مرحّل" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => reverseMutation.mutate(),
				disabled: reverseMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg border border-warning/30 bg-warning/10 text-warning px-3 py-2 text-sm font-semibold hover:bg-warning/20 transition-colors min-h-[40px]",
				children: "عكس القيد"
			}) }) : item.status === "مسودة" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => cancelMutation.mutate(),
				disabled: cancelMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 text-destructive px-3 py-2 text-sm font-semibold hover:bg-destructive/20 transition-colors min-h-[40px]",
				children: "إلغاء القيد"
			}) : null
		})
	});
}
//#endregion
export { EditJournalPage as component };
