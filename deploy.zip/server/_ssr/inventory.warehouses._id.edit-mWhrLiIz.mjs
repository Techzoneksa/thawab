import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.warehouses._id.edit-mWhrLiIz.js
var $$splitComponentImporter = () => import("./inventory.warehouses._id.edit-K3JM6Yrg.mjs");
var Route = createFileRoute("/inventory/warehouses/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل مستودع — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
