import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, y as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, P as statusTone, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { o as getProject, u as updateProject } from "./projects-fdUGDKDE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projects._id.edit-CpEisD4P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"جديد",
	"قيد التخطيط",
	"نشط",
	"قيد التنفيذ",
	"مكتمل",
	"متوقف",
	"ملغي"
];
function EditProjectPage() {
	const { id } = useParams({ from: "/projects/$id/edit" });
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: project, isLoading } = useQuery({
		queryKey: ["project", id],
		queryFn: () => getProject(id),
		enabled: !!id
	});
	const [name, setName] = (0, import_react.useState)("");
	const [code, setCode] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("تنموي");
	const [category, setCategory] = (0, import_react.useState)("أخرى");
	const [branch, setBranch] = (0, import_react.useState)("");
	const [manager, setManager] = (0, import_react.useState)("");
	const [budget, setBudget] = (0, import_react.useState)("0");
	const [startDate, setStartDate] = (0, import_react.useState)("");
	const [endDate, setEndDate] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [description, setDescription] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (project) {
			setName(project.name || "");
			setCode(project.code || "");
			setType(project.type || "تنموي");
			setCategory(project.category || "أخرى");
			setBranch(project.branch || "");
			setManager(project.manager || "");
			setBudget(String(project.budget || 0));
			setStartDate(project.startDate || "");
			setEndDate(project.endDate || "");
			setStatus(project.status || "نشط");
			setDescription(project.description || "");
			setNotes(project.notes || "");
		}
	}, [project]);
	const updateMutation = useMutation({
		mutationFn: (data) => updateProject({
			id,
			...data
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["project", id] });
			queryClient.invalidateQueries({ queryKey: ["projects"] });
			showToast("تم تحديث المشروع بنجاح", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleSave = async (andClose) => {
		setSaving(true);
		try {
			await updateMutation.mutateAsync({
				name,
				code,
				type,
				category,
				branch,
				manager,
				budget: parseFloat(budget) || 0,
				startDate,
				endDate,
				status,
				description,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			if (andClose) navigate({ to: "/projects" });
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المشاريع",
		breadcrumb: ["المشاريع", "تحميل..."],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!project) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المشاريع",
		breadcrumb: ["المشاريع"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center py-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-base font-bold mb-2",
				children: "المشروع غير موجود"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => navigate({ to: "/projects" }),
				className: "text-primary hover:underline text-sm",
				children: "العودة إلى المشاريع"
			})]
		})
	});
	const tabs = [
		{
			id: "basic",
			label: "البيانات الأساسية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات المشروع",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم المشروع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الرمز",
						hint: "للمستخدمين التقنيين",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: code,
							disabled: true,
							dir: "ltr",
							className: "font-mono"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "التصنيف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "إغاثي",
									children: "إغاثي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "تنموي",
									children: "تنموي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "تعليمي",
									children: "تعليمي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "صحي",
									children: "صحي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "كفالة",
									children: "كفالة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "رعاية أيتام",
									children: "رعاية أيتام"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "إسكان",
									children: "إسكان"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "أخرى",
									children: "أخرى"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "النوع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: type,
							onChange: (e) => setType(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "إغاثي",
									children: "إغاثي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "تنموي",
									children: "تنموي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "مستدام",
									children: "مستدام"
								})
							]
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الفرع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: branch,
							onChange: (e) => setBranch(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "مدير المشروع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: manager,
							onChange: (e) => setManager(e.target.value)
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الوصف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: description,
							onChange: (e) => setDescription(e.target.value),
							rows: 3
						})
					})
				]
			})
		},
		{
			id: "budget",
			label: "الميزانية والجدول",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "الميزانية والجدول الزمني",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الميزانية المعتمدة (ر.س)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						step: "0.01",
						value: budget,
						onChange: (e) => setBudget(e.target.value),
						dir: "ltr",
						className: "font-mono tabular-nums"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الحالة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
						value: status,
						onChange: (e) => setStatus(e.target.value),
						children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "تاريخ البدء",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "date",
						value: startDate,
						onChange: (e) => setStartDate(e.target.value),
						dir: "ltr"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "تاريخ النهاية",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "date",
						value: endDate,
						onChange: (e) => setEndDate(e.target.value),
						dir: "ltr"
					})
				})] })]
			})
		},
		{
			id: "summary",
			label: "الملخص والإحصاءات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "إحصاءات المشروع",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "إجمالي التبرعات",
							value: fmtSAR(project.totalDonations ?? project.donations ?? 0),
							tone: "success"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "إجمالي المساعدات",
							value: fmtSAR(project.totalAid ?? 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "عدد المساعدات",
							value: fmtNum(project.aidCount ?? 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "المستفيدون",
							value: fmtNum(project.beneficiaryCount ?? 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "المصروف",
							value: fmtSAR(project.spent ?? 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "المتبقي من الميزانية",
							value: fmtSAR(project.remainingBudget ?? project.budget ?? 0),
							tone: (project.remainingBudget ?? project.budget ?? 0) >= 0 ? "default" : "warning"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "نسبة الإنجاز",
							value: `${fmtNum(project.progress ?? 0)}%`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ الإنشاء",
							value: project.createdAt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "أنشأ بواسطة",
							value: project.createdBy || "—"
						})
					]
				})
			})
		},
		{
			id: "notes",
			label: "الملاحظات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "ملاحظات داخلية",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 6
					})
				})
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المشاريع",
		breadcrumb: ["المشاريع", project.name],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [{
				label: "المشاريع",
				to: "/projects"
			}, { label: project.name }],
			title: project.name,
			subtitle: `${project.code} · ${project.status} · ${project.category}`,
			draftNumber: project.code,
			status: {
				label: project.status,
				tone: statusTone(project.status)
			},
			tabs,
			defaultTab: "basic",
			loading: saving || updateMutation.isPending,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/projects" })
		})
	});
}
//#endregion
export { EditProjectPage as component };
