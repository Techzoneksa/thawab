import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { U as Plus, v as Trash2 } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { s as getSuppliers } from "./suppliers-CkCPjZYa.mjs";
import { l as getInventoryItems } from "./inventory-items-mo3tbFC9.mjs";
import { i as createPurchaseOrder } from "./purchase-orders-DLaoDtmH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.orders.new-4v9X8irw.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function newLine(key) {
	return {
		key,
		itemId: "",
		description: "",
		quantity: 0,
		unitPrice: 0,
		unit: "",
		notes: ""
	};
}
function NewOrderPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const suppliers = (useQuery({
		queryKey: ["suppliers-simple"],
		queryFn: () => getSuppliers({ limit: 1e3 })
	}).data?.items || []).filter((s) => s.status === "نشط");
	const items = (useQuery({
		queryKey: ["inventoryItems-simple"],
		queryFn: () => getInventoryItems({ limit: 1e3 })
	}).data?.items || []).filter((i) => i.status === "نشط");
	const [supplierId, setSupplierId] = (0, import_react.useState)("");
	const [subject, setSubject] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [deliveryDate, setDeliveryDate] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [lines, setLines] = (0, import_react.useState)([newLine("l1")]);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const total = (0, import_react.useMemo)(() => lines.reduce((s, l) => s + (l.quantity || 0) * (l.unitPrice || 0), 0), [lines]);
	const addLine = () => setLines([...lines, newLine(`l${Date.now()}`)]);
	const removeLine = (key) => setLines(lines.filter((l) => l.key !== key));
	const updateLine = (key, patch) => setLines(lines.map((l) => l.key === key ? {
		...l,
		...patch
	} : l));
	const handleSave = async (andClose) => {
		const errs = [];
		if (!supplierId) errs.push("يجب اختيار المورد");
		if (!subject.trim()) errs.push("موضوع أمر الشراء مطلوب");
		const validLines = lines.filter((l) => l.description.trim() && l.quantity > 0);
		if (validLines.length === 0) errs.push("أضف سطرًا واحدًا على الأقل بوصف وكمية");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			const created = await createPurchaseOrder({
				supplierId,
				subject: subject.trim(),
				date,
				deliveryDate: deliveryDate || void 0,
				notes: notes || void 0,
				lines: validLines.map((l) => ({
					itemId: l.itemId || void 0,
					description: l.description,
					quantity: l.quantity,
					unitPrice: l.unitPrice,
					unit: l.unit || void 0,
					notes: l.notes || void 0
				})),
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			showToast(`تم إنشاء أمر الشراء`, "success");
			if (andClose) navigate({ to: "/procurement/orders" });
			else navigate({
				to: "/procurement/orders/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const tabs = [
		{
			id: "basic",
			label: "بيانات الأمر",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات أمر الشراء",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المورد",
						required: true,
						error: errors[0],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: supplierId,
							onChange: (e) => setSupplierId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— اختر المورد —"
							}), suppliers.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s.id,
								children: s.name
							}, s.id))]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "موضوع أمر الشراء",
						required: true,
						error: errors[1],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: subject,
							onChange: (e) => setSubject(e.target.value),
							placeholder: "مثال: توريد سلال غذائية لشهر شعبان"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "تاريخ الأمر",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "تاريخ التوريد المتوقع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: deliveryDate,
							onChange: (e) => setDeliveryDate(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value),
							rows: 3
						})
					})
				]
			})
		},
		{
			id: "lines",
			label: "بنود الأمر",
			badge: lines.length,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بنود أمر الشراء",
				children: [errors[2] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-destructive/10 border border-destructive/30 px-3 py-2 text-xs text-destructive",
					children: ["⚠ ", errors[2]]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border bg-card overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "min-w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-muted/60 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-10",
										children: "#"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground min-w-[180px]",
										children: "الصنف"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground min-w-[200px]",
										children: "الوصف"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-24",
										children: "الكمية"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-20",
										children: "الوحدة"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-32",
										children: "السعر"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-32",
										children: "الإجمالي"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-3 py-2 font-semibold text-muted-foreground w-10" })
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5 text-muted-foreground tabular-nums",
										children: i + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: l.itemId,
											onChange: (e) => {
												const it = items.find((x) => x.id === e.target.value);
												updateLine(l.key, {
													itemId: e.target.value,
													unit: it?.unit || l.unit,
													description: l.description || it?.name || ""
												});
											},
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm min-h-[36px]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "— لا يوجد —"
											}), items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: it.id,
												children: it.name
											}, it.id))]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: l.description,
											onChange: (e) => updateLine(l.key, { description: e.target.value }),
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm min-h-[36px]",
											placeholder: "وصف البند"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: "0",
											step: "0.01",
											value: l.quantity || "",
											onChange: (e) => updateLine(l.key, { quantity: parseFloat(e.target.value) || 0 }),
											dir: "ltr",
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm font-mono tabular-nums min-h-[36px]"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: l.unit,
											onChange: (e) => updateLine(l.key, { unit: e.target.value }),
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm min-h-[36px]",
											placeholder: "قطعة"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: "0",
											step: "0.01",
											value: l.unitPrice || "",
											onChange: (e) => updateLine(l.key, { unitPrice: parseFloat(e.target.value) || 0 }),
											dir: "ltr",
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm font-mono tabular-nums min-h-[36px]"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5 font-bold tabular-nums text-foreground",
										children: fmtSAR((l.quantity || 0) * (l.unitPrice || 0))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => removeLine(l.key),
											disabled: lines.length <= 1,
											className: "grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive disabled:opacity-30 disabled:cursor-not-allowed transition-colors",
											title: "حذف السطر",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 14 })
										})
									})
								]
							}, l.key)) })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t bg-muted/30 px-3 py-3 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: addLine,
							className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-1.5 text-xs font-semibold hover:bg-muted transition-colors min-h-[36px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " إضافة بند"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-bold tabular-nums",
							children: ["الإجمالي: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: fmtSAR(total)
							})]
						})]
					})]
				})]
			})
		},
		{
			id: "summary",
			label: "ملخص",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ملخص أمر الشراء",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "المورد",
						value: suppliers.find((s) => s.id === supplierId)?.name || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الموضوع",
						value: subject || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "تاريخ الأمر",
						value: date
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "تاريخ التوريد",
						value: deliveryDate || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "عدد البنود",
						value: String(lines.filter((l) => l.description.trim()).length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الإجمالي",
						value: fmtSAR(total),
						tone: "success"
					})
				]
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "أوامر الشراء",
		breadcrumb: [
			"المشتريات",
			"أوامر الشراء",
			"جديد"
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المشتريات",
					to: "/procurement/requests"
				},
				{
					label: "أوامر الشراء",
					to: "/procurement/orders"
				},
				{ label: "أمر جديد" }
			],
			title: "أمر شراء جديد",
			subtitle: `${suppliers.find((s) => s.id === supplierId)?.name || "—"} · ${fmtSAR(total)}`,
			draftNumber: "مسودة جديدة",
			status: {
				label: "مسودة",
				tone: "muted"
			},
			tabs,
			defaultTab: "basic",
			loading: saving,
			validationErrors: errors,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/procurement/orders" })
		})
	});
}
//#endregion
export { NewOrderPage as component };
