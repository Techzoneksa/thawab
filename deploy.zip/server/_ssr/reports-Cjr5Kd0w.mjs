import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { B as Printer, Dt as FileText, Et as FileType, Ot as FileSpreadsheet, Pt as Download, Rt as Clock, U as Plus, t as lucide_react_exports, wt as Funnel } from "../_libs/lucide-react.mjs";
import { D as PrintStyle, E as PrintButton, N as showToast, _ as FilterBar, a as Btn, b as MobileFilterDrawer, h as EntityFormDrawer, k as Select, n as AppShell, s as Card } from "./actions-qTEe1ygX.mjs";
import { _ as REPORT_CATEGORIES } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-Cjr5Kd0w.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [createOpen, setCreateOpen] = (0, import_react.useState)(false);
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("الكل");
	const [formName, setFormName] = (0, import_react.useState)("");
	const [formType, setFormType] = (0, import_react.useState)("مالي");
	const [formPeriod, setFormPeriod] = (0, import_react.useState)("شهري");
	const [formFormat, setFormFormat] = (0, import_react.useState)("PDF");
	const filtered = typeFilter === "الكل" ? REPORT_CATEGORIES : REPORT_CATEGORIES.filter((c) => c.title.includes(typeFilter));
	const handleCreateReport = () => {
		if (!formName.trim()) {
			showToast("الرجاء إدخال اسم التقرير", "error");
			return;
		}
		showToast(`تم إنشاء التقرير "${formName}" بنجاح`, "success");
		setCreateOpen(false);
		setFormName("");
	};
	const handleSchedule = (name) => {
		showToast(`تمت جدولة التقرير "${name}" بنجاح`, "info");
	};
	const handleExportCat = (cat) => {
		const csv = ["الرقم,التقرير,التصنيف", ...cat.items.map((item, i) => ({
			الرقم: i + 1,
			التقرير: item,
			التصنيف: cat.title
		})).map((d) => `${d.الرقم},${d.التقرير},${d.التصنيف}`)].join("\r\n");
		const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8;bom" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `${cat.title}.csv`;
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
		URL.revokeObjectURL(url);
		showToast("تم تصدير التقرير بنجاح", "success");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"التقارير والحوكمة",
			"مركز التقارير"
		],
		title: "مركز التقارير",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: () => setCreateOpen(true),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إنشاء تقرير"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintStyle, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الفترة",
					options: [
						"اليوم",
						"هذا الأسبوع",
						"هذا الشهر",
						"هذا الربع",
						"هذا العام",
						"مخصصة"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "المشروع",
					options: [
						"جميع المشاريع",
						"كفالة الأيتام",
						"إفطار صائم",
						"كسوة الشتاء"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "المتبرع",
					options: [
						"الكل",
						"أفراد",
						"شركات",
						"مؤسسات"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "المستفيد",
					options: [
						"جميع الفئات",
						"أيتام",
						"أرامل",
						"مرضى"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الفرع",
					options: [
						"جميع الفروع",
						"الرياض",
						"جدة",
						"الدمام"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "نوع الصندوق",
					options: [
						"جميع الأموال",
						"مقيد",
						"غير مقيد",
						"أوقاف"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 lg:gap-4",
				children: filtered.map((cat) => {
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4 lg:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-9 w-9 lg:h-10 lg:w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(lucide_react_exports[cat.icon] || FileText, { size: 16 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-bold text-sm lg:text-base",
								children: cat.title
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-1.5",
							children: cat.items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between rounded-lg px-2 py-2 hover:bg-muted text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate ml-2 text-xs lg:text-sm",
									children: item
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-0.5 lg:gap-1 shrink-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											title: "PDF",
											onClick: () => showToast(`جاري تجهيز ${item} بصيغة PDF`, "info"),
											className: "rounded-lg p-2 hover:bg-background active:bg-muted min-h-[36px] min-w-[36px] flex items-center justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileType, { size: 13 })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											title: "Excel",
											onClick: () => handleExportCat(cat),
											className: "rounded-lg p-2 hover:bg-background active:bg-muted min-h-[36px] min-w-[36px] flex items-center justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileSpreadsheet, { size: 13 })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											title: "طباعة",
											onClick: () => window.print(),
											className: "rounded-lg p-2 hover:bg-background active:bg-muted min-h-[36px] min-w-[36px] flex items-center justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { size: 13 })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											title: "تنزيل",
											onClick: () => handleExportCat(cat),
											className: "rounded-lg p-2 hover:bg-background active:bg-muted min-h-[36px] min-w-[36px] flex items-center justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 13 })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											title: "جدولة",
											onClick: () => handleSchedule(item),
											className: "rounded-lg p-2 hover:bg-background active:bg-muted min-h-[36px] min-w-[36px] flex items-center justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { size: 13 })
										})
									]
								})]
							}, item))
						})]
					}, cat.title);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: createOpen,
				onClose: () => setCreateOpen(false),
				title: "إنشاء تقرير جديد",
				onSave: handleCreateReport,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "اسم التقرير"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						value: formName,
						onChange: (e) => setFormName(e.target.value),
						placeholder: "اسم التقرير"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "النوع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						value: formType,
						onChange: (e) => setFormType(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مالي" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "تبرعات" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مشاريع" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مستفيدين" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "منح" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مشتريات" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مخزون" })
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الفترة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						value: formPeriod,
						onChange: (e) => setFormPeriod(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "شهري" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ربعي" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "نصف سنوي" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "سنوي" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مخصص" })
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "التنسيق"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						value: formFormat,
						onChange: (e) => setFormFormat(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "PDF" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Excel" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "CSV" })
						]
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الفترة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "هذا الشهر" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "هذا الربع" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "هذا العام" })
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "المشروع"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "جميع المشاريع" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "كفالة الأيتام" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "إفطار صائم" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "كسوة الشتاء" })
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "نوع التقرير"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: typeFilter,
							onChange: (e) => setTypeFilter(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مالي" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "تبرعات" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مشاريع" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مستفيدين" })
							]
						})] })
					]
				})
			})
		]
	});
}
//#endregion
export { Page as component };
