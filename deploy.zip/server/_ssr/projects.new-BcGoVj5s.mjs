import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { i as createProject } from "./projects-fdUGDKDE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projects.new-BcGoVj5s.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"جديد",
	"قيد التخطيط",
	"نشط",
	"قيد التنفيذ",
	"مكتمل",
	"متوقف",
	"ملغي"
];
var CATEGORIES = [
	"إغاثي",
	"تنموي",
	"تعليمي",
	"صحي",
	"كفالة",
	"رعاية أيتام",
	"إسكان",
	"أخرى"
];
function NewProjectPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const [name, setName] = (0, import_react.useState)("");
	const [code, setCode] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("تنموي");
	const [category, setCategory] = (0, import_react.useState)("أخرى");
	const [branch, setBranch] = (0, import_react.useState)("الفرع الرئيسي");
	const [manager, setManager] = (0, import_react.useState)("");
	const [budget, setBudget] = (0, import_react.useState)("0");
	const [startDate, setStartDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [endDate, setEndDate] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [description, setDescription] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [saving, setSaving] = (0, import_react.useState)(false);
	const validate = () => {
		const e = {};
		if (!name.trim()) e.name = "اسم المشروع مطلوب";
		if (!code.trim()) e.code = "رمز المشروع مطلوب";
		if (!startDate) e.startDate = "تاريخ البدء مطلوب";
		if (endDate && startDate && new Date(endDate) < new Date(startDate)) e.endDate = "تاريخ النهاية يجب أن يكون بعد تاريخ البدء";
		setErrors(e);
		return Object.keys(e).length === 0;
	};
	const handleSave = async (andClose) => {
		if (!validate()) {
			showToast("يرجى تصحيح الأخطاء قبل الحفظ", "error");
			return;
		}
		setSaving(true);
		try {
			const created = await createProject({
				name: name.trim(),
				code: code.trim(),
				type,
				category,
				branch,
				manager,
				budget: parseFloat(budget) || 0,
				startDate,
				endDate,
				status,
				description,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["projects"] });
			showToast(`تم إنشاء المشروع ${created.name}`, "success");
			if (andClose) navigate({ to: "/projects" });
			else navigate({
				to: "/projects/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المشاريع",
		breadcrumb: ["المشاريع", "جديد"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [{
				label: "المشاريع",
				to: "/projects"
			}, { label: "مشروع جديد" }],
			title: "مشروع جديد",
			subtitle: "أنشئ مشروعاً جديداً لتخصيص التبرعات والمساعدات له",
			draftNumber: "مسودة جديدة",
			status: {
				label: "جديد",
				tone: "info"
			},
			tabs: [
				{
					id: "basic",
					label: "البيانات الأساسية",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "بيانات المشروع",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "اسم المشروع",
								required: true,
								error: errors.name,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: name,
									onChange: (e) => setName(e.target.value),
									invalid: !!errors.name
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "الرمز",
								required: true,
								error: errors.code,
								hint: "مثال: PRJ-2026-001",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: code,
									onChange: (e) => setCode(e.target.value),
									invalid: !!errors.code,
									dir: "ltr",
									className: "font-mono"
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "التصنيف",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
									value: category,
									onChange: (e) => setCategory(e.target.value),
									children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: c,
										children: c
									}, c))
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "النوع",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
									value: type,
									onChange: (e) => setType(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "إغاثي",
											children: "إغاثي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "تنموي",
											children: "تنموي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "مستدام",
											children: "مستدام"
										})
									]
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "الفرع",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
									value: branch,
									onChange: (e) => setBranch(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "الفرع الرئيسي",
											children: "الفرع الرئيسي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "فرع المنطقة الشمالية",
											children: "فرع المنطقة الشمالية"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "فرع المنطقة الجنوبية",
											children: "فرع المنطقة الجنوبية"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "مدير المشروع",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: manager,
									onChange: (e) => setManager(e.target.value)
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "الوصف",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
									value: description,
									onChange: (e) => setDescription(e.target.value),
									rows: 3
								})
							})
						]
					})
				},
				{
					id: "budget",
					label: "الميزانية والجدول",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "الميزانية والجدول الزمني",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "الميزانية المعتمدة (ر.س)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
								type: "number",
								step: "0.01",
								value: budget,
								onChange: (e) => setBudget(e.target.value),
								dir: "ltr",
								className: "font-mono tabular-nums"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "الحالة",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
								value: status,
								onChange: (e) => setStatus(e.target.value),
								children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: s,
									children: s
								}, s))
							})
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "تاريخ البدء",
							required: true,
							error: errors.startDate,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
								type: "date",
								value: startDate,
								onChange: (e) => setStartDate(e.target.value),
								dir: "ltr",
								invalid: !!errors.startDate
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "تاريخ النهاية المتوقع",
							error: errors.endDate,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
								type: "date",
								value: endDate,
								onChange: (e) => setEndDate(e.target.value),
								dir: "ltr",
								invalid: !!errors.endDate
							})
						})] })]
					})
				},
				{
					id: "notes",
					label: "الملاحظات",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
						title: "ملاحظات داخلية",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "ملاحظات",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
								value: notes,
								onChange: (e) => setNotes(e.target.value),
								rows: 6
							})
						})
					})
				}
			],
			defaultTab: "basic",
			loading: saving,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/projects" })
		})
	});
}
//#endregion
export { NewProjectPage as component };
