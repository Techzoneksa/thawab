//#region node_modules/.nitro/vite/services/ssr/assets/aid-ytMo61mr.js
var API_BASE = "/api/aid";
async function getAidRecords(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.type && filters.type !== "الكل") params.set("type", filters.type);
	if (filters.beneficiaryId) params.set("beneficiaryId", filters.beneficiaryId);
	if (filters.projectId) params.set("projectId", filters.projectId);
	if (filters.page) params.set("page", String(filters.page));
	if (filters.limit) params.set("limit", String(filters.limit));
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب سجلات المساعدة");
	return res.json();
}
async function getAidRecord(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات المساعدة");
	return (await res.json()).item;
}
async function createAidRecord(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة المساعدة");
	}
	return (await res.json()).item;
}
async function updateAidRecord(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث المساعدة");
	}
	return (await res.json()).item;
}
async function deleteAidRecord(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف المساعدة");
	}
}
async function approveAidRecord(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "approve"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في اعتماد المساعدة");
	}
	return (await res.json()).item;
}
async function rejectAidRecord(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "reject"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في رفض المساعدة");
	}
	return (await res.json()).item;
}
async function deliverAidRecord(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "deliver"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تسليم المساعدة");
	}
	return (await res.json()).item;
}
async function returnAidRecord(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "return"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إرجاع المساعدة");
	}
	return (await res.json()).item;
}
//#endregion
export { getAidRecord as a, returnAidRecord as c, deliverAidRecord as i, updateAidRecord as l, createAidRecord as n, getAidRecords as o, deleteAidRecord as r, rejectAidRecord as s, approveAidRecord as t };
