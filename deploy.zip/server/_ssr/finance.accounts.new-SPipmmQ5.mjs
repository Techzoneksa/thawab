import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, v as useSearch } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, o as FormSegmented, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { c as getAccounts, i as createAccount, n as ACCOUNT_TYPES, t as ACCOUNT_STATUSES } from "./accounts-i45ITZyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.accounts.new-SPipmmQ5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NewAccountPage() {
	const navigate = useNavigate();
	const search = useSearch({ from: "/finance/accounts/new" });
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const parentId = search.parent;
	const { data: accountsData } = useQuery({
		queryKey: ["accounts-all"],
		queryFn: () => getAccounts({ limit: 1e3 })
	});
	const allAccounts = accountsData?.items || [];
	const parent = (0, import_react.useMemo)(() => allAccounts.find((a) => a.id === parentId) || null, [allAccounts, parentId]);
	const [code, setCode] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)(parent ? "تفصيلي" : "رئيسي");
	const [parentId_, setParentId] = (0, import_react.useState)(parent?.id || "");
	const [currency, setCurrency] = (0, import_react.useState)("SAR");
	const [balance, setBalance] = (0, import_react.useState)("0");
	const [postable, setPostable] = (0, import_react.useState)(!parent);
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [description, setDescription] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [saving, setSaving] = (0, import_react.useState)(false);
	const validate = () => {
		const e = {};
		if (!code.trim()) e.code = "رقم الحساب مطلوب";
		else if (allAccounts.some((a) => a.code === code.trim())) e.code = "رقم الحساب مستخدم";
		if (!name.trim()) e.name = "اسم الحساب مطلوب";
		if (!parentId_ && type !== "رئيسي") e.parent = "الحساب الأب مطلوب للحسابات الفرعية";
		setErrors(e);
		return Object.keys(e).length === 0;
	};
	const handleSave = async (andClose) => {
		if (!validate()) {
			showToast("يرجى تصحيح الأخطاء قبل الحفظ", "error");
			return;
		}
		setSaving(true);
		try {
			const created = await createAccount({
				code: code.trim(),
				name: name.trim(),
				type,
				parentId: parentId_ || null,
				currency,
				balance: parseFloat(balance) || 0,
				postable,
				status,
				description,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["accounts"] });
			showToast(`تم إنشاء الحساب ${created.code} بنجاح`, "success");
			if (andClose) navigate({ to: "/finance/accounts" });
			else navigate({
				to: "/finance/accounts/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const tabs = [
		{
			id: "basic",
			label: "البيانات الأساسية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "تعريف الحساب",
				description: "الرقم والاسم والنوع والحساب الأب",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "رقم الحساب",
						required: true,
						error: errors.code,
						htmlFor: "acct-code",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							id: "acct-code",
							value: code,
							onChange: (e) => setCode(e.target.value),
							placeholder: "مثال: 1101",
							invalid: !!errors.code,
							dir: "ltr",
							className: "font-mono"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم الحساب",
						required: true,
						error: errors.name,
						htmlFor: "acct-name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							id: "acct-name",
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "مثال: النقدية بالصندوق الرئيسي",
							invalid: !!errors.name
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "نوع الحساب",
						required: true,
						htmlFor: "acct-type",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							id: "acct-type",
							value: type,
							onChange: (e) => {
								const v = e.target.value;
								setType(v);
								if (v === "رئيسي") {
									setPostable(false);
									setParentId("");
								} else setPostable(true);
							},
							children: ACCOUNT_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: t,
								children: t
							}, t))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحساب الأب",
						error: errors.parent,
						hint: type === "رئيسي" ? "الحسابات الرئيسية لا تحتاج أب" : "اختر الحساب الرئيسي الذي يندرج تحته هذا الحساب",
						htmlFor: "acct-parent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							id: "acct-parent",
							value: parentId_,
							onChange: (e) => setParentId(e.target.value),
							disabled: type === "رئيسي",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— (حساب رئيسي بدون أب)"
							}), allAccounts.filter((a) => a.type === "رئيسي").map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: a.id,
								children: [
									a.code,
									" — ",
									a.name
								]
							}, a.id))]
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الوصف",
						htmlFor: "acct-desc",
						hint: "يظهر في التقارير والقوائم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							id: "acct-desc",
							value: description,
							onChange: (e) => setDescription(e.target.value),
							rows: 2,
							placeholder: "وصف مختصر لطبيعة هذا الحساب..."
						})
					})
				]
			})
		},
		{
			id: "structure",
			label: "الهيكل المحاسبي",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "الهيكل والمستوى",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "المستوى في الشجرة",
					hint: "يحسب تلقائياً من الحساب الأب",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: parentId_ ? String((allAccounts.find((a) => a.id === parentId_)?.level || 1) + 1) : "1",
						disabled: true,
						dir: "ltr",
						className: "font-mono"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الحساب الأب الحالي",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: parentId_ ? `${allAccounts.find((a) => a.id === parentId_)?.code || ""} — ${allAccounts.find((a) => a.id === parentId_)?.name || ""}` : "— (بدون أب / حساب رئيسي)",
						disabled: true
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
					title: "الحسابات الفرعية",
					className: "bg-muted/30",
					children: allAccounts.filter((a) => a.parentId === "").length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "لم يتم بعد إنشاء حسابات رئيسية. الحسابات الرئيسية عادةً تكون أصول، التزامات، حقوق ملكية، إيرادات، مصروفات."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "بعد الحفظ، ستظهر الحسابات الفرعية تحت هذا الحساب في دليل الحسابات."
					})
				})]
			})
		},
		{
			id: "posting",
			label: "إعدادات الترحيل",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ضبط سلوك الترحيل",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "قابل للترحيل",
					hint: "الحسابات غير القابلة للترحيل تستقبل فقط حسابات فرعية",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSegmented, {
						value: postable ? "yes" : "no",
						onChange: (v) => setPostable(v === "yes"),
						disabled: type === "رئيسي",
						options: [{
							value: "yes",
							label: "نعم — يقبل قيود يومية"
						}, {
							value: "no",
							label: "لا — حساب رئيسي فقط"
						}]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "العملة",
					htmlFor: "acct-currency",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
						id: "acct-currency",
						value: currency,
						onChange: (e) => setCurrency(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "SAR",
								children: "ر.س — ريال سعودي"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "USD",
								children: "$ — دولار أمريكي"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "EUR",
								children: "€ — يورو"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "EGP",
								children: "ج.م — جنيه مصري"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الحالة",
					htmlFor: "acct-status",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
						id: "acct-status",
						value: status,
						onChange: (e) => setStatus(e.target.value),
						children: ACCOUNT_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))
					})
				})] })]
			})
		},
		{
			id: "balance",
			label: "الأرصدة والاستخدامات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "الرصيد الافتتاحي",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "رصيد افتتاحي",
					hint: "يُسجَّل فقط عند إنشاء حساب جديد",
					htmlFor: "acct-balance",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						id: "acct-balance",
						type: "number",
						step: "0.01",
						value: balance,
						onChange: (e) => setBalance(e.target.value),
						placeholder: "0.00",
						dir: "ltr",
						className: "font-mono tabular-nums"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "اتجاه الرصيد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: parseFloat(balance) > 0 ? "مدين" : parseFloat(balance) < 0 ? "دائن" : "صفر",
						disabled: true
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-muted/40 p-3 text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
						className: "text-foreground",
						children: "ملاحظة:"
					}), " الأرصدة اللاحقة تُحسب تلقائياً من القيود المرحلة. هذا الرصيد هو نقطة البداية فقط."]
				})]
			})
		},
		{
			id: "notes",
			label: "ملاحظات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "ملاحظات داخلية",
				description: "مرئية فقط لفريق المحاسبة",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 6,
						placeholder: "ملاحظات خاصة بهذا الحساب..."
					})
				})
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "دليل الحسابات",
		breadcrumb: [
			"المالية",
			"دليل الحسابات",
			"جديد"
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المالية",
					to: "/finance/accounts"
				},
				{
					label: "دليل الحسابات",
					to: "/finance/accounts"
				},
				{ label: "حساب جديد" }
			],
			title: parent ? `حساب فرعي تحت ${parent.code}` : "إنشاء حساب جديد",
			subtitle: parent ? `يندرج تحت: ${parent.name}` : "املأ البيانات لإنشاء حساب جديد في دليل الحسابات",
			draftNumber: code ? `مسودة · ${code}` : "مسودة جديدة",
			status: {
				label: "جديد",
				tone: "info"
			},
			tabs,
			defaultTab: "basic",
			loading: saving,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/finance/accounts" })
		})
	});
}
//#endregion
export { NewAccountPage as component };
