import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, y as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, P as statusTone, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { c as getProjects } from "./projects-fdUGDKDE.mjs";
import { i as getDonors } from "./donors-BTleOe7U.mjs";
import { n as confirmDonation, o as issueReceipt, s as updateDonation, t as cancelDonation } from "./donations-CspILvNi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donations._id.edit-BqIqCFpG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditDonationPage() {
	const { id } = useParams({ from: "/donations/$id/edit" });
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: donationData, isLoading } = useQuery({
		queryKey: ["donation", id],
		queryFn: async () => {
			const res = await fetch(`/api/donations?id=${id}`);
			if (!res.ok) throw new Error("فشل في جلب التبرع");
			return res.json();
		},
		enabled: !!id
	});
	const { data: donorsData } = useQuery({
		queryKey: ["donors-simple"],
		queryFn: () => getDonors({ limit: 200 })
	});
	const donors = donorsData?.items || [];
	const { data: projectsData } = useQuery({
		queryKey: ["projects-simple"],
		queryFn: () => getProjects({ limit: 200 })
	});
	const projects = projectsData?.items || [];
	const donation = donationData?.item;
	const [donorId, setDonorId] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [projectId, setProjectId] = (0, import_react.useState)("");
	const [method, setMethod] = (0, import_react.useState)("تحويل بنكي");
	const [channel, setChannel] = (0, import_react.useState)("موقع إلكتروني");
	const [date, setDate] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (donation) {
			setDonorId(donation.donorId || "");
			setAmount(String(donation.amount || ""));
			setProjectId(donation.projectId || "");
			setMethod(donation.method || "تحويل بنكي");
			setChannel(donation.channel || "موقع إلكتروني");
			setDate(donation.date || "");
			setNotes(donation.notes || "");
		}
	}, [donation]);
	const isPosted = donation?.status === "مؤكد" || donation?.status === "تم إصدار إيصال";
	const isCancelled = donation?.status === "ملغي";
	const validate = () => {
		const e = {};
		if (!donorId) e.donorId = "يرجى اختيار المتبرع";
		if (!amount || parseFloat(amount) <= 0) e.amount = "يرجى إدخال مبلغ أكبر من صفر";
		setErrors(e);
		return Object.keys(e).length === 0;
	};
	const updateMutation = useMutation({
		mutationFn: (data) => updateDonation({
			id,
			...data
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donation", id] });
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			showToast("تم تحديث التبرع بنجاح", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const confirmMutation = useMutation({
		mutationFn: () => confirmDonation({
			id,
			amount: parseFloat(amount) || 0,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donation", id] });
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			showToast("تم تأكيد التبرع بنجاح", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const cancelMutation = useMutation({
		mutationFn: () => cancelDonation({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donation", id] });
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			showToast("تم إلغاء التبرع", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const receiptMutation = useMutation({
		mutationFn: () => issueReceipt({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donation", id] });
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			queryClient.invalidateQueries({ queryKey: ["receipts"] });
			showToast("تم إصدار الإيصال بنجاح", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleSave = async (andClose) => {
		if (isPosted || isCancelled) return;
		if (!validate()) {
			showToast("يرجى تصحيح الأخطاء قبل الحفظ", "error");
			return;
		}
		setSaving(true);
		try {
			await updateMutation.mutateAsync({
				donorId,
				amount: parseFloat(amount),
				projectId: projectId || null,
				method,
				channel,
				date,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			if (andClose) navigate({ to: "/donations" });
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "التبرعات",
		breadcrumb: ["التبرعات", "تحميل..."],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!donation) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "التبرعات",
		breadcrumb: ["التبرعات"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center py-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-base font-bold mb-2",
				children: "التبرع غير موجود"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => navigate({ to: "/donations" }),
				className: "text-primary hover:underline text-sm",
				children: "العودة إلى التبرعات"
			})]
		})
	});
	const donor = donors.find((d) => d.id === donorId);
	const project = projects.find((p) => p.id === projectId);
	const tabs = [
		{
			id: "basic",
			label: "البيانات الأساسية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات التبرع",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المتبرع",
						required: true,
						error: errors.donorId,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: donorId,
							onChange: (e) => setDonorId(e.target.value),
							invalid: !!errors.donorId,
							disabled: isPosted,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— اختر متبرعاً —"
							}), donors.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: d.id,
								children: d.name
							}, d.id))]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "تاريخ التبرع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value),
							dir: "ltr",
							disabled: isPosted
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "قيمة التبرع",
						required: true,
						error: errors.amount,
						hint: "بالريال السعودي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							step: "0.01",
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							dir: "ltr",
							className: "font-mono tabular-nums text-base",
							invalid: !!errors.amount,
							disabled: isPosted
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "طريقة الدفع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: method,
							onChange: (e) => setMethod(e.target.value),
							disabled: isPosted,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "تحويل بنكي",
									children: "تحويل بنكي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "نقدًا",
									children: "نقدًا"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "شيك",
									children: "شيك"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "بطاقة",
									children: "بطاقة ائتمانية"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "محفظة إلكترونية",
									children: "محفظة إلكترونية"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "إيداع مباشر",
									children: "إيداع مباشر"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "قناة الاستلام",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: channel,
							onChange: (e) => setChannel(e.target.value),
							disabled: isPosted,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "موقع إلكتروني",
									children: "موقع إلكتروني"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "تطبيق",
									children: "تطبيق"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "مكتب",
									children: "مكتب"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "مندوب",
									children: "مندوب ميداني"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "هاتف",
									children: "هاتف"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "فاكس",
									children: "فاكس / رسالة"
								})
							]
						})
					})] })
				]
			})
		},
		{
			id: "allocation",
			label: "المشروع والتخصيص",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "تخصيص التبرع",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "المشروع",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
						value: projectId,
						onChange: (e) => setProjectId(e.target.value),
						disabled: isPosted,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "— تبرع عام (بدون مشروع) —"
						}), projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p.id,
							children: p.name
						}, p.id))]
					})
				}), project && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border bg-muted/30 p-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-semibold mb-1",
						children: project.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs text-muted-foreground",
						children: [
							project.status,
							" · ",
							fmtNum(project.progress),
							"% مكتمل"
						]
					})]
				})]
			})
		},
		{
			id: "donor",
			label: "المتبرع",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "بيانات المتبرع",
				children: donor ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "الاسم",
							value: donor.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "النوع",
							value: donor.type
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "الجوال",
							value: donor.phone || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "البريد",
							value: donor.email || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "المدينة",
							value: donor.city || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "إجمالي التبرعات",
							value: fmtSAR(donor.totalDonations)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "عدد التبرعات",
							value: fmtNum(donor.donationCount)
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "اختر متبرعاً في تبويب «البيانات الأساسية» لعرض تفاصيله هنا."
				})
			})
		},
		{
			id: "notes",
			label: "الملاحظات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "ملاحظات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 5,
						disabled: isPosted
					})
				})
			})
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "الحالة والإجراءات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "الحالة الحالية",
							value: donation.status,
							tone: "default"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "رقم الإيصال",
							value: donation.receiptId || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ التسجيل",
							value: donation.createdAt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "أنشأ بواسطة",
							value: donation.createdBy || "—"
						})
					]
				})
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "التبرعات",
		breadcrumb: ["التبرعات", donation.id],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [{
				label: "التبرعات",
				to: "/donations"
			}, { label: donor?.name || "تبرع" }],
			title: `تبرع من ${donor?.name || "متبرع"}`,
			subtitle: `${fmtSAR(donation.amount)} · ${donation.method} · ${donation.date}`,
			draftNumber: donation.id,
			status: {
				label: donation.status,
				tone: statusTone(donation.status)
			},
			isReadOnly: isPosted || isCancelled,
			readonlyReason: isPosted ? "التبرع مؤكد. لا يمكن التعديل، ولكن يمكن إصدار إيصال أو إلغاؤه." : isCancelled ? "التبرع ملغى." : "",
			tabs,
			defaultTab: "basic",
			loading: saving || updateMutation.isPending,
			primaryLabel: isPosted || isCancelled ? "غير قابل للتعديل" : "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: !isPosted && !isCancelled,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/donations" }),
			extraActions: !isPosted && !isCancelled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => confirmMutation.mutate(),
				disabled: confirmMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg bg-success px-3 py-2 text-sm font-semibold text-success-foreground hover:opacity-90 transition-opacity min-h-[40px] shadow-sm",
				children: "اعتماد التبرع"
			}) : isPosted && !donation.receiptId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => receiptMutation.mutate(),
				disabled: receiptMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg border border-primary/30 bg-primary/10 text-primary px-3 py-2 text-sm font-semibold hover:bg-primary/20 transition-colors min-h-[40px]",
				children: "إصدار إيصال"
			}) : !isCancelled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => cancelMutation.mutate(),
				disabled: cancelMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 text-destructive px-3 py-2 text-sm font-semibold hover:bg-destructive/20 transition-colors min-h-[40px]",
				children: "إلغاء التبرع"
			}) : null
		})
	});
}
//#endregion
export { EditDonationPage as component };
