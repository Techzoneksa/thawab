import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.items._id.edit-5VQs2kwA.js
var $$splitComponentImporter = () => import("./inventory.items._id.edit-ijShX3cC.mjs");
var Route = createFileRoute("/inventory/items/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل صنف — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
