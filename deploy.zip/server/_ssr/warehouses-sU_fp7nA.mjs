//#region node_modules/.nitro/vite/services/ssr/assets/warehouses-sU_fp7nA.js
var API_BASE = "/api/inventory/warehouses";
var WAREHOUSE_STATUSES = ["نشط", "موقوف"];
async function getWarehouses(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب المستودعات");
	return res.json();
}
async function getWarehouse(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات المستودع");
	return res.json();
}
async function createWarehouse(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة المستودع");
	}
	return (await res.json()).item;
}
async function updateWarehouse(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث المستودع");
	}
	return (await res.json()).item;
}
async function activateWarehouse(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "activate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تفعيل المستودع");
	}
	return (await res.json()).item;
}
async function deactivateWarehouse(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "deactivate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تعطيل المستودع");
	}
	return (await res.json()).item;
}
async function deleteWarehouse(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف المستودع");
	}
}
//#endregion
export { deleteWarehouse as a, updateWarehouse as c, deactivateWarehouse as i, activateWarehouse as n, getWarehouse as o, createWarehouse as r, getWarehouses as s, WAREHOUSE_STATUSES as t };
