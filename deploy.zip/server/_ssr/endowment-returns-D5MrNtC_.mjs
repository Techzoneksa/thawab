import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { U as Plus } from "../_libs/lucide-react.mjs";
import { N as showToast, O as SectionTitle, S as MobilePageHeader, a as Btn, h as EntityFormDrawer, n as AppShell, s as Card } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/endowment-returns-D5MrNtC_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [data, setData] = (0, import_react.useState)([
		{
			q: "Q1 1446",
			v: 192e3
		},
		{
			q: "Q2 1446",
			v: 204e3
		},
		{
			q: "Q3 1446",
			v: 218e3
		},
		{
			q: "Q4 1446 (متوقع)",
			v: 184e3
		}
	]);
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [formQuarter, setFormQuarter] = (0, import_react.useState)("");
	const [formAmount, setFormAmount] = (0, import_react.useState)("");
	const max = Math.max(...data.map((d) => d.v));
	const handleSave = () => {
		if (!formQuarter.trim() || !formAmount.trim()) {
			showToast("يرجى إدخال البيانات", "error");
			return;
		}
		setData([...data, {
			q: formQuarter,
			v: Number(formAmount)
		}]);
		showToast("تم إضافة عائد الوقف بنجاح", "success");
		setFormOpen(false);
		setFormQuarter("");
		setFormAmount("");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المنح والأوقاف",
			"عوائد الأوقاف"
		],
		title: "عوائد الأوقاف الاستثمارية",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: () => setFormOpen(true),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إضافة عائد وقف"]
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
			title: "عوائد الأوقاف الاستثمارية",
			count: `${data.length} ربع`
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				title: "العوائد الربعية للسنة 1446هـ",
				hint: `إجمالي محقق: ${fmtSAR(data.reduce((a, d) => a + d.v, 0))}`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-end gap-6 h-60 min-w-[400px]",
					children: data.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 flex flex-col items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold tabular-nums",
								children: fmtSAR(d.v)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full bg-gradient-to-t from-primary to-info/70 rounded-t",
								style: { height: `${d.v / max * 90}%` }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: d.q
							})
						]
					}, d.q))
				})
			})]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
		open: formOpen,
		onClose: () => setFormOpen(false),
		title: "إضافة عائد وقف",
		onSave: handleSave,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: "text-xs font-semibold text-muted-foreground",
			children: "الربع"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
			value: formQuarter,
			onChange: (e) => setFormQuarter(e.target.value),
			placeholder: "مثال: Q1 1447"
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
			className: "text-xs font-semibold text-muted-foreground",
			children: "القيمة"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
			type: "number",
			value: formAmount,
			onChange: (e) => setFormAmount(e.target.value)
		})] })]
	})] });
};
//#endregion
export { SplitComponent as component };
