import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, o as FormSegmented, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { t as createDonor } from "./donors-BTleOe7U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donors.new-pt77EYqX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TYPES = [
	"فرد",
	"شركة",
	"مؤسسة",
	"جهة حكومية"
];
var TAGS = [
	"عام",
	"VIP",
	"متكرر",
	"جديد",
	"متوسط",
	"غير نشط"
];
function NewDonorPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const [name, setName] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("فرد");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [tag, setTag] = (0, import_react.useState)("جديد");
	const [recurring, setRecurring] = (0, import_react.useState)(false);
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [saving, setSaving] = (0, import_react.useState)(false);
	const validate = () => {
		const e = {};
		if (!name.trim()) e.name = "اسم المتبرع مطلوب";
		if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) e.email = "بريد إلكتروني غير صالح";
		setErrors(e);
		return Object.keys(e).length === 0;
	};
	const handleSave = async (andClose) => {
		if (!validate()) {
			showToast("يرجى تصحيح الأخطاء قبل الحفظ", "error");
			return;
		}
		setSaving(true);
		try {
			const created = await createDonor({
				name: name.trim(),
				type,
				phone: phone || void 0,
				email: email || void 0,
				city,
				address,
				tag,
				recurring,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast(`تم تسجيل المتبرع ${created.name}`, "success");
			if (andClose) navigate({ to: "/donors" });
			else navigate({
				to: "/donors/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المتبرعون",
		breadcrumb: ["المتبرعون", "جديد"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [{
				label: "المتبرعون",
				to: "/donors"
			}, { label: "إضافة متبرع" }],
			title: "إضافة متبرع جديد",
			subtitle: "سجّل بيانات المتبرع لإضافته إلى قاعدة بيانات المتبرعين",
			draftNumber: "مسودة جديدة",
			status: {
				label: "جديد",
				tone: "info"
			},
			tabs: [
				{
					id: "basic",
					label: "البيانات الأساسية",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "بيانات المتبرع",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "الاسم",
								required: true,
								error: errors.name,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: name,
									onChange: (e) => setName(e.target.value),
									invalid: !!errors.name
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "النوع",
								required: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSegmented, {
									value: type,
									onChange: setType,
									options: TYPES.map((t) => ({
										value: t,
										label: t
									}))
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "رقم الجوال",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: phone,
									onChange: (e) => setPhone(e.target.value),
									placeholder: "05xxxxxxxx",
									dir: "ltr"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "البريد الإلكتروني",
								error: errors.email,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									type: "email",
									value: email,
									onChange: (e) => setEmail(e.target.value),
									placeholder: "email@example.com",
									dir: "ltr",
									invalid: !!errors.email
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "المدينة",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: city,
									onChange: (e) => setCity(e.target.value)
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "العنوان",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: address,
									onChange: (e) => setAddress(e.target.value)
								})
							})] })
						]
					})
				},
				{
					id: "categorization",
					label: "التصنيف",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "تصنيف المتبرع",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "الوسم",
							hint: "يستخدم لتصفية المتبرعين",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
								value: tag,
								onChange: (e) => setTag(e.target.value),
								children: TAGS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: t,
									children: t
								}, t))
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "متبرع متكرر",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSegmented, {
								value: recurring ? "yes" : "no",
								onChange: (v) => setRecurring(v === "yes"),
								options: [{
									value: "yes",
									label: "نعم — متبرع متكرر"
								}, {
									value: "no",
									label: "لا — تبرع لمرة واحدة"
								}]
							})
						})]
					})
				},
				{
					id: "notes",
					label: "ملاحظات",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
						title: "ملاحظات داخلية",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "ملاحظات",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
								value: notes,
								onChange: (e) => setNotes(e.target.value),
								rows: 6
							})
						})
					})
				}
			],
			defaultTab: "basic",
			loading: saving,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/donors" })
		})
	});
}
//#endregion
export { NewDonorPage as component };
