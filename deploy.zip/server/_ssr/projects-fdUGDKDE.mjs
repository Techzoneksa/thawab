//#region node_modules/.nitro/vite/services/ssr/assets/projects-fdUGDKDE.js
var API_BASE = "/api/projects";
async function getProjects(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.category && filters.category !== "الكل") params.set("category", filters.category);
	if (filters.branch && filters.branch !== "الكل") params.set("branch", filters.branch);
	if (filters.page) params.set("page", String(filters.page));
	if (filters.limit) params.set("limit", String(filters.limit));
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب المشاريع");
	return res.json();
}
async function getProject(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات المشروع");
	return res.json();
}
async function getProjectSummary(id) {
	const res = await fetch(`${API_BASE}?id=${id}&summary=true`);
	if (!res.ok) throw new Error("فشل في جلب ملخص المشروع");
	return (await res.json()).item;
}
async function createProject(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة المشروع");
	}
	return (await res.json()).item;
}
async function updateProject(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث المشروع");
	}
	return (await res.json()).item;
}
async function deleteProject(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف المشروع");
	}
}
async function activateProject(options) {
	return workflowAction(options.id, "activate", options.userId, options.userName);
}
async function pauseProject(options) {
	return workflowAction(options.id, "pause", options.userId, options.userName);
}
async function completeProject(options) {
	return workflowAction(options.id, "complete", options.userId, options.userName);
}
async function cancelProject(options) {
	return workflowAction(options.id, "cancel", options.userId, options.userName);
}
async function workflowAction(id, action, userId, userName) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			id,
			action,
			userId,
			userName
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || `فشل في تنفيذ العملية: ${action}`);
	}
	return (await res.json()).item;
}
//#endregion
export { deleteProject as a, getProjects as c, createProject as i, pauseProject as l, cancelProject as n, getProject as o, completeProject as r, getProjectSummary as s, activateProject as t, updateProject as u };
