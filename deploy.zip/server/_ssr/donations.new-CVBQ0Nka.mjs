import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { c as getProjects } from "./projects-fdUGDKDE.mjs";
import { i as getDonors } from "./donors-BTleOe7U.mjs";
import { r as createDonation } from "./donations-CspILvNi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donations.new-CVBQ0Nka.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NewDonationPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: donorsData } = useQuery({
		queryKey: ["donors-simple"],
		queryFn: () => getDonors({ limit: 200 })
	});
	const donors = donorsData?.items || [];
	const { data: projectsData } = useQuery({
		queryKey: ["projects-simple"],
		queryFn: () => getProjects({ limit: 200 })
	});
	const projects = projectsData?.items || [];
	const [donorId, setDonorId] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [projectId, setProjectId] = (0, import_react.useState)("");
	const [method, setMethod] = (0, import_react.useState)("تحويل بنكي");
	const [channel, setChannel] = (0, import_react.useState)("موقع إلكتروني");
	const [date, setDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [saving, setSaving] = (0, import_react.useState)(false);
	const validate = () => {
		const e = {};
		if (!donorId) e.donorId = "يرجى اختيار المتبرع";
		if (!amount || parseFloat(amount) <= 0) e.amount = "يرجى إدخال مبلغ أكبر من صفر";
		if (!method) e.method = "يرجى اختيار طريقة الدفع";
		setErrors(e);
		return Object.keys(e).length === 0;
	};
	const handleSave = async (andClose) => {
		if (!validate()) {
			showToast("يرجى تصحيح الأخطاء قبل الحفظ", "error");
			return;
		}
		setSaving(true);
		try {
			const created = await createDonation({
				donorId,
				amount: parseFloat(amount),
				projectId: projectId || void 0,
				method,
				channel,
				date,
				notes,
				status: "بانتظار التأكيد",
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			showToast(`تم تسجيل التبرع بمبلغ ${fmtSAR(created.amount)}`, "success");
			if (andClose) navigate({ to: "/donations" });
			else navigate({
				to: "/donations/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "التبرعات",
		breadcrumb: ["التبرعات", "جديد"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [{
				label: "التبرعات",
				to: "/donations"
			}, { label: "تسجيل تبرع جديد" }],
			title: "تسجيل تبرع جديد",
			subtitle: "املأ بيانات التبرع. سيتم تسجيل التبرع بحالة «بانتظار التأكيد» حتى يتم اعتماده.",
			draftNumber: "مسودة جديدة",
			status: {
				label: "مسودة",
				tone: "info"
			},
			tabs: [
				{
					id: "basic",
					label: "البيانات الأساسية",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "بيانات التبرع",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "المتبرع",
								required: true,
								error: errors.donorId,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
									value: donorId,
									onChange: (e) => setDonorId(e.target.value),
									invalid: !!errors.donorId,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "— اختر متبرعاً —"
									}), donors.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: d.id,
										children: [
											d.name,
											" ",
											d.phone ? `(${d.phone})` : ""
										]
									}, d.id))]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "تاريخ التبرع",
								required: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									type: "date",
									value: date,
									onChange: (e) => setDate(e.target.value),
									dir: "ltr"
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "قيمة التبرع",
								required: true,
								error: errors.amount,
								hint: "بالريال السعودي",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									type: "number",
									step: "0.01",
									value: amount,
									onChange: (e) => setAmount(e.target.value),
									placeholder: "0.00",
									dir: "ltr",
									className: "font-mono tabular-nums text-base",
									invalid: !!errors.amount
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "طريقة الدفع",
								required: true,
								error: errors.method,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
									value: method,
									onChange: (e) => setMethod(e.target.value),
									invalid: !!errors.method,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "تحويل بنكي",
											children: "تحويل بنكي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "نقدًا",
											children: "نقدًا"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "شيك",
											children: "شيك"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "بطاقة",
											children: "بطاقة ائتمانية"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "محفظة إلكترونية",
											children: "محفظة إلكترونية"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "إيداع مباشر",
											children: "إيداع مباشر"
										})
									]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "قناة الاستلام",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
									value: channel,
									onChange: (e) => setChannel(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "موقع إلكتروني",
											children: "موقع إلكتروني"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "تطبيق",
											children: "تطبيق"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "مكتب",
											children: "مكتب"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "مندوب",
											children: "مندوب ميداني"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "هاتف",
											children: "هاتف"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "فاكس",
											children: "فاكس / رسالة"
										})
									]
								})
							})] })
						]
					})
				},
				{
					id: "allocation",
					label: "المشروع والتخصيص",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "تخصيص التبرع",
						description: "اختر مشروعاً لتخصيص التبرع له، أو اتركه فارغاً ليُضاف للصندوق العام",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "المشروع",
							hint: "اتركه فارغاً للتبرع العام",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
								value: projectId,
								onChange: (e) => setProjectId(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "— تبرع عام (بدون مشروع) —"
								}), projects.filter((p) => p.status === "نشط" || p.status === "قيد التنفيذ").map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: p.id,
									children: p.name
								}, p.id))]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-muted/40 p-3 text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "text-foreground",
								children: "ملاحظة:"
							}), " بعد التأكيد، يتم إنشاء قيد يومية تلقائياً لتحويل المبلغ من حساب البنك إلى حساب التبرعات."]
						})]
					})
				},
				{
					id: "notes",
					label: "الملاحظات والمرفقات",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "ملاحظات",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "ملاحظات",
							hint: "تظهر في سجل التبرعات",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
								value: notes,
								onChange: (e) => setNotes(e.target.value),
								rows: 5,
								placeholder: "أي ملاحظات إضافية حول هذا التبرع..."
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-lg border border-dashed p-4 text-center text-xs text-muted-foreground",
							children: "إرفاق الإيصال أو مستند الدفع (قريباً)"
						})]
					})
				}
			],
			defaultTab: "basic",
			loading: saving,
			primaryLabel: "حفظ كمسودة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/donations" })
		})
	});
}
//#endregion
export { NewDonationPage as component };
