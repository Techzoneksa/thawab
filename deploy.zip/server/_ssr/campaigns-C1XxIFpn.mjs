import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Ht as CircleX, U as Plus, Wt as CircleCheckBig, it as Megaphone, jt as Eye, v as Trash2 } from "../_libs/lucide-react.mjs";
import { N as showToast, P as statusTone, S as MobilePageHeader, a as Btn, c as ConfirmDialog, g as ExportButton, h as EntityFormDrawer, i as Badge, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, a as CAMPAIGNS, x as fmtNum } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/campaigns-C1XxIFpn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [data, setData] = (0, import_react.useState)(CAMPAIGNS);
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [confirmIdx, setConfirmIdx] = (0, import_react.useState)(-1);
	const [formName, setFormName] = (0, import_react.useState)("");
	const [formTarget, setFormTarget] = (0, import_react.useState)("");
	const nextId = () => `CMP-${String(100 + data.length + 1).slice(-3)}`;
	const handleSave = () => {
		if (!formName.trim() || !formTarget.trim()) {
			showToast("يرجى إدخال البيانات", "error");
			return;
		}
		setData([{
			id: nextId(),
			name: formName,
			target: Number(formTarget),
			raised: 0,
			donors: 0,
			status: "نشطة",
			end: "—"
		}, ...data]);
		showToast("تم إضافة الحملة بنجاح", "success");
		setFormOpen(false);
		setFormName("");
		setFormTarget("");
	};
	const changeStatus = (idx, status) => {
		const d = [...data];
		d[idx] = {
			...d[idx],
			status
		};
		setData(d);
		showToast(`تم تغيير الحالة إلى ${status}`, "success");
	};
	const handleDelete = () => {
		setData(data.filter((_, i) => i !== confirmIdx));
		showToast("تم حذف الحملة", "success");
		setConfirmIdx(-1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"التبرعات",
			"الحملات"
		],
		title: "حملات التبرع",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
			data,
			filename: "campaigns.csv"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: () => {
				setFormName("");
				setFormTarget("");
				setFormOpen(true);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إضافة حملة"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "حملات التبرع",
				count: `${data.length} حملة`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4",
				children: data.map((c, idx) => {
					const pct = Math.round(c.raised / c.target * 100) || 0;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { size: 20 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold truncate",
										children: c.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground font-mono",
										children: c.id
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(c.status),
									children: c.status
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
									{
										label: "عرض",
										icon: Eye,
										onClick: () => showToast(c.name, "info")
									},
									{
										label: "إنهاء",
										icon: CircleCheckBig,
										onClick: () => changeStatus(idx, "مكتملة")
									},
									{
										label: "إلغاء",
										icon: CircleX,
										onClick: () => changeStatus(idx, "ملغاة")
									},
									{
										label: "حذف",
										icon: Trash2,
										variant: "destructive",
										onClick: () => setConfirmIdx(idx)
									}
								] })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-xs mb-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold tabular-nums",
										children: fmtSAR(c.raised)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: ["من ", fmtSAR(c.target)]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-3 rounded-full bg-muted overflow-hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `h-full ${pct >= 100 ? "bg-success" : "bg-gradient-to-l from-primary to-info"}`,
										style: { width: `${Math.min(pct, 100)}%` }
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground mt-1",
									children: [
										pct,
										"% من الهدف · ",
										fmtNum(c.donors),
										" متبرع · حتى ",
										c.end
									]
								})
							]
						})]
					}, c.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: formOpen,
				onClose: () => setFormOpen(false),
				title: "إضافة حملة",
				onSave: handleSave,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "اسم الحملة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: formName,
					onChange: (e) => setFormName(e.target.value)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "الهدف"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					type: "number",
					value: formTarget,
					onChange: (e) => setFormTarget(e.target.value)
				})] })]
			}),
			confirmIdx >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: true,
				onClose: () => setConfirmIdx(-1),
				onConfirm: handleDelete,
				title: "تأكيد الحذف",
				message: "هل أنت متأكد من حذف الحملة؟",
				confirmText: "حذف",
				variant: "destructive"
			})
		]
	});
};
//#endregion
export { SplitComponent as component };
