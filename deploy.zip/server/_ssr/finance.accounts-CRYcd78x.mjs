import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { G as Play, J as Pencil, Jt as ChevronDown, Kt as ChevronRight, P as Search, U as Plus, Y as Pause, jt as Eye, v as Trash2, wt as Funnel } from "../_libs/lucide-react.mjs";
import { A as Table, C as MobileSearchInput, F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { a as deactivateAccount, c as getAccounts, n as ACCOUNT_TYPES, o as deleteAccount, r as activateAccount, t as ACCOUNT_STATUSES } from "./accounts-i45ITZyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.accounts-CRYcd78x.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const navigate = useNavigate();
	const { user } = useAuth();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("الكل");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [statusTarget, setStatusTarget] = (0, import_react.useState)(null);
	const [view, setView] = (0, import_react.useState)("tree");
	const [expanded, setExpanded] = (0, import_react.useState)(/* @__PURE__ */ new Set());
	const [selectedId, setSelectedId] = (0, import_react.useState)(null);
	const { data, isLoading, error } = useQuery({
		queryKey: ["accounts", {
			search: searchQuery,
			type: typeFilter,
			status: statusFilter
		}],
		queryFn: () => getAccounts({
			search: searchQuery,
			type: typeFilter,
			status: statusFilter
		})
	});
	const accounts = data?.items || [];
	const total = data?.total || 0;
	const selectedAccount = (0, import_react.useMemo)(() => accounts.find((a) => a.id === selectedId) || null, [accounts, selectedId]);
	const childrenOf = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const a of accounts) if (a.parentId) {
			if (!map.has(a.parentId)) map.set(a.parentId, []);
			map.get(a.parentId).push(a);
		}
		return map;
	}, [accounts]);
	const roots = (0, import_react.useMemo)(() => accounts.filter((a) => !a.parentId).sort((a, b) => a.code.localeCompare(b.code)), [accounts]);
	(0, import_react.useEffect)(() => {
		if (expanded.size === 0 && roots.length > 0) {
			const all = /* @__PURE__ */ new Set();
			const walk = (a) => {
				all.add(a.id);
				childrenOf.get(a.id)?.forEach(walk);
			};
			roots.forEach(walk);
			setExpanded(all);
		}
	}, [
		roots,
		childrenOf,
		expanded.size
	]);
	const openAdd = (parent) => {
		navigate({
			to: "/finance/accounts/new",
			search: parent?.id ? { parent: parent.id } : {}
		});
	};
	const openEdit = (a) => {
		navigate({
			to: "/finance/accounts/$id/edit",
			params: { id: a.id }
		});
	};
	const deleteMutation = useMutation({
		mutationFn: deleteAccount,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["accounts"] });
			showToast("تم حذف الحساب بنجاح", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const statusMutation = useMutation({
		mutationFn: async (vars) => {
			return (vars.action === "deactivate" ? deactivateAccount : activateAccount)({
				id: vars.id,
				userId: vars.userId,
				userName: vars.userName
			});
		},
		onSuccess: (_, vars) => {
			queryClient.invalidateQueries({ queryKey: ["accounts"] });
			showToast(vars.action === "deactivate" ? "تم إيقاف الحساب" : "تم تفعيل الحساب", "success");
			setStatusTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleStatusConfirm = () => {
		if (statusTarget) statusMutation.mutate({
			id: statusTarget.id,
			action: statusTarget.action,
			userId: user?.id,
			userName: user?.name
		});
	};
	const toggleExpand = (id) => {
		const next = new Set(expanded);
		if (next.has(id)) next.delete(id);
		else next.add(id);
		setExpanded(next);
	};
	const stats = [
		{
			label: "إجمالي الحسابات",
			value: fmtNum(total)
		},
		{
			label: "حسابات نشطة",
			value: accounts.filter((a) => a.status === "نشط").length
		},
		{
			label: "قابلة للترحيل",
			value: accounts.filter((a) => a.postable).length
		},
		{
			label: "حسابات رئيسية",
			value: accounts.filter((a) => a.level === 1).length
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المالية",
			"دليل الحسابات"
		],
		title: "دليل الحسابات",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden lg:flex rounded-lg border overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setView("tree"),
					className: `px-3 py-2 ${view === "tree" ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`,
					children: "الشجرة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setView("table"),
					className: `px-3 py-2 ${view === "table" ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`,
					children: "القائمة"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: accounts,
				filename: "دليل_الحسابات.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => openAdd(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " حساب جديد"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base lg:text-xl font-extrabold mt-1 tabular-nums truncate",
						children: s.value
					})]
				}, s.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث بالرقم أو الاسم...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "النوع",
					options: ["الكل", ...ACCOUNT_TYPES],
					value: typeFilter,
					onChange: (e) => setTypeFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الحالة",
					options: ["الكل", ...ACCOUNT_STATUSES],
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "دليل الحسابات",
				count: `${fmtNum(total)} حساب`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => openAdd(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 })
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء تحميل الحسابات",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["accounts"] }),
					children: "إعادة المحاولة"
				})
			}) : accounts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد حسابات",
				description: "ابدأ بإضافة أول حساب",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => openAdd(),
					children: "إضافة حساب"
				})
			}) : view === "tree" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-1",
						children: roots.map((root) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreeNode, {
							account: root,
							childrenOf,
							expanded,
							selectedId,
							onToggle: toggleExpand,
							onSelect: setSelectedId,
							onAdd: (a) => openAdd(a),
							onEdit: openEdit,
							onDelete: (id) => setDeleteTarget(id),
							onDeactivate: (a) => setStatusTarget({
								id: a.id,
								name: `${a.code} - ${a.name}`,
								action: "deactivate"
							}),
							onActivate: (a) => setStatusTarget({
								id: a.id,
								name: `${a.code} - ${a.name}`,
								action: "activate"
							}),
							level: 0
						}, root.id))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "p-4 lg:p-5",
					children: selectedAccount ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3 mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-base lg:text-lg font-bold",
									children: [
										selectedAccount.code,
										" — ",
										selectedAccount.name
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground mt-1",
									children: [
										selectedAccount.type,
										" · المستوى ",
										selectedAccount.level,
										selectedAccount.parentId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											" ",
											"·",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono",
												children: accounts.find((a) => a.id === selectedAccount.parentId)?.code || ""
											})
										] })
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-end gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(selectedAccount.status),
									children: selectedAccount.status
								}), selectedAccount.postable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "info",
									children: "قابل للترحيل"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "muted",
									children: "رئيسي"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3 mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "الرصيد",
								value: fmtSAR(selectedAccount.balance)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "العملة",
								value: selectedAccount.currency
							})]
						}),
						selectedAccount.description && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-muted-foreground",
								children: "الوصف"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm mt-1",
								children: selectedAccount.description
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 border-t pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs font-semibold text-muted-foreground mb-2",
								children: [
									"الحسابات الفرعية (",
									childrenOf.get(selectedAccount.id)?.length || 0,
									")"
								]
							}), childrenOf.get(selectedAccount.id)?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-1",
								children: childrenOf.get(selectedAccount.id).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between rounded-lg border p-2 hover:bg-muted/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setSelectedId(c.id),
										className: "text-right text-sm font-semibold hover:text-primary flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono",
												children: c.code
											}),
											" — ",
											c.name
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: statusTone(c.status),
										children: c.status
									})]
								}, c.id))
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: "لا توجد حسابات فرعية"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
								variant: "outline",
								onClick: () => openEdit(selectedAccount),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { size: 14 }), " تعديل"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
								variant: "outline",
								onClick: () => openAdd(selectedAccount),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " إضافة فرعي"]
							})]
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-center py-8 text-sm text-muted-foreground",
						children: "اختر حساباً من الشجرة لعرض التفاصيل"
					})
				})]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-0 overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
					columns: [
						"الرقم",
						"الاسم",
						"النوع",
						"المستوى",
						"الأب",
						"الرصيد",
						"الحالة",
						""
					],
					rows: accounts,
					renderRow: (a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "font-mono text-xs",
							children: a.code
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setSelectedId(a.id),
							className: "font-semibold hover:text-primary text-right",
							children: a.name
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: a.type }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "tabular-nums",
							children: a.level
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "font-mono text-xs text-muted-foreground",
							children: a.parentId ? accounts.find((x) => x.id === a.parentId)?.code || "—" : "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "tabular-nums",
							children: fmtSAR(a.balance)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: statusTone(a.status),
							children: a.status
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getAccountActions(a, setStatusTarget, openEdit, setDeleteTarget) }) })
					] })
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: handleDelete,
				title: "حذف الحساب",
				message: "هل أنت متأكد من حذف هذا الحساب؟ سيتم الحذف فقط إذا لم يكن له فروع أو حركات.",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!statusTarget,
				onClose: () => setStatusTarget(null),
				onConfirm: handleStatusConfirm,
				title: statusTarget ? statusTarget.action === "deactivate" ? "إيقاف الحساب" : "تفعيل الحساب" : "",
				message: statusTarget ? `هل تريد ${statusTarget.action === "deactivate" ? "إيقاف" : "تفعيل"} الحساب "${statusTarget.name}"؟` : "",
				confirmText: statusTarget ? statusTarget.action === "deactivate" ? "إيقاف" : "تفعيل" : "",
				cancelText: "إلغاء",
				variant: "default"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "النوع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: typeFilter,
						onChange: (e) => setTypeFilter(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), ACCOUNT_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: t }, t))]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: statusFilter,
						onChange: (e) => setStatusFilter(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), ACCOUNT_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
					})] })]
				})
			})
		]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-muted/60 p-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-bold tabular-nums mt-0.5",
			children: value
		})]
	});
}
function TreeNode({ account, childrenOf, expanded, selectedId, onToggle, onSelect, onAdd, onEdit, onDelete, onDeactivate, onActivate, level }) {
	const kids = childrenOf.get(account.id) || [];
	const isExpanded = expanded.has(account.id);
	const isSelected = selectedId === account.id;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-center gap-2 rounded-lg p-2 cursor-pointer ${isSelected ? "bg-primary/15 border border-primary/30" : "hover:bg-muted/50"}`,
		style: { paddingRight: `${level * 16 + 8}px` },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: (e) => {
					e.stopPropagation();
					onToggle(account.id);
				},
				className: "text-muted-foreground hover:text-foreground",
				children: kids.length > 0 ? isExpanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { size: 14 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 14 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-[14px] inline-block" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => onSelect(account.id),
				className: "flex-1 text-right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-muted-foreground",
							children: account.code
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `text-sm ${isSelected ? "font-bold" : "font-medium"}`,
							children: account.name
						}),
						account.postable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground",
							children: "قابل للترحيل"
						}) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				tone: statusTone(account.status),
				children: account.status
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getAccountActionsInline(account, onAdd, onEdit, onDelete, onDeactivate, onActivate) })
		]
	}), isExpanded && kids.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreeNode, {
		account: k,
		childrenOf,
		expanded,
		selectedId,
		onToggle,
		onSelect,
		onAdd,
		onEdit,
		onDelete,
		onDeactivate,
		onActivate,
		level: level + 1
	}, k.id))] });
}
function getAccountActionsInline(a, onAdd, onEdit, onDelete, onDeactivate, onActivate) {
	const actions = [];
	if (a.type === "رئيسي" || !a.postable) actions.push({
		label: "إضافة حساب فرعي",
		icon: Plus,
		onClick: () => onAdd(a)
	});
	actions.push({
		label: "تعديل",
		icon: Pencil,
		onClick: () => onEdit(a)
	});
	if (a.status === "نشط") actions.push({
		label: "إيقاف",
		icon: Pause,
		onClick: () => onDeactivate(a)
	});
	else if (a.status === "موقوف") actions.push({
		label: "تفعيل",
		icon: Play,
		onClick: () => onActivate(a)
	});
	actions.push({
		label: "حذف",
		icon: Trash2,
		onClick: () => onDelete(a.id),
		variant: "destructive"
	});
	return actions;
}
function getAccountActions(a, setStatusTarget, openEdit, setDeleteTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => {}
	}];
	actions.push({
		label: "تعديل",
		icon: Pencil,
		onClick: () => openEdit(a)
	});
	if (a.status === "نشط") actions.push({
		label: "إيقاف",
		icon: Pause,
		onClick: () => setStatusTarget({
			id: a.id,
			name: `${a.code} - ${a.name}`,
			action: "deactivate"
		})
	});
	else if (a.status === "موقوف") actions.push({
		label: "تفعيل",
		icon: Play,
		onClick: () => setStatusTarget({
			id: a.id,
			name: `${a.code} - ${a.name}`,
			action: "activate"
		})
	});
	actions.push({
		label: "حذف",
		icon: Trash2,
		onClick: () => setDeleteTarget(a.id),
		variant: "destructive"
	});
	return actions;
}
//#endregion
export { Page as component };
