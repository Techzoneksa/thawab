import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { J as Pencil, U as Plus, Ut as CircleCheck, on as Ban, ot as MapPin, v as Trash2 } from "../_libs/lucide-react.mjs";
import { N as showToast, P as statusTone, S as MobilePageHeader, a as Btn, c as ConfirmDialog, g as ExportButton, h as EntityFormDrawer, i as Badge, n as AppShell, s as Card, t as ActionMenu, y as MobileActionRow } from "./actions-qTEe1ygX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings.branches-CGmFl2me.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [branches, setBranches] = (0, import_react.useState)([
		{
			n: "الفرع الرئيسي - الرياض",
			city: "الرياض",
			mgr: "د. عبدالله السبيعي",
			phone: "920001234",
			email: "hq@albir.org.sa",
			emp: 32,
			prj: 18,
			status: "نشط"
		},
		{
			n: "فرع جدة",
			city: "جدة",
			mgr: "أ. محمد العمري",
			phone: "920001235",
			email: "jeddah@albir.org.sa",
			emp: 14,
			prj: 7,
			status: "نشط"
		},
		{
			n: "فرع الدمام",
			city: "الدمام",
			mgr: "أ. خالد الدوسري",
			phone: "920001236",
			email: "dammam@albir.org.sa",
			emp: 10,
			prj: 5,
			status: "نشط"
		},
		{
			n: "فرع أبها",
			city: "أبها",
			mgr: "أ. سعيد الغامدي",
			phone: "920001237",
			email: "abha@albir.org.sa",
			emp: 8,
			prj: 4,
			status: "نشط"
		}
	]);
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [editIdx, setEditIdx] = (0, import_react.useState)(null);
	const [confirmOpen, setConfirmOpen] = (0, import_react.useState)(false);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(() => {});
	const [formName, setFormName] = (0, import_react.useState)("");
	const [formCity, setFormCity] = (0, import_react.useState)("");
	const [formMgr, setFormMgr] = (0, import_react.useState)("");
	const [formPhone, setFormPhone] = (0, import_react.useState)("");
	const [formEmail, setFormEmail] = (0, import_react.useState)("");
	const [formStatus, setFormStatus] = (0, import_react.useState)("نشط");
	function resetForm() {
		setFormName("");
		setFormCity("");
		setFormMgr("");
		setFormPhone("");
		setFormEmail("");
		setFormStatus("نشط");
	}
	function handleAdd() {
		if (!formName.trim()) {
			showToast("يرجى إدخال اسم الفرع", "error");
			return;
		}
		const newBranch = {
			n: formName,
			city: formCity || "—",
			mgr: formMgr || "—",
			phone: formPhone || "—",
			email: formEmail || "—",
			emp: 0,
			prj: 0,
			status: formStatus
		};
		setBranches([...branches, newBranch]);
		showToast(`تم إضافة الفرع ${formName} بنجاح`, "success");
		setAddOpen(false);
		resetForm();
	}
	function handleEdit(i) {
		const b = branches[i];
		setEditIdx(i);
		setFormName(b.n);
		setFormCity(b.city);
		setFormMgr(b.mgr);
		setFormPhone(b.phone);
		setFormEmail(b.email);
		setFormStatus(b.status);
		setEditOpen(true);
	}
	function handleSaveEdit() {
		if (editIdx === null) return;
		const updated = [...branches];
		updated[editIdx] = {
			...updated[editIdx],
			n: formName,
			city: formCity,
			mgr: formMgr,
			phone: formPhone,
			email: formEmail,
			status: formStatus
		};
		setBranches(updated);
		showToast(`تم تعديل الفرع ${formName} بنجاح`, "success");
		setEditOpen(false);
		setEditIdx(null);
		resetForm();
	}
	function toggleStatus(i) {
		const updated = [...branches];
		updated[i] = {
			...updated[i],
			status: updated[i].status === "نشط" ? "موقوف" : "نشط"
		};
		setBranches(updated);
		showToast(`تم ${updated[i].status === "نشط" ? "تفعيل" : "تعطيل"} الفرع ${updated[i].n}`, "success");
	}
	function handleDelete(i) {
		setConfirmAction(() => () => {
			setBranches(branches.filter((_, idx) => idx !== i));
			showToast("تم حذف الفرع بنجاح", "success");
		});
		setConfirmOpen(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"الإعدادات",
			"الفروع"
		],
		title: "فروع الجمعية",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: branches.map((b) => ({
					الفرع: b.n,
					المدينة: b.city,
					المدير: b.mgr,
					الجوال: b.phone,
					البريد: b.email,
					الحالة: b.status
				})),
				filename: "branches.csv"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => {
					resetForm();
					setAddOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "فرع جديد"]
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "فروع الجمعية",
				count: `${branches.length} فرع`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileActionRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => {
					resetForm();
					setAddOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "إضافة فرع"]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4 mt-3 lg:mt-0",
				children: branches.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2 mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { size: 20 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold truncate",
										children: b.n
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										children: b.city
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(b.status),
								children: b.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm text-muted-foreground space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["المدير: ", b.mgr] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["الجوال: ", b.phone] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["البريد: ", b.email] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3 mt-3 text-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-muted/60 p-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-muted-foreground",
									children: "الموظفون"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold mt-0.5",
									children: b.emp
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-muted/60 p-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-muted-foreground",
									children: "المشاريع"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold mt-0.5",
									children: b.prj
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex justify-end mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
								{
									label: "تعديل",
									icon: Pencil,
									onClick: () => handleEdit(i)
								},
								{
									label: b.status === "نشط" ? "تعطيل" : "تفعيل",
									icon: b.status === "نشط" ? Ban : CircleCheck,
									onClick: () => toggleStatus(i)
								},
								{
									label: "حذف",
									icon: Trash2,
									variant: "destructive",
									onClick: () => handleDelete(i)
								}
							] })
						})
					]
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: addOpen,
				onClose: () => {
					setAddOpen(false);
					resetForm();
				},
				title: "إضافة فرع جديد",
				onSave: handleAdd,
				saveText: "إضافة",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "اسم الفرع *"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formName,
						onChange: (e) => setFormName(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "المدينة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formCity,
						onChange: (e) => setFormCity(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "المدير"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formMgr,
						onChange: (e) => setFormMgr(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الجوال"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formPhone,
						onChange: (e) => setFormPhone(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "البريد"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formEmail,
						onChange: (e) => setFormEmail(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formStatus,
						onChange: (e) => setFormStatus(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "نشط" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "موقوف" })]
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: editOpen,
				onClose: () => {
					setEditOpen(false);
					setEditIdx(null);
					resetForm();
				},
				title: "تعديل الفرع",
				onSave: handleSaveEdit,
				saveText: "حفظ التغييرات",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "اسم الفرع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formName,
						onChange: (e) => setFormName(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "المدينة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formCity,
						onChange: (e) => setFormCity(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "المدير"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formMgr,
						onChange: (e) => setFormMgr(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الجوال"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formPhone,
						onChange: (e) => setFormPhone(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "البريد"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formEmail,
						onChange: (e) => setFormEmail(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formStatus,
						onChange: (e) => setFormStatus(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "نشط" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "موقوف" })]
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmOpen,
				onClose: () => setConfirmOpen(false),
				onConfirm: () => {
					confirmAction();
					setConfirmOpen(false);
				},
				title: "تأكيد حذف الفرع",
				message: "هل أنت متأكد من حذف هذا الفرع؟",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			})
		]
	});
};
//#endregion
export { SplitComponent as component };
