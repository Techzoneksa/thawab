import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { B as Printer, T as SquarePen, Ut as CircleCheck, nt as MessageCircle, ot as MapPin, p as Upload, q as Phone, st as Mail } from "../_libs/lucide-react.mjs";
import { D as PrintStyle, E as PrintButton, N as showToast, O as SectionTitle, S as MobilePageHeader, a as Btn, h as EntityFormDrawer, i as Badge, m as EmptyState, n as AppShell, s as Card, w as MobileTabBar } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { r as getDonor } from "./donors-BTleOe7U.mjs";
import { t as Route } from "./donors._id-sb3qfshX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donors._id-yzxNDb78.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function tagTone(t) {
	return t === "ذهبي" ? "warning" : t === "فضي" ? "info" : "muted";
}
function Page() {
	const { id } = Route.useParams();
	const { data: donor, isLoading, error } = useQuery({
		queryKey: ["donor", id],
		queryFn: () => getDonor(id)
	});
	const [tab, setTab] = (0, import_react.useState)("نظرة عامة");
	const [mobileTab, setMobileTab] = (0, import_react.useState)("نظرة عامة");
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [notesValue, setNotesValue] = (0, import_react.useState)("");
	const [tasks, setTasks] = (0, import_react.useState)([
		{
			t: "إرسال رسالة شكر على التبرع الأخير",
			done: false
		},
		{
			t: "جدولة مكالمة شكر شخصية",
			done: true
		},
		{
			t: "تحديث بيانات المتبرع",
			done: false
		},
		{
			t: "إرسال تقرير ربع سنوي",
			done: false
		}
	]);
	const [attachments, setAttachments] = (0, import_react.useState)([{
		n: "بطاقة المتبرع.pdf",
		s: "1446/05"
	}, {
		n: "خطاب التكريم.pdf",
		s: "1445/09"
	}]);
	const tabs = [
		"نظرة عامة",
		"التبرعات",
		"الإيصالات",
		"المهام",
		"المرفقات",
		"ملاحظات"
	];
	const activeTab = typeof window !== "undefined" && window.innerWidth < 1024 ? mobileTab : tab;
	typeof window !== "undefined" && window.innerWidth;
	const toggleTask = (i) => {
		const d = [...tasks];
		d[i] = {
			...d[i],
			done: !d[i].done
		};
		setTasks(d);
		showToast(d[i].done ? "تم إكمال المهمة" : "تم إلغاء إكمال المهمة", "success");
	};
	const handleAddAttachment = () => {
		setAttachments([{
			n: "مرفق جديد.pdf",
			s: "الآن"
		}, ...attachments]);
		showToast("تم رفع المرفق بنجاح", "success");
	};
	const handleSaveNotes = () => {
		showToast("تم حفظ الملاحظات بنجاح", "success");
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المتبرعون",
			"..."
		],
		title: "...",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, {}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (error || !donor) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المتبرعون",
			"غير موجود"
		],
		title: "غير موجود",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/donors",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "outline",
				children: "العودة للمتبرعين"
			})
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "المتبرع غير موجود",
			description: "لم يتم العثور على المتبرع المطلوب",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/donors",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					children: "العودة للمتبرعين"
				})
			})
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
			breadcrumb: [
				"الرئيسية",
				"المتبرعون",
				donor.name
			],
			title: donor.name,
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, { label: "طباعة" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
					variant: "outline",
					onClick: () => showToast("فتح محادثة جديدة مع المتبرع...", "info"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { size: 15 }), "تواصل"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
					variant: "primary",
					onClick: () => setEditOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { size: 15 }), "تعديل"]
				})
			] }),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-4 gap-3 lg:gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4 lg:p-5 lg:col-span-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex lg:flex-col items-center lg:text-center gap-4 lg:gap-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-14 w-14 lg:h-20 lg:w-20 shrink-0 place-items-center rounded-full bg-gradient-to-br from-primary to-info text-white text-lg lg:text-2xl font-extrabold",
								children: donor.name[0]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right lg:text-center flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-bold text-base lg:text-lg",
										children: donor.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground font-mono",
										children: donor.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-1.5 flex gap-1.5 flex-wrap lg:justify-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												tone: "info",
												children: donor.type
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												tone: tagTone(donor.tag),
												children: donor.tag
											}),
											donor.recurring && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												tone: "success",
												children: "متكرر"
											})
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 lg:mt-5 space-y-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { size: 14 }),
										" ",
										donor.phone || "غير محدد"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { size: 14 }),
										" ",
										donor.email || "غير محدد"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 text-muted-foreground",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { size: 14 }),
										" ",
										donor.city || "غير محدد",
										"، المملكة العربية السعودية"
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 lg:mt-5 grid grid-cols-2 gap-3 border-t pt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: "إجمالي التبرعات"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums text-base lg:text-lg",
									children: fmtSAR(donor.totalDonations)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: "عدد العمليات"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold text-base lg:text-lg",
									children: donor.donationCount
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: "أول تبرع"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-semibold text-sm",
									children: donor.lastDonation || "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: "آخر تبرع"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-semibold text-sm",
									children: donor.lastDonation || "—"
								})] })
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-3 space-y-3 lg:space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "px-2 hidden lg:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap gap-1 border-b px-2",
								children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setTab(t),
									className: `px-4 py-3 text-sm font-medium border-b-2 ${tab === t ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`,
									children: t
								}, t))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, { title: donor.name }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:hidden",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTabBar, {
								tabs: tabs.slice(0, 4),
								active: mobileTab,
								onChange: setMobileTab
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-4 lg:p-5",
							children: [
								activeTab === "نظرة عامة" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-2 gap-3 lg:gap-4",
									children: [[
										{
											l: "تبرعات هذا العام",
											v: fmtSAR(donor.totalDonations)
										},
										{
											l: "متوسط التبرع",
											v: donor.donationCount > 0 ? fmtSAR(Math.round(donor.totalDonations / donor.donationCount)) : fmtSAR(0)
										},
										{
											l: "أعلى تبرع",
											v: fmtSAR(donor.totalDonations)
										},
										{
											l: "حملات مدعومة",
											v: "—"
										}
									].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg border p-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-muted-foreground",
											children: s.l
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold mt-1 tabular-nums text-base",
											children: s.v
										})]
									}, s.l)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "col-span-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { title: "مخطط التبرعات الشهرية" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex items-end gap-1 h-28 lg:h-32",
											children: [
												40,
												65,
												30,
												80,
												50,
												95,
												70,
												100,
												60,
												75,
												85,
												55
											].map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex-1 bg-gradient-to-t from-primary to-info/70 rounded-t",
												style: { height: `${h}%` }
											}, i))
										})]
									})]
								}) }),
								activeTab === "التبرعات" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
									title: "لا توجد تبرعات",
									description: "التبرعات المرتبطة بهذا المتبرع ستظهر هنا"
								}),
								activeTab === "الإيصالات" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
									title: "لا توجد إيصالات",
									description: "الإيصالات المرتبطة بهذا المتبرع ستظهر هنا"
								}),
								activeTab === "المهام" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [tasks.map((task, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex items-center justify-between rounded-lg border p-3 min-h-[44px]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-3 min-w-0 flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => toggleTask(i),
												className: `grid h-6 w-6 shrink-0 place-items-center rounded-lg border ${task.done ? "bg-success border-success text-white" : "bg-muted"}`,
												children: task.done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 14 })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "min-w-0 flex-1",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `font-semibold text-sm truncate ${task.done ? "line-through text-muted-foreground" : ""}`,
													children: task.t
												})
											})]
										})
									}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2 pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											className: "flex-1 rounded-lg border bg-background p-3 text-sm min-h-[44px]",
											placeholder: "أضف مهمة جديدة..."
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
											variant: "primary",
											onClick: () => showToast("تم إضافة المهمة بنجاح", "success"),
											children: "إضافة"
										})]
									})]
								}),
								activeTab === "المرفقات" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [attachments.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between rounded-lg border p-3 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-center gap-2 truncate",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
													size: 14,
													className: "shrink-0"
												}),
												" ",
												a.n
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-muted-foreground",
												children: a.s
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
												variant: "ghost",
												onClick: () => showToast(`جاري تجهيز ${a.n} للطباعة`, "info"),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { size: 12 })
											})]
										})]
									}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
										variant: "outline",
										className: "w-full mt-2",
										onClick: handleAddAttachment,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { size: 15 }), " رفع مرفق"]
									})]
								}),
								activeTab === "ملاحظات" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
										className: "w-full rounded-lg border bg-background p-3 text-sm min-h-[100px]",
										placeholder: "ملاحظات إضافية...",
										value: notesValue,
										onChange: (e) => setNotesValue(e.target.value)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "flex justify-end",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
											variant: "primary",
											onClick: handleSaveNotes,
											children: "حفظ الملاحظات"
										})
									})]
								})
							]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
			open: editOpen,
			onClose: () => setEditOpen(false),
			title: "تعديل بيانات المتبرع",
			onSave: () => {
				showToast("تم تحديث بيانات المتبرع بنجاح", "success");
				setEditOpen(false);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "الاسم"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					defaultValue: donor.name
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "الجوال"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					defaultValue: donor.phone || ""
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "البريد الإلكتروني"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					defaultValue: donor.email || ""
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "المدينة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					defaultValue: donor.city || ""
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "الوسم"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					defaultValue: donor.tag,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ذهبي" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "فضي" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "برونزي" })
					]
				})] })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintStyle, {})
	] });
}
//#endregion
export { Page as component };
