//#region node_modules/.nitro/vite/services/ssr/assets/assets-C0jGCeQN.js
var API_BASE = "/api/assets";
var ASSET_STATUSES = [
	"نشط",
	"تحت الصيانة",
	"منقول",
	"مستبعد",
	"مباع",
	"ملغي"
];
var ASSET_CONDITIONS = [
	"جيد",
	"متوسط",
	"يحتاج صيانة",
	"تالف"
];
var ASSET_DEPRECIATION_METHODS = ["قسط ثابت", "قسط متناقص"];
async function getFixedAssets(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.category && filters.category !== "الكل") params.set("category", filters.category);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب الأصول الثابتة");
	return res.json();
}
async function getFixedAsset(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات الأصل");
	return res.json();
}
async function createFixedAsset(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة الأصل");
	}
	return (await res.json()).item;
}
async function updateFixedAsset(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث الأصل");
	}
	return (await res.json()).item;
}
async function transferFixedAsset(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "transfer"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في نقل الأصل");
	}
	return (await res.json()).item;
}
async function maintainFixedAsset(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "maintain"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تسجيل صيانة الأصل");
	}
	return (await res.json()).item;
}
async function returnFromMaintenance(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "returnFromMaintenance"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إنهاء الصيانة");
	}
	return (await res.json()).item;
}
async function depreciateFixedAsset(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "depreciate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تسجيل الإهلاك");
	}
	return (await res.json()).item;
}
async function disposeFixedAsset(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "dispose"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في استبعاد الأصل");
	}
	return (await res.json()).item;
}
async function sellFixedAsset(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "sell"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في بيع الأصل");
	}
	return (await res.json()).item;
}
async function deleteFixedAsset(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف الأصل");
	}
}
//#endregion
export { deleteFixedAsset as a, getFixedAsset as c, returnFromMaintenance as d, sellFixedAsset as f, createFixedAsset as i, getFixedAssets as l, updateFixedAsset as m, ASSET_DEPRECIATION_METHODS as n, depreciateFixedAsset as o, transferFixedAsset as p, ASSET_STATUSES as r, disposeFixedAsset as s, ASSET_CONDITIONS as t, maintainFixedAsset as u };
