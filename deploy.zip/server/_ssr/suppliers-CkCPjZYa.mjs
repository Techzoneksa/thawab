//#region node_modules/.nitro/vite/services/ssr/assets/suppliers-CkCPjZYa.js
var API_BASE = "/api/procurement/suppliers";
var SUPPLIER_STATUSES = ["نشط", "موقوف"];
async function getSuppliers(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب الموردين");
	return res.json();
}
async function getSupplier(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات المورد");
	return res.json();
}
async function createSupplier(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة المورد");
	}
	return (await res.json()).item;
}
async function updateSupplier(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث المورد");
	}
	return (await res.json()).item;
}
async function activateSupplier(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "activate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تفعيل المورد");
	}
	return (await res.json()).item;
}
async function deactivateSupplier(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "deactivate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تعطيل المورد");
	}
	return (await res.json()).item;
}
async function deleteSupplier(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف المورد");
	}
}
//#endregion
export { deleteSupplier as a, updateSupplier as c, deactivateSupplier as i, activateSupplier as n, getSupplier as o, createSupplier as r, getSuppliers as s, SUPPLIER_STATUSES as t };
