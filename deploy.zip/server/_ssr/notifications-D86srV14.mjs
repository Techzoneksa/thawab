import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { U as Plus, Ut as CircleCheck, Yt as Check, an as BellRing, h as TriangleAlert, jt as Eye, vt as Info } from "../_libs/lucide-react.mjs";
import { N as showToast, S as MobilePageHeader, a as Btn, h as EntityFormDrawer, i as Badge, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { t as ALERTS } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-D86srV14.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [data, setData] = (0, import_react.useState)([
		...ALERTS,
		...ALERTS,
		...ALERTS
	].map((a) => ({
		...a,
		read: false
	})));
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [formText, setFormText] = (0, import_react.useState)("");
	const [formTone, setFormTone] = (0, import_react.useState)("info");
	const icon = {
		destructive: TriangleAlert,
		warning: BellRing,
		info: Info,
		success: CircleCheck
	};
	const handleAdd = () => {
		if (!formText.trim()) {
			showToast("يرجى إدخال نص التنبيه", "error");
			return;
		}
		setData([{
			tone: formTone,
			text: formText,
			time: "الآن",
			read: false
		}, ...data]);
		showToast("تم إضافة التنبيه بنجاح", "success");
		setFormOpen(false);
		setFormText("");
		setFormTone("info");
	};
	const markRead = (idx) => {
		const d = [...data];
		d[idx] = {
			...d[idx],
			read: true
		};
		setData(d);
		showToast("تم تحديد التنبيه كمقروء", "success");
	};
	const unread = data.filter((a) => !a.read).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: ["الرئيسية", "التنبيهات"],
		title: "مركز التنبيهات",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "outline",
			onClick: () => {
				setData(data.map((a) => ({
					...a,
					read: true
				})));
				showToast("تم تحديد الكل كمقروء", "success");
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 15 }), " تحديد الكل مقروء"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: () => {
				setFormText("");
				setFormTone("info");
				setFormOpen(true);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إضافة تنبيه"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "مركز التنبيهات",
				count: `${unread} غير مقروء`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y",
					children: data.map((a, i) => {
						const Icon = icon[a.tone] || Info;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: `flex items-start gap-3 p-4 hover:bg-muted/50 ${a.read ? "opacity-60" : ""}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `grid h-9 w-9 shrink-0 place-items-center rounded-lg ${a.tone === "destructive" ? "bg-destructive/10 text-destructive" : a.tone === "warning" ? "bg-warning/20 text-warning-foreground" : a.tone === "success" ? "bg-success/10 text-success" : "bg-info/10 text-info"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 16 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-semibold",
										children: a.text
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground mt-0.5",
										children: a.time
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-1",
									children: [!a.read && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: "warning",
										children: "جديد"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [{
										label: "عرض",
										icon: Eye,
										onClick: () => showToast(a.text, "info")
									}, ...!a.read ? [{
										label: "تحديد كمقروء",
										icon: Check,
										onClick: () => markRead(i)
									}] : []] })]
								})
							]
						}, i);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: formOpen,
				onClose: () => setFormOpen(false),
				title: "إضافة تنبيه",
				onSave: handleAdd,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "نص التنبيه"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[80px]",
					value: formText,
					onChange: (e) => setFormText(e.target.value)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "النوع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: formTone,
					onChange: (e) => setFormTone(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "info",
							children: "معلومات"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "warning",
							children: "تحذير"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "destructive",
							children: "حرج"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "success",
							children: "نجاح"
						})
					]
				})] })]
			})
		]
	});
};
//#endregion
export { SplitComponent as component };
