import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { J as Pencil, S as ThumbsDown, U as Plus, Ut as CircleCheck, jt as Eye, v as Trash2, w as Star, x as ThumbsUp } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, S as MobilePageHeader, a as Btn, c as ConfirmDialog, g as ExportButton, i as Badge, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { s as getSuppliers } from "./suppliers-CkCPjZYa.mjs";
import { c as getPurchaseRequests } from "./purchase-requests-CdC7mUrc.mjs";
import { i as deleteQuote, n as acceptQuote, o as getQuotes, s as rejectQuote } from "./quotes-8hMRJcKl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.quotes-C0MDzgJU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [requestFilter, setRequestFilter] = (0, import_react.useState)("الكل");
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [detailTarget, setDetailTarget] = (0, import_react.useState)(null);
	const { data, isLoading, error } = useQuery({
		queryKey: ["quotes", {
			search: searchQuery,
			status: statusFilter,
			requestId: requestFilter
		}],
		queryFn: () => getQuotes({
			search: searchQuery,
			status: statusFilter,
			requestId: requestFilter === "الكل" ? "" : requestFilter
		})
	});
	const { data: requestsData } = useQuery({
		queryKey: ["purchaseRequests-all"],
		queryFn: () => getPurchaseRequests({})
	});
	const { data: suppliersData } = useQuery({
		queryKey: ["suppliers-all"],
		queryFn: () => getSuppliers({})
	});
	const acceptMutation = useMutation({
		mutationFn: acceptQuote,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["quotes"] });
			showToast("تم قبول العرض وتحديده كفائز", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const rejectMutation = useMutation({
		mutationFn: rejectQuote,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["quotes"] });
			showToast("تم رفض عرض السعر", "info");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deleteQuote,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["quotes"] });
			showToast("تم حذف عرض السعر", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => {
		navigate({ to: "/procurement/quotes/new" });
	};
	const openEdit = (q) => {
		if (q.status !== "بانتظار") {
			showToast("لا يمكن تعديل عرض تم البت فيه", "error");
			return;
		}
		navigate({
			to: "/procurement/quotes/$id/edit",
			params: { id: q.id }
		});
	};
	const items = data?.items || [];
	const requests = requestsData?.items || [];
	suppliersData?.items;
	const groupedByRequest = items.reduce((acc, q) => {
		const key = q.requestId || "_none";
		if (!acc[key]) acc[key] = [];
		acc[key].push(q);
		return acc;
	}, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المشتريات",
			"عروض الأسعار"
		],
		title: "مقارنة عروض الأسعار",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
			data: items.map((q) => ({
				id: q.id,
				requestId: q.requestId || "",
				supplier: q.supplier,
				price: q.price,
				delivery: q.delivery,
				warranty: q.warranty,
				rating: q.rating,
				winner: q.winner ? "نعم" : "لا",
				status: q.status,
				validUntil: q.validUntil
			})),
			filename: "quotes.csv"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: openAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "إضافة عرض سعر"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "مقارنة عروض الأسعار",
				count: `${items.length} عرض`
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء جلب عروض الأسعار",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["quotes"] }),
					children: "إعادة المحاولة"
				})
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد عروض أسعار",
				description: "ابدأ بإضافة عروض الأسعار لمقارنتها واختيار الأفضل",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة عرض سعر"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-6",
				children: Object.entries(groupedByRequest).map(([reqId, group]) => {
					const request = requests.find((r) => r.id === reqId);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [request && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "p-4 mb-3 bg-primary/5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "طلب الشراء:"
								}),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-foreground",
									children: request.id
								}),
								" ·",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: request.subject }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted-foreground",
									children: [" · ", request.department]
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 lg:grid-cols-3 gap-4",
						children: group.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: `p-5 ${q.winner ? "ring-2 ring-success" : ""}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-bold truncate",
											children: q.supplier
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-1 mt-1",
											children: [[
												1,
												2,
												3,
												4,
												5
											].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
												size: 12,
												className: s <= q.rating ? "fill-warning text-warning" : "text-muted-foreground"
											}, s)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-xs text-muted-foreground",
												children: [
													"(",
													q.rating,
													"/5)"
												]
											})]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getQuoteActions(q, setDetailTarget, openEdit, acceptMutation, rejectMutation, setDeleteTarget) })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 mt-3",
									children: [q.winner && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
										tone: "success",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
											size: 11,
											className: "inline ms-1"
										}), "الموصى به"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: quoteStatusTone(q.status),
										children: q.status
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-3xl font-extrabold tabular-nums mt-3",
									children: fmtSAR(q.price)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
									className: "mt-4 space-y-2 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "مدة التسليم"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: q.delivery || "—" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "الضمان"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: q.warranty || "—" })]
										}),
										q.validUntil && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted-foreground",
												children: "صالح حتى"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: q.validUntil })]
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2 mt-4",
									children: [q.status === "بانتظار" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
										variant: q.winner ? "primary" : "outline",
										className: "flex-1 justify-center",
										onClick: () => acceptMutation.mutate({
											id: q.id,
											userId: user?.id,
											userName: user?.name
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsUp, { size: 14 }), "قبول"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
										variant: "outline",
										className: "flex-1 justify-center",
										onClick: () => rejectMutation.mutate({
											id: q.id,
											userId: user?.id,
											userName: user?.name
										}),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThumbsDown, { size: 14 }), "رفض"]
									})] }), q.status !== "بانتظار" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
										variant: "outline",
										className: "w-full justify-center",
										onClick: () => setDetailTarget(q),
										children: "عرض التفاصيل"
									})]
								})
							]
						}, q.id))
					})] }, reqId);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailTarget,
				onClose: () => setDetailTarget(null),
				title: `تفاصيل عرض السعر: ${detailTarget?.supplier || ""}`,
				onSave: () => setDetailTarget(null),
				saveText: "إغلاق",
				children: detailTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الحالة",
								value: detailTarget.status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الموصى به",
								value: detailTarget.winner ? "نعم" : "لا"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "السعر",
								value: fmtSAR(detailTarget.price)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "التقييم",
								value: `${detailTarget.rating} / 5`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "مدة التسليم",
								value: detailTarget.delivery || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الضمان",
								value: detailTarget.warranty || "—"
							}),
							detailTarget.validUntil && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "صالح حتى",
								value: detailTarget.validUntil
							})
						]
					}), detailTarget.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-semibold text-muted-foreground mb-1",
						children: "ملاحظات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm",
						children: detailTarget.notes
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: () => {
					if (deleteTarget) deleteMutation.mutate({
						id: deleteTarget.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "تأكيد الحذف",
				message: deleteTarget ? `هل تريد حذف عرض السعر من "${deleteTarget.supplier}"؟` : "",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			})
		]
	});
}
function quoteStatusTone(s) {
	if (s === "مقبول") return "success";
	if (s === "مرفوض") return "destructive";
	return "warning";
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-semibold",
			children: value
		})]
	});
}
function getQuoteActions(q, setDetailTarget, openEdit, acceptMutation, rejectMutation, setDeleteTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => setDetailTarget(q)
	}];
	if (q.status === "بانتظار") {
		actions.push({
			label: "تعديل",
			icon: Pencil,
			onClick: () => openEdit(q)
		});
		actions.push({
			label: "قبول",
			icon: ThumbsUp,
			onClick: () => acceptMutation.mutate({ id: q.id })
		});
		actions.push({
			label: "رفض",
			icon: ThumbsDown,
			onClick: () => rejectMutation.mutate({ id: q.id })
		});
	}
	actions.push({
		label: "حذف",
		icon: Trash2,
		variant: "destructive",
		onClick: () => setDeleteTarget(q)
	});
	return actions;
}
//#endregion
export { Page as component };
