import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assets._id.edit-4UdN5357.js
var $$splitComponentImporter = () => import("./assets._id.edit-B0gYM03y.mjs");
var Route = createFileRoute("/assets/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل أصل — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
