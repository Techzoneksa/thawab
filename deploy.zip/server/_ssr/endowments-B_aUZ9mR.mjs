import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { U as Plus, gt as Landmark, jt as Eye, v as Trash2 } from "../_libs/lucide-react.mjs";
import { N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, g as ExportButton, h as EntityFormDrawer, i as Badge, j as Td, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, l as ENDOWMENTS } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/endowments-B_aUZ9mR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [data, setData] = (0, import_react.useState)(ENDOWMENTS);
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [confirmIdx, setConfirmIdx] = (0, import_react.useState)(-1);
	const [formName, setFormName] = (0, import_react.useState)("");
	const [formType, setFormType] = (0, import_react.useState)("نقدي");
	const [formValue, setFormValue] = (0, import_react.useState)("");
	const nextId = () => `WQF-${String(data.length + 1).padStart(3, "0")}`;
	const handleSave = () => {
		if (!formName.trim()) {
			showToast("يرجى إدخال اسم الوقف", "error");
			return;
		}
		setData([{
			id: nextId(),
			name: formName,
			type: formType,
			value: Number(formValue) || 0,
			yearReturn: 0,
			status: "مستثمر"
		}, ...data]);
		showToast("تم إضافة الوقف بنجاح", "success");
		setFormOpen(false);
		setFormName("");
		setFormType("نقدي");
		setFormValue("");
	};
	const handleDelete = () => {
		setData(data.filter((_, i) => i !== confirmIdx));
		showToast("تم حذف الوقف", "success");
		setConfirmIdx(-1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
			breadcrumb: [
				"الرئيسية",
				"المنح والأوقاف",
				"الأوقاف"
			],
			title: "إدارة الأوقاف",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data,
				filename: "endowments.csv"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => {
					setFormName("");
					setFormType("نقدي");
					setFormValue("");
					setFormOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إضافة وقف"]
			})] }),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4",
				children: [
					{
						l: "إجمالي قيمة الأوقاف",
						v: fmtSAR(data.reduce((a, e) => a + e.value, 0))
					},
					{
						l: "عوائد متوقعة سنوياً",
						v: fmtSAR(data.reduce((a, e) => a + e.yearReturn, 0))
					},
					{
						l: "عدد الأوقاف",
						v: String(data.length)
					},
					{
						l: "نسبة العائد",
						v: data.length > 0 ? `${Math.round(data.reduce((a, e) => a + e.yearReturn, 0) / data.reduce((a, e) => a + e.value, 0) * 100)}%` : "0%"
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: s.l
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-lg font-extrabold mt-1 tabular-nums",
						children: s.v
					})]
				}, s.l))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "إدارة الأوقاف",
				count: `${data.length} وقف`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الرقم",
					"اسم الوقف",
					"النوع",
					"القيمة",
					"العائد السنوي",
					"الحالة",
					""
				],
				rows: data,
				renderRow: (w, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: w.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, {
						className: "font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, {
							size: 13,
							className: "inline ms-1 text-primary"
						}), w.name]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "info",
						children: w.type
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums font-bold",
						children: fmtSAR(w.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums text-success font-semibold",
						children: fmtSAR(w.yearReturn)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(w.status),
						children: w.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [{
						label: "عرض",
						icon: Eye,
						onClick: () => showToast(`${w.name} - ${fmtSAR(w.value)}`, "info")
					}, {
						label: "حذف",
						icon: Trash2,
						variant: "destructive",
						onClick: () => setConfirmIdx(idx)
					}] }) })
				] }),
				mobileCard: (w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(w.status),
								children: w.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "info",
								children: w.type
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, {
								size: 13,
								className: "inline ms-1 text-primary"
							}), w.name]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums font-bold",
								children: fmtSAR(w.value)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-success font-semibold text-sm",
								children: fmtSAR(w.yearReturn)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mt-1",
							children: "العائد السنوي"
						})
					]
				}, w.id)
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
			open: formOpen,
			onClose: () => setFormOpen(false),
			title: "إضافة وقف",
			onSave: handleSave,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "اسم الوقف"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: formName,
					onChange: (e) => setFormName(e.target.value),
					placeholder: "اسم الوقف"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "النوع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: formType,
					onChange: (e) => setFormType(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "نقدي" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "عقاري" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "أسهم" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "صندوق استثماري" })
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "القيمة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					type: "number",
					value: formValue,
					onChange: (e) => setFormValue(e.target.value)
				})] })
			]
		}),
		confirmIdx >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			open: true,
			onClose: () => setConfirmIdx(-1),
			onConfirm: handleDelete,
			title: "تأكيد الحذف",
			message: "هل أنت متأكد من حذف الوقف؟",
			confirmText: "حذف",
			variant: "destructive"
		})
	] });
};
//#endregion
export { SplitComponent as component };
