//#region node_modules/.nitro/vite/services/ssr/assets/inventory-items-mo3tbFC9.js
var API_BASE = "/api/inventory/items";
var ITEM_STATUSES = [
	"نشط",
	"موقوف",
	"مغلق"
];
var MOVEMENT_TYPES = [
	"استلام",
	"صرف",
	"تحويل",
	"تسوية",
	"جرد"
];
async function getInventoryItems(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.category && filters.category !== "الكل") params.set("category", filters.category);
	if (filters.warehouseId) params.set("warehouseId", filters.warehouseId);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب الأصناف");
	return res.json();
}
async function getInventoryItem(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات الصنف");
	return res.json();
}
async function createInventoryItem(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة الصنف");
	}
	return (await res.json()).item;
}
async function updateInventoryItem(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث الصنف");
	}
	return (await res.json()).item;
}
async function activateInventoryItem(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "activate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تفعيل الصنف");
	}
	return (await res.json()).item;
}
async function deactivateInventoryItem(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "deactivate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تعطيل الصنف");
	}
	return (await res.json()).item;
}
async function receiveInventoryItem(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "receive"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في استلام الصنف");
	}
	return (await res.json()).item;
}
async function issueInventoryItem(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "issue"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في صرف الصنف");
	}
	return (await res.json()).item;
}
async function adjustInventoryItem(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "adjust"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تسوية الصنف");
	}
	return (await res.json()).item;
}
async function transferInventoryItem(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "transfer"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحويل الصنف");
	}
	return (await res.json()).item;
}
async function deleteInventoryItem(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف الصنف");
	}
}
//#endregion
export { createInventoryItem as a, getInventoryItem as c, receiveInventoryItem as d, transferInventoryItem as f, adjustInventoryItem as i, getInventoryItems as l, MOVEMENT_TYPES as n, deactivateInventoryItem as o, updateInventoryItem as p, activateInventoryItem as r, deleteInventoryItem as s, ITEM_STATUSES as t, issueInventoryItem as u };
