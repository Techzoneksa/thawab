//#region node_modules/.nitro/vite/services/ssr/assets/accounts-i45ITZyC.js
var API_BASE = "/api/finance/accounts";
var ACCOUNT_TYPES = [
	"أصل",
	"التزام",
	"حقوق ملكية",
	"إيراد",
	"مصروف",
	"رئيسي",
	"تفصيلي"
];
var ACCOUNT_STATUSES = [
	"نشط",
	"موقوف",
	"مغلق"
];
async function getAccounts(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.type && filters.type !== "الكل") params.set("type", filters.type);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب الحسابات");
	return res.json();
}
async function getAccount(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات الحساب");
	return res.json();
}
async function createAccount(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة الحساب");
	}
	return (await res.json()).item;
}
async function updateAccount(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث الحساب");
	}
	return (await res.json()).item;
}
async function deleteAccount(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف الحساب");
	}
}
async function deactivateAccount(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "deactivate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إيقاف الحساب");
	}
	return (await res.json()).item;
}
async function activateAccount(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "activate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تفعيل الحساب");
	}
	return (await res.json()).item;
}
//#endregion
export { deactivateAccount as a, getAccounts as c, createAccount as i, updateAccount as l, ACCOUNT_TYPES as n, deleteAccount as o, activateAccount as r, getAccount as s, ACCOUNT_STATUSES as t };
