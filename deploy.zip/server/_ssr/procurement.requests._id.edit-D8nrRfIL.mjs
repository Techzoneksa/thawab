import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { I as RotateCcw, N as Send, Yt as Check, n as X, on as Ban, pn as Archive } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, P as statusTone, c as ConfirmDialog, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { t as getAuditEntries } from "./audit-DP6UgtXG.mjs";
import { d as submitPurchaseRequest, f as updatePurchaseRequest, i as cancelPurchaseRequest, l as rejectPurchaseRequest, o as deletePurchaseRequest, r as approvePurchaseRequest, s as getPurchaseRequest, t as REQUEST_PRIORITIES, u as returnPurchaseRequestToDraft } from "./purchase-requests-CdC7mUrc.mjs";
import { t as Route } from "./procurement.requests._id.edit-BZPrk1_u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.requests._id.edit-D8nrRfIL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DEPARTMENTS = [
	"إدارة المساعدات",
	"تقنية المعلومات",
	"إدارة المشاريع",
	"الإدارة المالية",
	"المشتريات"
];
function EditRequestPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const detailQuery = useQuery({
		queryKey: ["purchaseRequestDetail", id],
		queryFn: () => getPurchaseRequest(id)
	});
	const item = detailQuery.data?.item;
	const orderCount = detailQuery.data?.orderCount ?? 0;
	const [subject, setSubject] = (0, import_react.useState)("");
	const [department, setDepartment] = (0, import_react.useState)("");
	const [priority, setPriority] = (0, import_react.useState)("متوسطة");
	const [requester, setRequester] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [deliveryDate, setDeliveryDate] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [rejectReason, setRejectReason] = (0, import_react.useState)("");
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(null);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	if (item && !hydrated) {
		setSubject(item.subject);
		setDepartment(item.department);
		setPriority(item.priority || "متوسطة");
		setRequester(item.requester || "");
		setAmount(String(item.amount || 0));
		setDeliveryDate(item.deliveryDate || "");
		setNotes(item.notes || "");
		setHydrated(true);
	}
	const isEditable = !!item && ["مسودة", "مرفوض"].includes(item.status);
	const handleSave = async () => {
		if (!isEditable) {
			showToast("لا يمكن تعديل طلب في هذه الحالة. أعده إلى المسودة أولاً.", "error");
			return;
		}
		const errs = [];
		if (!subject.trim()) errs.push("موضوع الطلب مطلوب");
		if (!department.trim()) errs.push("الإدارة مطلوبة");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			await updatePurchaseRequest({
				id,
				subject: subject.trim(),
				department,
				priority,
				requester: requester || void 0,
				amount: parseFloat(amount) || 0,
				deliveryDate: deliveryDate || void 0,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequestDetail", id] });
			showToast("تم حفظ التعديلات", "success");
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const auditQuery = useQuery({
		queryKey: ["purchaseRequestAudit", id],
		queryFn: () => getAuditEntries({
			entityType: "طلب شراء",
			entityId: id,
			limit: 50
		}),
		enabled: !!item
	});
	const tabs = [
		{
			id: "basic",
			label: "بيانات الطلب",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات طلب الشراء",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "موضوع الطلب",
						required: true,
						error: errors[0],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: subject,
							onChange: (e) => setSubject(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الإدارة",
						required: true,
						error: errors[1],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: department,
							onChange: (e) => setDepartment(e.target.value),
							children: DEPARTMENTS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: d,
								children: d
							}, d))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الأولوية",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: priority,
							onChange: (e) => setPriority(e.target.value),
							children: REQUEST_PRIORITIES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: p,
								children: p
							}, p))
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "مقدم الطلب",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: requester,
							onChange: (e) => setRequester(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المبلغ التقديري",
						hint: "ر.س",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "تاريخ التوريد المطلوب",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: deliveryDate,
							onChange: (e) => setDeliveryDate(e.target.value),
							dir: "ltr"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value),
							rows: 4
						})
					})
				]
			})
		},
		{
			id: "summary",
			label: "ملخص",
			content: item ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ملخص الطلب",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الموضوع",
						value: item.subject
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الإدارة",
						value: item.department
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الأولوية",
						value: item.priority
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الحالة",
						value: item.status,
						tone: statusTone(item.status)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "المبلغ",
						value: fmtSAR(item.amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "تاريخ التوريد",
						value: item.deliveryDate || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "أوامر شراء مرتبطة",
						value: String(orderCount),
						tone: orderCount > 0 ? "success" : "default"
					})
				]
			}) : null
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			badge: auditQuery.data?.items.length,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "سجل العمليات",
				children: auditQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "جاري التحميل..."
				}) : (auditQuery.data?.items ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "لا توجد عمليات مسجلة على هذا الطلب."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: (auditQuery.data?.items ?? []).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border bg-card px-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-foreground",
									children: e.action
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground font-mono",
									children: e.timestamp?.slice(0, 16).replace("T", " ")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground mt-0.5",
								children: e.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-muted-foreground mt-0.5",
								children: ["المستخدم: ", e.userName || "—"]
							})
						]
					}, e.id))
				})
			})
		}
	];
	const submitMut = useMutation({
		mutationFn: () => submitPurchaseRequest({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequestDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequestAudit", id] });
			showToast("تم إرسال الطلب للموافقة", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const approveMut = useMutation({
		mutationFn: () => approvePurchaseRequest({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequestDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequestAudit", id] });
			showToast("تم اعتماد الطلب", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const rejectMut = useMutation({
		mutationFn: () => rejectPurchaseRequest({
			id,
			reason: rejectReason,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequestDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequestAudit", id] });
			showToast("تم رفض الطلب", "success");
			setConfirmAction(null);
			setRejectReason("");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const returnMut = useMutation({
		mutationFn: () => returnPurchaseRequestToDraft({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequestDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequestAudit", id] });
			showToast("تم إرجاع الطلب للمسودة", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const cancelMut = useMutation({
		mutationFn: () => cancelPurchaseRequest({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequestDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["purchaseRequestAudit", id] });
			showToast("تم إلغاء الطلب", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMut = useMutation({
		mutationFn: () => deletePurchaseRequest({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			showToast("تم حذف الطلب", "success");
			navigate({ to: "/procurement/requests" });
		},
		onError: (err) => showToast(err.message, "error")
	});
	if (detailQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "طلبات الشراء",
		breadcrumb: ["المشتريات", "طلبات الشراء"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "طلبات الشراء",
		breadcrumb: ["المشتريات", "طلبات الشراء"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-center py-12 text-muted-foreground",
			children: "الطلب غير موجود"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "طلبات الشراء",
		breadcrumb: [
			"المشتريات",
			"طلبات الشراء",
			"تعديل"
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
				breadcrumb: [
					{
						label: "المشتريات",
						to: "/procurement/requests"
					},
					{
						label: "طلبات الشراء",
						to: "/procurement/requests"
					},
					{ label: item.subject }
				],
				title: item.subject,
				subtitle: `${item.department} · ${fmtSAR(item.amount)}`,
				draftNumber: item.id,
				status: {
					label: item.status,
					tone: statusTone(item.status)
				},
				isReadOnly: !isEditable,
				readonlyReason: !isEditable ? `الطلب في حالة "${item.status}". أعده إلى المسودة أولاً لتعديله.` : void 0,
				tabs,
				defaultTab: "basic",
				loading: saving,
				validationErrors: errors,
				primaryLabel: "حفظ التعديلات",
				secondaryLabel: "حفظ وإغلاق",
				showSecondary: false,
				extraActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					item.status === "مسودة" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("submit"),
						className: "inline-flex items-center gap-1.5 rounded-lg border border-primary/40 bg-primary/10 px-3 py-2 text-sm font-medium text-primary hover:bg-primary/20 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { size: 15 }), " إرسال للموافقة"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("delete"),
						className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { size: 15 }), " حذف"]
					})] }),
					item.status === "بانتظار الموافقة" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("approve"),
						className: "inline-flex items-center gap-1.5 rounded-lg border border-success/40 bg-success/10 px-3 py-2 text-sm font-medium text-success hover:bg-success/20 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 15 }), " اعتماد"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("reject"),
						className: "inline-flex items-center gap-1.5 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/20 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 15 }), " رفض"]
					})] }),
					(item.status === "معتمد" || item.status === "مرفوض") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("return"),
						className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium hover:bg-muted transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 15 }), " إعادة للمسودة"]
					}),
					item.status !== "ملغي" && item.status !== "محول إلى أمر شراء" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("cancel"),
						className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { size: 15 }), " إلغاء"]
					}),
					item.status === "ملغي" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("delete"),
						className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { size: 15 }), " حذف نهائي"]
					})
				] }),
				onPrimary: handleSave,
				onCancel: () => navigate({ to: "/procurement/requests" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "submit",
				onClose: () => setConfirmAction(null),
				onConfirm: () => submitMut.mutate(),
				title: "إرسال للموافقة",
				message: `هل تريد إرسال الطلب "${item.subject}" للموافقة؟ لن تستطيع تعديله بعد ذلك حتى تتم الموافقة أو الرفض.`,
				confirmText: "إرسال",
				cancelText: "تراجع",
				loading: submitMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "approve",
				onClose: () => setConfirmAction(null),
				onConfirm: () => approveMut.mutate(),
				title: "اعتماد الطلب",
				message: `هل تريد اعتماد الطلب "${item.subject}"؟ بعد الاعتماد يمكنك تحويله إلى أمر شراء.`,
				confirmText: "اعتماد",
				cancelText: "تراجع",
				loading: approveMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "reject",
				onClose: () => {
					setConfirmAction(null);
					setRejectReason("");
				},
				onConfirm: () => rejectMut.mutate(),
				title: "رفض الطلب",
				message: `هل تريد رفض الطلب "${item.subject}"؟ سيتم تسجيل السبب في الملاحظات.`,
				confirmText: "تأكيد الرفض",
				cancelText: "تراجع",
				variant: "destructive",
				loading: rejectMut.isPending,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-1.5 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "سبب الرفض"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: rejectReason,
						onChange: (e) => setRejectReason(e.target.value),
						rows: 3,
						placeholder: "اذكر سبب الرفض...",
						className: "w-full rounded-lg border bg-background p-2.5 text-sm"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "return",
				onClose: () => setConfirmAction(null),
				onConfirm: () => returnMut.mutate(),
				title: "إعادة للمسودة",
				message: `هل تريد إعادة الطلب "${item.subject}" إلى المسودة؟`,
				confirmText: "إعادة للمسودة",
				cancelText: "تراجع",
				loading: returnMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "cancel",
				onClose: () => setConfirmAction(null),
				onConfirm: () => cancelMut.mutate(),
				title: "إلغاء الطلب",
				message: `هل تريد إلغاء الطلب "${item.subject}"؟ هذا الإجراء لا يمكن التراجع عنه إلا بإعادة الطلب إلى المسودة.`,
				confirmText: "إلغاء",
				cancelText: "تراجع",
				variant: "destructive",
				loading: cancelMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "delete",
				onClose: () => setConfirmAction(null),
				onConfirm: () => deleteMut.mutate(),
				title: "حذف الطلب",
				message: `هل تريد حذف الطلب "${item.subject}"؟ هذا الإجراء لا يمكن التراجع عنه.`,
				confirmText: "حذف",
				cancelText: "تراجع",
				variant: "destructive",
				loading: deleteMut.isPending
			})
		]
	});
}
//#endregion
export { EditRequestPage as component };
