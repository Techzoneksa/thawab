import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { I as useRouter, g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Slot, P as require_jsx_runtime, a as Overlay2, c as Title2, d as DialogContent, f as DialogDescription, h as DialogTitle, i as Description2, l as Dialog, m as DialogPortal, n as Cancel, o as Portal2, p as DialogOverlay, r as Content2, s as Root2, t as Action, u as DialogClose } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { $t as Calculator, At as FileChartColumnIncreasing, B as Printer, Ct as GitBranch, D as SlidersHorizontal, Dt as FileText, E as SquareCheckBig, Ft as DatabaseBackup, Jt as ChevronDown, K as PiggyBank, Kt as ChevronRight, L as Repeat, Nt as Ellipsis, O as ShoppingCart, Ot as FileSpreadsheet, P as Search, Pt as Download, Q as PackageSearch, Qt as CalendarDays, St as Globe, Tt as FolderKanban, Vt as Circle, W as Plug, Yt as Check, _t as KeyRound, at as Map, bt as HeartHandshake, ct as LogOut, dt as LoaderCircle, en as Building2, f as UserCog, g as TrendingUp, gt as Landmark, ht as Layers, i as Workflow, in as Bell, it as Megaphone, j as Settings, kt as FileSearch, l as Users, m as Truck, mt as LayoutDashboard, n as X, nn as Boxes, o as Warehouse, qt as ChevronLeft, rn as BookOpen, rt as Menu, s as Wallet, sn as BadgeDollarSign, tn as Briefcase, u as UsersRound, xt as HandHelping, z as ReceiptText, zt as ClipboardList } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { a as Label2, c as Root2$1, d as SubTrigger2, f as Trigger, i as ItemIndicator2, l as Separator2, n as Content2$1, o as Portal2$1, r as Item2, s as RadioItem2, t as CheckboxItem2, u as SubContent2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/actions-qTEe1ygX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var API = "/api/auth";
var SESSION_KEY = "session_token";
var AuthContext = (0, import_react.createContext)({
	user: null,
	token: null,
	isLoading: true,
	login: async () => {},
	logout: async () => {}
});
function AuthProvider({ children }) {
	useQueryClient();
	const [token, setToken] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return null;
		return localStorage.getItem(SESSION_KEY);
	});
	const { data: user, isLoading } = useQuery({
		queryKey: ["currentUser"],
		queryFn: async () => {
			if (!token) return null;
			return (await (await fetch(API, { headers: { "x-session-token": token } })).json()).user;
		},
		enabled: !!token
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value: {
			user: user || null,
			token,
			isLoading
		},
		children
	});
}
function useAuth() {
	return (0, import_react.useContext)(AuthContext);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var AI_ASSISTANT_ENABLED = false;
var NAV = [
	{
		label: "الرئيسية",
		items: [
			{
				to: "/",
				label: "لوحة المعلومات",
				icon: LayoutDashboard
			},
			{
				to: "/notifications",
				label: "التنبيهات",
				icon: Bell
			},
			{
				to: "/approvals",
				label: "الموافقات",
				icon: SquareCheckBig
			}
		]
	},
	{
		label: "المالية",
		items: [
			{
				to: "/finance/accounts",
				label: "دليل الحسابات",
				icon: BookOpen
			},
			{
				to: "/finance/journal",
				label: "قيود اليومية",
				icon: FileSpreadsheet
			},
			{
				to: "/finance/ledger",
				label: "دفتر الأستاذ",
				icon: Wallet
			},
			{
				to: "/finance/budgets",
				label: "الموازنات",
				icon: Calculator
			},
			{
				to: "/finance/cost-centers",
				label: "مراكز التكلفة",
				icon: PiggyBank
			},
			{
				to: "/finance/closing",
				label: "الإقفال المالي",
				icon: GitBranch
			},
			{
				to: "/finance/statements",
				label: "القوائم المالية",
				icon: FileChartColumnIncreasing
			}
		]
	},
	{
		label: "التبرعات والمتبرعون",
		items: [
			{
				to: "/donors",
				label: "المتبرعون",
				icon: HeartHandshake
			},
			{
				to: "/donations",
				label: "التبرعات",
				icon: Wallet
			},
			{
				to: "/receipts",
				label: "الإيصالات",
				icon: ReceiptText
			},
			{
				to: "/recurring",
				label: "التبرعات المتكررة",
				icon: Repeat
			},
			{
				to: "/campaigns",
				label: "الحملات",
				icon: Megaphone
			}
		]
	},
	{
		label: "المشاريع والمستفيدون",
		items: [
			{
				to: "/projects",
				label: "المشاريع والبرامج",
				icon: FolderKanban
			},
			{
				to: "/beneficiaries",
				label: "المستفيدون",
				icon: Users
			},
			{
				to: "/aid",
				label: "المساعدات",
				icon: HandHelping
			},
			{
				to: "/distribution",
				label: "تقارير التوزيع",
				icon: Map
			}
		]
	},
	{
		label: "المنح والأوقاف",
		items: [
			{
				to: "/grants",
				label: "المنح",
				icon: BadgeDollarSign
			},
			{
				to: "/donor-orgs",
				label: "الجهات المانحة",
				icon: Building2
			},
			{
				to: "/endowments",
				label: "الأوقاف",
				icon: Landmark
			},
			{
				to: "/endowment-returns",
				label: "عوائد الأوقاف",
				icon: TrendingUp
			}
		]
	},
	{
		label: "المشتريات والمخزون",
		items: [
			{
				to: "/procurement/requests",
				label: "طلبات الشراء",
				icon: ClipboardList
			},
			{
				to: "/procurement/quotes",
				label: "عروض الأسعار",
				icon: FileText
			},
			{
				to: "/procurement/orders",
				label: "أوامر الشراء",
				icon: ShoppingCart
			},
			{
				to: "/procurement/suppliers",
				label: "الموردون",
				icon: Truck
			},
			{
				to: "/inventory/warehouses",
				label: "المستودعات",
				icon: Warehouse
			},
			{
				to: "/inventory/items",
				label: "الأصناف",
				icon: Boxes
			},
			{
				to: "/inventory/stocktake",
				label: "الجرد",
				icon: PackageSearch
			}
		]
	},
	{
		label: "الموارد",
		items: [
			{
				to: "/assets",
				label: "الأصول الثابتة",
				icon: Layers
			},
			{
				to: "/hr",
				label: "الموارد البشرية",
				icon: Briefcase
			},
			{
				to: "/memberships",
				label: "العضويات",
				icon: UsersRound
			},
			{
				to: "/meetings",
				label: "الاجتماعات",
				icon: CalendarDays
			}
		]
	},
	{
		label: "التقارير والحوكمة",
		items: [
			{
				to: "/reports",
				label: "مركز التقارير",
				icon: FileChartColumnIncreasing
			},
			{
				to: "/audit",
				label: "سجل التدقيق",
				icon: FileSearch
			},
			{
				to: "/permissions",
				label: "الصلاحيات",
				icon: KeyRound
			},
			{
				to: "/workflows",
				label: "سير العمل",
				icon: Workflow
			}
		]
	},
	{
		label: "الإعدادات",
		items: [
			{
				to: "/settings/org",
				label: "إعدادات الجمعية",
				icon: Settings
			},
			{
				to: "/settings/branches",
				label: "الفروع",
				icon: GitBranch
			},
			{
				to: "/settings/users",
				label: "المستخدمون",
				icon: UserCog
			},
			{
				to: "/settings/integrations",
				label: "التكاملات",
				icon: Plug
			},
			{
				to: "/settings/backup",
				label: "النسخ الاحتياطي",
				icon: DatabaseBackup
			},
			{
				to: "/settings/system",
				label: "إعدادات النظام",
				icon: SlidersHorizontal
			}
		]
	}
];
var BOTTOM_NAV_ITEMS = [
	{
		to: "/",
		label: "الرئيسية",
		icon: LayoutDashboard
	},
	{
		to: "/donations",
		label: "التبرعات",
		icon: Wallet
	},
	{
		to: "/projects",
		label: "المشاريع",
		icon: FolderKanban
	},
	{
		to: "/approvals",
		label: "الموافقات",
		icon: SquareCheckBig
	},
	{
		to: "#more",
		label: "المزيد",
		icon: Ellipsis
	}
];
function useBodyScrollLock(locked) {
	(0, import_react.useEffect)(() => {
		if (!locked) return;
		const prev = document.body.style.overflow;
		const prevPadRight = document.body.style.paddingRight;
		const scrollbar = window.innerWidth - document.documentElement.clientWidth;
		document.body.style.overflow = "hidden";
		if (scrollbar > 0) document.body.style.paddingRight = `${scrollbar}px`;
		return () => {
			document.body.style.overflow = prev;
			document.body.style.paddingRight = prevPadRight;
		};
	}, [locked]);
}
function Sidebar({ open, onClose }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	useBodyScrollLock(open);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `fixed inset-0 z-30 bg-black/55 backdrop-blur-sm transition-opacity duration-200 lg:hidden ${open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"}`,
		onClick: onClose,
		"aria-hidden": "true"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		"aria-label": "القائمة الرئيسية",
		className: `fixed top-0 right-0 z-40 h-[100dvh] w-[85vw] max-w-[320px] shrink-0 bg-nav text-nav-foreground flex flex-col transition-transform duration-300 ease-out will-change-transform lg:sticky lg:top-0 lg:h-screen lg:w-72 lg:max-w-none lg:translate-x-0 lg:transition-none ${open ? "translate-x-0" : "translate-x-full lg:translate-x-0"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 px-5 py-5 border-b border-white/10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-primary to-info text-white font-extrabold",
						children: "ث"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-extrabold truncate",
							children: "ثواب"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] text-nav-muted truncate",
							children: "نظام إدارة الجمعيات الخيرية"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "grid h-11 w-11 place-items-center rounded-lg text-nav-muted hover:bg-white/10 active:bg-white/20 transition-colors lg:hidden",
					onClick: onClose,
					"aria-label": "إغلاق القائمة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 22 })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "flex-1 overflow-y-auto scrollbar-thin overscroll-contain px-3 py-4 space-y-5",
				children: NAV.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-3 pb-2 text-[11px] font-bold tracking-wide text-nav-muted uppercase",
					children: group.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-0.5",
					children: group.items.map((it) => {
						const active = pathname === it.to || it.to !== "/" && pathname.startsWith(it.to);
						const Icon = it.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: it.to,
							onClick: onClose,
							className: `flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors min-h-[44px] ${active ? "bg-nav-active text-white font-semibold shadow-sm" : "text-nav-foreground/90 hover:bg-nav-hover active:bg-white/10"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								size: 17,
								className: "shrink-0 opacity-90"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: it.label
							})]
						}) }, it.to);
					})
				})] }, group.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-white/10 p-4 safe-area-bottom",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserProfile, {})
			})
		]
	})] });
}
function UserProfile() {
	const { user, isLoading, logout } = useAuth();
	useRouter();
	const handleLogout = async () => {
		await logout();
		window.location.href = "/login";
	};
	const initials = user?.name ? user.name[0] : "؟";
	const roleLabel = user ? getRoleLabel(user.role) : "";
	const name = user?.name || (isLoading ? "..." : "مستخدم");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2 rounded-lg bg-white/5 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-9 w-9 shrink-0 place-items-center rounded-full bg-white/10 font-bold",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "animate-pulse",
					children: "…"
				}) : initials
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm font-semibold truncate",
					children: name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] text-nav-muted truncate",
					children: roleLabel || "—"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: handleLogout,
			className: "flex items-center justify-center gap-2 rounded-lg bg-white/10 hover:bg-white/20 active:bg-white/30 transition-colors px-3 py-2 text-sm font-semibold text-white min-h-[40px] w-full",
			title: "تسجيل الخروج",
			"aria-label": "تسجيل الخروج",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { size: 16 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "تسجيل الخروج" })]
		})]
	});
}
function getRoleLabel(role) {
	return {
		"مدير النظام": "مدير النظام",
		محاسب: "محاسب",
		مدير: "مدير",
		"موظف تبرعات": "موظف تبرعات",
		"منسق مشاريع": "منسق مشاريع",
		employee: "موظف",
		admin: "مدير",
		manager: "مدير"
	}[role] || role;
}
function Topbar({ onMenu, aiOpen, setAiOpen }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const pageTitle = pathname === "/" ? "لوحة المعلومات" : pathname === "/donations" ? "التبرعات" : pathname === "/projects" ? "المشاريع" : pathname === "/approvals" ? "الموافقات" : pathname === "/donors" ? "المتبرعون" : pathname === "/beneficiaries" ? "المستفيدون" : pathname === "/reports" ? "مركز التقارير" : pathname === "/notifications" ? "التنبيهات" : pathname.startsWith("/finance") ? "المالية" : pathname.startsWith("/procurement") ? "المشتريات" : pathname.startsWith("/inventory") ? "المخزون" : pathname.startsWith("/settings") ? "الإعدادات" : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "hidden lg:flex sticky top-0 z-20 items-center gap-3 border-b bg-surface/80 backdrop-blur px-4 lg:px-6 h-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "grid h-11 w-11 place-items-center rounded-lg text-foreground hover:bg-muted transition-colors",
				onClick: onMenu,
				"aria-label": "القائمة",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 22 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 max-w-xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 16,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						placeholder: "بحث ذكي عن متبرع، مستفيد، مشروع، قيد...",
						className: "w-full rounded-lg border bg-background py-2 pr-9 pl-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring min-h-[40px]"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden md:flex items-center gap-2 rounded-lg border bg-background px-3 py-2 text-xs text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { size: 14 }), " جمعية البر الخيرية · الفرع الرئيسي · 1446هـ"]
			}),
			AI_ASSISTANT_ENABLED,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "relative grid h-11 w-11 place-items-center rounded-lg border hover:bg-muted transition-colors",
				"aria-label": "إشعارات",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "absolute top-1 left-1 grid h-4 min-w-4 place-items-center rounded-full bg-destructive px-1 text-[10px] font-bold text-white",
					children: "7"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: onMenu,
				className: "flex items-center gap-2 rounded-lg border p-1.5 pr-2 hover:bg-muted transition-colors min-h-[40px]",
				"aria-label": "حسابي",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-7 w-7 place-items-center rounded-full bg-gradient-to-br from-primary to-info text-white text-[10px] font-bold",
					children: "س"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-medium text-muted-foreground hidden sm:inline",
					children: "سعد الغامدي"
				})]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "lg:hidden sticky top-0 z-20 flex items-center gap-1 border-b bg-surface/95 backdrop-blur px-2 h-14 safe-area-top",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onMenu,
				className: "grid h-11 w-11 place-items-center rounded-lg hover:bg-muted active:bg-muted/80 transition-colors shrink-0",
				"aria-label": "القائمة",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 22 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "flex-1 text-base font-bold truncate px-1 min-w-0",
				children: pageTitle || "ثواب"
			}),
			AI_ASSISTANT_ENABLED,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "relative grid h-11 w-11 place-items-center rounded-lg hover:bg-muted active:bg-muted/80 transition-colors shrink-0",
				"aria-label": "إشعارات",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { size: 20 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 left-2 h-2 w-2 rounded-full bg-destructive ring-2 ring-surface" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onMenu,
				className: "grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-primary to-info text-white text-xs font-bold shadow-sm active:scale-95 transition-transform",
				"aria-label": "حسابي",
				children: "س"
			})
		]
	})] });
}
function BottomNav({ onMore }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		"aria-label": "التنقل السفلي",
		className: "fixed bottom-0 right-0 left-0 z-30 border-t bg-surface/95 backdrop-blur-xl safe-area-bottom lg:hidden shadow-[0_-1px_3px_rgba(0,0,0,0.05)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center justify-around h-16",
			children: BOTTOM_NAV_ITEMS.map((item) => {
				const active = item.to === "/" ? pathname === "/" : item.to !== "#more" && pathname.startsWith(item.to);
				const Icon = item.icon;
				if (item.to === "#more") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: onMore,
					className: "flex flex-col items-center justify-center gap-0.5 h-full min-w-[64px] px-1 rounded-lg text-muted-foreground hover:text-foreground active:bg-muted/50 transition-colors active:scale-95",
					"aria-label": "القائمة الكاملة",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						size: 22,
						className: active ? "text-primary" : ""
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-semibold leading-none",
						children: item.label
					})]
				}, item.label);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					className: `flex flex-col items-center justify-center gap-0.5 h-full min-w-[64px] px-1 rounded-lg transition-colors active:bg-muted/50 active:scale-95 ${active ? "text-primary font-semibold" : "text-muted-foreground hover:text-foreground"}`,
					"aria-label": item.label,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 22 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] font-semibold leading-none",
						children: item.label
					})]
				}, item.label);
			})
		})
	});
}
function AppShell({ children, title, breadcrumb, actions }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [aiOpen, setAiOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-[100dvh] flex w-full max-w-full bg-background mobile-container",
		dir: "rtl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {
				open,
				onClose: () => setOpen(false)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 flex flex-col min-w-0 max-w-full pb-[calc(4rem+env(safe-area-inset-bottom,0px))] lg:pb-0 overflow-x-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Topbar, {
						onMenu: () => setOpen(true),
						aiOpen,
						setAiOpen
					}),
					(title || breadcrumb || actions) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-b bg-surface px-3 sm:px-4 lg:px-8 py-3 lg:py-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-end justify-between gap-2 lg:gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [breadcrumb && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
									className: "flex items-center gap-1 text-xs text-muted-foreground mb-0.5 overflow-x-auto no-scrollbar",
									children: breadcrumb.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1 whitespace-nowrap shrink-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate max-w-[80px] sm:max-w-none",
											children: b
										}), i < breadcrumb.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
											size: 12,
											className: "shrink-0"
										})]
									}, i))
								}), title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "text-lg sm:text-xl lg:text-2xl font-extrabold tracking-tight truncate",
									children: title
								})]
							}), actions && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap items-center gap-2 shrink-0",
								children: actions
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
						className: "flex-1 px-3 sm:px-4 lg:px-8 py-4 lg:py-6 overflow-x-hidden max-w-full",
						children
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
						className: "hidden lg:flex border-t bg-surface px-6 py-3 text-[11px] text-muted-foreground flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "© 1446هـ — ثواب. مستضاف داخل المملكة العربية السعودية." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "نظام خاص لإدارة الجمعيات والجهات الخيرية" })]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, { onMore: () => setOpen(true) }),
			AI_ASSISTANT_ENABLED
		]
	});
}
function Badge({ tone = "muted", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold ${{
			muted: "bg-muted text-muted-foreground",
			success: "bg-success/15 text-success",
			warning: "bg-warning/20 text-warning-foreground",
			destructive: "bg-destructive/15 text-destructive",
			info: "bg-info/15 text-info",
			primary: "bg-primary/10 text-primary"
		}[tone]}`,
		children
	});
}
function statusTone(status) {
	status.toLowerCase();
	if ([
		"مكتمل",
		"معتمد",
		"مرحّل",
		"متصل",
		"نشط",
		"نشطة",
		"مكتملة",
		"تشغيل",
		"مستحق",
		"مستثمر",
		"جاهز"
	].some((k) => status.includes(k))) return "success";
	if ([
		"بانتظار",
		"قيد",
		"صيانة",
		"إجازة",
		"مجدول",
		"بانتظار التفعيل"
	].some((k) => status.includes(k))) return "warning";
	if ([
		"مرفوض",
		"موقوف",
		"متأخر"
	].some((k) => status.includes(k))) return "destructive";
	if ([
		"تم التحويل",
		"وقف",
		"منعقد"
	].some((k) => status.includes(k))) return "info";
	return "muted";
}
function Card({ children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `rounded-xl border bg-card shadow-card ${className}`,
		children
	});
}
function SectionTitle({ title, hint, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-end justify-between gap-3 mb-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-base font-bold truncate",
				children: title
			}), hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground truncate",
				children: hint
			})]
		}), action]
	});
}
function Btn({ children, variant = "default", className = "", ...rest }) {
	const map = {
		default: "bg-background border hover:bg-muted",
		primary: "bg-primary text-primary-foreground hover:opacity-90",
		ghost: "hover:bg-muted",
		outline: "border hover:bg-muted"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		...rest,
		className: `inline-flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors min-h-[36px] ${map[variant]} ${className}`,
		children
	});
}
function FilterBar({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap items-center gap-2 rounded-xl border bg-card p-3 shadow-card mb-4",
		children
	});
}
function Select({ label, options, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-muted-foreground whitespace-nowrap",
			children: [label, ":"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				className: "appearance-none rounded-lg border bg-background pr-3 pl-7 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring min-h-[36px]",
				value,
				onChange,
				children: options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: o }, o))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
				size: 14,
				className: "absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none text-muted-foreground"
			})]
		})]
	});
}
function Table({ columns, rows, renderRow }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-xl border bg-card shadow-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "min-w-full text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "bg-muted/60 text-right",
				children: columns.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "px-4 py-3 font-semibold text-muted-foreground whitespace-nowrap",
					children: c
				}, c))
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "border-t hover:bg-muted/40 transition-colors",
				children: renderRow(r, i)
			}, i)) })]
		})
	});
}
function Td({ children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
		className: `px-4 py-3 whitespace-nowrap ${className}`,
		children
	});
}
function MobileTable({ columns, rows, renderRow, mobileCard }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "hidden lg:block",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
			columns,
			rows,
			renderRow
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "lg:hidden space-y-3",
		children: rows.map((r, i) => mobileCard(r, i))
	})] });
}
function MobileKPIGrid({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-6 gap-3 lg:gap-4 mb-4",
		children
	});
}
function MobileFilterDrawer({ open, onClose, children }) {
	useBodyScrollLock(open);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `fixed inset-0 z-[55] bg-black/55 backdrop-blur-sm transition-opacity duration-200 lg:hidden ${open ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"}`,
		onClick: onClose,
		"aria-hidden": "true"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "التصفية",
		className: `fixed bottom-0 right-0 left-0 z-[60] bg-surface rounded-t-2xl border shadow-elevated transition-transform duration-300 ease-out lg:hidden pb-safe will-change-transform ${open ? "translate-y-0" : "translate-y-full"}`,
		style: { maxHeight: "85dvh" },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between px-5 pt-4 pb-3 border-b sticky top-0 bg-surface rounded-t-2xl safe-area-top",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-bold text-base",
				children: "تصفية"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onClose,
				"aria-label": "إغلاق",
				className: "grid h-11 w-11 place-items-center rounded-lg text-muted-foreground hover:bg-muted active:bg-muted/80 transition-colors",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 22 })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "overflow-y-auto overscroll-contain p-5 space-y-4",
			style: { maxHeight: "calc(85dvh - 64px)" },
			children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onClose,
				className: "w-full rounded-lg bg-primary text-primary-foreground py-3 font-semibold text-sm min-h-[48px] hover:opacity-90 active:opacity-80 transition-opacity",
				children: "تطبيق التصفية"
			})]
		})]
	})] });
}
function MobileActionChips({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "lg:hidden flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 -mx-1 px-1",
		children: items.map((item) => {
			const Icon = item.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: item.onClick,
				className: "flex items-center gap-1.5 rounded-full border bg-card px-4 py-2 text-xs font-semibold whitespace-nowrap hover:bg-muted active:bg-muted/80 transition-colors shrink-0 min-h-[36px]",
				children: [Icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 14 }), item.label]
			}, item.label);
		})
	});
}
function MobileActionRow({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "lg:hidden flex items-center gap-2 overflow-x-auto no-scrollbar pb-1",
		children
	});
}
function MobileSearchInput({ placeholder = "بحث...", value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex-1 min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
			size: 16,
			className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "w-full rounded-xl border bg-background py-2.5 pr-9 pl-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring min-h-[44px]",
			placeholder,
			value,
			onChange
		})]
	});
}
function MobilePageHeader({ title, count, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "lg:hidden flex items-center justify-between mb-3 gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-base font-bold truncate",
				children: title
			}), count && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground truncate",
				children: count
			})]
		}), action]
	});
}
function MobileTabBar({ tabs, active, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1 overflow-x-auto no-scrollbar pb-2 -mx-1 px-1 flex-nowrap",
		children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => onChange(t),
			className: `whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-colors min-h-[36px] shrink-0 ${t === active ? "bg-primary text-primary-foreground shadow-sm" : "bg-muted text-muted-foreground hover:bg-muted/80"}`,
			children: t
		}, t))
	});
}
var AlertDialog = Root2;
var AlertDialogPortal = Portal2;
var AlertDialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay2, {
	className: cn("fixed inset-0 z-50 bg-black/80 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
AlertDialogOverlay.displayName = Overlay2.displayName;
var AlertDialogContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props
})] }));
AlertDialogContent.displayName = Content2.displayName;
var AlertDialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
AlertDialogHeader.displayName = "AlertDialogHeader";
var AlertDialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
AlertDialogFooter.displayName = "AlertDialogFooter";
var AlertDialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Title2, {
	ref,
	className: cn("text-lg font-semibold", className),
	...props
}));
AlertDialogTitle.displayName = Title2.displayName;
var AlertDialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Description2, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
AlertDialogDescription.displayName = Description2.displayName;
var AlertDialogAction = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Action, {
	ref,
	className: cn(buttonVariants(), className),
	...props
}));
AlertDialogAction.displayName = Action.displayName;
var AlertDialogCancel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cancel, {
	ref,
	className: cn(buttonVariants({ variant: "outline" }), "mt-2 sm:mt-0", className),
	...props
}));
AlertDialogCancel.displayName = Cancel.displayName;
var Sheet = Dialog;
var SheetClose = DialogClose;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, showClose = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [showClose && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute end-4 top-4 grid h-11 w-11 place-items-center rounded-lg opacity-90 ring-offset-background cursor-pointer transition-colors hover:bg-muted focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
var DropdownMenu = Root2$1;
var DropdownMenuTrigger = Trigger;
var DropdownMenuSubTrigger = import_react.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SubTrigger2, {
	ref,
	className: cn("flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", inset && "pl-8", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "ml-auto" })]
}));
DropdownMenuSubTrigger.displayName = SubTrigger2.displayName;
var DropdownMenuSubContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubContent2, {
	ref,
	className: cn("z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}));
DropdownMenuSubContent.displayName = SubContent2.displayName;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2$1, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2$1, {
	ref,
	sideOffset,
	className: cn("z-50 max-h-[var(--radix-dropdown-menu-content-available-height)] min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md", "data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-dropdown-menu-content-transform-origin)", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2$1.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 [&>svg]:size-4 [&>svg]:shrink-0", inset && "pl-8", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuCheckboxItem = import_react.forwardRef(({ className, children, checked, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CheckboxItem2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	checked,
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" }) })
	}), children]
}));
DropdownMenuCheckboxItem.displayName = CheckboxItem2.displayName;
var DropdownMenuRadioItem = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RadioItem2, {
	ref,
	className: cn("relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex h-3.5 w-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-2 w-2 fill-current" }) })
	}), children]
}));
DropdownMenuRadioItem.displayName = RadioItem2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-2 py-1.5 text-sm font-semibold", inset && "pl-8", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-muted", className),
	...props
}));
DropdownMenuSeparator.displayName = Separator2.displayName;
var DropdownMenuShortcut = ({ className, ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("ml-auto text-xs tracking-widest opacity-60", className),
		...props
	});
};
DropdownMenuShortcut.displayName = "DropdownMenuShortcut";
function useIsMobile(breakpoint = 1024) {
	const [isMobile, setIsMobile] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia(`(max-width: ${breakpoint - 1}px)`);
		setIsMobile(mq.matches);
		const handler = (e) => setIsMobile(e.matches);
		mq.addEventListener("change", handler);
		return () => mq.removeEventListener("change", handler);
	}, [breakpoint]);
	return isMobile;
}
function showToast(message, type = "info") {
	if (type === "success") toast.success(message);
	else if (type === "error") toast.error(message);
	else toast.info(message);
}
function ConfirmDialog({ open, onClose, onConfirm, title = "تأكيد الإجراء", message = "هل أنت متأكد من هذا الإجراء؟", confirmText = "تأكيد", cancelText = "إلغاء", variant = "default" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open,
		onOpenChange: (o) => {
			if (!o) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: message })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: cancelText }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
			onClick: onConfirm,
			className: variant === "destructive" ? buttonVariants({ variant: "destructive" }) : void 0,
			children: confirmText
		})] })] })
	});
}
function EntityFormDrawer({ open, onClose, title, children, onSave, saveText = "حفظ", loading = false }) {
	const isMobile = useIsMobile();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open,
		onOpenChange: (o) => {
			if (!o) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			side: isMobile ? "bottom" : "right",
			showClose: false,
			className: cn("flex flex-col p-0 gap-0", isMobile ? "max-h-[90dvh] rounded-t-2xl pb-safe [&_[data-radix-dialog-content]]:rounded-t-2xl" : "w-full max-w-xl start-0"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, {
					className: "flex flex-row items-center justify-between border-b px-4 sm:px-5 py-3 sm:py-4 shrink-0 relative safe-area-top",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, {
						className: "text-base truncate",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetClose, {
						className: "grid h-11 w-11 place-items-center rounded-lg text-muted-foreground hover:bg-muted active:bg-muted/80 transition-colors shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 22 })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 overflow-y-auto px-5 py-4 space-y-4",
					children
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetFooter, {
					className: "flex-row items-center gap-2 border-t px-5 py-4 shrink-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "outline",
						onClick: onClose,
						disabled: loading,
						children: "إلغاء"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
						variant: "primary",
						onClick: onSave,
						disabled: loading,
						children: [loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							size: 16,
							className: "animate-spin"
						}), saveText]
					})]
				})
			]
		})
	});
}
function ActionMenu({ actions }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "inline-flex items-center justify-center h-8 w-8 rounded-lg border hover:bg-muted transition-colors",
			"aria-label": "الإجراءات",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { size: 16 })
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, {
		align: "end",
		children: actions.map((action) => {
			const Icon = action.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				onClick: action.onClick,
				className: cn(action.variant === "destructive" && "text-destructive focus:text-destructive"),
				children: [Icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 16 }), action.label]
			}, action.label);
		})
	})] });
}
function generateCSV(data) {
	if (!data.length) return "";
	const headers = Object.keys(data[0]);
	const rows = data.map((row) => headers.map((h) => {
		const val = row[h];
		const str = val == null ? "" : String(val);
		if (str.includes(",") || str.includes("\"") || str.includes("\n")) return `"${str.replace(/"/g, "\"\"")}"`;
		return str;
	}).join(","));
	return [headers.join(","), ...rows].join("\r\n");
}
function ExportButton({ data, filename = "export.csv", label = "تصدير CSV" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
		variant: "outline",
		onClick: (0, import_react.useCallback)(() => {
			const csv = generateCSV(data);
			const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8;bom" });
			const url = URL.createObjectURL(blob);
			const a = document.createElement("a");
			a.href = url;
			a.download = filename;
			document.body.appendChild(a);
			a.click();
			document.body.removeChild(a);
			URL.revokeObjectURL(url);
			showToast("تم تصدير الملف بنجاح", "success");
		}, [data, filename]),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 15 }), label]
	});
}
function PrintButton({ label = "طباعة", onPrint, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
		variant: "outline",
		onClick: (0, import_react.useCallback)(() => {
			onPrint?.();
			window.print();
			showToast("تم تجهيز الملف للطباعة", "info");
		}, [onPrint]),
		className,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { size: 15 }), label]
	});
}
function EmptyState({ title = "لا توجد نتائج مطابقة", description = "حاول تعديل معايير البحث أو التصفية", icon, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center justify-center py-16 px-4 text-center",
		children: [
			icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 text-muted-foreground",
				children: icon
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 grid h-16 w-16 place-items-center rounded-2xl bg-muted text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
					xmlns: "http://www.w3.org/2000/svg",
					width: "28",
					height: "28",
					viewBox: "0 0 24 24",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "2",
					strokeLinecap: "round",
					strokeLinejoin: "round",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "11",
						cy: "11",
						r: "8"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m21 21-4.3-4.3" })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-lg font-bold mb-1",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground max-w-xs",
				children: description
			}),
			action && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: action
			})
		]
	});
}
function PrintStyle() {
	(0, import_react.useEffect)(() => {
		const style = document.createElement("style");
		style.id = "erp-print-style";
		style.textContent = `
      @media print {
        body {
          direction: rtl !important;
          font-family: system-ui, -apple-system, sans-serif !important;
          padding: 0 !important;
          margin: 0 !important;
          color: #000 !important;
          background: #fff !important;
        }
        .no-print { display: none !important; }
        nav, header, footer:not(.print-footer), .sidebar,
        .fixed, .sticky:not(.print-sticky) { display: none !important; }
        @page { margin: 1.5cm; }
        * { box-shadow: none !important; text-shadow: none !important; }
        .print-header {
          display: flex !important;
          justify-content: space-between !important;
          align-items: center !important;
          border-bottom: 2px solid #000 !important;
          padding-bottom: 8px !important;
          margin-bottom: 16px !important;
        }
        .print-header .org-name {
          font-size: 18px !important;
          font-weight: 800 !important;
        }
        .print-header .doc-meta {
          font-size: 11px !important;
          text-align: left !important;
          direction: ltr !important;
        }
        .print-footer {
          display: flex !important;
          justify-content: space-between !important;
          border-top: 1px solid #ccc !important;
          padding-top: 8px !important;
          margin-top: 24px !important;
          font-size: 10px !important;
          color: #666 !important;
        }
      }
    `;
		document.head.appendChild(style);
		return () => {
			const el = document.getElementById("erp-print-style");
			if (el) el.remove();
		};
	}, []);
	return null;
}
//#endregion
export { Table as A, MobileSearchInput as C, PrintStyle as D, PrintButton as E, useAuth as F, cn as M, showToast as N, SectionTitle as O, statusTone as P, MobilePageHeader as S, MobileTable as T, FilterBar as _, Btn as a, MobileFilterDrawer as b, ConfirmDialog as c, DropdownMenuItem as d, DropdownMenuSeparator as f, ExportButton as g, EntityFormDrawer as h, Badge as i, Td as j, Select as k, DropdownMenu as l, EmptyState as m, AppShell as n, Button as o, DropdownMenuTrigger as p, AuthProvider as r, Card as s, ActionMenu as t, DropdownMenuContent as u, MobileActionChips as v, MobileTabBar as w, MobileKPIGrid as x, MobileActionRow as y };
