import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/beneficiaries._id-BFV4YTRB.js
var $$splitComponentImporter = () => import("./beneficiaries._id-DygqQXrG.mjs");
var Route = createFileRoute("/beneficiaries/$id")({
	head: () => ({ meta: [{ title: "ملف المستفيد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
