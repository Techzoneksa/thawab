import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Dt as FileText, T as SquarePen, U as Plus, Xt as ChartColumn, Zt as Calendar, jt as Eye, tn as Briefcase, v as Trash2 } from "../_libs/lucide-react.mjs";
import { N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, g as ExportButton, h as EntityFormDrawer, i as Badge, j as Td, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, c as EMPLOYEES } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hr-B12ZJnm7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [data, setData] = (0, import_react.useState)(EMPLOYEES.map((e) => ({
		...e,
		phone: "05xxxxxxxx"
	})));
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [editIdx, setEditIdx] = (0, import_react.useState)(-1);
	const [confirmIdx, setConfirmIdx] = (0, import_react.useState)(-1);
	const [formName, setFormName] = (0, import_react.useState)("");
	const [formDept, setFormDept] = (0, import_react.useState)("");
	const [formTitle, setFormTitle] = (0, import_react.useState)("");
	const [formSalary, setFormSalary] = (0, import_react.useState)("");
	const nextId = () => `EMP-${String(data.length + 1).padStart(3, "0")}`;
	const handleSave = () => {
		if (!formName.trim()) {
			showToast("يرجى إدخال اسم الموظف", "error");
			return;
		}
		if (editIdx >= 0) {
			const d = [...data];
			d[editIdx] = {
				...d[editIdx],
				name: formName,
				dept: formDept,
				title: formTitle,
				salary: Number(formSalary) || 0
			};
			setData(d);
			showToast("تم تعديل الموظف بنجاح", "success");
		} else {
			setData([{
				id: nextId(),
				name: formName,
				dept: formDept || "غير محدد",
				title: formTitle,
				salary: Number(formSalary) || 0,
				joined: (/* @__PURE__ */ new Date()).toLocaleDateString("ar-SA"),
				status: "نشط",
				phone: "05xxxxxxxx"
			}, ...data]);
			showToast("تم إضافة الموظف بنجاح", "success");
		}
		setFormOpen(false);
	};
	const handleDelete = () => {
		setData(data.filter((_, i) => i !== confirmIdx));
		showToast("تم حذف الموظف", "success");
		setConfirmIdx(-1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
			breadcrumb: [
				"الرئيسية",
				"الموارد",
				"الموارد البشرية"
			],
			title: "الموارد البشرية",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data,
				filename: "employees.csv"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => {
					setEditIdx(-1);
					setFormName("");
					setFormDept("");
					setFormTitle("");
					setFormSalary("");
					setFormOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إضافة موظف"]
			})] }),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 lg:grid-cols-4 gap-3 mb-3 lg:mb-4",
					children: [
						{
							l: "إجمالي الموظفين",
							v: String(data.length),
							i: Briefcase
						},
						{
							l: "في إجازة",
							v: String(data.filter((e) => e.status === "إجازة").length),
							i: Calendar
						},
						{
							l: "إجمالي الرواتب الشهرية",
							v: fmtSAR(data.reduce((a, e) => a + e.salary, 0)),
							i: FileText
						},
						{
							l: "متوسط الراتب",
							v: fmtSAR(Math.round(data.reduce((a, e) => a + e.salary, 0) / data.length) || 0),
							i: ChartColumn
						}
					].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-9 w-9 lg:h-10 lg:w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.i, { size: 16 })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground truncate",
								children: s.l
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base lg:text-lg font-extrabold tabular-nums truncate",
								children: s.v
							})]
						})]
					}, s.l))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
					title: "الموظفون",
					count: `${data.length} موظف`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
					columns: [
						"الرقم",
						"الموظف",
						"الإدارة",
						"المسمى الوظيفي",
						"الراتب",
						"تاريخ التعيين",
						"الحالة",
						""
					],
					rows: data,
					renderRow: (e, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "font-mono text-xs",
							children: e.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "font-semibold",
							children: e.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: e.dept }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "text-muted-foreground",
							children: e.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "tabular-nums font-bold",
							children: fmtSAR(e.salary)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, {
							className: "text-muted-foreground",
							children: [e.joined, "هـ"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: statusTone(e.status),
							children: e.status
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
							{
								label: "عرض",
								icon: Eye,
								onClick: () => showToast(`${e.name} - ${e.title}`, "info")
							},
							{
								label: "تعديل",
								icon: SquarePen,
								onClick: () => {
									setEditIdx(idx);
									setFormName(e.name);
									setFormDept(e.dept);
									setFormTitle(e.title);
									setFormSalary(String(e.salary));
									setFormOpen(true);
								}
							},
							{
								label: "حذف",
								icon: Trash2,
								variant: "destructive",
								onClick: () => setConfirmIdx(idx)
							}
						] }) })
					] }),
					mobileCard: (e, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border bg-card shadow-card p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary/10 text-primary font-bold text-sm",
									children: e.name.split(" ")[0]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "min-w-0 flex-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-sm font-bold truncate",
												children: e.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-muted-foreground truncate",
												children: e.title
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											tone: statusTone(e.status),
											children: e.status
										})]
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid grid-cols-2 gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-muted/50 p-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "الإدارة: "
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: e.dept
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-muted/50 p-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "الراتب: "
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold tabular-nums",
										children: fmtSAR(e.salary)
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center justify-between text-xs text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono",
									children: e.id
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"تعيين: ",
									e.joined,
									"هـ"
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 pt-2 border-t flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg border py-2 text-xs font-semibold min-h-[36px]",
									onClick: () => showToast(`الملف الوظيفي لـ ${e.name}`, "info"),
									children: "عرض الملف الوظيفي"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg border py-2 text-xs font-semibold min-h-[36px]",
									onClick: () => {
										setEditIdx(idx);
										setFormName(e.name);
										setFormDept(e.dept);
										setFormTitle(e.title);
										setFormSalary(String(e.salary));
										setFormOpen(true);
									},
									children: "تعديل"
								})]
							})
						]
					}, e.id)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
			open: formOpen,
			onClose: () => setFormOpen(false),
			title: editIdx >= 0 ? "تعديل موظف" : "إضافة موظف",
			onSave: handleSave,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "الاسم"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: formName,
					onChange: (e) => setFormName(e.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "الإدارة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: formDept,
					onChange: (e) => setFormDept(e.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "المسمى الوظيفي"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: formTitle,
					onChange: (e) => setFormTitle(e.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "الراتب"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					type: "number",
					value: formSalary,
					onChange: (e) => setFormSalary(e.target.value)
				})] })
			]
		}),
		confirmIdx >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			open: true,
			onClose: () => setConfirmIdx(-1),
			onConfirm: handleDelete,
			title: "تأكيد الحذف",
			message: "هل أنت متأكد من حذف الموظف؟",
			confirmText: "حذف",
			variant: "destructive"
		})
	] });
};
//#endregion
export { SplitComponent as component };
