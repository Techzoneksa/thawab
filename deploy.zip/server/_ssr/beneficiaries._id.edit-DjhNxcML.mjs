import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, y as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, P as statusTone, i as Badge, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { n as MARITAL_STATUSES, p as updateBeneficiary, s as getBeneficiary, t as ELIGIBILITY_STATUSES } from "./beneficiaries-aRDRq8QX.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/beneficiaries._id.edit-DjhNxcML.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditBeneficiaryPage() {
	const { id } = useParams({ from: "/beneficiaries/$id/edit" });
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: beneficiary, isLoading } = useQuery({
		queryKey: ["beneficiary", id],
		queryFn: () => getBeneficiary(id),
		enabled: !!id
	});
	const [name, setName] = (0, import_react.useState)("");
	const [fileNumber, setFileNumber] = (0, import_react.useState)("");
	const [idNumber, setIdNumber] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("أسرة");
	const [status, setStatus] = (0, import_react.useState)("جديد");
	const [familyMembers, setFamilyMembers] = (0, import_react.useState)("1");
	const [monthlyIncome, setMonthlyIncome] = (0, import_react.useState)("0");
	const [maritalStatus, setMaritalStatus] = (0, import_react.useState)("أعزب");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (beneficiary) {
			setName(beneficiary.name || "");
			setFileNumber(beneficiary.fileNumber || "");
			setIdNumber(beneficiary.idNumber || "");
			setPhone(beneficiary.phone || "");
			setCity(beneficiary.city || "");
			setAddress(beneficiary.address || "");
			setCategory(beneficiary.category || "أسرة");
			setStatus(beneficiary.status || "جديد");
			setFamilyMembers(String(beneficiary.familyMembers || 1));
			setMonthlyIncome(String(beneficiary.monthlyIncome || 0));
			setMaritalStatus(beneficiary.maritalStatus || "أعزب");
			setNotes(beneficiary.notes || "");
		}
	}, [beneficiary]);
	const updateMutation = useMutation({
		mutationFn: (data) => updateBeneficiary({
			id,
			...data
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["beneficiary", id] });
			queryClient.invalidateQueries({ queryKey: ["beneficiaries"] });
			showToast("تم تحديث المستفيد بنجاح", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleSave = async (andClose) => {
		setSaving(true);
		try {
			await updateMutation.mutateAsync({
				name,
				fileNumber,
				idNumber,
				phone,
				city,
				address,
				category,
				status,
				familyMembers: parseInt(familyMembers) || 1,
				monthlyIncome: parseFloat(monthlyIncome) || 0,
				maritalStatus,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			if (andClose) navigate({ to: "/beneficiaries" });
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المستفيدون",
		breadcrumb: ["المستفيدون", "تحميل..."],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!beneficiary) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المستفيدون",
		breadcrumb: ["المستفيدون"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center py-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-base font-bold mb-2",
				children: "المستفيد غير موجود"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => navigate({ to: "/beneficiaries" }),
				className: "text-primary hover:underline text-sm",
				children: "العودة إلى المستفيدين"
			})]
		})
	});
	const aidHistory = beneficiary.aidHistory || [];
	const tabs = [
		{
			id: "personal",
			label: "البيانات الشخصية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات المستفيد",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الاسم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "رقم الملف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: fileNumber,
							onChange: (e) => setFileNumber(e.target.value),
							dir: "ltr",
							className: "font-mono"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "رقم الهوية",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: idNumber,
							onChange: (e) => setIdNumber(e.target.value),
							dir: "ltr",
							className: "font-mono"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "رقم الجوال",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: phone,
							onChange: (e) => setPhone(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المدينة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: city,
							onChange: (e) => setCity(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "العنوان",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: address,
							onChange: (e) => setAddress(e.target.value)
						})
					})] })
				]
			})
		},
		{
			id: "family",
			label: "بيانات الأسرة",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "الحالة الأسرية والمالية",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الحالة الاجتماعية",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
						value: maritalStatus,
						onChange: (e) => setMaritalStatus(e.target.value),
						children: MARITAL_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "عدد أفراد الأسرة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						min: "1",
						value: familyMembers,
						onChange: (e) => setFamilyMembers(e.target.value),
						dir: "ltr",
						className: "font-mono tabular-nums"
					})
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الدخل الشهري (ر.س)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						step: "0.01",
						value: monthlyIncome,
						onChange: (e) => setMonthlyIncome(e.target.value),
						dir: "ltr",
						className: "font-mono tabular-nums"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "فئة المستفيد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
						value: category,
						onChange: (e) => setCategory(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "أسرة",
								children: "أسرة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "يتيم",
								children: "يتيم"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "أرملة",
								children: "أرملة"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "مطلق",
								children: "مطلق"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "معاق",
								children: "معاق"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "طالب",
								children: "طالب"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "أخرى",
								children: "أخرى"
							})
						]
					})
				})] })]
			})
		},
		{
			id: "eligibility",
			label: "الأهلية والحالة",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "حالة الأهلية",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "حالة الأهلية",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
						value: status,
						onChange: (e) => setStatus(e.target.value),
						children: ELIGIBILITY_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))
					})
				})
			})
		},
		{
			id: "aid",
			label: "تاريخ المساعدات",
			badge: aidHistory.length || void 0,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "المساعدات السابقة",
				children: aidHistory.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "لم يتلقَ هذا المستفيد أي مساعدات بعد."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: aidHistory.slice(0, 20).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border bg-background p-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-muted-foreground",
									children: a.id
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(a.status),
									children: a.status
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold",
									children: a.type
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold tabular-nums",
									children: fmtSAR(a.amount)
								})]
							}),
							a.date && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: a.date
							})
						]
					}, a.id))
				})
			})
		},
		{
			id: "summary",
			label: "الملخص",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "إحصاءات المستفيد",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "إجمالي المساعدات",
							value: fmtSAR(beneficiary.totalAid ?? 0),
							tone: "success"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "عدد المساعدات",
							value: fmtNum(beneficiary.aidCount ?? 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "مساعدات قيد الانتظار",
							value: fmtNum(beneficiary.pendingAidCount ?? 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "آخر مساعدة",
							value: beneficiary.lastAidDate || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ التسجيل",
							value: beneficiary.createdAt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "أنشأ بواسطة",
							value: beneficiary.createdBy || "—"
						})
					]
				})
			})
		},
		{
			id: "notes",
			label: "الملاحظات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "ملاحظات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 6
					})
				})
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المستفيدون",
		breadcrumb: ["المستفيدون", beneficiary.name],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [{
				label: "المستفيدون",
				to: "/beneficiaries"
			}, { label: beneficiary.name }],
			title: beneficiary.name,
			subtitle: `${beneficiary.category} · ${beneficiary.city || "—"} · ${fmtNum(parseInt(familyMembers) || 0)} أفراد`,
			draftNumber: beneficiary.fileNumber || beneficiary.id,
			status: {
				label: beneficiary.status,
				tone: statusTone(beneficiary.status)
			},
			tabs,
			defaultTab: "personal",
			loading: saving || updateMutation.isPending,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/beneficiaries" })
		})
	});
}
//#endregion
export { EditBeneficiaryPage as component };
