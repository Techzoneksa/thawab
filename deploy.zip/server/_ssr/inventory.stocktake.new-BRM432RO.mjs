import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { U as Plus, v as Trash2 } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { s as getWarehouses } from "./warehouses-sU_fp7nA.mjs";
import { l as getInventoryItems } from "./inventory-items-mo3tbFC9.mjs";
import { i as createStocktake } from "./stocktake-CPsewedU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.stocktake.new-BRM432RO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function newLine(key, itemId = "", systemQuantity = 0) {
	return {
		key,
		itemId,
		systemQuantity,
		countedQuantity: systemQuantity,
		notes: ""
	};
}
function NewStocktakePage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const warehouses = (useQuery({
		queryKey: ["warehouses-simple"],
		queryFn: () => getWarehouses({ limit: 1e3 })
	}).data?.items || []).filter((w) => w.status === "نشط");
	const items = useQuery({
		queryKey: ["inventoryItems-simple"],
		queryFn: () => getInventoryItems({ limit: 1e3 })
	}).data?.items ?? [];
	const [name, setName] = (0, import_react.useState)(`جرد ${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}`);
	const [warehouseId, setWarehouseId] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [notes, setNotes] = (0, import_react.useState)("");
	const [lines, setLines] = (0, import_react.useState)([newLine("l1")]);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const stats = (0, import_react.useMemo)(() => {
		let sys = 0;
		let cnt = 0;
		let diff = 0;
		for (const l of lines) {
			if (!l.itemId) continue;
			sys += l.systemQuantity;
			cnt += l.countedQuantity;
			diff += l.countedQuantity - l.systemQuantity;
		}
		return {
			sys,
			cnt,
			diff,
			count: lines.filter((l) => l.itemId).length
		};
	}, [lines]);
	const addLine = () => setLines([...lines, newLine(`l${Date.now()}`)]);
	const removeLine = (key) => setLines(lines.filter((l) => l.key !== key));
	const updateLine = (key, patch) => setLines(lines.map((l) => l.key === key ? {
		...l,
		...patch
	} : l));
	const handleSave = async (andClose) => {
		const errs = [];
		if (!name.trim()) errs.push("اسم الجرد مطلوب");
		const validLines = lines.filter((l) => l.itemId);
		if (validLines.length === 0) errs.push("أضف صنفًا واحدًا على الأقل");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			const created = await createStocktake({
				name: name.trim(),
				warehouseId: warehouseId || void 0,
				date,
				notes: notes || void 0,
				lines: validLines.map((l) => ({
					itemId: l.itemId,
					countedQuantity: l.countedQuantity,
					notes: l.notes || void 0
				})),
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["stocktakes"] });
			showToast(`تم إنشاء الجرد`, "success");
			if (andClose) navigate({ to: "/inventory/stocktake" });
			else navigate({
				to: "/inventory/stocktake/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const tabs = [
		{
			id: "basic",
			label: "بيانات الجرد",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات الجرد",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم الجرد",
						required: true,
						error: errors[0],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "مثال: جرد المستودع الرئيسي لشهر شعبان"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المستودع",
						hint: "اختياري",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: warehouseId,
							onChange: (e) => setWarehouseId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— كل المستودعات —"
							}), warehouses.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: w.id,
								children: w.name
							}, w.id))]
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "تاريخ الجرد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value),
							dir: "ltr"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value),
							rows: 3
						})
					})
				]
			})
		},
		{
			id: "lines",
			label: "بنود الجرد",
			badge: stats.count,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بنود الجرد",
				children: [errors[1] && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-destructive/10 border border-destructive/30 px-3 py-2 text-xs text-destructive",
					children: ["⚠ ", errors[1]]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border bg-card overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "min-w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-muted/60 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-10",
										children: "#"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground min-w-[180px]",
										children: "الصنف"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-28",
										children: "الكمية النظامية"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-28",
										children: "الكمية الفعلية"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-20",
										children: "الفرق"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground",
										children: "ملاحظات"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-3 py-2 font-semibold text-muted-foreground w-10" })
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.map((l, i) => {
								const diff = l.countedQuantity - l.systemQuantity;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-1.5 text-muted-foreground tabular-nums",
											children: i + 1
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-1.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: l.itemId,
												onChange: (e) => {
													const sys = items.find((x) => x.id === e.target.value)?.quantity || 0;
													updateLine(l.key, {
														itemId: e.target.value,
														systemQuantity: sys,
														countedQuantity: sys
													});
												},
												className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm min-h-[36px]",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "",
													children: "— اختر —"
												}), items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: it.id,
													children: it.name
												}, it.id))]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-1.5 tabular-nums font-mono text-muted-foreground",
											children: l.systemQuantity
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-1.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												step: "0.01",
												value: l.countedQuantity || "",
												onChange: (e) => updateLine(l.key, { countedQuantity: parseFloat(e.target.value) || 0 }),
												dir: "ltr",
												className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm font-mono tabular-nums min-h-[36px]"
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: `px-3 py-1.5 tabular-nums font-bold ${diff === 0 ? "text-muted-foreground" : diff > 0 ? "text-success" : "text-destructive"}`,
											children: diff > 0 ? `+${diff}` : diff
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-1.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												value: l.notes,
												onChange: (e) => updateLine(l.key, { notes: e.target.value }),
												className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm min-h-[36px]",
												placeholder: "ملاحظات..."
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-1.5",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => removeLine(l.key),
												disabled: lines.length <= 1,
												className: "grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive disabled:opacity-30 disabled:cursor-not-allowed transition-colors",
												title: "حذف السطر",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 14 })
											})
										})
									]
								}, l.key);
							}) })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t bg-muted/30 px-3 py-3 flex items-center justify-between gap-3 flex-wrap",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: addLine,
							className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-1.5 text-xs font-semibold hover:bg-muted transition-colors min-h-[36px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " إضافة بند"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs flex items-center gap-3 flex-wrap",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["الأصناف: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: stats.count })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["نظامي: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "tabular-nums",
									children: stats.sys
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["فعلي: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "tabular-nums",
									children: stats.cnt
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: stats.diff === 0 ? "" : stats.diff > 0 ? "text-success font-bold" : "text-destructive font-bold",
									children: [
										"فرق:",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "tabular-nums",
											children: stats.diff > 0 ? `+${stats.diff}` : stats.diff
										})
									]
								})
							]
						})]
					})]
				})]
			})
		},
		{
			id: "summary",
			label: "ملخص",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ملخص الجرد",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "اسم الجرد",
						value: name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "التاريخ",
						value: date
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "المستودع",
						value: warehouses.find((w) => w.id === warehouseId)?.name || "كل المستودعات"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "عدد الأصناف",
						value: String(stats.count)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "إجمالي النظامي",
						value: String(stats.sys)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "إجمالي الفعلي",
						value: String(stats.cnt)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "إجمالي الفرق",
						value: stats.diff > 0 ? `+${stats.diff}` : String(stats.diff),
						tone: stats.diff === 0 ? "success" : stats.diff > 0 ? "success" : "destructive"
					})
				]
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الجرد",
		breadcrumb: [
			"المخزون",
			"الجرد",
			"جديد"
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المخزون",
					to: "/inventory/items"
				},
				{
					label: "الجرد",
					to: "/inventory/stocktake"
				},
				{ label: "جرد جديد" }
			],
			title: "جرد جديد",
			subtitle: `${name} · ${stats.count} صنف`,
			draftNumber: "مسودة جديدة",
			status: {
				label: "مسودة",
				tone: "muted"
			},
			tabs,
			defaultTab: "basic",
			loading: saving,
			validationErrors: errors,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/inventory/stocktake" })
		})
	});
}
//#endregion
export { NewStocktakePage as component };
