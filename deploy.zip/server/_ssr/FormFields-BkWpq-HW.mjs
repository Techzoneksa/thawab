import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { F as Save, dt as LoaderCircle, h as TriangleAlert, lt as Lock, n as X, qt as ChevronLeft } from "../_libs/lucide-react.mjs";
import { M as cn } from "./actions-qTEe1ygX.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/FormFields-BkWpq-HW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = Content.displayName;
var TONE = {
	muted: "bg-muted text-muted-foreground",
	success: "bg-success/15 text-success",
	warning: "bg-warning/20 text-warning-foreground",
	destructive: "bg-destructive/15 text-destructive",
	info: "bg-info/15 text-info",
	primary: "bg-primary/10 text-primary"
};
function EnterpriseFormLayout({ breadcrumb, title, subtitle, draftNumber, status, isReadOnly = false, readonlyReason, validationErrors = [], loading = false, tabs, defaultTab, primaryLabel = "حفظ", secondaryLabel = "حفظ وإغلاق", showSecondary = true, extraActions, onPrimary, onSecondary, onCancel, children }) {
	const activeTab = defaultTab ?? tabs[0]?.id;
	const canEdit = !isReadOnly && !loading;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col min-h-[calc(100dvh-7rem)] -mx-3 sm:-mx-4 lg:-mx-8 -mt-4 lg:-mt-6 bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-14 lg:top-16 z-20 bg-surface/95 backdrop-blur border-b shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-3 sm:px-4 lg:px-8 pt-3 pb-2",
					children: [breadcrumb && breadcrumb.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex items-center gap-1 text-xs text-muted-foreground mb-2 overflow-x-auto no-scrollbar",
						children: breadcrumb.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1 whitespace-nowrap shrink-0",
							children: [b.to ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: b.to,
								className: "hover:text-foreground hover:underline font-medium",
								children: b.label
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: b.label }), i < breadcrumb.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
								size: 12,
								className: "shrink-0 opacity-50"
							})]
						}, i))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 flex-wrap",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-lg sm:text-xl lg:text-2xl font-extrabold tracking-tight truncate",
										children: title
									}),
									draftNumber && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-md whitespace-nowrap",
										children: draftNumber
									}),
									status && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-[11px] font-semibold", TONE[status.tone]),
										children: status.label
									}),
									isReadOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-semibold bg-muted text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { size: 11 }), "للقراءة فقط"]
									})
								]
							}), subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs sm:text-sm text-muted-foreground mt-1 truncate",
								children: subtitle
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden lg:flex items-center gap-2 shrink-0",
							children: [
								extraActions,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: onCancel,
									disabled: loading,
									className: "inline-flex items-center justify-center gap-2 rounded-lg border bg-background px-3 py-2 text-sm font-medium hover:bg-muted transition-colors min-h-[40px] disabled:opacity-50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 15 }), "إلغاء"]
								}),
								showSecondary && onSecondary && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: onSecondary,
									disabled: !canEdit,
									className: "inline-flex items-center justify-center gap-2 rounded-lg border bg-background px-3 py-2 text-sm font-medium hover:bg-muted transition-colors min-h-[40px] disabled:opacity-50 disabled:cursor-not-allowed",
									children: [loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
										size: 15,
										className: "animate-spin"
									}), secondaryLabel]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: onPrimary,
									disabled: !canEdit,
									className: "inline-flex items-center justify-center gap-2 rounded-lg bg-primary text-primary-foreground px-4 py-2 text-sm font-semibold hover:opacity-90 transition-opacity min-h-[40px] disabled:opacity-50 disabled:cursor-not-allowed shadow-sm",
									children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
										size: 15,
										className: "animate-spin"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { size: 15 }), primaryLabel]
								})
							]
						})]
					})]
				}), tabs.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-3 sm:px-4 lg:px-8 border-t bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
						value: activeTab,
						className: "w-full",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, {
							className: "h-auto p-0 bg-transparent rounded-none justify-start gap-0 overflow-x-auto no-scrollbar -mx-1",
							children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
								value: t.id,
								disabled: isReadOnly && t.id !== activeTab,
								className: cn("rounded-none border-b-2 border-transparent px-3 sm:px-4 py-2.5 text-sm font-medium whitespace-nowrap shrink-0", "data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:text-primary data-[state=active]:shadow-none", "hover:text-foreground transition-colors"),
								children: [t.label, t.badge != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ms-2 inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full bg-muted text-[10px] font-bold text-muted-foreground",
									children: t.badge
								})]
							}, t.id))
						})
					})
				})]
			}),
			isReadOnly && readonlyReason && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 sm:mx-4 lg:mx-8 mt-3 lg:mt-4 rounded-lg border border-warning/30 bg-warning/10 px-3 sm:px-4 py-2.5 flex items-start gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					size: 16,
					className: "text-warning shrink-0 mt-0.5"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-semibold text-warning-foreground",
						children: "السجل في وضع القراءة فقط"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground mt-0.5",
						children: readonlyReason
					})]
				})]
			}),
			validationErrors.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-3 sm:mx-4 lg:mx-8 mt-3 lg:mt-4 rounded-lg border border-destructive/30 bg-destructive/10 px-3 sm:px-4 py-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-2 text-sm font-semibold text-destructive",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
						size: 16,
						className: "shrink-0 mt-0.5"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "لا يمكن الحفظ — يرجى تصحيح الأخطاء التالية:" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "ms-7 mt-1 space-y-0.5 text-xs text-destructive",
					children: validationErrors.map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", e] }, i))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 px-3 sm:px-4 lg:px-8 py-4 lg:py-6 overflow-x-hidden",
				children: [tabs.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
					value: activeTab,
					className: "w-full",
					children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
						value: t.id,
						className: "mt-0 focus-visible:outline-none",
						children: t.content
					}, t.id))
				}) : tabs[0]?.content, children]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden fixed bottom-16 left-0 right-0 z-30 border-t bg-surface/95 backdrop-blur-xl shadow-[0_-2px_8px_rgba(0,0,0,0.08)] safe-area-bottom",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 px-3 py-2.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onCancel,
							disabled: loading,
							className: "flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg border bg-background py-2.5 text-sm font-medium min-h-[44px] disabled:opacity-50 active:bg-muted transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 15 }), "إلغاء"]
						}),
						showSecondary && onSecondary && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onSecondary,
							disabled: !canEdit,
							className: "flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg border bg-background py-2.5 text-sm font-medium min-h-[44px] disabled:opacity-50 disabled:cursor-not-allowed active:bg-muted transition-colors",
							children: secondaryLabel
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: onPrimary,
							disabled: !canEdit,
							className: "flex-[1.5] inline-flex items-center justify-center gap-1.5 rounded-lg bg-primary text-primary-foreground py-2.5 text-sm font-semibold min-h-[44px] disabled:opacity-50 disabled:cursor-not-allowed shadow-sm active:opacity-80 transition-opacity",
							children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								size: 15,
								className: "animate-spin"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { size: 15 }), primaryLabel]
						})
					]
				})
			})
		]
	});
}
function FormField({ label, required, error, hint, className, children, htmlFor }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("space-y-1.5", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				htmlFor,
				className: "flex items-center gap-1 text-xs font-semibold text-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }),
					required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-destructive",
						children: "*"
					}),
					hint && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground font-normal ms-1",
						children: [
							"(",
							hint,
							")"
						]
					})
				]
			}),
			children,
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-destructive font-medium flex items-start gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "leading-none mt-0.5",
					children: "⚠"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: error })]
			})
		]
	});
}
var baseInputClass = "w-full rounded-lg border bg-background px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring min-h-[40px] placeholder:text-muted-foreground/60 disabled:opacity-60 disabled:cursor-not-allowed";
var FormInput = (0, import_react.forwardRef)(function FormInput({ className, invalid, ...rest }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref,
		className: cn(baseInputClass, invalid && "border-destructive focus:ring-destructive/30", className),
		...rest
	});
});
var FormTextarea = (0, import_react.forwardRef)(function FormTextarea({ className, invalid, rows = 3, ...rest }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		ref,
		rows,
		className: cn(baseInputClass, "min-h-[80px] py-2 resize-y", invalid && "border-destructive focus:ring-destructive/30", className),
		...rest
	});
});
var FormSelect = (0, import_react.forwardRef)(function FormSelect({ className, invalid, children, ...rest }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		ref,
		className: cn(baseInputClass, "appearance-none bg-no-repeat bg-[length:14px] bg-[left_0.65rem_center]", invalid && "border-destructive focus:ring-destructive/30", className),
		style: {
			backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E\")",
			paddingLeft: "2rem"
		},
		...rest,
		children
	});
});
function FormSegmented({ value, options, onChange, disabled, className, ariaLabel }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "radiogroup",
		"aria-label": ariaLabel,
		className: cn("inline-flex w-full rounded-lg border bg-muted/40 p-1 gap-1", disabled && "opacity-60 cursor-not-allowed", className),
		children: options.map((opt) => {
			const active = opt.value === value;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				role: "radio",
				"aria-checked": active,
				disabled,
				onClick: () => onChange(opt.value),
				className: cn("flex-1 inline-flex items-center justify-center rounded-md px-2 py-2 text-xs sm:text-sm font-semibold transition-colors min-h-[36px]", active ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground hover:bg-background/50", disabled && "cursor-not-allowed"),
				children: opt.label
			}, opt.value);
		})
	});
}
function FormSection({ title, description, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("rounded-xl border bg-card shadow-card p-4 sm:p-5 space-y-4", className),
		children: [(title || description) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "border-b pb-3 -mx-4 sm:-mx-5 px-4 sm:px-5",
			children: [title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-sm sm:text-base font-bold",
				children: title
			}), description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground mt-0.5",
				children: description
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children
		})]
	});
}
function FormRow({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("grid gap-3 lg:gap-4 grid-cols-1 sm:grid-cols-2", className),
		children
	});
}
function FormSummaryLine({ label, value, tone = "default" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between py-2 border-b last:border-b-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("text-sm font-bold tabular-nums", {
				default: "text-foreground",
				success: "text-success",
				warning: "text-warning",
				destructive: "text-destructive"
			}[tone]),
			children: value
		})]
	});
}
//#endregion
export { FormSection as a, FormSummaryLine as c, FormRow as i, FormTextarea as l, FormField as n, FormSegmented as o, FormInput as r, FormSelect as s, EnterpriseFormLayout as t };
