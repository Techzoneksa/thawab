//#region node_modules/.nitro/vite/services/ssr/assets/audit-DP6UgtXG.js
var API_BASE = "/api/audit";
async function getAuditEntries(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.userName && filters.userName !== "الكل") params.set("userName", filters.userName);
	if (filters.action && filters.action !== "الكل") params.set("action", filters.action);
	if (filters.entityType && filters.entityType !== "الكل") params.set("entityType", filters.entityType);
	if (filters.entityId) params.set("entityId", filters.entityId);
	if (filters.dateFrom) params.set("dateFrom", filters.dateFrom);
	if (filters.dateTo) params.set("dateTo", filters.dateTo);
	if (filters.page) params.set("page", String(filters.page));
	if (filters.limit) params.set("limit", String(filters.limit));
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب سجل التدقيق");
	return res.json();
}
async function getAuditEntry(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات السجل");
	return res.json();
}
//#endregion
export { getAuditEntry as n, getAuditEntries as t };
