import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Dt as FileText, Qt as CalendarDays, T as SquarePen, U as Plus, X as Paperclip, c as Vote, jt as Eye, v as Trash2 } from "../_libs/lucide-react.mjs";
import { N as showToast, P as statusTone, S as MobilePageHeader, a as Btn, c as ConfirmDialog, h as EntityFormDrawer, i as Badge, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { p as MEETINGS } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/meetings-AzFhFPGW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [data, setData] = (0, import_react.useState)(MEETINGS);
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [minutesOpen, setMinutesOpen] = (0, import_react.useState)(false);
	const [decisionOpen, setDecisionOpen] = (0, import_react.useState)(false);
	const [confirmIdx, setConfirmIdx] = (0, import_react.useState)(-1);
	const [formTitle, setFormTitle] = (0, import_react.useState)("");
	const [formDate, setFormDate] = (0, import_react.useState)("");
	const [minutesTitle, setMinutesTitle] = (0, import_react.useState)("");
	const [minutesContent, setMinutesContent] = (0, import_react.useState)("");
	const [decisionTitle, setDecisionTitle] = (0, import_react.useState)("");
	const [decisionDesc, setDecisionDesc] = (0, import_react.useState)("");
	const nextId = () => `MTG-${String(100 + data.length + 1).slice(-3)}`;
	const handleAddMeeting = () => {
		if (!formTitle.trim()) {
			showToast("يرجى إدخال عنوان الاجتماع", "error");
			return;
		}
		setData([{
			id: nextId(),
			title: formTitle,
			date: formDate || (/* @__PURE__ */ new Date()).toLocaleDateString("ar-SA"),
			attendees: 0,
			status: "مجدول",
			decisions: 0
		}, ...data]);
		showToast("تم إضافة الاجتماع بنجاح", "success");
		setFormOpen(false);
		setFormTitle("");
		setFormDate("");
	};
	const handleAddMinutes = () => {
		if (!minutesTitle.trim()) {
			showToast("يرجى إدخال عنوان المحضر", "error");
			return;
		}
		showToast(`تم إضافة محضر الاجتماع "${minutesTitle}" بنجاح`, "success");
		setMinutesOpen(false);
		setMinutesTitle("");
		setMinutesContent("");
	};
	const handleAddDecision = () => {
		if (!decisionTitle.trim()) {
			showToast("يرجى إدخال عنوان القرار", "error");
			return;
		}
		showToast(`تم إضافة القرار "${decisionTitle}" بنجاح`, "success");
		setDecisionOpen(false);
		setDecisionTitle("");
		setDecisionDesc("");
	};
	const handleDelete = () => {
		setData(data.filter((_, i) => i !== confirmIdx));
		showToast("تم حذف الاجتماع", "success");
		setConfirmIdx(-1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"الموارد",
			"الاجتماعات"
		],
		title: "الاجتماعات والقرارات",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => {
					setDecisionTitle("");
					setDecisionDesc("");
					setDecisionOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vote, { size: 15 }), " إضافة قرار"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => {
					setMinutesTitle("");
					setMinutesContent("");
					setMinutesOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { size: 15 }), " إضافة محضر اجتماع"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => {
					setFormTitle("");
					setFormDate("");
					setFormOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إضافة اجتماع"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "الاجتماعات والقرارات",
				count: `${data.length} اجتماع`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 lg:grid-cols-2 gap-4",
				children: data.map((m, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { size: 20 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-bold",
									children: m.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: [
										m.date,
										"هـ · ",
										m.attendees,
										" حاضر"
									]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(m.status),
								children: m.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
								{
									label: "عرض",
									icon: Eye,
									onClick: () => showToast(m.title, "info")
								},
								{
									label: "تعديل",
									icon: SquarePen,
									onClick: () => {
										setFormTitle(m.title);
										setFormDate(m.date);
										setFormOpen(true);
									}
								},
								{
									label: "حذف",
									icon: Trash2,
									variant: "destructive",
									onClick: () => setConfirmIdx(idx)
								}
							] })]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-3 mt-4 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-muted/60 p-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] text-muted-foreground",
									children: "قرارات"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-bold mt-0.5",
									children: m.decisions
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-muted/60 p-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] text-muted-foreground",
									children: "تصويتات"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm font-bold mt-0.5 inline-flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vote, { size: 12 }),
										" ",
										m.decisions
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg bg-muted/60 p-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] text-muted-foreground",
									children: "مرفقات"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm font-bold mt-0.5 inline-flex items-center gap-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { size: 12 }),
										" ",
										m.status === "منعقد" ? 3 : 0
									]
								})]
							})
						]
					})]
				}, m.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: formOpen,
				onClose: () => setFormOpen(false),
				title: "إضافة اجتماع",
				onSave: handleAddMeeting,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "عنوان الاجتماع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: formTitle,
					onChange: (e) => setFormTitle(e.target.value),
					placeholder: "عنوان الاجتماع"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "التاريخ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					type: "date",
					value: formDate,
					onChange: (e) => setFormDate(e.target.value)
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: minutesOpen,
				onClose: () => setMinutesOpen(false),
				title: "إضافة محضر اجتماع",
				onSave: handleAddMinutes,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "عنوان المحضر"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: minutesTitle,
					onChange: (e) => setMinutesTitle(e.target.value)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "المحتوى"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[120px]",
					value: minutesContent,
					onChange: (e) => setMinutesContent(e.target.value)
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: decisionOpen,
				onClose: () => setDecisionOpen(false),
				title: "إضافة قرار",
				onSave: handleAddDecision,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "عنوان القرار"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: decisionTitle,
					onChange: (e) => setDecisionTitle(e.target.value)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "الوصف"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[120px]",
					value: decisionDesc,
					onChange: (e) => setDecisionDesc(e.target.value)
				})] })]
			}),
			confirmIdx >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: true,
				onClose: () => setConfirmIdx(-1),
				onConfirm: handleDelete,
				title: "تأكيد الحذف",
				message: "هل أنت متأكد من حذف الاجتماع؟",
				confirmText: "حذف",
				variant: "destructive"
			})
		]
	});
};
//#endregion
export { SplitComponent as component };
