import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { O as ShoppingCart, Wt as CircleCheckBig, _ as TrendingDown, pn as Archive, r as Wrench, un as ArrowRightLeft } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, P as statusTone, c as ConfirmDialog, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { a as deleteFixedAsset, c as getFixedAsset, d as returnFromMaintenance, f as sellFixedAsset, m as updateFixedAsset, n as ASSET_DEPRECIATION_METHODS, o as depreciateFixedAsset, p as transferFixedAsset, s as disposeFixedAsset, t as ASSET_CONDITIONS, u as maintainFixedAsset } from "./assets-C0jGCeQN.mjs";
import { t as Route } from "./assets._id.edit-4UdN5357.mjs";
import { t as getAuditEntries } from "./audit-DP6UgtXG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assets._id.edit-B0gYM03y.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATEGORIES = [
	"أجهزة كمبيوتر",
	"أثاث مكتبي",
	"معدات",
	"سيارات",
	"مبانٍ",
	"أجهزة اتصال",
	"أخرى"
];
function EditAssetPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const detailQuery = useQuery({
		queryKey: ["fixedAssetDetail", id],
		queryFn: () => getFixedAsset(id)
	});
	const item = detailQuery.data?.item;
	const depreciationCount = detailQuery.data?.depreciationCount ?? 0;
	const movementCount = detailQuery.data?.movementCount ?? 0;
	const hasHistory = detailQuery.data?.hasHistory ?? false;
	const bookValue = detailQuery.data?.bookValue ?? 0;
	const [name, setName] = (0, import_react.useState)("");
	const [code, setCode] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("");
	const [location, setLocation] = (0, import_react.useState)("");
	const [cost, setCost] = (0, import_react.useState)("0");
	const [salvageValue, setSalvageValue] = (0, import_react.useState)("0");
	const [usefulLifeMonths, setUsefulLifeMonths] = (0, import_react.useState)("60");
	const [depreciationMethod, setDepreciationMethod] = (0, import_react.useState)("قسط ثابت");
	const [condition, setCondition] = (0, import_react.useState)("جيد");
	const [purchaseDate, setPurchaseDate] = (0, import_react.useState)("");
	const [serialNumber, setSerialNumber] = (0, import_react.useState)("");
	const [responsiblePerson, setResponsiblePerson] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(null);
	const [toLocation, setToLocation] = (0, import_react.useState)("");
	const [toResponsible, setToResponsible] = (0, import_react.useState)("");
	const [transferReason, setTransferReason] = (0, import_react.useState)("");
	const [maintainCost, setMaintainCost] = (0, import_react.useState)("0");
	const [maintainReason, setMaintainReason] = (0, import_react.useState)("");
	const [depAmount, setDepAmount] = (0, import_react.useState)("");
	const [depDate, setDepDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [returnCondition, setReturnCondition] = (0, import_react.useState)("جيد");
	const [disposeReason, setDisposeReason] = (0, import_react.useState)("");
	const [salePrice, setSalePrice] = (0, import_react.useState)("");
	const [saleBuyer, setSaleBuyer] = (0, import_react.useState)("");
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	if (item && !hydrated) {
		setName(item.name);
		setCode(item.code);
		setCategory(item.category);
		setLocation(item.location);
		setCost(String(item.cost || 0));
		setSalvageValue(String(item.salvageValue || 0));
		setUsefulLifeMonths(String(item.usefulLifeMonths || 60));
		setDepreciationMethod(item.depreciationMethod || "قسط ثابت");
		setCondition(item.condition || "جيد");
		setPurchaseDate(item.purchaseDate || "");
		setSerialNumber(item.serialNumber || "");
		setResponsiblePerson(item.responsiblePerson || "");
		setStatus(item.status || "نشط");
		setNotes(item.notes || "");
		setToLocation(item.location);
		setToResponsible(item.responsiblePerson);
		setHydrated(true);
	}
	const isReadOnly = !!item && (item.status === "مستبعد" || item.status === "مباع" || item.status === "ملغي");
	const handleSave = async () => {
		if (isReadOnly) {
			showToast("لا يمكن تعديل أصل مستبعد أو مباع", "error");
			return;
		}
		const errs = [];
		if (!name.trim()) errs.push("اسم الأصل مطلوب");
		const c = parseFloat(cost) || 0;
		const s = parseFloat(salvageValue) || 0;
		if (c < 0) errs.push("قيمة الشراء لا يمكن أن تكون سالبة");
		if (s < 0) errs.push("قيمة الإنقاذ لا يمكن أن تكون سالبة");
		if (s > c) errs.push("قيمة الإنقاذ لا يمكن أن تتجاوز قيمة الشراء");
		const life = parseInt(usefulLifeMonths) || 0;
		if (life <= 0) errs.push("العمر الافتراضي يجب أن يكون أكبر من صفر");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			await updateFixedAsset({
				id,
				name: name.trim(),
				code: code || void 0,
				category: category || void 0,
				location: location || void 0,
				cost: c,
				salvageValue: s,
				usefulLifeMonths: life,
				depreciationMethod,
				condition,
				purchaseDate: purchaseDate || void 0,
				serialNumber: serialNumber || void 0,
				responsiblePerson: responsiblePerson || void 0,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail", id] });
			showToast("تم حفظ التعديلات", "success");
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const handleTransfer = async () => {
		try {
			await transferFixedAsset({
				id,
				toLocation: toLocation || void 0,
				toResponsible: toResponsible || void 0,
				date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
				reason: transferReason || void 0,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetAudit", id] });
			showToast("تم نقل الأصل", "success");
			setConfirmAction(null);
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل النقل", "error");
		}
	};
	const handleMaintain = async () => {
		try {
			await maintainFixedAsset({
				id,
				cost: parseFloat(maintainCost) || 0,
				date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
				reason: maintainReason || void 0,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetAudit", id] });
			showToast("تم تسجيل الصيانة", "success");
			setConfirmAction(null);
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل تسجيل الصيانة", "error");
		}
	};
	const handleReturn = async () => {
		try {
			await returnFromMaintenance({
				id,
				condition: returnCondition,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetAudit", id] });
			showToast("تم إنهاء الصيانة", "success");
			setConfirmAction(null);
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل إنهاء الصيانة", "error");
		}
	};
	const handleDepreciate = async () => {
		const amt = parseFloat(depAmount);
		if (!amt || amt <= 0) {
			showToast("قيمة الإهلاك يجب أن تكون أكبر من صفر", "error");
			return;
		}
		try {
			await depreciateFixedAsset({
				id,
				amount: amt,
				date: depDate,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetAudit", id] });
			showToast(`تم تسجيل إهلاك ${fmtSAR(amt)}`, "success");
			setDepAmount("");
			setConfirmAction(null);
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل تسجيل الإهلاك", "error");
		}
	};
	const handleDispose = async () => {
		try {
			await disposeFixedAsset({
				id,
				date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
				reason: disposeReason || void 0,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetAudit", id] });
			showToast("تم استبعاد الأصل", "success");
			setConfirmAction(null);
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الاستبعاد", "error");
		}
	};
	const handleSell = async () => {
		try {
			await sellFixedAsset({
				id,
				salePrice: parseFloat(salePrice) || 0,
				date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
				buyer: saleBuyer || void 0,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetAudit", id] });
			showToast("تم تسجيل بيع الأصل", "success");
			setConfirmAction(null);
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل تسجيل البيع", "error");
		}
	};
	const deleteMut = useMutation({
		mutationFn: () => deleteFixedAsset({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			showToast("تم حذف الأصل", "success");
			navigate({ to: "/assets" });
		},
		onError: (err) => showToast(err.message, "error")
	});
	const auditQuery = useQuery({
		queryKey: ["fixedAssetAudit", id],
		queryFn: () => getAuditEntries({
			entityType: "أصل ثابت",
			entityId: id,
			limit: 50
		}),
		enabled: !!item
	});
	const tabs = [
		{
			id: "basic",
			label: "بيانات الأصل",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات الأصل",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم الأصل",
						required: true,
						error: errors[0],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "رقم الأصل",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: code,
							onChange: (e) => setCode(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "التصنيف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— اختر —"
							}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c,
								children: c
							}, c))]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الموقع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: location,
							onChange: (e) => setLocation(e.target.value)
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الشخص المسؤول",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: responsiblePerson,
							onChange: (e) => setResponsiblePerson(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الرقم التسلسلي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: serialNumber,
							onChange: (e) => setSerialNumber(e.target.value),
							dir: "ltr"
						})
					})] })
				]
			})
		},
		{
			id: "financial",
			label: "البيانات المالية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "البيانات المالية",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "قيمة الشراء",
						hint: "ر.س",
						error: errors[1],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: cost,
							onChange: (e) => setCost(e.target.value),
							dir: "ltr",
							disabled: depreciationCount > 0
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "قيمة الإنقاذ",
						hint: "ر.س",
						error: errors[2] || errors[3],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: salvageValue,
							onChange: (e) => setSalvageValue(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "العمر الافتراضي",
						hint: "بالأشهر",
						error: errors[4],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "1",
							value: usefulLifeMonths,
							onChange: (e) => setUsefulLifeMonths(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "طريقة الإهلاك",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: depreciationMethod,
							onChange: (e) => setDepreciationMethod(e.target.value),
							children: ASSET_DEPRECIATION_METHODS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: m,
								children: m
							}, m))
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-lg bg-info/10 border border-info/30 px-3 py-2 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 sm:grid-cols-4 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "قيمة الشراء"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums",
									children: fmtSAR(parseFloat(cost) || 0)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "الإهلاك المتراكم"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums text-warning",
									children: fmtSAR(item?.accumulatedDepreciation || 0)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "القيمة الدفترية الحالية"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums text-info",
									children: fmtSAR(bookValue)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "عدد حركات الإهلاك"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums",
									children: depreciationCount
								})] })
							]
						})
					})
				]
			})
		},
		{
			id: "actions",
			label: "العمليات",
			badge: movementCount || void 0,
			content: isReadOnly ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "العمليات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-muted/40 p-4 text-sm text-muted-foreground text-center",
					children: [
						"الأصل في حالة \"",
						item?.status,
						"\" — لا يمكن تنفيذ عمليات إضافية."
					]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "عمليات الأصل",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setConfirmAction("transfer"),
							className: "text-right rounded-lg border bg-card p-3 hover:bg-muted/40 transition-colors min-h-[64px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 font-semibold text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRightLeft, {
									size: 15,
									className: "text-info"
								}), " نقل الأصل"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: "نقل إلى موقع أو مسؤول جديد"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setConfirmAction("maintain"),
							className: "text-right rounded-lg border bg-card p-3 hover:bg-muted/40 transition-colors min-h-[64px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 font-semibold text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wrench, {
									size: 15,
									className: "text-warning"
								}), " تسجيل صيانة"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: "تحوّل الأصل إلى حالة \"تحت الصيانة\""
							})]
						}),
						item?.status === "تحت الصيانة" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setConfirmAction("return"),
							className: "text-right rounded-lg border bg-card p-3 hover:bg-muted/40 transition-colors min-h-[64px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 font-semibold text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, {
									size: 15,
									className: "text-success"
								}), " إنهاء الصيانة"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: "إرجاع الأصل إلى حالة نشط"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setConfirmAction("depreciate"),
							className: "text-right rounded-lg border bg-card p-3 hover:bg-muted/40 transition-colors min-h-[64px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 font-semibold text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, {
									size: 15,
									className: "text-warning"
								}), " تسجيل إهلاك"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: "إنقاص القيمة الدفترية بمبلغ الإهلاك"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setConfirmAction("sell"),
							className: "text-right rounded-lg border bg-card p-3 hover:bg-muted/40 transition-colors min-h-[64px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 font-semibold text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingCart, {
									size: 15,
									className: "text-info"
								}), " بيع الأصل"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: "تسجيل عملية بيع مع سعر البيع والمشتري"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setConfirmAction("dispose"),
							className: "text-right rounded-lg border border-destructive/40 bg-destructive/5 p-3 hover:bg-destructive/10 transition-colors min-h-[64px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 font-semibold text-sm text-destructive",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { size: 15 }), " استبعاد الأصل"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: "إزالة الأصل بدون بيع (هالك / تالف نهائي)"
							})]
						})
					]
				})
			})
		},
		{
			id: "summary",
			label: "ملخص",
			content: item ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ملخص الأصل",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الاسم",
						value: item.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "رقم الأصل",
						value: item.code || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "التصنيف",
						value: item.category || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الحالة",
						value: item.status,
						tone: statusTone(item.status)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الموقع",
						value: item.location || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "المسؤول",
						value: item.responsiblePerson || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "تاريخ الشراء",
						value: item.purchaseDate || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "قيمة الشراء",
						value: fmtSAR(item.cost || 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "قيمة الإنقاذ",
						value: fmtSAR(item.salvageValue || 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الإهلاك المتراكم",
						value: fmtSAR(item.accumulatedDepreciation || 0),
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "القيمة الدفترية",
						value: fmtSAR(bookValue),
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "العمر الافتراضي",
						value: `${item.usefulLifeMonths} شهرًا`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "طريقة الإهلاك",
						value: item.depreciationMethod
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "عدد حركات الإهلاك",
						value: String(depreciationCount),
						tone: depreciationCount > 0 ? "warning" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "عدد حركات النقل/الصيانة",
						value: String(movementCount),
						tone: movementCount > 0 ? "warning" : "default"
					})
				]
			}) : null
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			badge: auditQuery.data?.items.length,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "سجل العمليات",
				children: auditQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "جاري التحميل..."
				}) : (auditQuery.data?.items ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "لا توجد عمليات مسجلة على هذا الأصل."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: (auditQuery.data?.items ?? []).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border bg-card px-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-foreground",
									children: e.action
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground font-mono",
									children: e.timestamp?.slice(0, 16).replace("T", " ")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground mt-0.5",
								children: e.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-muted-foreground mt-0.5",
								children: ["المستخدم: ", e.userName || "—"]
							})
						]
					}, e.id))
				})
			})
		}
	];
	if (detailQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الأصول الثابتة",
		breadcrumb: ["المالية", "الأصول الثابتة"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الأصول الثابتة",
		breadcrumb: ["المالية", "الأصول الثابتة"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-center py-12 text-muted-foreground",
			children: "الأصل غير موجود"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "الأصول الثابتة",
		breadcrumb: [
			"المالية",
			"الأصول الثابتة",
			"تعديل"
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
				breadcrumb: [{
					label: "الأصول",
					to: "/assets"
				}, { label: item.name }],
				title: item.name,
				subtitle: `${item.code ? `(${item.code}) · ` : ""}${fmtSAR(bookValue)}`,
				draftNumber: item.id,
				status: {
					label: item.status,
					tone: statusTone(item.status)
				},
				isReadOnly,
				readonlyReason: isReadOnly ? `الأصل في حالة "${item.status}" — للقراءة فقط.` : void 0,
				tabs,
				defaultTab: "basic",
				loading: saving,
				validationErrors: errors,
				primaryLabel: "حفظ التعديلات",
				secondaryLabel: "حفظ وإغلاق",
				showSecondary: false,
				onPrimary: handleSave,
				onCancel: () => navigate({ to: "/assets" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "transfer",
				onClose: () => setConfirmAction(null),
				onConfirm: handleTransfer,
				title: "نقل الأصل",
				message: `هل تريد نقل الأصل "${item.name}" إلى موقع/مسؤول جديد؟`,
				confirmText: "تأكيد النقل",
				cancelText: "تراجع",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2 text-right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "إلى موقع",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
								value: toLocation,
								onChange: (e) => setToLocation(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "إلى مسؤول",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
								value: toResponsible,
								onChange: (e) => setToResponsible(e.target.value)
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "سبب النقل",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
								value: transferReason,
								onChange: (e) => setTransferReason(e.target.value),
								rows: 2
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "maintain",
				onClose: () => setConfirmAction(null),
				onConfirm: handleMaintain,
				title: "تسجيل صيانة",
				message: `هل تريد تسجيل صيانة للأصل "${item.name}"؟ سيتحول إلى حالة "تحت الصيانة".`,
				confirmText: "تسجيل",
				cancelText: "تراجع",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "تكلفة الصيانة",
						hint: "ر.س",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: maintainCost,
							onChange: (e) => setMaintainCost(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "سبب الصيانة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: maintainReason,
							onChange: (e) => setMaintainReason(e.target.value),
							rows: 2
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "return",
				onClose: () => setConfirmAction(null),
				onConfirm: handleReturn,
				title: "إنهاء الصيانة",
				message: `هل تريد إنهاء صيانة "${item.name}" وإرجاعه إلى الحالة نشطة؟`,
				confirmText: "إنهاء",
				cancelText: "تراجع",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 space-y-2 text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحالة المادية بعد الصيانة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: returnCondition,
							onChange: (e) => setReturnCondition(e.target.value),
							children: ASSET_CONDITIONS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c,
								children: c
							}, c))
						})
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "depreciate",
				onClose: () => setConfirmAction(null),
				onConfirm: handleDepreciate,
				title: "تسجيل إهلاك",
				message: `هل تريد تسجيل إهلاك للأصل "${item.name}"؟ القيمة الدفترية ستنخفض بمقدار الإهلاك لكنها لن تقل عن قيمة الإنقاذ.`,
				confirmText: "تسجيل",
				cancelText: "تراجع",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "قيمة الإهلاك",
						hint: "ر.س",
						required: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: depAmount,
							onChange: (e) => setDepAmount(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "تاريخ الإهلاك",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: depDate,
							onChange: (e) => setDepDate(e.target.value),
							dir: "ltr"
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "dispose",
				onClose: () => setConfirmAction(null),
				onConfirm: handleDispose,
				title: "استبعاد الأصل",
				message: `هل تريد استبعاد الأصل "${item.name}" (إزالته بدون بيع)؟ هذا الإجراء لا يمكن التراجع عنه.`,
				confirmText: "استبعاد",
				cancelText: "تراجع",
				variant: "destructive",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 space-y-2 text-right",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "سبب الاستبعاد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: disposeReason,
							onChange: (e) => setDisposeReason(e.target.value),
							rows: 2
						})
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "sell",
				onClose: () => setConfirmAction(null),
				onConfirm: handleSell,
				title: "بيع الأصل",
				message: `هل تريد تسجيل بيع الأصل "${item.name}"؟`,
				confirmText: "تسجيل البيع",
				cancelText: "تراجع",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 space-y-2 text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "سعر البيع",
						hint: "ر.س",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: salePrice,
							onChange: (e) => setSalePrice(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المشتري",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: saleBuyer,
							onChange: (e) => setSaleBuyer(e.target.value)
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "delete",
				onClose: () => setConfirmAction(null),
				onConfirm: () => deleteMut.mutate(),
				title: "حذف الأصل",
				message: `هل تريد حذف الأصل "${item.name}"؟ ${hasHistory ? "الأصل له سجل حركات، قد لا يُسمح بالحذف." : ""}`,
				confirmText: "حذف",
				cancelText: "تراجع",
				variant: "destructive",
				loading: deleteMut.isPending
			})
		]
	});
}
//#endregion
export { EditAssetPage as component };
