import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { It as Copy, J as Pencil, U as Plus, _t as KeyRound, k as ShieldPlus, v as Trash2 } from "../_libs/lucide-react.mjs";
import { N as showToast, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, h as EntityFormDrawer, i as Badge, j as Td, n as AppShell, s as Card, t as ActionMenu, y as MobileActionRow } from "./actions-qTEe1ygX.mjs";
import { m as PERMISSIONS_MATRIX } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/permissions-B9N0yo2j.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var modules = [
	"finance",
	"donations",
	"projects",
	"procurement",
	"reports",
	"settings"
];
var labels = {
	finance: "المالية",
	donations: "التبرعات",
	projects: "المشاريع",
	procurement: "المشتريات",
	reports: "التقارير",
	settings: "الإعدادات"
};
var permLevels = [
	"—",
	"قراءة",
	"محدود",
	"إدخال",
	"طلب",
	"اعتماد",
	"كامل"
];
function Page() {
	const [matrix, setMatrix] = (0, import_react.useState)(PERMISSIONS_MATRIX.map((r) => ({ ...r })));
	const [addRoleOpen, setAddRoleOpen] = (0, import_react.useState)(false);
	const [addPermOpen, setAddPermOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [editIdx, setEditIdx] = (0, import_react.useState)(null);
	const [confirmOpen, setConfirmOpen] = (0, import_react.useState)(false);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(() => {});
	const [formRole, setFormRole] = (0, import_react.useState)("");
	const [formDesc, setFormDesc] = (0, import_react.useState)("");
	const [formPerms, setFormPerms] = (0, import_react.useState)(["المالية"]);
	const [permName, setPermName] = (0, import_react.useState)("");
	const [permModule, setPermModule] = (0, import_react.useState)("المالية");
	const permOptions = [
		"المالية",
		"التبرعات",
		"المشاريع",
		"المشتريات",
		"التقارير",
		"الإعدادات"
	];
	function resetForm() {
		setFormRole("");
		setFormDesc("");
		setFormPerms(["المالية"]);
	}
	function handleAddRole() {
		if (!formRole.trim()) {
			showToast("يرجى إدخال اسم الدور", "error");
			return;
		}
		const newRole = { role: formRole };
		modules.forEach((m) => {
			newRole[m] = "قراءة";
		});
		setMatrix([...matrix, newRole]);
		showToast(`تم إضافة الدور ${formRole} بنجاح`, "success");
		setAddRoleOpen(false);
		resetForm();
	}
	function handleAddPerm() {
		if (!permName.trim()) {
			showToast("يرجى إدخال اسم الصلاحية", "error");
			return;
		}
		showToast(`تم إضافة الصلاحية ${permName} لوحدة ${permModule}`, "success");
		setAddPermOpen(false);
		setPermName("");
		setPermModule("المالية");
	}
	function handleEdit(i) {
		setEditIdx(i);
		setFormRole(matrix[i].role);
		setAddRoleOpen(false);
		setEditOpen(true);
	}
	function handleSaveEdit() {
		if (editIdx === null) return;
		const updated = [...matrix];
		updated[editIdx] = {
			...updated[editIdx],
			role: formRole
		};
		setMatrix(updated);
		showToast(`تم تعديل الدور ${formRole} بنجاح`, "success");
		setEditOpen(false);
		setEditIdx(null);
	}
	function handleDuplicate(i) {
		const newRole = {
			...matrix[i],
			role: `${matrix[i].role} (نسخة)`
		};
		setMatrix([...matrix, newRole]);
		showToast(`تم نسخ الدور ${matrix[i].role}`, "success");
	}
	function handleDelete(i) {
		setConfirmAction(() => () => {
			setMatrix(matrix.filter((_, idx) => idx !== i));
			showToast("تم حذف الدور", "success");
		});
		setConfirmOpen(true);
	}
	function handlePermChange(idx, mod, val) {
		const updated = [...matrix];
		updated[idx][mod] = val;
		setMatrix(updated);
		showToast(`تم تحديث صلاحية ${mod === "finance" ? "المالية" : labels[mod] || mod} لـ ${updated[idx].role}`, "success");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"التقارير والحوكمة",
			"الصلاحيات"
		],
		title: "مصفوفة الصلاحيات (RBAC)",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => {
					setPermName("");
					setPermModule("المالية");
					setAddPermOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldPlus, { size: 15 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden md:inline",
					children: "إضافة صلاحية"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => {
					resetForm();
					setAddRoleOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "دور جديد"]
			})]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "مصفوفة الصلاحيات",
				count: `${matrix.length} دور`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MobileActionRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => {
					setPermName("");
					setPermModule("المالية");
					setAddPermOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldPlus, { size: 15 }), " إضافة صلاحية"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => {
					resetForm();
					setAddRoleOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إضافة دور"]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 lg:mt-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الدور",
					...modules.map((m) => labels[m]),
					""
				],
				rows: matrix,
				renderRow: (r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, {
						className: "font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
							size: 14,
							className: "inline ms-1 text-primary"
						}), r.role]
					}),
					modules.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "appearance-none rounded-lg border bg-background px-2 py-1 text-xs min-h-[32px] cursor-pointer",
							value: r[m],
							onChange: (e) => handlePermChange(i, m, e.target.value),
							children: permLevels.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: l }, l))
						})
					}, m)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
						{
							label: "تعديل",
							icon: Pencil,
							onClick: () => handleEdit(i)
						},
						{
							label: "نسخ الدور",
							icon: Copy,
							onClick: () => handleDuplicate(i)
						},
						{
							label: "حذف",
							icon: Trash2,
							variant: "destructive",
							onClick: () => handleDelete(i)
						}
					] }) })
				] }),
				mobileCard: (r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between mb-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-semibold",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {
								size: 14,
								className: "inline ms-1 text-primary"
							}), r.role]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
							{
								label: "تعديل",
								icon: Pencil,
								onClick: () => handleEdit(i)
							},
							{
								label: "نسخ الدور",
								icon: Copy,
								onClick: () => handleDuplicate(i)
							},
							{
								label: "حذف",
								icon: Trash2,
								variant: "destructive",
								onClick: () => handleDelete(i)
							}
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: modules.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: [labels[m], ":"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								className: "appearance-none rounded-lg border bg-background px-1.5 py-0.5 text-xs",
								value: r[m],
								onChange: (e) => handlePermChange(i, m, e.target.value),
								children: permLevels.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: l }, l))
							})]
						}, m))
					})]
				}, r.role)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 md:grid-cols-3 gap-4 mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-bold mb-3",
							children: "فصل المهام (SoD)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "text-sm space-y-2 text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "✓ المنشئ ≠ المعتمِد للقيود المالية" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "✓ المشتريات ≠ السداد" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "✓ صرف المساعدة يتطلب 3 مستويات اعتماد" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "✓ تعديل الميزانية يتطلب موافقة المجلس" })
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-bold mb-3",
								children: "المصادقة الثنائية 2FA"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground mb-3",
								children: "مفعّلة لجميع المستخدمين ذوي الصلاحيات المالية والإدارية."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "success",
								children: "مفعّلة لـ 24 مستخدم"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-bold mb-3",
							children: "سياسة كلمات المرور"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "text-sm space-y-1 text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "• الحد الأدنى 12 حرفاً" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "• تجديد كل 90 يوم" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "• حظر آخر 5 كلمات مرور" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "• قفل بعد 5 محاولات فاشلة" })
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: addRoleOpen,
				onClose: () => setAddRoleOpen(false),
				title: "إضافة دور جديد",
				onSave: handleAddRole,
				saveText: "إضافة",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "اسم الدور *"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formRole,
						onChange: (e) => setFormRole(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الوصف"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm min-h-[80px]",
						value: formDesc,
						onChange: (e) => setFormDesc(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الصلاحيات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 space-y-2",
						children: permOptions.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "rounded border-gray-300",
								checked: formPerms.includes(p),
								onChange: (e) => {
									if (e.target.checked) setFormPerms([...formPerms, p]);
									else setFormPerms(formPerms.filter((x) => x !== p));
								}
							}), p]
						}, p))
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: addPermOpen,
				onClose: () => setAddPermOpen(false),
				title: "إضافة صلاحية جديدة",
				onSave: handleAddPerm,
				saveText: "إضافة",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs text-muted-foreground",
					children: "اسم الصلاحية *"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
					value: permName,
					onChange: (e) => setPermName(e.target.value)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs text-muted-foreground",
					children: "الوحدة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
					value: permModule,
					onChange: (e) => setPermModule(e.target.value),
					children: permOptions.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: p }, p))
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: editOpen,
				onClose: () => {
					setEditOpen(false);
					setEditIdx(null);
				},
				title: "تعديل الدور",
				onSave: handleSaveEdit,
				saveText: "حفظ التغييرات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs text-muted-foreground",
					children: "اسم الدور"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
					value: formRole,
					onChange: (e) => setFormRole(e.target.value)
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmOpen,
				onClose: () => setConfirmOpen(false),
				onConfirm: () => {
					confirmAction();
					setConfirmOpen(false);
				},
				title: "تأكيد حذف الدور",
				message: "هل أنت متأكد من حذف هذا الدور؟",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			})
		]
	});
}
//#endregion
export { Page as component };
