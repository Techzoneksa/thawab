import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { Bt as ClipboardCheck, G as Play, Ht as CircleX, J as Pencil, P as Search, Wt as CircleCheckBig, Y as Pause, d as UserPlus, ft as List, pt as LayoutGrid, v as Trash2, wt as Funnel } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, E as PrintButton, F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { a as disqualifyBeneficiary, d as reviewBeneficiary, f as suspendBeneficiary, i as deleteBeneficiary, l as qualifyBeneficiary, o as getBeneficiaries, t as ELIGIBILITY_STATUSES, u as reactivateBeneficiary } from "./beneficiaries-aRDRq8QX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/beneficiaries-CwUYDYMv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BENEFICIARY_CATEGORIES = [
	"الكل",
	"أيتام",
	"أرامل",
	"أسر محتاجة",
	"مرضى",
	"أسر منتجة"
];
var CITIES = [
	"الكل",
	"الرياض",
	"جدة",
	"الدمام",
	"أبها",
	"الطائف",
	"المدينة المنورة"
];
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [view, setView] = (0, import_react.useState)("grid");
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [workflowTarget, setWorkflowTarget] = (0, import_react.useState)(null);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [categoryFilter, setCategoryFilter] = (0, import_react.useState)("الكل");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [cityFilter, setCityFilter] = (0, import_react.useState)("الكل");
	const [page, setPage] = (0, import_react.useState)(1);
	const [apiFilters, setApiFilters] = (0, import_react.useState)({
		search: "",
		status: "",
		category: "",
		city: "",
		page: 1,
		limit: 50
	});
	const { data, isLoading, error } = useQuery({
		queryKey: ["beneficiaries", apiFilters],
		queryFn: () => getBeneficiaries(apiFilters)
	});
	const beneficiaries = data?.items || [];
	const total = data?.total || 0;
	const totalPages = Math.ceil(total / 50);
	(0, import_react.useEffect)(() => {
		setPage(1);
		setApiFilters((f) => ({
			...f,
			search: searchQuery,
			status: statusFilter,
			category: categoryFilter,
			city: cityFilter,
			page: 1
		}));
	}, [
		searchQuery,
		statusFilter,
		categoryFilter,
		cityFilter
	]);
	(0, import_react.useEffect)(() => {
		setApiFilters((f) => ({
			...f,
			page
		}));
	}, [page]);
	const deleteMutation = useMutation({
		mutationFn: deleteBeneficiary,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["beneficiaries"] });
			showToast("تم حذف المستفيد بنجاح", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const workflowMutation = useMutation({
		mutationFn: async (vars) => {
			return {
				review: reviewBeneficiary,
				qualify: qualifyBeneficiary,
				disqualify: disqualifyBeneficiary,
				suspend: suspendBeneficiary,
				reactivate: reactivateBeneficiary
			}[vars.action]({
				id: vars.id,
				userId: vars.userId,
				userName: vars.userName
			});
		},
		onSuccess: (_, vars) => {
			queryClient.invalidateQueries({ queryKey: ["beneficiaries"] });
			queryClient.invalidateQueries({ queryKey: ["beneficiary"] });
			queryClient.invalidateQueries({ queryKey: ["beneficiaries-simple"] });
			showToast({
				review: "تم إرسال المستفيد للمراجعة",
				qualify: "تم تأهيل المستفيد",
				disqualify: "تم عدم تأهيل المستفيد",
				suspend: "تم إيقاف المستفيد",
				reactivate: "تم إعادة تفعيل المستفيد"
			}[vars.action], "success");
			setWorkflowTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => navigate({ to: "/beneficiaries/new" });
	const openEdit = (b) => navigate({
		to: "/beneficiaries/$id/edit",
		params: { id: b.id }
	});
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleWorkflowConfirm = () => {
		if (workflowTarget) workflowMutation.mutate({
			id: workflowTarget.id,
			action: workflowTarget.action,
			userId: user?.id,
			userName: user?.name
		});
	};
	const stats = [
		{
			label: "إجمالي المستفيدين",
			value: fmtNum(total)
		},
		{
			label: "مؤهلين",
			value: beneficiaries.filter((b) => b.status === "مؤهل").length
		},
		{
			label: "قيد المراجعة",
			value: beneficiaries.filter((b) => b.status === "قيد المراجعة").length
		},
		{
			label: "موقوفين",
			value: beneficiaries.filter((b) => b.status === "موقوف").length
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المشاريع والمستفيدون",
			"المستفيدون"
		],
		title: "قاعدة بيانات المستفيدين",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden lg:flex rounded-lg border overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setView("grid"),
					className: `px-3 py-2 ${view === "grid" ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { size: 15 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setView("table"),
					className: `px-3 py-2 ${view === "table" ? "bg-primary text-primary-foreground" : "hover:bg-muted"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, { size: 15 })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: beneficiaries,
				filename: "المستفيدون.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: openAdd,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { size: 15 }), " إضافة مستفيد"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base lg:text-xl font-extrabold mt-1 tabular-nums truncate",
						children: s.value
					})]
				}, s.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث بالاسم، رقم الملف، الهوية، الجوال...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الفئة",
					options: BENEFICIARY_CATEGORIES,
					value: categoryFilter,
					onChange: (e) => setCategoryFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الحالة",
					options: ["الكل", ...ELIGIBILITY_STATUSES],
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "المدينة",
					options: CITIES,
					value: cityFilter,
					onChange: (e) => setCityFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث عن مستفيد...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "المستفيدون",
				count: `${fmtNum(total)} مستفيد`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { size: 15 })
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء تحميل المستفيدين",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["beneficiaries"] }),
					children: "إعادة المحاولة"
				})
			}) : beneficiaries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد مستفيدين",
				description: "ابدأ بإضافة أول مستفيد",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة مستفيد"
				})
			}) : view === "grid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 lg:gap-4",
				children: beneficiaries.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4 lg:p-5 hover:border-primary transition-all",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-12 w-12 shrink-0 place-items-center rounded-full bg-info/15 text-info text-base font-bold",
								children: b.name?.[0] || "؟"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "font-bold text-sm lg:text-base truncate",
											children: b.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-muted-foreground font-mono",
											children: b.fileNumber || b.id
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: statusTone(b.status),
										children: b.status
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground mt-1 truncate",
									children: [b.category, b.city ? ` · ${b.city}` : ""]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-3 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-muted/60 p-2 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] lg:text-[10px] text-muted-foreground",
										children: "الأفراد"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] lg:text-xs font-bold tabular-nums mt-0.5",
										children: fmtNum(b.familyMembers || 1)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-success/10 p-2 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] lg:text-[10px] text-success",
										children: "الدخل"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] lg:text-xs font-bold tabular-nums mt-0.5 text-success",
										children: fmtSAR(b.monthlyIncome || 0)
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg bg-warning/15 p-2 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[9px] lg:text-[10px] text-warning-foreground",
										children: "المساعدات"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] lg:text-xs font-bold tabular-nums mt-0.5",
										children: fmtNum(b.aidCount || 0)
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center justify-between text-xs text-muted-foreground border-t pt-2 lg:pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: b.phone || "—"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/beneficiaries/$id",
										params: { id: b.id },
										className: "text-info text-xs font-semibold",
										children: "تفاصيل"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => openEdit(b),
										className: "text-primary text-xs font-semibold",
										children: "تعديل"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setDeleteTarget(b.id),
										className: "text-destructive text-xs font-semibold",
										children: "حذف"
									})
								]
							})]
						})
					]
				}, b.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"رقم الملف",
					"الاسم",
					"الفئة",
					"الجوال",
					"المدينة",
					"الأفراد",
					"الحالة",
					""
				],
				rows: beneficiaries,
				renderRow: (b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: b.fileNumber || b.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/beneficiaries/$id",
						params: { id: b.id },
						className: "font-semibold hover:text-primary",
						children: b.name
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "info",
						children: b.category
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-muted-foreground",
						children: b.phone || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-muted-foreground",
						children: b.city || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums",
						children: fmtNum(b.familyMembers || 1)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(b.status),
						children: b.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getBeneficiaryActions(b, setWorkflowTarget, openEdit, setDeleteTarget) }) })
				] }),
				mobileCard: (b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/beneficiaries/$id",
					params: { id: b.id },
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "p-3 hover:border-primary transition-colors",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-10 w-10 shrink-0 place-items-center rounded-full bg-info/15 text-info text-sm font-bold",
								children: b.name?.[0] || "؟"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-bold truncate",
											children: b.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-muted-foreground",
											children: [
												b.fileNumber || b.id,
												" · ",
												b.category
											]
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: statusTone(b.status),
										children: b.status
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground",
										children: [
											b.city || "—",
											" · ",
											b.phone || "—"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: (e) => {
												e.preventDefault();
												openEdit(b);
											},
											className: "text-primary text-xs",
											children: "تعديل"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: (e) => {
												e.preventDefault();
												setDeleteTarget(b.id);
											},
											className: "text-destructive text-xs",
											children: "حذف"
										})]
									})]
								})]
							})]
						})
					})
				}, b.id)
			}),
			totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mt-3 px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: [
						"صفحة ",
						page,
						" من ",
						totalPages,
						" | ",
						fmtNum(total),
						" مستفيد"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "px-3 py-1.5 text-xs rounded-lg border bg-background hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed min-h-[36px]",
						disabled: page <= 1,
						onClick: () => setPage((p) => Math.max(1, p - 1)),
						children: "السابق"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "px-3 py-1.5 text-xs rounded-lg border bg-background hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed min-h-[36px]",
						disabled: page >= totalPages,
						onClick: () => setPage((p) => Math.min(totalPages, p + 1)),
						children: "التالي"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: handleDelete,
				title: "حذف المستفيد",
				message: "هل أنت متأكد من حذف هذا المستفيد؟ سيتم الحذف فقط إذا لم يكن لديه مساعدات مستلمة أو قيد المعالجة.",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!workflowTarget,
				onClose: () => setWorkflowTarget(null),
				onConfirm: handleWorkflowConfirm,
				title: workflowTarget ? getWorkflowTitle(workflowTarget.action) : "",
				message: workflowTarget ? `هل تريد ${getWorkflowVerb(workflowTarget.action)} المستفيد "${workflowTarget.name}"؟` : "",
				confirmText: workflowTarget ? getWorkflowConfirm(workflowTarget.action) : "تأكيد",
				cancelText: "إلغاء",
				variant: getWorkflowVariant(workflowTarget?.action)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الفئة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: categoryFilter,
							onChange: (e) => setCategoryFilter(e.target.value),
							children: BENEFICIARY_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الحالة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: statusFilter,
							onChange: (e) => setStatusFilter(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), ELIGIBILITY_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "المدينة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: cityFilter,
							onChange: (e) => setCityFilter(e.target.value),
							children: CITIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: c }, c))
						})] })
					]
				})
			})
		]
	});
}
function getBeneficiaryActions(b, setWorkflowTarget, openEdit, setDeleteTarget) {
	const actions = [];
	if (b.status === "جديد") actions.push({
		label: "إرسال للمراجعة",
		icon: ClipboardCheck,
		onClick: () => setWorkflowTarget({
			id: b.id,
			name: b.name,
			action: "review"
		})
	});
	if (b.status === "قيد المراجعة") {
		actions.push({
			label: "تأهيل",
			icon: CircleCheckBig,
			onClick: () => setWorkflowTarget({
				id: b.id,
				name: b.name,
				action: "qualify"
			})
		});
		actions.push({
			label: "عدم تأهيل",
			icon: CircleX,
			onClick: () => setWorkflowTarget({
				id: b.id,
				name: b.name,
				action: "disqualify"
			}),
			variant: "destructive"
		});
	}
	if (b.status === "مؤهل") actions.push({
		label: "إيقاف",
		icon: Pause,
		onClick: () => setWorkflowTarget({
			id: b.id,
			name: b.name,
			action: "suspend"
		})
	});
	if (b.status === "موقوف") actions.push({
		label: "إعادة تفعيل",
		icon: Play,
		onClick: () => setWorkflowTarget({
			id: b.id,
			name: b.name,
			action: "reactivate"
		})
	});
	if (b.status === "غير مؤهل") actions.push({
		label: "إرسال للمراجعة",
		icon: ClipboardCheck,
		onClick: () => setWorkflowTarget({
			id: b.id,
			name: b.name,
			action: "review"
		})
	});
	actions.push({
		label: "تعديل",
		icon: Pencil,
		onClick: () => openEdit(b)
	});
	actions.push({
		label: "حذف",
		icon: Trash2,
		onClick: () => setDeleteTarget(b.id),
		variant: "destructive"
	});
	return actions;
}
function getWorkflowTitle(action) {
	return {
		review: "إرسال للمراجعة",
		qualify: "تأهيل المستفيد",
		disqualify: "عدم تأهيل المستفيد",
		suspend: "إيقاف المستفيد",
		reactivate: "إعادة تفعيل المستفيد"
	}[action];
}
function getWorkflowVerb(action) {
	return {
		review: "إرسال للمراجعة",
		qualify: "تأهيل",
		disqualify: "عدم تأهيل",
		suspend: "إيقاف",
		reactivate: "إعادة تفعيل"
	}[action];
}
function getWorkflowConfirm(action) {
	return {
		review: "إرسال",
		qualify: "تأهيل",
		disqualify: "عدم تأهيل",
		suspend: "إيقاف",
		reactivate: "إعادة التفعيل"
	}[action];
}
function getWorkflowVariant(action) {
	if (action === "disqualify" || action === "suspend") return "destructive";
	return "default";
}
//#endregion
export { Page as component };
