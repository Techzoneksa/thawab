//#region node_modules/.nitro/vite/services/ssr/assets/sample-D8-YMyyC.js
var fmtSAR = (n) => new Intl.NumberFormat("ar-SA", { maximumFractionDigits: 0 }).format(n) + " ر.س";
var fmtNum = (n) => new Intl.NumberFormat("ar-SA").format(n);
var TENANTS = [
	"جمعية البر الخيرية",
	"جمعية نماء للخدمات الاجتماعية",
	"جمعية رعاية الأيتام",
	"جمعية حفظ النعمة",
	"جمعية دعم الأسر المنتجة"
];
var KPIS = [
	{
		label: "إجمالي التبرعات (شهر)",
		value: 4582400,
		delta: 12.4,
		unit: "ر.س",
		tone: "primary"
	},
	{
		label: "إجمالي المصروفات",
		value: 2140300,
		delta: -3.2,
		unit: "ر.س",
		tone: "warning"
	},
	{
		label: "التدفق النقدي الصافي",
		value: 2442100,
		delta: 18.6,
		unit: "ر.س",
		tone: "success"
	},
	{
		label: "المستفيدون النشطون",
		value: 12846,
		delta: 4.1,
		unit: "",
		tone: "info"
	},
	{
		label: "المشاريع النشطة",
		value: 27,
		delta: 2,
		unit: "",
		tone: "primary"
	},
	{
		label: "تنفيذ الميزانية",
		value: 68,
		delta: 5,
		unit: "%",
		tone: "success"
	}
];
var DONATIONS_BY_PROJECT = [
	{
		name: "كفالة الأيتام",
		value: 124e4
	},
	{
		name: "إفطار صائم",
		value: 86e4
	},
	{
		name: "كسوة الشتاء",
		value: 62e4
	},
	{
		name: "السلال الغذائية",
		value: 54e4
	},
	{
		name: "ترميم المساجد",
		value: 41e4
	},
	{
		name: "علاج المرضى",
		value: 38e4
	},
	{
		name: "حفر الآبار",
		value: 312e3
	}
];
var CASH_FLOW_12M = [
	{
		m: "محرم",
		in: 380,
		out: 220
	},
	{
		m: "صفر",
		in: 420,
		out: 260
	},
	{
		m: "ربيع 1",
		in: 510,
		out: 310
	},
	{
		m: "ربيع 2",
		in: 470,
		out: 290
	},
	{
		m: "جمادى 1",
		in: 540,
		out: 320
	},
	{
		m: "جمادى 2",
		in: 610,
		out: 360
	},
	{
		m: "رجب",
		in: 580,
		out: 340
	},
	{
		m: "شعبان",
		in: 720,
		out: 410
	},
	{
		m: "رمضان",
		in: 1240,
		out: 760
	},
	{
		m: "شوال",
		in: 690,
		out: 420
	},
	{
		m: "ذو القعدة",
		in: 540,
		out: 310
	},
	{
		m: "ذو الحجة",
		in: 820,
		out: 480
	}
];
var TOP_DONORS = [
	{
		name: "مؤسسة الراجحي الإنسانية",
		total: 12e5,
		type: "مؤسسة",
		count: 4
	},
	{
		name: "شركة أرامكو السعودية",
		total: 85e4,
		type: "شركة",
		count: 2
	},
	{
		name: "عبدالله بن سليمان العتيبي",
		total: 42e4,
		type: "فرد",
		count: 12
	},
	{
		name: "مؤسسة سليمان الحبيب",
		total: 38e4,
		type: "مؤسسة",
		count: 3
	},
	{
		name: "نورة بنت محمد القحطاني",
		total: 22e4,
		type: "فرد",
		count: 8
	},
	{
		name: "شركة الاتصالات السعودية",
		total: 18e4,
		type: "شركة",
		count: 2
	}
];
var RECENT_TRANSACTIONS = [
	{
		id: "JV-2406-0188",
		date: "1446/10/12",
		desc: "تبرع بنكي - حملة كفالة الأيتام",
		amount: 25e4,
		type: "إيراد",
		status: "مرحّل"
	},
	{
		id: "JV-2406-0187",
		date: "1446/10/12",
		desc: "صرف مساعدة عاجلة - أسرة (ع.م)",
		amount: -8500,
		type: "مصروف",
		status: "بانتظار الموافقة"
	},
	{
		id: "JV-2406-0186",
		date: "1446/10/11",
		desc: "فاتورة مورد - مستلزمات السلال الغذائية",
		amount: -47300,
		type: "مصروف",
		status: "مرحّل"
	},
	{
		id: "JV-2406-0185",
		date: "1446/10/11",
		desc: "تبرع نقدي - حملة إفطار صائم",
		amount: 32e3,
		type: "إيراد",
		status: "مرحّل"
	},
	{
		id: "JV-2406-0184",
		date: "1446/10/10",
		desc: "إيراد وقف - عوائد استثمارية ربعية",
		amount: 18e4,
		type: "إيراد",
		status: "مرحّل"
	},
	{
		id: "JV-2406-0183",
		date: "1446/10/10",
		desc: "رواتب موظفي الإدارة - شهر شوال",
		amount: -312400,
		type: "مصروف",
		status: "مرحّل"
	}
];
var BANK_ACCOUNTS = [
	{
		bank: "مصرف الراجحي",
		iban: "SA03 8000 0000 6080 1016 5519",
		balance: 412e4,
		type: "حساب التبرعات العام"
	},
	{
		bank: "البنك الأهلي السعودي",
		iban: "SA44 1000 0001 2345 6789 0123",
		balance: 184e4,
		type: "كفالة الأيتام (مقيّد)"
	},
	{
		bank: "بنك الرياض",
		iban: "SA22 2000 0001 1122 3344 5566",
		balance: 98e4,
		type: "حساب التشغيل"
	},
	{
		bank: "بنك الإنماء",
		iban: "SA77 0500 0000 9988 7766 5544",
		balance: 612e3,
		type: "الأوقاف"
	}
];
var APPROVALS = [
	{
		id: "APR-1042",
		subject: "اعتماد قيد يومية JV-2406-0187",
		requester: "محاسب: سارة الزهراني",
		amount: 8500,
		type: "قيد يومية",
		level: "المدير المالي",
		date: "اليوم 10:24",
		priority: "عالية"
	},
	{
		id: "APR-1041",
		subject: "اعتماد طلب شراء PR-2406-0073",
		requester: "المشتريات: خالد الدوسري",
		amount: 84200,
		type: "طلب شراء",
		level: "مدير الإدارة",
		date: "اليوم 09:11",
		priority: "متوسطة"
	},
	{
		id: "APR-1040",
		subject: "اعتماد صرف مساعدة - أسرة (ر.س)",
		requester: "الباحث: منى السلمي",
		amount: 12e3,
		type: "مساعدة",
		level: "لجنة المساعدات",
		date: "أمس 16:40",
		priority: "عالية"
	},
	{
		id: "APR-1039",
		subject: "اعتماد ميزانية مشروع كسوة الشتاء",
		requester: "م. المشاريع: فهد العتيبي",
		amount: 62e4,
		type: "ميزانية مشروع",
		level: "المدير التنفيذي",
		date: "أمس 14:02",
		priority: "متوسطة"
	},
	{
		id: "APR-1038",
		subject: "اعتماد فاتورة مورد INV-887",
		requester: "حسابات دائنة: محمد الغامدي",
		amount: 47300,
		type: "فاتورة مورد",
		level: "المدير المالي",
		date: "أمس 11:30",
		priority: "منخفضة"
	}
];
var ALERTS = [
	{
		tone: "destructive",
		text: "تجاوز ميزانية بند (مستلزمات إدارية) بنسبة 8%",
		time: "قبل 12 دقيقة"
	},
	{
		tone: "warning",
		text: "5 طلبات شراء بانتظار موافقتك منذ أكثر من 24 ساعة",
		time: "قبل ساعة"
	},
	{
		tone: "info",
		text: "اقتراب موعد الإقفال الشهري - 3 أيام متبقية",
		time: "اليوم"
	},
	{
		tone: "success",
		text: "تم اعتماد التقرير المالي الربعي من مجلس الإدارة",
		time: "أمس"
	}
];
var PROJECTS = [
	{
		id: "PRJ-014",
		name: "كفالة الأيتام 1446",
		manager: "فهد العتيبي",
		budget: 32e5,
		spent: 198e4,
		donations: 264e4,
		beneficiaries: 1240,
		progress: 62,
		status: "نشط",
		start: "1446/01/01",
		end: "1446/12/30"
	},
	{
		id: "PRJ-015",
		name: "إفطار صائم - رمضان",
		manager: "سارة الزهراني",
		budget: 15e5,
		spent: 146e4,
		donations: 158e4,
		beneficiaries: 24e3,
		progress: 97,
		status: "مكتمل",
		start: "1446/08/15",
		end: "1446/09/30"
	},
	{
		id: "PRJ-016",
		name: "كسوة الشتاء 1446",
		manager: "خالد الدوسري",
		budget: 62e4,
		spent: 11e4,
		donations: 38e4,
		beneficiaries: 3400,
		progress: 18,
		status: "نشط",
		start: "1446/10/01",
		end: "1446/12/15"
	},
	{
		id: "PRJ-017",
		name: "السلال الغذائية الشهرية",
		manager: "منى السلمي",
		budget: 18e5,
		spent: 9e5,
		donations: 102e4,
		beneficiaries: 6200,
		progress: 50,
		status: "نشط",
		start: "1446/01/01",
		end: "1446/12/30"
	},
	{
		id: "PRJ-018",
		name: "علاج المرضى المحتاجين",
		manager: "د. أحمد الشهري",
		budget: 24e5,
		spent: 132e4,
		donations: 18e5,
		beneficiaries: 480,
		progress: 55,
		status: "نشط",
		start: "1446/01/01",
		end: "1446/12/30"
	},
	{
		id: "PRJ-019",
		name: "حفر الآبار - دول إفريقيا",
		manager: "ياسر القرني",
		budget: 9e5,
		spent: 2e5,
		donations: 312e3,
		beneficiaries: 18e3,
		progress: 22,
		status: "نشط",
		start: "1446/06/01",
		end: "1447/05/30"
	},
	{
		id: "PRJ-020",
		name: "ترميم المساجد",
		manager: "عبدالعزيز الحارثي",
		budget: 75e4,
		spent: 41e4,
		donations: 41e4,
		beneficiaries: 12,
		progress: 55,
		status: "نشط",
		start: "1446/03/01",
		end: "1446/12/30"
	},
	{
		id: "PRJ-021",
		name: "تأهيل الأسر المنتجة",
		manager: "هدى المالكي",
		budget: 11e5,
		spent: 48e4,
		donations: 66e4,
		beneficiaries: 240,
		progress: 44,
		status: "نشط",
		start: "1446/02/01",
		end: "1446/12/30"
	}
];
var EMPLOYEES = [
	{
		id: "EMP-001",
		name: "م. عبدالعزيز الحارثي",
		dept: "إدارة المشاريع",
		title: "مدير مشاريع",
		salary: 22e3,
		joined: "1442/01/15",
		status: "نشط"
	},
	{
		id: "EMP-002",
		name: "أ. سارة الزهراني",
		dept: "الإدارة المالية",
		title: "محاسب أول",
		salary: 14e3,
		joined: "1443/03/10",
		status: "نشط"
	},
	{
		id: "EMP-003",
		name: "د. أحمد الشهري",
		dept: "البرامج الصحية",
		title: "مستشار طبي",
		salary: 28e3,
		joined: "1441/06/01",
		status: "نشط"
	},
	{
		id: "EMP-004",
		name: "أ. منى السلمي",
		dept: "المستفيدون",
		title: "باحث اجتماعي",
		salary: 11e3,
		joined: "1444/02/20",
		status: "نشط"
	},
	{
		id: "EMP-005",
		name: "أ. خالد الدوسري",
		dept: "المشتريات",
		title: "أخصائي مشتريات",
		salary: 12500,
		joined: "1443/09/01",
		status: "إجازة"
	},
	{
		id: "EMP-006",
		name: "م. فهد العتيبي",
		dept: "إدارة المشاريع",
		title: "مدير مشروع كفالة",
		salary: 18e3,
		joined: "1442/11/05",
		status: "نشط"
	}
];
var BOARD_MEMBERS = [
	{
		name: "أ. سليمان بن عبدالله الراجحي",
		role: "رئيس مجلس الإدارة",
		since: "1443",
		attendance: 96
	},
	{
		name: "د. فهد بن محمد القحطاني",
		role: "نائب الرئيس",
		since: "1443",
		attendance: 92
	},
	{
		name: "أ. عبدالرحمن بن صالح العمر",
		role: "أمين الصندوق",
		since: "1443",
		attendance: 88
	},
	{
		name: "د. هند بنت ناصر السبيعي",
		role: "عضو",
		since: "1444",
		attendance: 84
	},
	{
		name: "أ. خالد بن يوسف الغامدي",
		role: "عضو",
		since: "1444",
		attendance: 80
	},
	{
		name: "أ. نورة بنت محمد الشهري",
		role: "عضو مستقل",
		since: "1445",
		attendance: 76
	}
];
var MEETINGS = [
	{
		id: "MTG-014",
		title: "اجتماع مجلس الإدارة - الربع الثالث",
		date: "1446/10/20",
		attendees: 6,
		status: "مجدول",
		decisions: 0
	},
	{
		id: "MTG-013",
		title: "اجتماع لجنة المراجعة",
		date: "1446/10/05",
		attendees: 4,
		status: "منعقد",
		decisions: 5
	},
	{
		id: "MTG-012",
		title: "الجمعية العمومية العادية",
		date: "1446/08/15",
		attendees: 84,
		status: "منعقد",
		decisions: 12
	}
];
var GRANTS = [
	{
		id: "GRT-009",
		donor: "الصندوق الخيري الوطني",
		project: "تأهيل الأسر المنتجة",
		amount: 15e5,
		disbursed: 6e5,
		status: "نشطة",
		end: "1447/02"
	},
	{
		id: "GRT-008",
		donor: "صندوق الملك سلمان للإغاثة",
		project: "إغاثة عاجلة - اليمن",
		amount: 24e5,
		disbursed: 24e5,
		status: "مكتملة",
		end: "1446/06"
	},
	{
		id: "GRT-007",
		donor: "بنك التنمية الإسلامي",
		project: "حفر الآبار - إفريقيا",
		amount: 9e5,
		disbursed: 22e4,
		status: "نشطة",
		end: "1447/05"
	},
	{
		id: "GRT-006",
		donor: "وزارة الموارد البشرية",
		project: "تمكين الأسر المنتجة",
		amount: 8e5,
		disbursed: 48e4,
		status: "نشطة",
		end: "1446/12"
	}
];
var ENDOWMENTS = [
	{
		id: "WQF-002",
		name: "وقف بر الوالدين - عمارة سكنية",
		type: "عقاري",
		value: 42e5,
		yearReturn: 38e4,
		status: "مستثمر"
	},
	{
		id: "WQF-003",
		name: "وقف العلم - أسهم متنوعة",
		type: "أسهم",
		value: 18e5,
		yearReturn: 18e4,
		status: "مستثمر"
	},
	{
		id: "WQF-004",
		name: "وقف إفطار صائم",
		type: "نقدي",
		value: 62e4,
		yearReturn: 42e3,
		status: "مستثمر"
	},
	{
		id: "WQF-005",
		name: "وقف كفالة الأيتام",
		type: "صندوق استثماري",
		value: 24e5,
		yearReturn: 196e3,
		status: "مستثمر"
	}
];
var CAMPAIGNS = [
	{
		id: "CMP-021",
		name: "حملة كفالة الأيتام 1446",
		target: 3e6,
		raised: 264e4,
		donors: 1240,
		status: "نشطة",
		end: "1446/12/30"
	},
	{
		id: "CMP-020",
		name: "حملة إفطار صائم - رمضان",
		target: 15e5,
		raised: 158e4,
		donors: 8420,
		status: "مكتملة",
		end: "1446/09/30"
	},
	{
		id: "CMP-019",
		name: "حملة كسوة الشتاء",
		target: 6e5,
		raised: 38e4,
		donors: 2140,
		status: "نشطة",
		end: "1446/12/15"
	},
	{
		id: "CMP-018",
		name: "حملة حفر الآبار",
		target: 9e5,
		raised: 312e3,
		donors: 980,
		status: "نشطة",
		end: "1447/05/30"
	}
];
var PERMISSIONS_MATRIX = [
	{
		role: "المدير التنفيذي",
		finance: "كامل",
		donations: "كامل",
		projects: "كامل",
		procurement: "اعتماد",
		reports: "كامل",
		settings: "قراءة"
	},
	{
		role: "المدير المالي",
		finance: "كامل",
		donations: "قراءة",
		projects: "قراءة",
		procurement: "اعتماد",
		reports: "كامل",
		settings: "—"
	},
	{
		role: "محاسب",
		finance: "إدخال",
		donations: "إدخال",
		projects: "قراءة",
		procurement: "إدخال",
		reports: "قراءة",
		settings: "—"
	},
	{
		role: "مدير المشاريع",
		finance: "قراءة",
		donations: "قراءة",
		projects: "كامل",
		procurement: "طلب",
		reports: "قراءة",
		settings: "—"
	},
	{
		role: "باحث اجتماعي",
		finance: "—",
		donations: "—",
		projects: "قراءة",
		procurement: "—",
		reports: "محدود",
		settings: "—"
	},
	{
		role: "مدقق داخلي",
		finance: "قراءة",
		donations: "قراءة",
		projects: "قراءة",
		procurement: "قراءة",
		reports: "كامل",
		settings: "—"
	}
];
var REPORT_CATEGORIES = [
	{
		title: "التقارير المالية",
		icon: "Wallet",
		items: [
			"الميزانية العمومية",
			"قائمة الأنشطة",
			"قائمة التدفقات النقدية",
			"ميزان المراجعة",
			"الأموال المقيدة وغير المقيدة"
		]
	},
	{
		title: "تقارير التبرعات",
		icon: "HeartHandshake",
		items: [
			"تقرير التبرعات حسب القناة",
			"تقرير المتبرعين المتكررين",
			"تقرير الإيصالات الإلكترونية",
			"تحليل الحملات"
		]
	},
	{
		title: "تقارير المشاريع",
		icon: "FolderKanban",
		items: [
			"تنفيذ الميزانية حسب المشروع",
			"مؤشرات الأداء KPIs",
			"تقرير الإنجاز الزمني",
			"الإيرادات والمصروفات للمشروع"
		]
	},
	{
		title: "تقارير المستفيدين",
		icon: "Users",
		items: [
			"توزيع المستفيدين جغرافياً",
			"تقرير المساعدات المصروفة",
			"تقرير الاستحقاق",
			"تحليل الفئات"
		]
	},
	{
		title: "تقارير المنح",
		icon: "BadgeDollarSign",
		items: [
			"تقرير الالتزامات",
			"صرف المنح",
			"تقرير الجهات المانحة"
		]
	},
	{
		title: "تقارير المشتريات",
		icon: "ShoppingCart",
		items: [
			"تقرير الموردين",
			"أمر الشراء حسب الفترة",
			"مقارنة عروض الأسعار"
		]
	},
	{
		title: "تقارير المخزون",
		icon: "Boxes",
		items: [
			"حركة المخزون",
			"تنبيهات الحد الأدنى",
			"تقرير الجرد الدوري"
		]
	},
	{
		title: "تقارير الموارد البشرية",
		icon: "Briefcase",
		items: [
			"الرواتب الشهرية",
			"الإجازات",
			"الحضور والانصراف"
		]
	},
	{
		title: "تقارير الحوكمة",
		icon: "ShieldCheck",
		items: [
			"سجل التدقيق",
			"فصل المهام",
			"تقرير الصلاحيات"
		]
	},
	{
		title: "تقارير مجلس الإدارة",
		icon: "Landmark",
		items: [
			"تقرير الأداء الربعي",
			"ملخص الأموال المقيدة",
			"تقرير الحملات والإنجازات"
		]
	}
];
var INTEGRATIONS = [
	{
		name: "بوابة الدفع - مدى",
		category: "مدفوعات",
		status: "متصل",
		info: "تم تفعيل الدفع عبر مدى و Apple Pay"
	},
	{
		name: "STC Pay",
		category: "مدفوعات",
		status: "متصل",
		info: "تبرعات صغيرة فورية"
	},
	{
		name: "مصرف الراجحي - Open Banking",
		category: "بنوك",
		status: "متصل",
		info: "ربط الحساب الرئيسي تلقائياً"
	},
	{
		name: "البنك الأهلي السعودي",
		category: "بنوك",
		status: "بانتظار التفعيل",
		info: "ربط الحسابات المقيدة"
	},
	{
		name: "بوابة الفاتورة الإلكترونية (فاتورة)",
		category: "حكومي",
		status: "جاهز",
		info: "متوافق مع متطلبات الزكاة والضريبة"
	},
	{
		name: "خدمة الرسائل القصيرة SMS",
		category: "اتصالات",
		status: "متصل",
		info: "إرسال إيصالات وتنبيهات"
	},
	{
		name: "WhatsApp Business API",
		category: "اتصالات",
		status: "متصل",
		info: "تواصل مع المتبرعين والمستفيدين"
	},
	{
		name: "البريد الإلكتروني SMTP",
		category: "اتصالات",
		status: "متصل",
		info: "smtp.charity-cloud.sa"
	},
	{
		name: "REST API عام",
		category: "تطوير",
		status: "نشط",
		info: "إصدار v1 - 24 نقطة وصول"
	},
	{
		name: "Webhooks",
		category: "تطوير",
		status: "نشط",
		info: "5 مشتركين نشطين"
	}
];
var WORKFLOWS = [
	{
		name: "اعتماد قيد يومية",
		steps: [
			"إنشاء (محاسب)",
			"مراجعة (محاسب أول)",
			"اعتماد (المدير المالي)"
		],
		avg: "4 ساعات",
		active: 12
	},
	{
		name: "اعتماد طلب شراء",
		steps: [
			"طلب (الإدارة)",
			"مراجعة (المشتريات)",
			"اعتماد مالي",
			"اعتماد إداري"
		],
		avg: "1.5 يوم",
		active: 7
	},
	{
		name: "اعتماد صرف مساعدة",
		steps: [
			"دراسة الحالة",
			"لجنة المساعدات",
			"اعتماد المدير",
			"صرف"
		],
		avg: "3 أيام",
		active: 24
	},
	{
		name: "اعتماد مشروع جديد",
		steps: [
			"دراسة الجدوى",
			"اعتماد المشاريع",
			"اعتماد المالية",
			"اعتماد المدير التنفيذي"
		],
		avg: "10 أيام",
		active: 2
	},
	{
		name: "اعتماد ميزانية",
		steps: [
			"إعداد الميزانية",
			"مراجعة مالية",
			"اعتماد المجلس"
		],
		avg: "14 يوم",
		active: 1
	},
	{
		name: "اعتماد فاتورة مورد",
		steps: [
			"استلام الفاتورة",
			"مطابقة مع أمر الشراء",
			"اعتماد مالي",
			"صرف"
		],
		avg: "2 يوم",
		active: 9
	}
];
//#endregion
export { fmtSAR as S, REPORT_CATEGORIES as _, CAMPAIGNS as a, WORKFLOWS as b, EMPLOYEES as c, INTEGRATIONS as d, KPIS as f, RECENT_TRANSACTIONS as g, PROJECTS as h, BOARD_MEMBERS as i, ENDOWMENTS as l, PERMISSIONS_MATRIX as m, APPROVALS as n, CASH_FLOW_12M as o, MEETINGS as p, BANK_ACCOUNTS as r, DONATIONS_BY_PROJECT as s, ALERTS as t, GRANTS as u, TENANTS as v, fmtNum as x, TOP_DONORS as y };
