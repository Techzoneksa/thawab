import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { H as PowerOff, V as Power, pn as Archive } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, P as statusTone, c as ConfirmDialog, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { t as getAuditEntries } from "./audit-DP6UgtXG.mjs";
import { a as deleteWarehouse, c as updateWarehouse, i as deactivateWarehouse, n as activateWarehouse, o as getWarehouse, t as WAREHOUSE_STATUSES } from "./warehouses-sU_fp7nA.mjs";
import { t as Route } from "./inventory.warehouses._id.edit-mWhrLiIz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.warehouses._id.edit-K3JM6Yrg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditWarehousePage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const detailQuery = useQuery({
		queryKey: ["warehouseDetail", id],
		queryFn: () => getWarehouse(id)
	});
	const item = detailQuery.data?.item;
	const itemCount = detailQuery.data?.itemCount ?? 0;
	const movementCount = detailQuery.data?.movementCount ?? 0;
	const totalQty = detailQuery.data?.totalQty ?? 0;
	const hasMovements = detailQuery.data?.hasMovements ?? false;
	const [name, setName] = (0, import_react.useState)("");
	const [location, setLocation] = (0, import_react.useState)("");
	const [manager, setManager] = (0, import_react.useState)("");
	const [capacity, setCapacity] = (0, import_react.useState)("0");
	const [occupancy, setOccupancy] = (0, import_react.useState)("0");
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(null);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	if (item && !hydrated) {
		setName(item.name);
		setLocation(item.location);
		setManager(item.manager);
		setCapacity(String(item.capacity || 0));
		setOccupancy(String(item.occupancy || 0));
		setStatus(item.status || "نشط");
		setNotes(item.notes || "");
		setHydrated(true);
	}
	const handleSave = async () => {
		const errs = [];
		if (!name.trim()) errs.push("اسم المستودع مطلوب");
		if (!location.trim()) errs.push("موقع المستودع مطلوب");
		const cap = parseFloat(capacity) || 0;
		const occ = parseFloat(occupancy) || 0;
		if (cap < 0) errs.push("السعة يجب ألا تكون سالبة");
		if (occ < 0) errs.push("الإشغال يجب ألا يكون سالبًا");
		if (cap > 0 && occ > cap) errs.push("الإشغال لا يمكن أن يتجاوز السعة");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			await updateWarehouse({
				id,
				name: name.trim(),
				location: location.trim(),
				manager: manager || void 0,
				capacity: cap,
				occupancy: occ,
				status,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["warehouses"] });
			queryClient.invalidateQueries({ queryKey: ["warehouseDetail", id] });
			showToast("تم حفظ التعديلات", "success");
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const auditQuery = useQuery({
		queryKey: ["warehouseAudit", id],
		queryFn: () => getAuditEntries({
			entityType: "مستودع",
			entityId: id,
			limit: 50
		}),
		enabled: !!item
	});
	const tabs = [
		{
			id: "basic",
			label: "بيانات المستودع",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات المستودع",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم المستودع",
						required: true,
						error: errors[0],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الموقع",
						required: true,
						error: errors[1],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: location,
							onChange: (e) => setLocation(e.target.value)
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "مدير المستودع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: manager,
							onChange: (e) => setManager(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "السعة",
						error: errors[2] || errors[4],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: capacity,
							onChange: (e) => setCapacity(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الإشغال الحالي",
						error: errors[3] || errors[4],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: occupancy,
							onChange: (e) => setOccupancy(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحالة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: status,
							onChange: (e) => setStatus(e.target.value),
							children: WAREHOUSE_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								children: s
							}, s))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value),
							rows: 3
						})
					})
				]
			})
		},
		{
			id: "summary",
			label: "ملخص",
			badge: hasMovements ? "مرتبط" : void 0,
			content: item ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ملخص المستودع",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "اسم المستودع",
						value: item.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الموقع",
						value: item.location || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الحالة",
						value: item.status,
						tone: item.status === "نشط" ? "success" : "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "السعة",
						value: String(item.capacity || 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الإشغال",
						value: String(item.occupancy || 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الأصناف المسجلة",
						value: String(itemCount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "إجمالي الكمية",
						value: String(totalQty),
						tone: totalQty > 0 ? "warning" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "عدد الحركات",
						value: String(movementCount),
						tone: movementCount > 0 ? "warning" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-lg bg-muted/40 p-3 text-xs text-muted-foreground leading-relaxed",
						children: hasMovements ? "هذا المستودع مرتبط بحركات قائمة. لا يمكن حذفه للحفاظ على سلامة البيانات." : "هذا المستودع غير مرتبط بأي حركة. يمكن أرشفته بأمان إذا لزم الأمر."
					})
				]
			}) : null
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			badge: auditQuery.data?.items.length,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "سجل العمليات",
				children: auditQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "جاري التحميل..."
				}) : (auditQuery.data?.items ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "لا توجد عمليات مسجلة على هذا المستودع."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: (auditQuery.data?.items ?? []).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border bg-card px-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-foreground",
									children: e.action
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground font-mono",
									children: e.timestamp?.slice(0, 16).replace("T", " ")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground mt-0.5",
								children: e.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-muted-foreground mt-0.5",
								children: ["المستخدم: ", e.userName || "—"]
							})
						]
					}, e.id))
				})
			})
		}
	];
	const activateMut = useMutation({
		mutationFn: () => activateWarehouse({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["warehouseDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["warehouses"] });
			queryClient.invalidateQueries({ queryKey: ["warehouseAudit", id] });
			showToast("تم تفعيل المستودع", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deactivateMut = useMutation({
		mutationFn: () => deactivateWarehouse({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["warehouseDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["warehouses"] });
			queryClient.invalidateQueries({ queryKey: ["warehouseAudit", id] });
			showToast("تم إيقاف المستودع", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMut = useMutation({
		mutationFn: () => deleteWarehouse({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["warehouses"] });
			showToast("تم أرشفة المستودع", "success");
			navigate({ to: "/inventory/warehouses" });
		},
		onError: (err) => showToast(err.message, "error")
	});
	if (detailQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المستودعات",
		breadcrumb: ["المخزون", "المستودعات"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المستودعات",
		breadcrumb: ["المخزون", "المستودعات"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-center py-12 text-muted-foreground",
			children: "المستودع غير موجود"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "المستودعات",
		breadcrumb: [
			"المخزون",
			"المستودعات",
			"تعديل"
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
				breadcrumb: [
					{
						label: "المخزون",
						to: "/inventory/items"
					},
					{
						label: "المستودعات",
						to: "/inventory/warehouses"
					},
					{ label: item.name }
				],
				title: item.name,
				subtitle: `${item.location || ""} · ${item.manager || ""}`,
				draftNumber: item.id,
				status: {
					label: item.status,
					tone: statusTone(item.status)
				},
				tabs,
				defaultTab: "basic",
				loading: saving,
				validationErrors: errors,
				primaryLabel: "حفظ التعديلات",
				secondaryLabel: "حفظ وإغلاق",
				showSecondary: false,
				extraActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [item.status === "نشط" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("deactivate"),
					className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium hover:bg-muted transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PowerOff, { size: 15 }), " إيقاف"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("activate"),
					className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium hover:bg-muted transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Power, { size: 15 }), " تفعيل"]
				}), !hasMovements && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("delete"),
					className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { size: 15 }), " أرشفة"]
				})] }),
				onPrimary: handleSave,
				onCancel: () => navigate({ to: "/inventory/warehouses" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "activate",
				onClose: () => setConfirmAction(null),
				onConfirm: () => activateMut.mutate(),
				title: "تفعيل المستودع",
				message: `هل تريد تفعيل المستودع "${item.name}"؟ سيظهر في القوائم المتاحة لإنشاء الحركات.`,
				confirmText: "تفعيل",
				cancelText: "إلغاء",
				loading: activateMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "deactivate",
				onClose: () => setConfirmAction(null),
				onConfirm: () => deactivateMut.mutate(),
				title: "إيقاف المستودع",
				message: `هل تريد إيقاف المستودع "${item.name}"؟ سيختفي من القوائم المتاحة، لكن حركاته القائمة ستبقى مرتبطة به.`,
				confirmText: "إيقاف",
				cancelText: "إلغاء",
				variant: "destructive",
				loading: deactivateMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "delete",
				onClose: () => setConfirmAction(null),
				onConfirm: () => deleteMut.mutate(),
				title: "أرشفة المستودع",
				message: `هل تريد أرشفة المستودع "${item.name}"؟ لن يستطيع أحد استخدامه بعد الآن.`,
				confirmText: "أرشفة",
				cancelText: "إلغاء",
				variant: "destructive",
				loading: deleteMut.isPending
			})
		]
	});
}
//#endregion
export { EditWarehousePage as component };
