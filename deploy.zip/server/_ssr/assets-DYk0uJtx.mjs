import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { Ht as CircleX, P as Search, T as SquarePen, U as Plus, _ as TrendingDown, jt as Eye, ln as ArrowRight, r as Wrench, v as Trash2 } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as deleteFixedAsset, d as returnFromMaintenance, f as sellFixedAsset, l as getFixedAssets, o as depreciateFixedAsset, p as transferFixedAsset, r as ASSET_STATUSES, s as disposeFixedAsset, u as maintainFixedAsset } from "./assets-C0jGCeQN.mjs";
import { s as getSuppliers } from "./suppliers-CkCPjZYa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assets-DYk0uJtx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [categoryFilter, setCategoryFilter] = (0, import_react.useState)("الكل");
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [actionTarget, setActionTarget] = (0, import_react.useState)(null);
	const [depDraft, setDepDraft] = (0, import_react.useState)({
		amount: "",
		date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
		notes: ""
	});
	const [transferDraft, setTransferDraft] = (0, import_react.useState)({
		toLocation: "",
		toResponsible: "",
		reason: "",
		notes: ""
	});
	const [maintainDraft, setMaintainDraft] = (0, import_react.useState)({
		cost: "",
		reason: "",
		notes: ""
	});
	const [sellDraft, setSellDraft] = (0, import_react.useState)({
		salePrice: "",
		buyer: "",
		notes: ""
	});
	const { data, isLoading, error } = useQuery({
		queryKey: ["fixedAssets", {
			search: searchQuery,
			status: statusFilter,
			category: categoryFilter
		}],
		queryFn: () => getFixedAssets({
			search: searchQuery,
			status: statusFilter,
			category: categoryFilter
		})
	});
	const { data: suppliersData } = useQuery({
		queryKey: ["suppliers-all"],
		queryFn: () => getSuppliers({})
	});
	const detailQuery = useQuery({
		queryKey: ["fixedAssetDetail", detailId],
		queryFn: async () => detailId ? await fetch(`/api/assets?id=${detailId}`).then((r) => r.json()) : null,
		enabled: !!detailId
	});
	const transferMutation = useMutation({
		mutationFn: transferFixedAsset,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail"] });
			showToast("تم نقل الأصل بنجاح", "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const maintainMutation = useMutation({
		mutationFn: maintainFixedAsset,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail"] });
			showToast("تم تسجيل الصيانة", "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const returnMaintenanceMutation = useMutation({
		mutationFn: returnFromMaintenance,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail"] });
			showToast("تم إنهاء الصيانة وإعادة الأصل للعمل", "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const depreciateMutation = useMutation({
		mutationFn: depreciateFixedAsset,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail"] });
			showToast("تم تسجيل الإهلاك بنجاح", "success");
			setActionTarget(null);
			setDepDraft({
				amount: "",
				date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
				notes: ""
			});
		},
		onError: (err) => showToast(err.message, "error")
	});
	const disposeMutation = useMutation({
		mutationFn: disposeFixedAsset,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail"] });
			showToast("تم استبعاد الأصل", "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const sellMutation = useMutation({
		mutationFn: sellFixedAsset,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			queryClient.invalidateQueries({ queryKey: ["fixedAssetDetail"] });
			showToast("تم تسجيل بيع الأصل", "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deleteFixedAsset,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			showToast("تم حذف الأصل", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => {
		navigate({ to: "/assets/new" });
	};
	const openEdit = (a) => {
		if ([
			"مستبعد",
			"مباع",
			"ملغي"
		].includes(a.status)) {
			showToast(`لا يمكن تعديل أصل في حالة ${a.status}`, "error");
			return;
		}
		navigate({
			to: "/assets/$id/edit",
			params: { id: a.id }
		});
	};
	const items = data?.items || [];
	const total = data?.total || 0;
	const suppliers = suppliersData?.items || [];
	const stats = {
		active: items.filter((a) => a.status === "نشط").length,
		maintenance: items.filter((a) => a.status === "تحت الصيانة").length,
		disposed: items.filter((a) => [
			"مستبعد",
			"مباع",
			"ملغي"
		].includes(a.status)).length,
		totalCost: items.reduce((s, a) => s + (a.cost || 0), 0),
		totalDepreciation: items.reduce((s, a) => s + (a.accumulatedDepreciation || 0), 0),
		totalBookValue: items.reduce((s, a) => s + ((a.cost || 0) - (a.accumulatedDepreciation || 0)), 0),
		total
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: ["الرئيسية", "الأصول"],
		title: "الأصول الثابتة",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
			data: items.map((a) => ({
				id: a.id,
				code: a.code,
				name: a.name,
				category: a.category,
				location: a.location,
				cost: a.cost,
				accumulatedDepreciation: a.accumulatedDepreciation,
				bookValue: a.cost - a.accumulatedDepreciation,
				status: a.status,
				condition: a.condition,
				purchaseDate: a.purchaseDate,
				responsiblePerson: a.responsiblePerson
			})),
			filename: "fixed-assets.csv"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: openAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "إضافة أصل"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "إجمالي الأصول"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold tabular-nums",
							children: fmtSAR(stats.total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "التكلفة الإجمالية"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-primary tabular-nums",
							children: fmtSAR(stats.totalCost)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "إجمالي الإهلاك"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-warning tabular-nums",
							children: fmtSAR(stats.totalDepreciation)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "القيمة الدفترية"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-success tabular-nums",
							children: fmtSAR(stats.totalBookValue)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:flex items-center gap-2 mb-3 hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1 min-w-[200px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
							size: 14,
							className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
							placeholder: "بحث...",
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "rounded-lg border bg-background py-1.5 px-3 text-sm",
						value: statusFilter,
						onChange: (e) => setStatusFilter(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), ASSET_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "rounded-lg border bg-background py-1.5 px-3 text-sm",
						value: categoryFilter,
						onChange: (e) => setCategoryFilter(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "أجهزة مكتبية" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "أجهزة حاسب" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "معدات" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "سيارات" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "أثاث" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مباني" })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "الأصول الثابتة",
				count: `${total} أصل`
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء جلب الأصول",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["fixedAssets"] }),
					children: "إعادة المحاولة"
				})
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد أصول",
				description: "ابدأ بإضافة أول أصل ثابت لمتابعة إهلاكه وصيانته",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة أصل"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الاسم",
					"الفئة",
					"التكلفة",
					"القيمة الدفترية",
					"الحالة",
					""
				],
				rows: items,
				renderRow: (a) => {
					const bookValue = (a.cost || 0) - (a.accumulatedDepreciation || 0);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => navigate({
								to: "/assets/$id/edit",
								params: { id: a.id }
							}),
							className: "font-semibold hover:text-primary text-right",
							children: a.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground font-mono",
							children: a.code || a.id
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: a.category ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "info",
							children: a.category
						}) : "—" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "tabular-nums",
							children: fmtSAR(a.cost)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "tabular-nums font-bold",
							children: fmtSAR(bookValue)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: statusTone(a.status),
							children: a.status
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getAssetActions(a, navigate, openEdit, setActionTarget, setDeleteTarget) }) })
					] });
				},
				mobileCard: (a) => {
					const bookValue = (a.cost || 0) - (a.accumulatedDepreciation || 0);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(a.status),
									children: a.status
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-muted-foreground",
									children: a.code || a.id
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => navigate({
									to: "/assets/$id/edit",
									params: { id: a.id }
								}),
								className: "font-semibold text-right hover:text-primary",
								children: a.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: [
									a.location || "—",
									" · ",
									a.responsiblePerson || "بدون مسؤول"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 mt-2 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "التكلفة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold tabular-nums",
										children: fmtSAR(a.cost)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "القيمة الدفترية"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-success tabular-nums",
										children: fmtSAR(bookValue)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "الإهلاك المتراكم"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "tabular-nums",
										children: fmtSAR(a.accumulatedDepreciation)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "الحالة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: a.condition || "—" })] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2 mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px]",
									onClick: () => navigate({
										to: "/assets/$id/edit",
										params: { id: a.id }
									}),
									children: "تفاصيل"
								}), a.status === "نشط" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg bg-warning/15 text-warning text-xs font-semibold py-2 min-h-[36px]",
									onClick: () => setActionTarget({
										asset: a,
										action: "depreciate"
									}),
									children: "إهلاك"
								})]
							})
						]
					}, a.id);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailId && !actionTarget,
				onClose: () => setDetailId(null),
				title: `تفاصيل الأصل: ${detailQuery.data?.item?.name || ""}`,
				onSave: () => setDetailId(null),
				saveText: "إغلاق",
				children: detailQuery.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الرمز",
									value: detailQuery.data.item.code || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الفئة",
									value: detailQuery.data.item.category || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحالة",
									value: detailQuery.data.item.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحالة الفنية",
									value: detailQuery.data.item.condition || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الموقع",
									value: detailQuery.data.item.location || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "المسؤول",
									value: detailQuery.data.item.responsiblePerson || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "التكلفة",
									value: fmtSAR(detailQuery.data.item.cost)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الإهلاك المتراكم",
									value: fmtSAR(detailQuery.data.item.accumulatedDepreciation)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "القيمة الدفترية",
									value: fmtSAR(detailQuery.data.bookValue)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "العمر الإنتاجي",
									value: `${detailQuery.data.item.usefulLifeMonths} شهر`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "القيمة المتبقية",
									value: fmtSAR(detailQuery.data.item.salvageValue)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "طريقة الإهلاك",
									value: detailQuery.data.item.depreciationMethod
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "تاريخ الشراء",
									value: detailQuery.data.item.purchaseDate || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "المورد",
									value: suppliers.find((s) => s.id === detailQuery.data.item.supplierId)?.name || "—"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-primary/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-muted-foreground mb-1",
								children: "سجل الأصل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "قيود الإهلاك"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-base",
										children: fmtSAR(detailQuery.data.depreciationCount)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "حركات/تحويلات"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-base",
										children: fmtSAR(detailQuery.data.movementCount)
									})]
								})]
							})]
						}),
						detailQuery.data.item.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-1",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm",
							children: detailQuery.data.item.notes
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!actionTarget && actionTarget.action === "depreciate",
				onClose: () => setActionTarget(null),
				title: `إهلاك الأصل: ${actionTarget?.asset.name || ""}`,
				onSave: () => {
					if (actionTarget) {
						const amt = parseFloat(depDraft.amount) || 0;
						if (amt <= 0) return showToast("يرجى إدخال مبلغ إهلاك صحيح", "error");
						depreciateMutation.mutate({
							id: actionTarget.asset.id,
							amount: amt,
							date: depDraft.date,
							notes: depDraft.notes,
							userId: user?.id,
							userName: user?.name
						});
					}
				},
				loading: depreciateMutation.isPending,
				saveText: "تأكيد الإهلاك",
				children: actionTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-warning/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-bold text-warning mb-1",
								children: "معلومات الإهلاك"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["التكلفة: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtSAR(actionTarget.asset.cost) })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["الإهلاك المتراكم: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtSAR(actionTarget.asset.accumulatedDepreciation) })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										"القيمة الدفترية:",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-success",
											children: fmtSAR(actionTarget.asset.cost - actionTarget.asset.accumulatedDepreciation)
										})
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["القيمة المتبقية: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtSAR(actionTarget.asset.salvageValue) })] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "col-span-2",
										children: [
											"الحد الأقصى للإهلاك المتبقي:",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtSAR(actionTarget.asset.cost - actionTarget.asset.accumulatedDepreciation - (actionTarget.asset.salvageValue || 0)) })
										]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "مبلغ الإهلاك *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: depDraft.amount,
							onChange: (e) => setDepDraft({
								...depDraft,
								amount: e.target.value
							}),
							placeholder: "0"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "تاريخ الإهلاك"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: depDraft.date,
							onChange: (e) => setDepDraft({
								...depDraft,
								date: e.target.value
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							rows: 2,
							value: depDraft.notes,
							onChange: (e) => setDepDraft({
								...depDraft,
								notes: e.target.value
							})
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!actionTarget && actionTarget.action === "transfer",
				onClose: () => setActionTarget(null),
				title: `نقل الأصل: ${actionTarget?.asset.name || ""}`,
				onSave: () => {
					if (actionTarget) transferMutation.mutate({
						id: actionTarget.asset.id,
						toLocation: transferDraft.toLocation,
						toResponsible: transferDraft.toResponsible,
						reason: transferDraft.reason,
						notes: transferDraft.notes,
						userId: user?.id,
						userName: user?.name
					});
				},
				loading: transferMutation.isPending,
				saveText: "تأكيد النقل",
				children: actionTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-info/10 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold text-info mb-1",
									children: "الموقع الحالي"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["الموقع: ", actionTarget.asset.location || "—"] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: ["المسؤول: ", actionTarget.asset.responsiblePerson || "—"] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الموقع الجديد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: transferDraft.toLocation,
							onChange: (e) => setTransferDraft({
								...transferDraft,
								toLocation: e.target.value
							}),
							placeholder: "الموقع الجديد"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "المسؤول الجديد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: transferDraft.toResponsible,
							onChange: (e) => setTransferDraft({
								...transferDraft,
								toResponsible: e.target.value
							}),
							placeholder: "اسم المسؤول الجديد"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "سبب النقل"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: transferDraft.reason,
							onChange: (e) => setTransferDraft({
								...transferDraft,
								reason: e.target.value
							}),
							placeholder: "سبب النقل"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							rows: 2,
							value: transferDraft.notes,
							onChange: (e) => setTransferDraft({
								...transferDraft,
								notes: e.target.value
							})
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!actionTarget && actionTarget.action === "maintain",
				onClose: () => setActionTarget(null),
				title: `صيانة الأصل: ${actionTarget?.asset.name || ""}`,
				onSave: () => {
					if (actionTarget) maintainMutation.mutate({
						id: actionTarget.asset.id,
						cost: parseFloat(maintainDraft.cost) || 0,
						reason: maintainDraft.reason,
						notes: maintainDraft.notes,
						userId: user?.id,
						userName: user?.name
					});
				},
				loading: maintainMutation.isPending,
				saveText: "تسجيل الصيانة",
				children: actionTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "تكلفة الصيانة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: maintainDraft.cost,
							onChange: (e) => setMaintainDraft({
								...maintainDraft,
								cost: e.target.value
							}),
							placeholder: "0"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "سبب/وصف الصيانة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							rows: 2,
							value: maintainDraft.reason,
							onChange: (e) => setMaintainDraft({
								...maintainDraft,
								reason: e.target.value
							}),
							placeholder: "مثال: صيانة دورية، إصلاح عطل..."
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							rows: 2,
							value: maintainDraft.notes,
							onChange: (e) => setMaintainDraft({
								...maintainDraft,
								notes: e.target.value
							})
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget && actionTarget.action === "returnMaintenance",
				onClose: () => setActionTarget(null),
				onConfirm: () => {
					if (actionTarget) returnMaintenanceMutation.mutate({
						id: actionTarget.asset.id,
						condition: detailQuery.data?.item?.condition,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "إنهاء الصيانة",
				message: `هل تريد إعادة الأصل "${actionTarget?.asset.name}" للعمل بعد الصيانة؟`,
				confirmText: "إعادة للعمل",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!actionTarget && actionTarget.action === "sell",
				onClose: () => setActionTarget(null),
				title: `بيع الأصل: ${actionTarget?.asset.name || ""}`,
				onSave: () => {
					if (actionTarget) sellMutation.mutate({
						id: actionTarget.asset.id,
						salePrice: parseFloat(sellDraft.salePrice) || 0,
						buyer: sellDraft.buyer,
						notes: sellDraft.notes,
						userId: user?.id,
						userName: user?.name
					});
				},
				loading: sellMutation.isPending,
				saveText: "تأكيد البيع",
				children: actionTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "p-3 bg-warning/10 text-xs",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								"القيمة الدفترية الحالية:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: fmtSAR(actionTarget.asset.cost - actionTarget.asset.accumulatedDepreciation) })
							] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "سعر البيع"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: sellDraft.salePrice,
							onChange: (e) => setSellDraft({
								...sellDraft,
								salePrice: e.target.value
							}),
							placeholder: "0"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "المشتري"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: sellDraft.buyer,
							onChange: (e) => setSellDraft({
								...sellDraft,
								buyer: e.target.value
							}),
							placeholder: "اسم المشتري"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							rows: 2,
							value: sellDraft.notes,
							onChange: (e) => setSellDraft({
								...sellDraft,
								notes: e.target.value
							})
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget && actionTarget.action === "dispose",
				onClose: () => setActionTarget(null),
				onConfirm: () => {
					if (actionTarget) disposeMutation.mutate({
						id: actionTarget.asset.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "استبعاد الأصل",
				message: `هل تريد استبعاد الأصل "${actionTarget?.asset.name}"؟ سيصبح read-only ويحتفظ به النظام للسجل التاريخي.`,
				confirmText: "استبعاد",
				cancelText: "تراجع",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: () => {
					if (deleteTarget) deleteMutation.mutate({
						id: deleteTarget.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "تأكيد الحذف",
				message: deleteTarget ? `هل تريد حذف الأصل "${deleteTarget.name}"؟ لا يمكن الحذف إذا كان مرتبطاً بحركات أو إهلاك.` : "",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			})
		]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-semibold",
			children: value
		})]
	});
}
function getAssetActions(a, navigate, openEdit, setActionTarget, setDeleteTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => navigate({
			to: "/assets/$id/edit",
			params: { id: a.id }
		})
	}];
	const readOnly = [
		"مستبعد",
		"مباع",
		"ملغي"
	].includes(a.status);
	if (!readOnly) {
		actions.push({
			label: "تعديل",
			icon: SquarePen,
			onClick: () => openEdit(a)
		});
		actions.push({
			label: "تسجيل إهلاك",
			icon: TrendingDown,
			onClick: () => setActionTarget({
				asset: a,
				action: "depreciate"
			})
		});
		actions.push({
			label: "نقل",
			icon: ArrowRight,
			onClick: () => setActionTarget({
				asset: a,
				action: "transfer"
			})
		});
		if (a.status !== "تحت الصيانة") actions.push({
			label: "تسجيل صيانة",
			icon: Wrench,
			onClick: () => setActionTarget({
				asset: a,
				action: "maintain"
			})
		});
		else actions.push({
			label: "إنهاء الصيانة",
			icon: Wrench,
			onClick: () => setActionTarget({
				asset: a,
				action: "returnMaintenance"
			})
		});
		actions.push({
			label: "بيع",
			icon: TrendingDown,
			onClick: () => setActionTarget({
				asset: a,
				action: "sell"
			})
		});
		actions.push({
			label: "استبعاد",
			icon: CircleX,
			onClick: () => setActionTarget({
				asset: a,
				action: "dispose"
			})
		});
	}
	if (!readOnly && !a.accumulatedDepreciation) actions.push({
		label: "حذف",
		icon: Trash2,
		variant: "destructive",
		onClick: () => setDeleteTarget(a)
	});
	return actions;
}
//#endregion
export { Page as component };
