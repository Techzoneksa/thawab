import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { O as ShoppingCart, P as Search, T as SquarePen, U as Plus, Z as Package, b as ToggleLeft, h as TriangleAlert, jt as Eye, ln as ArrowRight, v as Trash2, y as ToggleRight } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, F as useAuth, N as showToast, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { s as getWarehouses } from "./warehouses-sU_fp7nA.mjs";
import { d as receiveInventoryItem, f as transferInventoryItem, i as adjustInventoryItem, l as getInventoryItems, o as deactivateInventoryItem, r as activateInventoryItem, s as deleteInventoryItem, t as ITEM_STATUSES, u as issueInventoryItem } from "./inventory-items-mo3tbFC9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.items-CpO7W_7B.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [categoryFilter, setCategoryFilter] = (0, import_react.useState)("الكل");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [moveTarget, setMoveTarget] = (0, import_react.useState)(null);
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const [moveDraft, setMoveDraft] = (0, import_react.useState)({
		type: "receive",
		quantity: "",
		fromWarehouseId: "",
		toWarehouseId: "",
		notes: ""
	});
	const { data, isLoading, error } = useQuery({
		queryKey: ["inventoryItems", {
			search: searchQuery,
			category: categoryFilter,
			status: statusFilter
		}],
		queryFn: () => getInventoryItems({
			search: searchQuery,
			category: categoryFilter,
			status: statusFilter
		})
	});
	const { data: warehousesData } = useQuery({
		queryKey: ["warehouses-all"],
		queryFn: () => getWarehouses({})
	});
	const detailQuery = useQuery({
		queryKey: ["inventoryItemDetail", detailId],
		queryFn: async () => detailId ? await fetch(`/api/inventory/items?id=${detailId}`).then((r) => r.json()) : null,
		enabled: !!detailId
	});
	const activateMutation = useMutation({
		mutationFn: activateInventoryItem,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			showToast("تم تفعيل الصنف", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deactivateMutation = useMutation({
		mutationFn: deactivateInventoryItem,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			showToast("تم تعطيل الصنف", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const receiveMutation = useMutation({
		mutationFn: receiveInventoryItem,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItemDetail"] });
			showToast("تم استلام الصنف وتحديث المخزون", "success");
			setMoveTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const issueMutation = useMutation({
		mutationFn: issueInventoryItem,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItemDetail"] });
			showToast("تم صرف الصنف وتحديث المخزون", "success");
			setMoveTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const adjustMutation = useMutation({
		mutationFn: adjustInventoryItem,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItemDetail"] });
			showToast("تم تسوية الصنف", "success");
			setMoveTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const transferMutation = useMutation({
		mutationFn: transferInventoryItem,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItemDetail"] });
			showToast("تم تحويل الصنف بين المستودعات", "success");
			setMoveTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deleteInventoryItem,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			showToast("تم حذف الصنف", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => {
		navigate({ to: "/inventory/items/new" });
	};
	const openEdit = (i) => {
		navigate({
			to: "/inventory/items/$id/edit",
			params: { id: i.id }
		});
	};
	const openMove = (i, type) => {
		setMoveTarget(i);
		setMoveDraft({
			type,
			quantity: "",
			fromWarehouseId: i.warehouseId || "",
			toWarehouseId: "",
			notes: ""
		});
	};
	const handleMove = () => {
		if (!moveTarget) return;
		const qty = parseFloat(moveDraft.quantity) || 0;
		if (qty <= 0) return showToast("يرجى إدخال كمية صحيحة", "error");
		const base = {
			id: moveTarget.id,
			quantity: qty,
			notes: moveDraft.notes,
			userId: user?.id,
			userName: user?.name
		};
		if (moveDraft.type === "receive") receiveMutation.mutate({
			...base,
			warehouseId: moveTarget.warehouseId || void 0
		});
		else if (moveDraft.type === "issue") issueMutation.mutate({
			...base,
			warehouseId: moveTarget.warehouseId || void 0
		});
		else if (moveDraft.type === "adjust") adjustMutation.mutate({
			...base,
			warehouseId: moveTarget.warehouseId || void 0
		});
		else if (moveDraft.type === "transfer") {
			if (!moveDraft.fromWarehouseId || !moveDraft.toWarehouseId) return showToast("يرجى تحديد المستودع المصدر والهدف", "error");
			transferMutation.mutate({
				...base,
				fromWarehouseId: moveDraft.fromWarehouseId,
				toWarehouseId: moveDraft.toWarehouseId
			});
		}
	};
	const items = data?.items || [];
	const total = data?.total || 0;
	const warehouses = warehousesData?.items || [];
	const stats = {
		total: items.length,
		active: items.filter((i) => i.status === "نشط").length,
		lowStock: items.filter((i) => i.quantity <= i.minQuantity && i.quantity > 0).length,
		outOfStock: items.filter((i) => i.quantity === 0).length,
		totalValue: items.reduce((s, i) => s + (i.quantity || 0) * (i.price || 0), 0)
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المخزون",
			"الأصناف"
		],
		title: "إدارة الأصناف",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
			data: items.map((i) => ({
				id: i.id,
				name: i.name,
				sku: i.sku,
				unit: i.unit,
				category: i.category,
				warehouseId: i.warehouseId || "",
				quantity: i.quantity,
				minQuantity: i.minQuantity,
				price: i.price,
				status: i.status
			})),
			filename: "inventory-items.csv"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: openAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "إضافة صنف"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "إجمالي الأصناف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold tabular-nums",
							children: fmtSAR(stats.total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "نشط"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-success tabular-nums",
							children: fmtSAR(stats.active)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "منخفض / نفد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-warning tabular-nums",
							children: fmtSAR(stats.lowStock + stats.outOfStock)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "قيمة المخزون"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-primary tabular-nums",
							children: fmtSAR(stats.totalValue)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:flex items-center gap-2 mb-3 hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1 min-w-[200px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
							size: 14,
							className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
							placeholder: "بحث...",
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "rounded-lg border bg-background py-1.5 px-3 text-sm",
						value: categoryFilter,
						onChange: (e) => setCategoryFilter(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مساعدات" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مواد غذائية" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "أجهزة" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "قرطاسية" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "معدات" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "rounded-lg border bg-background py-1.5 px-3 text-sm",
						value: statusFilter,
						onChange: (e) => setStatusFilter(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), ITEM_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "إدارة الأصناف",
				count: `${total} صنف`
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء جلب الأصناف",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["inventoryItems"] }),
					children: "إعادة المحاولة"
				})
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد أصناف",
				description: "ابدأ بإضافة أول صنف للمخزون",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة صنف"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"SKU",
					"الصنف",
					"الفئة",
					"الكمية",
					"السعر",
					"الحالة",
					""
				],
				rows: items,
				renderRow: (i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: i.sku || i.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => navigate({
							to: "/inventory/items/$id/edit",
							params: { id: i.id }
						}),
						className: "font-semibold hover:text-primary text-right",
						children: i.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: warehouses.find((w) => w.id === i.warehouseId)?.name || "بدون مستودع"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: i.category ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "info",
						children: i.category
					}) : "—" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, {
						className: "tabular-nums font-bold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: stockTone(i.quantity, i.minQuantity),
								children: [
									fmtSAR(i.quantity),
									" ",
									i.unit
								]
							}),
							i.quantity <= i.minQuantity && i.quantity > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
								size: 11,
								className: "inline ms-1 text-warning"
							}),
							i.quantity === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
								size: 11,
								className: "inline ms-1 text-destructive"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums",
						children: fmtSAR(i.price)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(i.status),
						children: i.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getItemActions(i, setDetailId, openEdit, openMove, activateMutation, deactivateMutation, setDeleteTarget) }) })
				] }),
				mobileCard: (i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(i.status),
								children: i.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted-foreground",
								children: i.sku || i.id
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => navigate({
								to: "/inventory/items/$id/edit",
								params: { id: i.id }
							}),
							className: "font-semibold text-right hover:text-primary",
							children: i.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mt-1",
							children: warehouses.find((w) => w.id === i.warehouseId)?.name || "بدون مستودع"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `tabular-nums font-bold ${stockTone(i.quantity, i.minQuantity)}`,
								children: [
									fmtSAR(i.quantity),
									" ",
									i.unit
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: ["الحد الأدنى: ", fmtSAR(i.minQuantity)]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 mt-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px]",
									onClick: () => openMove(i, "receive"),
									children: "استلام"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px]",
									onClick: () => openMove(i, "issue"),
									children: "صرف"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px]",
									onClick: () => openEdit(i),
									children: "تعديل"
								})
							]
						})
					]
				}, i.id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailId && !moveTarget,
				onClose: () => setDetailId(null),
				title: `تفاصيل الصنف: ${detailQuery.data?.item?.name || ""}`,
				onSave: () => setDetailId(null),
				saveText: "إغلاق",
				children: detailQuery.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "SKU",
									value: detailQuery.data.item.sku || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الفئة",
									value: detailQuery.data.item.category || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الوحدة",
									value: detailQuery.data.item.unit
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحالة",
									value: detailQuery.data.item.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الكمية",
									value: `${fmtSAR(detailQuery.data.item.quantity)} ${detailQuery.data.item.unit}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحد الأدنى",
									value: `${fmtSAR(detailQuery.data.item.minQuantity)} ${detailQuery.data.item.unit}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "السعر",
									value: fmtSAR(detailQuery.data.item.price)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "المستودع",
									value: warehouses.find((w) => w.id === detailQuery.data.item.warehouseId)?.name || "—"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-primary/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-muted-foreground mb-1",
								children: "ارتباطات الصنف"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "حركات المخزون"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-base",
										children: fmtSAR(detailQuery.data.movementCount)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-center",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-muted-foreground",
										children: "سطور أوامر شراء"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-base",
										children: fmtSAR(detailQuery.data.poLineCount)
									})]
								})]
							})]
						}),
						detailQuery.data.item.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-1",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm",
							children: detailQuery.data.item.notes
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!moveTarget && !detailId,
				onClose: () => setMoveTarget(null),
				title: `${moveTarget?.name || ""} — حركة مخزون`,
				onSave: handleMove,
				loading: receiveMutation.isPending || issueMutation.isPending || adjustMutation.isPending || transferMutation.isPending,
				children: moveTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-4 gap-2",
							children: [
								"receive",
								"issue",
								"adjust",
								"transfer"
							].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: `rounded-lg border p-2 text-xs font-bold transition-colors ${moveDraft.type === t ? "bg-primary text-primary-foreground border-primary" : "bg-background hover:bg-muted"}`,
								onClick: () => setMoveDraft({
									...moveDraft,
									type: t
								}),
								children: t === "receive" ? "استلام" : t === "issue" ? "صرف" : t === "adjust" ? "تسوية" : "تحويل"
							}, t))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-info/10 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-info mb-1",
								children: moveDraft.type === "receive" ? "📥 استلام" : moveDraft.type === "issue" ? "📤 صرف" : moveDraft.type === "adjust" ? "⚖ تسوية" : "🔄 تحويل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs",
								children: [
									"الرصيد الحالي: ",
									fmtSAR(moveTarget.quantity),
									" ",
									moveTarget.unit,
									moveDraft.type === "issue" && moveTarget.quantity === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-destructive font-bold mt-1",
										children: "⚠ لا يمكن الصرف — الرصيد صفر"
									})
								]
							})]
						}),
						moveDraft.type === "transfer" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "من المستودع *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: moveDraft.fromWarehouseId,
							onChange: (e) => setMoveDraft({
								...moveDraft,
								fromWarehouseId: e.target.value
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— اختر —"
							}), warehouses.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: w.id,
								children: w.name
							}, w.id))]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "إلى المستودع *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: moveDraft.toWarehouseId,
							onChange: (e) => setMoveDraft({
								...moveDraft,
								toWarehouseId: e.target.value
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— اختر —"
							}), warehouses.filter((w) => w.id !== moveDraft.fromWarehouseId).map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: w.id,
								children: w.name
							}, w.id))]
						})] })] }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: moveDraft.type === "adjust" ? "الرصيد الجديد *" : "الكمية *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: moveDraft.quantity,
							onChange: (e) => setMoveDraft({
								...moveDraft,
								quantity: e.target.value
							}),
							placeholder: "0"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							rows: 2,
							value: moveDraft.notes,
							onChange: (e) => setMoveDraft({
								...moveDraft,
								notes: e.target.value
							})
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: () => {
					if (deleteTarget) deleteMutation.mutate({
						id: deleteTarget.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "تأكيد الحذف",
				message: deleteTarget ? `هل تريد حذف الصنف "${deleteTarget.name}"؟ لا يمكن الحذف إذا كان مرتبطاً بحركات أو أوامر شراء.` : "",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			})
		]
	});
}
function stockTone(qty, min) {
	if (qty === 0) return "text-destructive";
	if (qty <= min) return "text-warning";
	return "";
}
function statusTone(s) {
	if (s === "نشط") return "success";
	if (s === "مغلق") return "destructive";
	return "muted";
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-semibold",
			children: value
		})]
	});
}
function getItemActions(i, setDetailId, openEdit, openMove, activateMutation, deactivateMutation, setDeleteTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => setDetailId(i.id)
	}, {
		label: "تعديل",
		icon: SquarePen,
		onClick: () => openEdit(i)
	}];
	if (i.status !== "مغلق") {
		actions.push({
			label: "استلام",
			icon: ShoppingCart,
			onClick: () => openMove(i, "receive")
		});
		actions.push({
			label: "صرف",
			icon: ArrowRight,
			onClick: () => openMove(i, "issue")
		});
		actions.push({
			label: "تسوية",
			icon: Package,
			onClick: () => openMove(i, "adjust")
		});
		actions.push({
			label: "تحويل",
			icon: ArrowRight,
			onClick: () => openMove(i, "transfer")
		});
	}
	if (i.status === "نشط") actions.push({
		label: "تعطيل",
		icon: ToggleLeft,
		onClick: () => deactivateMutation.mutate({ id: i.id })
	});
	else actions.push({
		label: "تفعيل",
		icon: ToggleRight,
		onClick: () => activateMutation.mutate({ id: i.id })
	});
	actions.push({
		label: "حذف",
		icon: Trash2,
		variant: "destructive",
		onClick: () => setDeleteTarget(i)
	});
	return actions;
}
//#endregion
export { Page as component };
