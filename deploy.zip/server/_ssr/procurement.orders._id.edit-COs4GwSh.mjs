import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { Yt as Check, lt as Lock, m as Truck, on as Ban, pn as Archive } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, P as statusTone, c as ConfirmDialog, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { t as getAuditEntries } from "./audit-DP6UgtXG.mjs";
import { a as deletePurchaseOrder, c as receivePurchaseOrder, l as updatePurchaseOrder, n as cancelPurchaseOrder, o as getPurchaseOrder, r as closePurchaseOrder, t as approvePurchaseOrder } from "./purchase-orders-DLaoDtmH.mjs";
import { t as Route } from "./procurement.orders._id.edit-CBUFb_Ds.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.orders._id.edit-COs4GwSh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditOrderPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const detailQuery = useQuery({
		queryKey: ["purchaseOrderDetail", id],
		queryFn: () => getPurchaseOrder(id)
	});
	const item = detailQuery.data?.item;
	const lines = detailQuery.data?.lines ?? [];
	const [subject, setSubject] = (0, import_react.useState)("");
	const [date, setDate] = (0, import_react.useState)("");
	const [deliveryDate, setDeliveryDate] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(null);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [receiptEntries, setReceiptEntries] = (0, import_react.useState)([]);
	if (item && !hydrated) {
		setSubject(item.subject);
		setDate(item.date);
		setDeliveryDate(item.deliveryDate || "");
		setNotes(item.notes || "");
		setHydrated(true);
	}
	if (item && receiptEntries.length === 0 && lines.length > 0) setReceiptEntries(lines.map((l) => ({
		lineId: l.id,
		orderedQty: l.quantity,
		alreadyReceivedQty: l.receivedQuantity,
		receivingQty: 0
	})));
	const isReadOnly = !!item && (item.status === "مغلق" || item.status === "ملغي" || item.status === "تم الاستلام");
	const canApprove = item?.status === "مسودة";
	const canReceive = item?.status === "معتمد" || item?.status === "تم الاستلام جزئيًا";
	const canClose = item?.status === "تم الاستلام" || item?.status === "تم الاستلام جزئيًا";
	const canCancel = item?.status !== "ملغي" && item?.status !== "مغلق";
	const total = (0, import_react.useMemo)(() => lines.reduce((s, l) => s + (l.quantity || 0) * (l.unitPrice || 0), 0), [lines]);
	const receivedAmount = item?.receivedAmount ?? 0;
	const handleSave = async () => {
		if (isReadOnly) {
			showToast("لا يمكن تعديل أمر مغلق أو ملغي أو مكتمل الاستلام", "error");
			return;
		}
		if (item?.status !== "مسودة") {
			showToast("لا يمكن تعديل أمر الشراء إلا في حالة المسودة", "error");
			return;
		}
		const errs = [];
		if (!subject.trim()) errs.push("موضوع أمر الشراء مطلوب");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			await updatePurchaseOrder({
				id,
				subject: subject.trim(),
				date,
				deliveryDate: deliveryDate || void 0,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseOrderDetail", id] });
			showToast("تم حفظ التعديلات", "success");
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const handleReceive = async () => {
		const validEntries = receiptEntries.filter((r) => r.receivingQty > 0);
		if (validEntries.length === 0) {
			showToast("أدخل كمية استلام واحدة على الأقل", "error");
			return;
		}
		try {
			await receivePurchaseOrder({
				id,
				receipts: validEntries.map((r) => ({
					lineId: r.lineId,
					receivedQty: r.receivingQty
				})),
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseOrderDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["purchaseOrderAudit", id] });
			queryClient.invalidateQueries({ queryKey: ["inventoryItems"] });
			showToast("تم تسجيل الاستلام", "success");
			setConfirmAction(null);
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الاستلام", "error");
		}
	};
	const auditQuery = useQuery({
		queryKey: ["purchaseOrderAudit", id],
		queryFn: () => getAuditEntries({
			entityType: "أمر شراء",
			entityId: id,
			limit: 50
		}),
		enabled: !!item
	});
	const tabs = [
		{
			id: "basic",
			label: "بيانات الأمر",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات أمر الشراء",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "موضوع أمر الشراء",
						required: true,
						error: errors[0],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: subject,
							onChange: (e) => setSubject(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "تاريخ الأمر",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: date,
							onChange: (e) => setDate(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "تاريخ التوريد المتوقع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: deliveryDate,
							onChange: (e) => setDeliveryDate(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value),
							rows: 3
						})
					})
				]
			})
		},
		{
			id: "lines",
			label: "بنود الأمر",
			badge: lines.length,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "بنود أمر الشراء",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-xl border bg-card overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "min-w-full text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-muted/60 text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground w-10",
											children: "#"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground",
											children: "الوصف"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground w-24",
											children: "الكمية"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground w-20",
											children: "الوحدة"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground w-32",
											children: "السعر"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground w-32",
											children: "الإجمالي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-3 py-2 font-semibold text-muted-foreground w-32",
											children: "مستلم"
										})
									] })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 text-muted-foreground tabular-nums",
											children: i + 1
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2",
											children: l.description
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 tabular-nums",
											children: l.quantity
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 text-muted-foreground",
											children: l.unit || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 tabular-nums",
											children: fmtSAR(l.unitPrice)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 font-bold tabular-nums",
											children: fmtSAR(l.quantity * l.unitPrice)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2 tabular-nums",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: l.receivedQuantity >= l.quantity ? "text-success font-bold" : l.receivedQuantity > 0 ? "text-warning font-semibold" : "text-muted-foreground",
												children: [
													l.receivedQuantity,
													" / ",
													l.quantity
												]
											})
										})
									]
								}, l.id)) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("tfoot", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t-2 bg-muted/30",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											colSpan: 5,
											className: "px-3 py-3 text-left font-semibold",
											children: "الإجمالي"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-3 font-bold tabular-nums",
											children: fmtSAR(total)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-3 font-bold tabular-nums text-success",
											children: fmtSAR(receivedAmount)
										})
									]
								}) })
							]
						})
					})
				})
			})
		},
		{
			id: "receive",
			label: "استلام البنود",
			badge: canReceive ? receiptEntries.filter((r) => r.receivingQty > 0).length : void 0,
			content: !canReceive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "استلام البنود",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-muted/40 p-4 text-sm text-muted-foreground text-center",
					children: [
						"لا يمكن تسجيل استلام في الحالة الحالية (",
						item?.status,
						"). اعتمد الأمر أولاً ثم سجل الاستلام."
					]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "استلام البنود",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg bg-info/10 border border-info/30 px-3 py-2 text-xs mb-3",
					children: "أدخل الكميات المستلمة فعليًا. سيتم تحديث الكمية في المخزون تلقائيًا بعد التأكيد."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border bg-card overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "min-w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-muted/60 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground",
										children: "الوصف"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-28",
										children: "مطلوب"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-28",
										children: "مستلم سابقًا"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-32",
										children: "استلام الآن"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: receiptEntries.map((r) => {
								const line = lines.find((l) => l.id === r.lineId);
								const remaining = r.orderedQty - r.alreadyReceivedQty;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-2",
											children: line?.description
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-3 py-2 tabular-nums",
											children: [
												r.orderedQty,
												" ",
												line?.unit || ""
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-3 py-2 tabular-nums text-muted-foreground",
											children: [
												r.alreadyReceivedQty,
												" ",
												line?.unit || ""
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-3 py-1.5",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "number",
												min: "0",
												step: "0.01",
												max: remaining,
												value: r.receivingQty || "",
												onChange: (e) => setReceiptEntries(receiptEntries.map((x) => x.lineId === r.lineId ? {
													...x,
													receivingQty: parseFloat(e.target.value) || 0
												} : x)),
												dir: "ltr",
												placeholder: "0",
												className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm font-mono tabular-nums min-h-[36px]"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-[10px] text-muted-foreground mt-1",
												children: [
													"المتبقي: ",
													remaining,
													" ",
													line?.unit || ""
												]
											})]
										})
									]
								}, r.lineId);
							}) })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-t bg-muted/30 px-3 py-3 flex justify-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setConfirmAction("receive"),
							disabled: !receiptEntries.some((r) => r.receivingQty > 0),
							className: "inline-flex items-center gap-1.5 rounded-lg bg-primary text-primary-foreground px-4 py-2 text-sm font-semibold hover:opacity-90 disabled:opacity-50 min-h-[40px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, { size: 15 }), " تأكيد الاستلام"]
						})
					})]
				})]
			})
		},
		{
			id: "summary",
			label: "ملخص",
			content: item ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ملخص أمر الشراء",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الموضوع",
						value: item.subject
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "المورد",
						value: item.supplierId ? "مرتبط" : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الحالة",
						value: item.status,
						tone: statusTone(item.status)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "تاريخ الأمر",
						value: item.date
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "تاريخ التوريد",
						value: item.deliveryDate || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "إجمالي الأمر",
						value: fmtSAR(total)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "المستلم حتى الآن",
						value: fmtSAR(receivedAmount),
						tone: receivedAmount >= total ? "success" : "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "المتبقي",
						value: fmtSAR(Math.max(0, total - receivedAmount)),
						tone: total - receivedAmount > 0 ? "warning" : "success"
					})
				]
			}) : null
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			badge: auditQuery.data?.items.length,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "سجل العمليات",
				children: auditQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "جاري التحميل..."
				}) : (auditQuery.data?.items ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "لا توجد عمليات مسجلة على هذا الأمر."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: (auditQuery.data?.items ?? []).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border bg-card px-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-foreground",
									children: e.action
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground font-mono",
									children: e.timestamp?.slice(0, 16).replace("T", " ")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground mt-0.5",
								children: e.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-muted-foreground mt-0.5",
								children: ["المستخدم: ", e.userName || "—"]
							})
						]
					}, e.id))
				})
			})
		}
	];
	const approveMut = useMutation({
		mutationFn: () => approvePurchaseOrder({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseOrderDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["purchaseOrderAudit", id] });
			showToast("تم اعتماد أمر الشراء", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const cancelMut = useMutation({
		mutationFn: () => cancelPurchaseOrder({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseOrderDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["purchaseOrderAudit", id] });
			showToast("تم إلغاء أمر الشراء", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const closeMut = useMutation({
		mutationFn: () => closePurchaseOrder({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			queryClient.invalidateQueries({ queryKey: ["purchaseOrderDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["purchaseOrderAudit", id] });
			showToast("تم إغلاق الأمر", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMut = useMutation({
		mutationFn: () => deletePurchaseOrder({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseOrders"] });
			showToast("تم حذف الأمر", "success");
			navigate({ to: "/procurement/orders" });
		},
		onError: (err) => showToast(err.message, "error")
	});
	if (detailQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "أوامر الشراء",
		breadcrumb: ["المشتريات", "أوامر الشراء"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "أوامر الشراء",
		breadcrumb: ["المشتريات", "أوامر الشراء"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-center py-12 text-muted-foreground",
			children: "أمر الشراء غير موجود"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "أوامر الشراء",
		breadcrumb: [
			"المشتريات",
			"أوامر الشراء",
			"تعديل"
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
				breadcrumb: [
					{
						label: "المشتريات",
						to: "/procurement/requests"
					},
					{
						label: "أوامر الشراء",
						to: "/procurement/orders"
					},
					{ label: item.subject }
				],
				title: item.subject,
				subtitle: `${fmtSAR(total)} · مستلم ${fmtSAR(receivedAmount)}`,
				draftNumber: item.id,
				status: {
					label: item.status,
					tone: statusTone(item.status)
				},
				isReadOnly,
				readonlyReason: isReadOnly ? `أمر الشراء في حالة "${item.status}". هذا السجل مغلق للتعديل.` : item.status !== "مسودة" ? "لا يمكن تعديل البيانات إلا في حالة المسودة. يمكنك تسجيل الاستلام من تبويب 'استلام البنود'." : void 0,
				tabs,
				defaultTab: "basic",
				loading: saving,
				validationErrors: errors,
				primaryLabel: "حفظ التعديلات",
				secondaryLabel: "حفظ وإغلاق",
				showSecondary: false,
				extraActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					canApprove && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("approve"),
						className: "inline-flex items-center gap-1.5 rounded-lg border border-success/40 bg-success/10 px-3 py-2 text-sm font-medium text-success hover:bg-success/20 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { size: 15 }), " اعتماد"]
					}),
					canClose && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("close"),
						className: "inline-flex items-center gap-1.5 rounded-lg border border-info/40 bg-info/10 px-3 py-2 text-sm font-medium text-info hover:bg-info/20 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { size: 15 }), " إغلاق الأمر"]
					}),
					canCancel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("cancel"),
						className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { size: 15 }), " إلغاء"]
					}),
					item.status === "مسودة" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmAction("delete"),
						className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors min-h-[40px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { size: 15 }), " حذف"]
					})
				] }),
				onPrimary: handleSave,
				onCancel: () => navigate({ to: "/procurement/orders" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "approve",
				onClose: () => setConfirmAction(null),
				onConfirm: () => approveMut.mutate(),
				title: "اعتماد أمر الشراء",
				message: `هل تريد اعتماد أمر الشراء "${item.subject}"؟ بعد الاعتماد يمكنك تسجيل الاستلام.`,
				confirmText: "اعتماد",
				cancelText: "تراجع",
				loading: approveMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "close",
				onClose: () => setConfirmAction(null),
				onConfirm: () => closeMut.mutate(),
				title: "إغلاق الأمر",
				message: `هل تريد إغلاق أمر الشراء "${item.subject}"؟ الإغلاق يعني اكتمال الاستلام وعدم توقع أي حركات إضافية.`,
				confirmText: "إغلاق",
				cancelText: "تراجع",
				loading: closeMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "cancel",
				onClose: () => setConfirmAction(null),
				onConfirm: () => cancelMut.mutate(),
				title: "إلغاء أمر الشراء",
				message: `هل تريد إلغاء أمر الشراء "${item.subject}"؟`,
				confirmText: "إلغاء",
				cancelText: "تراجع",
				variant: "destructive",
				loading: cancelMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "delete",
				onClose: () => setConfirmAction(null),
				onConfirm: () => deleteMut.mutate(),
				title: "حذف أمر الشراء",
				message: `هل تريد حذف أمر الشراء "${item.subject}" نهائيًا؟`,
				confirmText: "حذف",
				cancelText: "تراجع",
				variant: "destructive",
				loading: deleteMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "receive",
				onClose: () => setConfirmAction(null),
				onConfirm: handleReceive,
				title: "تأكيد الاستلام",
				message: `هل تريد تسجيل استلام ${receiptEntries.filter((r) => r.receivingQty > 0).length} بندًا؟ سيتم تحديث المخزون تلقائيًا.`,
				confirmText: "تأكيد",
				cancelText: "تراجع"
			})
		]
	});
}
//#endregion
export { EditOrderPage as component };
