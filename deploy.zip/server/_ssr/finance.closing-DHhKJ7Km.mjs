import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { Ct as GitBranch, J as Pencil, P as Search, U as Plus, Zt as Calendar, jt as Eye, lt as Lock, ut as LockOpen, v as Trash2, wt as Funnel } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, h as EntityFormDrawer, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { x as fmtNum } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.closing-DHhKJ7Km.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var API_BASE = "/api/finance/periods";
var PERIOD_STATUSES = [
	"مفتوحة",
	"قيد الإقفال",
	"مقفلة",
	"معاد فتحتها"
];
async function getPeriods(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب الفترات المالية");
	return res.json();
}
async function getPeriod(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات الفترة المالية");
	return res.json();
}
async function createPeriod(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة الفترة المالية");
	}
	return (await res.json()).item;
}
async function updatePeriod(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث الفترة المالية");
	}
	return (await res.json()).item;
}
async function closePeriod(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "close"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إقفال الفترة المالية");
	}
	return (await res.json()).item;
}
async function reopenPeriod(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "reopen"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إعادة فتح الفترة المالية");
	}
	return (await res.json()).item;
}
async function deletePeriod(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف الفترة المالية");
	}
}
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [actionTarget, setActionTarget] = (0, import_react.useState)(null);
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const [formName, setFormName] = (0, import_react.useState)("");
	const [formStartDate, setFormStartDate] = (0, import_react.useState)("");
	const [formEndDate, setFormEndDate] = (0, import_react.useState)("");
	const [formNotes, setFormNotes] = (0, import_react.useState)("");
	const [closeNotes, setCloseNotes] = (0, import_react.useState)("");
	const { data, isLoading, error } = useQuery({
		queryKey: ["periods", {
			search: searchQuery,
			status: statusFilter
		}],
		queryFn: () => getPeriods({
			search: searchQuery,
			status: statusFilter
		})
	});
	const periods = data?.items || [];
	const total = data?.total || 0;
	const { data: detailData } = useQuery({
		queryKey: ["period", detailId],
		queryFn: () => detailId ? getPeriod(detailId) : Promise.resolve(null),
		enabled: !!detailId
	});
	const createMutation = useMutation({
		mutationFn: createPeriod,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["periods"] });
			showToast("تم إضافة الفترة المالية بنجاح", "success");
			setAddOpen(false);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const updateMutation = useMutation({
		mutationFn: updatePeriod,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["periods"] });
			queryClient.invalidateQueries({ queryKey: ["period"] });
			showToast("تم تحديث الفترة المالية بنجاح", "success");
			setAddOpen(false);
			setEditing(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deletePeriod,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["periods"] });
			showToast("تم حذف الفترة المالية بنجاح", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const closeMutation = useMutation({
		mutationFn: closePeriod,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["periods"] });
			queryClient.invalidateQueries({ queryKey: ["period"] });
			showToast("تم إقفال الفترة المالية بنجاح", "success");
			setActionTarget(null);
			setCloseNotes("");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const reopenMutation = useMutation({
		mutationFn: reopenPeriod,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["periods"] });
			queryClient.invalidateQueries({ queryKey: ["period"] });
			showToast("تم إعادة فتح الفترة المالية بنجاح", "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => {
		setEditing(null);
		setFormName("");
		setFormStartDate("");
		setFormEndDate("");
		setFormNotes("");
		setAddOpen(true);
	};
	const openEdit = (p) => {
		if (p.status === "مقفلة") {
			showToast("لا يمكن تعديل فترة مقفلة. أعد فتحها أولاً.", "error");
			return;
		}
		setEditing(p);
		setFormName(p.name);
		setFormStartDate(p.startDate);
		setFormEndDate(p.endDate);
		setFormNotes(p.notes || "");
		setAddOpen(true);
	};
	const handleSave = () => {
		if (!formName.trim()) return showToast("يرجى إدخال اسم الفترة", "error");
		if (!formStartDate) return showToast("يرجى تحديد تاريخ البداية", "error");
		if (!formEndDate) return showToast("يرجى تحديد تاريخ النهاية", "error");
		if (formStartDate > formEndDate) return showToast("تاريخ البداية يجب أن يكون قبل تاريخ النهاية", "error");
		const basePayload = {
			name: formName,
			startDate: formStartDate,
			endDate: formEndDate,
			notes: formNotes,
			userId: user?.id,
			userName: user?.name
		};
		if (editing) updateMutation.mutate({
			id: editing.id,
			...basePayload
		});
		else createMutation.mutate(basePayload);
	};
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleActionConfirm = () => {
		if (!actionTarget) return;
		if (actionTarget.action === "close") closeMutation.mutate({
			id: actionTarget.id,
			notes: closeNotes,
			userId: user?.id,
			userName: user?.name
		});
		else reopenMutation.mutate({
			id: actionTarget.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const stats = {
		open: periods.filter((p) => p.status === "مفتوحة").length,
		closed: periods.filter((p) => p.status === "مقفلة").length,
		reopened: periods.filter((p) => p.status === "معاد فتحتها").length,
		total
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المالية",
			"الإقفال المالي"
		],
		title: "الإقفال المالي للفترات",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: openAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " فترة جديدة"]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs text-muted-foreground mb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GitBranch, { size: 13 }), " إجمالي الفترات"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold tabular-nums",
							children: fmtNum(stats.total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs text-muted-foreground mb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { size: 13 }), " مفتوحة"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-warning tabular-nums",
							children: fmtNum(stats.open)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs text-muted-foreground mb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { size: 13 }), " مقفلة"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-success tabular-nums",
							children: fmtNum(stats.closed)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 text-xs text-muted-foreground mb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockOpen, { size: 13 }), " معاد فتحتها"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-info tabular-nums",
							children: fmtNum(stats.reopened)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث بالاسم...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الحالة",
					options: ["الكل", ...PERIOD_STATUSES],
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "الفترات المالية",
				count: `${fmtNum(total)} فترة`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 })
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء جلب الفترات المالية",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["periods"] }),
					children: "إعادة المحاولة"
				})
			}) : periods.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد فترات مالية",
				description: "ابدأ بإضافة أول فترة مالية (شهرية أو ربع سنوية أو سنوية)",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة فترة"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الفترة",
					"البداية",
					"النهاية",
					"الحالة",
					"أُقفلت بواسطة",
					""
				],
				rows: periods,
				renderRow: (p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setDetailId(p.id),
						className: "font-semibold hover:text-primary text-right",
						children: p.name
					}), p.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate max-w-[180px]",
						children: p.notes
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: p.startDate
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: p.endDate
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(p.status),
						children: p.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-xs",
						children: p.closedByName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-semibold",
							children: p.closedByName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-muted-foreground",
							children: p.closedAt
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted-foreground",
							children: "—"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getPeriodActions(p, setDetailId, openEdit, setDeleteTarget, setActionTarget) }) })
				] }),
				mobileCard: (p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2 mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setDetailId(p.id),
								className: "text-sm font-bold hover:text-primary text-right",
								children: p.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(p.status),
								children: p.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 text-xs text-muted-foreground mb-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, {
									size: 11,
									className: "inline ml-1"
								}), p.startDate] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "→" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.endDate })
							]
						}),
						p.closedByName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground",
							children: [
								"أُقفلت بواسطة: ",
								p.closedByName,
								" · ",
								p.closedAt
							]
						})
					]
				}, p.id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: addOpen,
				onClose: () => {
					setAddOpen(false);
					setEditing(null);
				},
				title: editing ? "تعديل فترة مالية" : "إضافة فترة مالية جديدة",
				onSave: handleSave,
				loading: createMutation.isPending || updateMutation.isPending,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "اسم الفترة *"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							value: formName,
							onChange: (e) => setFormName(e.target.value),
							placeholder: "مثال: شهر شوال 1446، الربع الأول 1446، السنة 1446"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold text-muted-foreground",
								children: "تاريخ البداية *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
								value: formStartDate,
								onChange: (e) => setFormStartDate(e.target.value)
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold text-muted-foreground",
								children: "تاريخ النهاية *"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
								value: formEndDate,
								onChange: (e) => setFormEndDate(e.target.value)
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
							rows: 2,
							value: formNotes,
							onChange: (e) => setFormNotes(e.target.value),
							placeholder: "ملاحظات حول الفترة..."
						})] }),
						editing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-info/10 p-3 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold mb-1",
									children: "معلومات الإقفال"
								}),
								editing.closedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									"أُقفلت في ",
									editing.closedAt,
									" بواسطة ",
									editing.closedByName
								] }),
								editing.reopenedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1",
									children: [
										"أُعيد فتحها في ",
										editing.reopenedAt,
										" بواسطة ",
										editing.reopenedByName
									]
								})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailId && !addOpen,
				onClose: () => setDetailId(null),
				title: `تفاصيل الفترة: ${detailData?.item?.name || ""}`,
				onSave: () => setDetailId(null),
				saveText: "إغلاق",
				children: detailData && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحالة",
									value: detailData.item.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "من تاريخ",
									value: detailData.item.startDate
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "إلى تاريخ",
									value: detailData.item.endDate
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "أنشأ بواسطة",
									value: detailData.item.createdBy || "—"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-primary/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-muted-foreground mb-2",
								children: "إحصائيات الفترة"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
										label: "إجمالي القيود",
										value: fmtNum(detailData.stats.totalEntries)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
										label: "مرحّلة",
										value: fmtNum(detailData.stats.postedEntries),
										tone: "success"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
										label: "مسودة",
										value: fmtNum(detailData.stats.draftEntries),
										tone: "warning"
									})
								]
							})]
						}),
						detailData.item.closedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-success/10",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-bold text-success mb-1",
									children: "معلومات الإقفال"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs",
									children: ["التاريخ: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: detailData.item.closedAt
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs",
									children: ["بواسطة: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: detailData.item.closedByName
									})]
								})
							]
						}),
						detailData.item.reopenedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-warning/10",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-bold text-warning mb-1",
									children: "معلومات إعادة الفتح"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs",
									children: ["التاريخ: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: detailData.item.reopenedAt
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs",
									children: ["بواسطة: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: detailData.item.reopenedByName
									})]
								})
							]
						}),
						detailData.item.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-1",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm",
							children: detailData.item.notes
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: handleDelete,
				title: "حذف الفترة المالية",
				message: "سيتم حذف الفترة المالية نهائياً. لا يمكن حذف الفترات المقفلة.",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			actionTarget?.action === "close" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!actionTarget,
				onClose: () => setActionTarget(null),
				title: `إقفال الفترة: ${actionTarget?.name || ""}`,
				onSave: handleActionConfirm,
				saveText: "تأكيد الإقفال",
				loading: closeMutation.isPending,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-warning/10 p-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold text-warning mb-2",
							children: "⚠ تنبيهات قبل الإقفال"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "text-xs space-y-1 pr-4 list-disc",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "سيتم منع أي تعديل على القيود ضمن هذه الفترة" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "لا يمكن حذف الفترة بعد الإقفال" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "يجب أن تكون جميع القيود مرحّلة ومتوازنة أولاً" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "يتم تسجيل هذا الإجراء في سجل التدقيق" })
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "ملاحظات الإقفال"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						rows: 3,
						value: closeNotes,
						onChange: (e) => setCloseNotes(e.target.value),
						placeholder: "ملاحظات اختيارية حول الإقفال..."
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget && actionTarget.action === "reopen",
				onClose: () => setActionTarget(null),
				onConfirm: handleActionConfirm,
				title: "إعادة فتح الفترة",
				message: actionTarget ? `هل تريد إعادة فتح الفترة "${actionTarget.name}"؟ سيتم السماح بإضافة وتعديل القيود مرة أخرى، ويبقى السجل في سجل التدقيق.` : "",
				confirmText: "إعادة الفتح",
				cancelText: "إلغاء",
				variant: "default"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: statusFilter,
						onChange: (e) => setStatusFilter(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), PERIOD_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
					})] })
				})
			})
		]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-semibold",
			children: value
		})]
	});
}
function StatBox({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `font-bold tabular-nums ${tone === "success" ? "text-success" : tone === "warning" ? "text-warning" : ""}`,
			children: value
		})]
	});
}
function getPeriodActions(p, setDetailId, openEdit, setDeleteTarget, setActionTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => setDetailId(p.id)
	}];
	if (p.status === "مفتوحة") {
		actions.push({
			label: "تعديل",
			icon: Pencil,
			onClick: () => openEdit(p)
		});
		actions.push({
			label: "إقفال الفترة",
			icon: Lock,
			onClick: () => setActionTarget({
				id: p.id,
				name: p.name,
				action: "close"
			})
		});
		actions.push({
			label: "حذف",
			icon: Trash2,
			onClick: () => setDeleteTarget(p.id),
			variant: "destructive"
		});
	}
	if (p.status === "مقفلة") actions.push({
		label: "إعادة الفتح",
		icon: LockOpen,
		onClick: () => setActionTarget({
			id: p.id,
			name: p.name,
			action: "reopen"
		})
	});
	if (p.status === "معاد فتحتها") actions.push({
		label: "إقفال مرة أخرى",
		icon: Lock,
		onClick: () => setActionTarget({
			id: p.id,
			name: p.name,
			action: "close"
		})
	});
	return actions;
}
//#endregion
export { Page as component };
