import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { H as PowerOff, V as Power, pn as Archive } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, P as statusTone, c as ConfirmDialog, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { a as deleteSupplier, c as updateSupplier, i as deactivateSupplier, n as activateSupplier, o as getSupplier, t as SUPPLIER_STATUSES } from "./suppliers-CkCPjZYa.mjs";
import { t as getAuditEntries } from "./audit-DP6UgtXG.mjs";
import { t as Route } from "./procurement.suppliers._id.edit-BQrBo6wP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.suppliers._id.edit-CeynAwYd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditSupplierPage() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const detailQuery = useQuery({
		queryKey: ["supplierDetail", id],
		queryFn: () => getSupplier(id)
	});
	const item = detailQuery.data?.item;
	const orderCount = detailQuery.data?.orderCount ?? 0;
	const assetCount = detailQuery.data?.assetCount ?? 0;
	const movementCount = detailQuery.data?.movementCount ?? 0;
	const hasTransactions = detailQuery.data?.hasTransactions ?? false;
	const [name, setName] = (0, import_react.useState)("");
	const [activity, setActivity] = (0, import_react.useState)("");
	const [contactPerson, setContactPerson] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [taxNumber, setTaxNumber] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [rating, setRating] = (0, import_react.useState)("0");
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(null);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	if (item && !hydrated) {
		setName(item.name);
		setActivity(item.activity);
		setContactPerson(item.contactPerson || "");
		setPhone(item.phone || "");
		setEmail(item.email || "");
		setTaxNumber(item.taxNumber || "");
		setAddress(item.address || "");
		setRating(String(item.rating || 0));
		setStatus(item.status || "نشط");
		setNotes(item.notes || "");
		setHydrated(true);
	}
	const isReadOnly = !!item && hasTransactions;
	const handleSave = async () => {
		if (isReadOnly) {
			showToast("لا يمكن تعديل مورد مرتبط بحركات", "error");
			return;
		}
		const errs = [];
		if (!name.trim()) errs.push("اسم المورد مطلوب");
		if (!activity.trim()) errs.push("نشاط المورد مطلوب");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			await updateSupplier({
				id,
				name: name.trim(),
				activity: activity.trim(),
				contactPerson: contactPerson || void 0,
				phone: phone || void 0,
				email: email || void 0,
				taxNumber: taxNumber || void 0,
				address: address || void 0,
				rating: parseFloat(rating) || 0,
				status,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["suppliers"] });
			queryClient.invalidateQueries({ queryKey: ["supplierDetail", id] });
			showToast("تم حفظ التعديلات", "success");
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const auditQuery = useQuery({
		queryKey: ["supplierAudit", id],
		queryFn: () => getAuditEntries({
			entityType: "مورد",
			entityId: id,
			limit: 50
		}),
		enabled: !!item
	});
	const tabs = [
		{
			id: "basic",
			label: "البيانات الأساسية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات المورد",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم المورد",
						required: true,
						error: errors[0],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "نشاط المورد",
						required: true,
						error: errors[1],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: activity,
							onChange: (e) => setActivity(e.target.value)
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الشخص المسؤول",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: contactPerson,
							onChange: (e) => setContactPerson(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "رقم الجوال",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: phone,
							onChange: (e) => setPhone(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "البريد الإلكتروني",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "email",
							value: email,
							onChange: (e) => setEmail(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الرقم الضريبي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: taxNumber,
							onChange: (e) => setTaxNumber(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "العنوان",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: address,
							onChange: (e) => setAddress(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "التقييم",
						hint: "من 1 إلى 5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							max: "5",
							step: "0.5",
							value: rating,
							onChange: (e) => setRating(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحالة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: status,
							onChange: (e) => setStatus(e.target.value),
							children: SUPPLIER_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								children: s
							}, s))
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value),
							rows: 3
						})
					})
				]
			})
		},
		{
			id: "summary",
			label: "ملخص",
			badge: hasTransactions ? "مرتبط" : void 0,
			content: item ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ملخص المورد",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "اسم المورد",
						value: item.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "النشاط",
						value: item.activity || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الحالة",
						value: item.status,
						tone: status === "نشط" ? "success" : "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "التقييم",
						value: `${item.rating || 0} / 5`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الرصيد",
						value: fmtSAR(item.balance || 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "أوامر شراء مرتبطة",
						value: String(orderCount),
						tone: orderCount > 0 ? "warning" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "أصول مرتبطة",
						value: String(assetCount),
						tone: assetCount > 0 ? "warning" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "حركات مرتبطة",
						value: String(movementCount),
						tone: movementCount > 0 ? "warning" : "default"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-lg bg-muted/40 p-3 text-xs text-muted-foreground leading-relaxed",
						children: hasTransactions ? "هذا المورد مرتبط بحركات قائمة. لا يمكن حذفه للحفاظ على سلامة البيانات، كما أن بعض الحقول لا يمكن تعديلها." : "هذا المورد غير مرتبط بأي حركة. يمكن حذفه بأمان إذا لزم الأمر."
					})
				]
			}) : null
		},
		{
			id: "audit",
			label: "سجل التدقيق",
			badge: auditQuery.data?.items.length,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "سجل العمليات",
				children: auditQuery.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "جاري التحميل..."
				}) : (auditQuery.data?.items ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs text-muted-foreground",
					children: "لا توجد عمليات مسجلة على هذا المورد."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-2",
					children: (auditQuery.data?.items ?? []).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border bg-card px-3 py-2 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-semibold text-foreground",
									children: e.action
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground font-mono",
									children: e.timestamp?.slice(0, 16).replace("T", " ")
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-muted-foreground mt-0.5",
								children: e.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-muted-foreground mt-0.5",
								children: ["المستخدم: ", e.userName || "—"]
							})
						]
					}, e.id))
				})
			})
		}
	];
	const activateMut = useMutation({
		mutationFn: () => activateSupplier({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["supplierDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["suppliers"] });
			queryClient.invalidateQueries({ queryKey: ["supplierAudit", id] });
			showToast("تم تفعيل المورد", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deactivateMut = useMutation({
		mutationFn: () => deactivateSupplier({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["supplierDetail", id] });
			queryClient.invalidateQueries({ queryKey: ["suppliers"] });
			queryClient.invalidateQueries({ queryKey: ["supplierAudit", id] });
			showToast("تم إيقاف المورد", "success");
			setConfirmAction(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMut = useMutation({
		mutationFn: () => deleteSupplier({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["suppliers"] });
			showToast("تم حذف المورد", "success");
			navigate({ to: "/procurement/suppliers" });
		},
		onError: (err) => showToast(err.message, "error")
	});
	if (detailQuery.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الموردين",
		breadcrumb: ["المشتريات", "الموردين"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الموردين",
		breadcrumb: ["المشتريات", "الموردين"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-center py-12 text-muted-foreground",
			children: "المورد غير موجود"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "الموردين",
		breadcrumb: [
			"المشتريات",
			"الموردين",
			"تعديل"
		],
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
				breadcrumb: [
					{
						label: "المشتريات",
						to: "/procurement/requests"
					},
					{
						label: "الموردين",
						to: "/procurement/suppliers"
					},
					{ label: item.name }
				],
				title: item.name,
				subtitle: `${item.activity || ""} · ${item.phone || ""}`,
				draftNumber: item.id,
				status: {
					label: item.status || "—",
					tone: statusTone(item.status)
				},
				isReadOnly,
				readonlyReason: isReadOnly ? "هذا المورد مرتبط بحركات قائمة (أوامر شراء / أصول / حركات). تعديل بعض الحقول محظور للحفاظ على سلامة البيانات." : void 0,
				tabs,
				defaultTab: "basic",
				loading: saving,
				validationErrors: errors,
				primaryLabel: "حفظ التعديلات",
				secondaryLabel: "حفظ وإغلاق",
				showSecondary: false,
				extraActions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [item.status === "نشط" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("deactivate"),
					className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium hover:bg-muted transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PowerOff, { size: 15 }), " إيقاف"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("activate"),
					className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium hover:bg-muted transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Power, { size: 15 }), " تفعيل"]
				}), !hasTransactions && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setConfirmAction("delete"),
					className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-2 text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors min-h-[40px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { size: 15 }), " أرشفة"]
				})] }),
				onPrimary: handleSave,
				onCancel: () => navigate({ to: "/procurement/suppliers" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "activate",
				onClose: () => setConfirmAction(null),
				onConfirm: () => activateMut.mutate(),
				title: "تفعيل المورد",
				message: `هل تريد تفعيل المورد "${item.name}"؟ سيظهر في القوائم المتاحة لإنشاء أوامر الشراء.`,
				confirmText: "تفعيل",
				cancelText: "إلغاء",
				loading: activateMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "deactivate",
				onClose: () => setConfirmAction(null),
				onConfirm: () => deactivateMut.mutate(),
				title: "إيقاف المورد",
				message: `هل تريد إيقاف المورد "${item.name}"؟ سيختفي من القوائم المتاحة لإنشاء أوامر شراء جديدة، لكن أوامره القائمة ستبقى مرتبطة به.`,
				confirmText: "إيقاف",
				cancelText: "إلغاء",
				variant: "destructive",
				loading: deactivateMut.isPending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmAction === "delete",
				onClose: () => setConfirmAction(null),
				onConfirm: () => deleteMut.mutate(),
				title: "أرشفة المورد",
				message: `هل تريد أرشفة المورد "${item.name}"؟ لن يستطيع أحد استخدامه بعد الآن، لكن بياناته ستبقى في التقارير.`,
				confirmText: "أرشفة",
				cancelText: "إلغاء",
				variant: "destructive",
				loading: deleteMut.isPending
			})
		]
	});
}
//#endregion
export { EditSupplierPage as component };
