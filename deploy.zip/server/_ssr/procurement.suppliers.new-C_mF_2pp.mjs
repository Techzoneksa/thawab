import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { r as createSupplier, t as SUPPLIER_STATUSES } from "./suppliers-CkCPjZYa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.suppliers.new-C_mF_2pp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NewSupplierPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const [name, setName] = (0, import_react.useState)("");
	const [activity, setActivity] = (0, import_react.useState)("");
	const [contactPerson, setContactPerson] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [taxNumber, setTaxNumber] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [rating, setRating] = (0, import_react.useState)("3");
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const handleSave = async (andClose) => {
		const errs = [];
		if (!name.trim()) errs.push("اسم المورد مطلوب");
		if (!activity.trim()) errs.push("نشاط المورد مطلوب");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			const created = await createSupplier({
				name: name.trim(),
				activity: activity.trim(),
				contactPerson: contactPerson || void 0,
				phone: phone || void 0,
				email: email || void 0,
				taxNumber: taxNumber || void 0,
				address: address || void 0,
				rating: parseFloat(rating) || 0,
				status,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["suppliers"] });
			showToast(`تم إنشاء المورد ${created.name}`, "success");
			if (andClose) navigate({ to: "/procurement/suppliers" });
			else navigate({
				to: "/procurement/suppliers/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const tabs = [{
		id: "basic",
		label: "البيانات الأساسية",
		content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
			title: "بيانات المورد",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "اسم المورد",
					required: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: "مثال: شركة النور للتجهيزات"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "نشاط المورد",
					required: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: activity,
						onChange: (e) => setActivity(e.target.value),
						placeholder: "مثال: توريد مواد غذائية"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الشخص المسؤول",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: contactPerson,
						onChange: (e) => setContactPerson(e.target.value),
						placeholder: "اسم الشخص المسؤول"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "رقم الجوال",
					hint: "يستخدم للاتصال",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: phone,
						onChange: (e) => setPhone(e.target.value),
						dir: "ltr",
						placeholder: "05XXXXXXXX"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "البريد الإلكتروني",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "email",
						value: email,
						onChange: (e) => setEmail(e.target.value),
						dir: "ltr",
						placeholder: "supplier@example.com"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الرقم الضريبي",
					hint: "إن وجد",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: taxNumber,
						onChange: (e) => setTaxNumber(e.target.value),
						dir: "ltr",
						placeholder: "300XXXXXXXXX"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "العنوان",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: address,
						onChange: (e) => setAddress(e.target.value),
						placeholder: "المدينة، الحي، الشارع"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "التقييم",
					hint: "من 1 إلى 5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						min: "0",
						max: "5",
						step: "0.5",
						value: rating,
						onChange: (e) => setRating(e.target.value),
						dir: "ltr"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الحالة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
						value: status,
						onChange: (e) => setStatus(e.target.value),
						children: SUPPLIER_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 3,
						placeholder: "أي ملاحظات إضافية حول المورد..."
					})
				})
			]
		})
	}];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الموردين",
		breadcrumb: [
			"المشتريات",
			"الموردين",
			"جديد"
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المشتريات",
					to: "/procurement/requests"
				},
				{
					label: "الموردين",
					to: "/procurement/suppliers"
				},
				{ label: "مورد جديد" }
			],
			title: "مورد جديد",
			subtitle: name || "أدخل بيانات المورد",
			draftNumber: "مسودة جديدة",
			status: {
				label: status,
				tone: status === "نشط" ? "success" : "muted"
			},
			tabs,
			defaultTab: "basic",
			loading: saving,
			validationErrors: errors,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/procurement/suppliers" })
		})
	});
}
//#endregion
export { NewSupplierPage as component };
