//#region node_modules/.nitro/vite/services/ssr/assets/purchase-orders-DLaoDtmH.js
var API_BASE = "/api/procurement/orders";
async function getPurchaseOrders(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.supplierId) params.set("supplierId", filters.supplierId);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب أوامر الشراء");
	return res.json();
}
async function getPurchaseOrder(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات أمر الشراء");
	return res.json();
}
async function createPurchaseOrder(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة أمر الشراء");
	}
	return (await res.json()).item;
}
async function updatePurchaseOrder(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث أمر الشراء");
	}
	return (await res.json()).item;
}
async function approvePurchaseOrder(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "approve"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في اعتماد أمر الشراء");
	}
	return (await res.json()).item;
}
async function cancelPurchaseOrder(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "cancel"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إلغاء أمر الشراء");
	}
	return (await res.json()).item;
}
async function receivePurchaseOrder(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "receive"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في استلام أمر الشراء");
	}
	return (await res.json()).item;
}
async function closePurchaseOrder(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "close"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إغلاق أمر الشراء");
	}
	return (await res.json()).item;
}
async function deletePurchaseOrder(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف أمر الشراء");
	}
}
//#endregion
export { deletePurchaseOrder as a, receivePurchaseOrder as c, createPurchaseOrder as i, updatePurchaseOrder as l, cancelPurchaseOrder as n, getPurchaseOrder as o, closePurchaseOrder as r, getPurchaseOrders as s, approvePurchaseOrder as t };
