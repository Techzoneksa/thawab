import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { rn as BookOpen, wt as Funnel } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, E as PrintButton, S as MobilePageHeader, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, g as ExportButton, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card } from "./actions-qTEe1ygX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.ledger-CaA-J-zt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var API_BASE = "/api/finance/ledger";
async function getLedgerMovements(filters = {}) {
	const params = new URLSearchParams();
	if (filters.accountId) params.set("accountId", filters.accountId);
	if (filters.costCenterId) params.set("costCenterId", filters.costCenterId);
	if (filters.projectId) params.set("projectId", filters.projectId);
	if (filters.dateFrom) params.set("dateFrom", filters.dateFrom);
	if (filters.dateTo) params.set("dateTo", filters.dateTo);
	if (filters.search) params.set("search", filters.search);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب حركة دفتر الأستاذ");
	return res.json();
}
function fmt(n) {
	return new Intl.NumberFormat("ar-SA", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	}).format(n);
}
function Page() {
	const [accountId, setAccountId] = (0, import_react.useState)("");
	const [costCenterId, setCostCenterId] = (0, import_react.useState)("");
	const [projectId, setProjectId] = (0, import_react.useState)("");
	const [dateFrom, setDateFrom] = (0, import_react.useState)("");
	const [dateTo, setDateTo] = (0, import_react.useState)("");
	const [search, setSearch] = (0, import_react.useState)("");
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const { data, isLoading, error } = useQuery({
		queryKey: ["ledger", {
			accountId,
			costCenterId,
			projectId,
			dateFrom,
			dateTo,
			search
		}],
		queryFn: () => getLedgerMovements({
			accountId,
			costCenterId,
			projectId,
			dateFrom,
			dateTo,
			search
		}),
		staleTime: 3e4
	});
	const movements = data?.movements || [];
	const totals = data?.totals || {
		debit: 0,
		credit: 0,
		net: 0
	};
	const balances = data?.balances || {
		opening: 0,
		closing: 0
	};
	const options = data?.options || {
		accounts: [],
		costCenters: [],
		projects: []
	};
	const summary = [
		{
			label: "الرصيد الافتتاحي",
			value: balances.opening,
			tone: balances.opening >= 0 ? "success" : "destructive"
		},
		{
			label: "إجمالي المدين",
			value: totals.debit,
			tone: "info"
		},
		{
			label: "إجمالي الدائن",
			value: totals.credit,
			tone: "warning"
		},
		{
			label: "صافي الحركة",
			value: totals.net,
			tone: totals.net >= 0 ? "success" : "destructive"
		},
		{
			label: "الرصيد الختامي",
			value: balances.closing,
			tone: balances.closing >= 0 ? "success" : "destructive"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المالية",
			"دفتر الأستاذ"
		],
		title: "دفتر الأستاذ العام (General Ledger)",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: movements.map((m) => ({
					التاريخ: m.date,
					"رقم القيد": m.entryNumber,
					الحساب: `${m.accountCode} — ${m.accountName}`,
					الوصف: m.description,
					"مركز التكلفة": m.costCenterName,
					المشروع: m.projectName,
					مدين: m.debit,
					دائن: m.credit,
					الرصيد: m.runningBalance,
					ملاحظات: m.notes
				})),
				filename: "دفتر_الأستاذ.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => setFilterOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 }), " تصفية"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-5 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: summary.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `text-base lg:text-xl font-extrabold mt-1 tabular-nums truncate ${s.tone === "success" ? "text-success" : s.tone === "destructive" ? "text-destructive" : s.tone === "warning" ? "text-warning" : "text-info"}`,
						children: fmt(s.value)
					})]
				}, s.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الحساب",
					options: ["كل الحساتب", ...options.accounts.map((a) => `${a.code} — ${a.name}`)],
					value: accountId ? options.accounts.find((a) => a.id === accountId) ? `${options.accounts.find((a) => a.id === accountId).code} — ${options.accounts.find((a) => a.id === accountId).name}` : "كل الحسابات" : "كل الحسابات",
					onChange: (e) => {
						const v = e.target.value;
						if (v === "كل الحسابات") setAccountId("");
						else setAccountId(options.accounts.find((x) => `${x.code} — ${x.name}` === v)?.id || "");
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "مركز التكلفة",
					options: ["كل المراكز", ...options.costCenters.map((c) => c.name)],
					value: costCenterId ? options.costCenters.find((c) => c.id === costCenterId)?.name || "كل المراكز" : "كل المراكز",
					onChange: (e) => {
						const v = e.target.value;
						if (v === "كل المراكز") setCostCenterId("");
						else setCostCenterId(options.costCenters.find((x) => x.name === v)?.id || "");
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "المشروع",
					options: ["كل المشاريع", ...options.projects.map((p) => p.name)],
					value: projectId ? options.projects.find((p) => p.id === projectId)?.name || "كل المشاريع" : "كل المشاريع",
					onChange: (e) => {
						const v = e.target.value;
						if (v === "كل المشاريع") setProjectId("");
						else setProjectId(options.projects.find((x) => x.name === v)?.id || "");
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden lg:flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "rounded-lg border bg-background px-3 py-1.5 text-sm",
							value: dateFrom,
							onChange: (e) => setDateFrom(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: "إلى"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "rounded-lg border bg-background px-3 py-1.5 text-sm",
							value: dateTo,
							onChange: (e) => setDateTo(e.target.value)
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث برقم القيد أو الوصف...",
					value: search,
					onChange: (e) => setSearch(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "دفتر الأستاذ",
				count: `${movements.length} حركة`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "min-h-[44px] min-w-[44px] grid place-items-center",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 18 })
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء تحميل دفتر الأستاذ",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => {
						window.location.reload();
					},
					children: "إعادة المحاولة"
				})
			}) : movements.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد حركات",
				description: accountId ? "لا توجد قيود مرحّلة تطابق الفلاتر المختارة." : "لم يتم ترحيل أي قيود بعد. ارحل قيود اليومية من صفحة «القيود» لعرض الحركات هنا."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"التاريخ",
					"القيد",
					"الحساب",
					"الوصف",
					"مدين",
					"دائن",
					"الرصيد"
				],
				rows: movements,
				renderRow: (m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: m.date
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs text-info",
						children: m.entryNumber
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-muted-foreground",
							children: m.accountCode
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold mx-1",
							children: m.accountName
						})]
					}), (m.costCenterName || m.projectName) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[10px] text-muted-foreground",
						children: [
							m.costCenterName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: m.costCenterName }),
							m.costCenterName && m.projectName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: " • " }),
							m.projectName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: m.projectName })
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-xs max-w-xs truncate",
						children: m.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums font-semibold",
						children: m.debit > 0 ? fmt(m.debit) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums font-semibold",
						children: m.credit > 0 ? fmt(m.credit) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: `tabular-nums font-bold ${m.runningBalance >= 0 ? "text-success" : "text-destructive"}`,
						children: fmt(m.runningBalance)
					})
				] }),
				mobileCard: (m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs",
								children: m.date
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-info",
								children: m.entryNumber
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-semibold mb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-muted-foreground",
								children: m.accountCode
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-1",
								children: m.accountName
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground line-clamp-2 mb-2",
							children: m.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "مدين"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-semibold tabular-nums",
									children: m.debit > 0 ? fmt(m.debit) : "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "دائن"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-semibold tabular-nums",
									children: m.credit > 0 ? fmt(m.credit) : "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "الرصيد"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `font-bold tabular-nums ${m.runningBalance >= 0 ? "text-success" : "text-destructive"}`,
									children: fmt(m.runningBalance)
								})] })
							]
						}),
						(m.costCenterName || m.projectName) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-1",
							children: [m.costCenterName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "muted",
								children: m.costCenterName
							}), m.projectName && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "info",
								children: m.projectName
							})]
						})
					]
				}, m.lineId)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3 p-3 bg-muted/30 flex items-start gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
					size: 14,
					className: "mt-0.5 text-muted-foreground shrink-0"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs text-muted-foreground",
					children: [
						"دفتر الأستاذ يعرض القيود ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "المرحّلة" }),
						" فقط (يستثني المسودة والإلغاء والعكس). الرصيد الجاري يُحسب تراكمياً عبر الفترة المختارة.",
						accountId && dateFrom && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							" ",
							"الرصيد الافتتاحي يشمل جميع الحركات المرحّلة للحساب قبل ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: dateFrom }),
							"."
						] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							label: "الحساب",
							options: ["كل الحسابات", ...options.accounts.map((a) => `${a.code} — ${a.name}`)],
							value: accountId ? options.accounts.find((a) => a.id === accountId) ? `${options.accounts.find((a) => a.id === accountId).code} — ${options.accounts.find((a) => a.id === accountId).name}` : "كل الحسابات" : "كل الحسابات",
							onChange: (e) => {
								const v = e.target.value;
								if (v === "كل الحسابات") setAccountId("");
								else setAccountId(options.accounts.find((x) => `${x.code} — ${x.name}` === v)?.id || "");
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							label: "مركز التكلفة",
							options: ["كل المراكز", ...options.costCenters.map((c) => c.name)],
							value: costCenterId ? options.costCenters.find((c) => c.id === costCenterId)?.name || "كل المراكز" : "كل المراكز",
							onChange: (e) => {
								const v = e.target.value;
								if (v === "كل المراكز") setCostCenterId("");
								else setCostCenterId(options.costCenters.find((x) => x.name === v)?.id || "");
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							label: "المشروع",
							options: ["كل المشاريع", ...options.projects.map((p) => p.name)],
							value: projectId ? options.projects.find((p) => p.id === projectId)?.name || "كل المشاريع" : "كل المشاريع",
							onChange: (e) => {
								const v = e.target.value;
								if (v === "كل المشاريع") setProjectId("");
								else setProjectId(options.projects.find((x) => x.name === v)?.id || "");
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "التاريخ من"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: dateFrom,
							onChange: (e) => setDateFrom(e.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "التاريخ إلى"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: dateTo,
							onChange: (e) => setDateTo(e.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "بحث"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							placeholder: "رقم القيد أو الوصف...",
							value: search,
							onChange: (e) => setSearch(e.target.value)
						})] })
					]
				})
			})
		]
	});
}
//#endregion
export { Page as component };
