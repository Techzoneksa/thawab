import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { Gt as CircleAlert, U as Plus, v as Trash2 } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { c as getProjects } from "./projects-fdUGDKDE.mjs";
import { c as getAccounts } from "./accounts-i45ITZyC.mjs";
import { i as createJournalEntry, t as JOURNAL_FUNDS } from "./journal-Da8V5shh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.journal.new-2Qck64cj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function newLine(key) {
	return {
		key,
		accountId: "",
		description: "",
		debit: 0,
		credit: 0
	};
}
function NewJournalPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: accData } = useQuery({
		queryKey: ["accounts-postable"],
		queryFn: () => getAccounts({ limit: 1e3 })
	});
	const accounts = (accData?.items || []).filter((a) => a.postable);
	const { data: projData } = useQuery({
		queryKey: ["projects-simple"],
		queryFn: () => getProjects({ limit: 200 })
	});
	const projects = projData?.items || [];
	const [date, setDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [description, setDescription] = (0, import_react.useState)("");
	const [fund, setFund] = (0, import_react.useState)("غير مقيد");
	const [projectId, setProjectId] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [lines, setLines] = (0, import_react.useState)([newLine("l1"), newLine("l2")]);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const totals = (0, import_react.useMemo)(() => {
		const debit = lines.reduce((s, l) => s + (l.debit || 0), 0);
		const credit = lines.reduce((s, l) => s + (l.credit || 0), 0);
		return {
			debit,
			credit,
			diff: debit - credit
		};
	}, [lines]);
	const validate = () => {
		if (!description.trim()) return "وصف القيد مطلوب";
		if (lines.length < 2) return "القيد يحتاج سطرين على الأقل";
		if (Math.abs(totals.diff) > .001) return `القيد غير متوازن (الفرق ${fmtSAR(totals.diff)})`;
		if (lines.some((l) => !l.accountId)) return "كل سطر يحتاج حساب";
		if (totals.debit <= 0) return "إجمالي المدين يجب أن يكون أكبر من صفر";
		return null;
	};
	const handleSave = async (andClose) => {
		const err = validate();
		if (err) {
			showToast(err, "error");
			return;
		}
		setSaving(true);
		try {
			const created = await createJournalEntry({
				date,
				description: description.trim(),
				fund,
				projectId: projectId || null,
				currency: "SAR",
				notes,
				lines: lines.map((l) => ({
					accountId: l.accountId,
					description: l.description || void 0,
					debit: l.debit || 0,
					credit: l.credit || 0
				})),
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["journal"] });
			showToast(`تم إنشاء القيد ${created.number}`, "success");
			if (andClose) navigate({ to: "/finance/journal" });
			else navigate({
				to: "/finance/journal/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const addLine = () => setLines([...lines, newLine(`l${Date.now()}`)]);
	const removeLine = (key) => setLines(lines.length > 2 ? lines.filter((l) => l.key !== key) : lines);
	const updateLine = (key, patch) => setLines(lines.map((l) => l.key === key ? {
		...l,
		...patch
	} : l));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "قيود اليومية",
		breadcrumb: [
			"المالية",
			"قيود اليومية",
			"جديد"
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المالية",
					to: "/finance/journal"
				},
				{
					label: "قيود اليومية",
					to: "/finance/journal"
				},
				{ label: "قيد جديد" }
			],
			title: "قيد يومية جديد",
			subtitle: "أنشئ قيداً متوازناً (إجمالي المدين = إجمالي الدائن)",
			draftNumber: "مسودة جديدة",
			status: {
				label: "مسودة",
				tone: "info"
			},
			tabs: [
				{
					id: "lines",
					label: "بنود القيد",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "بنود القيد اليومية",
						description: "يجب أن يتساوى إجمالي المدين مع إجمالي الدائن",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border bg-card overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
									className: "min-w-full text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
										className: "bg-muted/60 text-right",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 font-semibold text-muted-foreground w-10",
												children: "#"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 font-semibold text-muted-foreground",
												children: "الحساب"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 font-semibold text-muted-foreground",
												children: "البيان"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 font-semibold text-muted-foreground w-32",
												children: "مدين"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "px-3 py-2 font-semibold text-muted-foreground w-32",
												children: "دائن"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-3 py-2 font-semibold text-muted-foreground w-10" })
										] })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-t",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-2 text-muted-foreground tabular-nums",
												children: i + 1
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-1.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
													value: l.accountId,
													onChange: (e) => updateLine(l.key, { accountId: e.target.value }),
													className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm min-h-[36px]",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
														value: "",
														children: "— اختر —"
													}), accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
														value: a.id,
														children: [
															a.code,
															" — ",
															a.name
														]
													}, a.id))]
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-1.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													value: l.description,
													onChange: (e) => updateLine(l.key, { description: e.target.value }),
													placeholder: "بيان السطر",
													className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm min-h-[36px]"
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-1.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "number",
													step: "0.01",
													value: l.debit || "",
													onChange: (e) => updateLine(l.key, {
														debit: parseFloat(e.target.value) || 0,
														credit: 0
													}),
													placeholder: "0",
													dir: "ltr",
													className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm font-mono tabular-nums min-h-[36px]"
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-1.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "number",
													step: "0.01",
													value: l.credit || "",
													onChange: (e) => updateLine(l.key, {
														credit: parseFloat(e.target.value) || 0,
														debit: 0
													}),
													placeholder: "0",
													dir: "ltr",
													className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm font-mono tabular-nums min-h-[36px]"
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "px-3 py-1.5",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => removeLine(l.key),
													disabled: lines.length <= 2,
													className: "grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive disabled:opacity-30 disabled:cursor-not-allowed transition-colors",
													title: "حذف السطر",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 14 })
												})
											})
										]
									}, l.key)) })]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t bg-muted/30 px-3 py-3 flex items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: addLine,
									className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-1.5 text-xs font-semibold hover:bg-muted transition-colors min-h-[36px]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), "إضافة سطر"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-4 text-sm font-bold tabular-nums",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["مدين: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground",
											children: fmtSAR(totals.debit)
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["دائن: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-foreground",
											children: fmtSAR(totals.credit)
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: totals.diff === 0 ? "text-success" : "text-destructive",
											children: ["فرق: ", fmtSAR(totals.diff)]
										})
									]
								})]
							})]
						}), Math.abs(totals.diff) > .001 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-xs text-destructive font-medium flex items-center gap-2 mt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { size: 14 }), "القيد غير متوازن. يجب أن يتساوى إجمالي المدين مع إجمالي الدائن."]
						})]
					})
				},
				{
					id: "header",
					label: "بيانات القيد",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "بيانات القيد",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "تاريخ القيد",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									type: "date",
									value: date,
									onChange: (e) => setDate(e.target.value),
									dir: "ltr"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "نوع الصندوق",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
									value: fund,
									onChange: (e) => setFund(e.target.value),
									children: JOURNAL_FUNDS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: f,
										children: f
									}, f))
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "وصف القيد",
								required: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: description,
									onChange: (e) => setDescription(e.target.value),
									placeholder: "مثال: قيد تحصيل تبرعات شهر محرم"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "المشروع",
								hint: "اختياري - لربط القيد بمشروع",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
									value: projectId,
									onChange: (e) => setProjectId(e.target.value),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "— خارج مشروع —"
									}), projects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: p.id,
										children: p.name
									}, p.id))]
								})
							})
						]
					})
				},
				{
					id: "notes",
					label: "الملاحظات",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
						title: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "ملاحظات",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
								value: notes,
								onChange: (e) => setNotes(e.target.value),
								rows: 5
							})
						})
					})
				}
			],
			defaultTab: "lines",
			loading: saving,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/finance/journal" })
		})
	});
}
//#endregion
export { NewJournalPage as component };
