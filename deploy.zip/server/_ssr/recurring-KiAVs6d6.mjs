import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { L as Repeat, U as Plus, b as ToggleLeft, jt as Eye, v as Trash2, y as ToggleRight } from "../_libs/lucide-react.mjs";
import { N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, g as ExportButton, h as EntityFormDrawer, i as Badge, j as Td, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/recurring-KiAVs6d6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [data, setData] = (0, import_react.useState)([
		{
			id: "RCR-101",
			donor: "شركة أرامكو السعودية",
			amount: 5e4,
			freq: "شهري",
			project: "كفالة الأيتام",
			next: "1446/11/01",
			status: "نشط"
		},
		{
			id: "RCR-102",
			donor: "عبدالله العتيبي",
			amount: 800,
			freq: "شهري",
			project: "كفالة طفل يتيم",
			next: "1446/11/05",
			status: "نشط"
		},
		{
			id: "RCR-103",
			donor: "نورة القحطاني",
			amount: 1200,
			freq: "شهري",
			project: "السلال الغذائية",
			next: "1446/11/10",
			status: "نشط"
		},
		{
			id: "RCR-104",
			donor: "خالد الدوسري",
			amount: 500,
			freq: "أسبوعي",
			project: "صدقة جارية",
			next: "1446/10/18",
			status: "نشط"
		},
		{
			id: "RCR-105",
			donor: "هند السبيعي",
			amount: 2400,
			freq: "ربع سنوي",
			project: "كسوة الشتاء",
			next: "1447/01/01",
			status: "نشط"
		},
		{
			id: "RCR-106",
			donor: "فهد المالكي",
			amount: 300,
			freq: "شهري",
			project: "إفطار صائم",
			next: "—",
			status: "موقوف"
		}
	]);
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [confirmIdx, setConfirmIdx] = (0, import_react.useState)(-1);
	const [formDonor, setFormDonor] = (0, import_react.useState)("");
	const [formAmount, setFormAmount] = (0, import_react.useState)("");
	const [formFreq, setFormFreq] = (0, import_react.useState)("شهري");
	const [formProject, setFormProject] = (0, import_react.useState)("");
	const nextId = () => `RCR-${String(100 + data.length + 1).slice(-3)}`;
	const handleSave = () => {
		if (!formDonor.trim() || !formAmount.trim()) {
			showToast("يرجى إدخال البيانات", "error");
			return;
		}
		setData([{
			id: nextId(),
			donor: formDonor,
			amount: Number(formAmount),
			freq: formFreq,
			project: formProject || "—",
			next: "—",
			status: "نشط"
		}, ...data]);
		showToast("تم إضافة التبرع المتكرر بنجاح", "success");
		setFormOpen(false);
		setFormDonor("");
		setFormAmount("");
		setFormFreq("شهري");
		setFormProject("");
	};
	const toggleStatus = (idx) => {
		const d = [...data];
		d[idx] = {
			...d[idx],
			status: d[idx].status === "نشط" ? "موقوف" : "نشط"
		};
		setData(d);
		showToast(`تم ${d[idx].status === "نشط" ? "تفعيل" : "إيقاف"} التبرع المتكرر`, "success");
	};
	const handleDelete = () => {
		setData(data.filter((_, i) => i !== confirmIdx));
		showToast("تم حذف التبرع المتكرر", "success");
		setConfirmIdx(-1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
			breadcrumb: [
				"الرئيسية",
				"التبرعات",
				"التبرعات المتكررة"
			],
			title: "التبرعات المتكررة",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data,
				filename: "recurring.csv"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => {
					setFormDonor("");
					setFormAmount("");
					setFormFreq("شهري");
					setFormProject("");
					setFormOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إضافة تبرع متكرر"]
			})] }),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4",
				children: [
					{
						l: "تبرعات متكررة نشطة",
						v: String(data.filter((d) => d.status === "نشط").length)
					},
					{
						l: "إيراد شهري متوقع",
						v: fmtSAR(data.filter((d) => d.status === "نشط").reduce((a, d) => a + d.amount, 0))
					},
					{
						l: "نسبة الاستمرارية",
						v: `${Math.round(data.filter((d) => d.status === "نشط").length / data.length * 100)}%`
					},
					{
						l: "عدد المشتركين",
						v: String(data.length)
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: s.l
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-lg font-extrabold mt-1 tabular-nums",
						children: s.v
					})]
				}, s.l))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "التبرعات المتكررة",
				count: `${data.length} تبرع`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الرقم",
					"المتبرع",
					"المبلغ",
					"التكرار",
					"المشروع",
					"الخصم القادم",
					"الحالة",
					""
				],
				rows: data,
				renderRow: (r, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: r.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-semibold",
						children: r.donor
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums font-bold",
						children: fmtSAR(r.amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						tone: "info",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, {
							size: 11,
							className: "inline ms-1"
						}), r.freq]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: r.project }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-muted-foreground",
						children: r.next
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(r.status),
						children: r.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
						{
							label: "عرض",
							icon: Eye,
							onClick: () => showToast(`${r.donor} - ${fmtSAR(r.amount)}`, "info")
						},
						{
							label: r.status === "نشط" ? "إيقاف" : "تفعيل",
							icon: r.status === "نشط" ? ToggleLeft : ToggleRight,
							onClick: () => toggleStatus(idx)
						},
						{
							label: "حذف",
							icon: Trash2,
							variant: "destructive",
							onClick: () => setConfirmIdx(idx)
						}
					] }) })
				] }),
				mobileCard: (r, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(r.status),
								children: r.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
								tone: "info",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Repeat, {
									size: 11,
									className: "inline ms-1"
								}), r.freq]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-semibold",
							children: r.donor
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums font-bold",
								children: fmtSAR(r.amount)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: r.project
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground mt-1",
							children: ["الخصم القادم: ", r.next]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-2 mt-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px]",
								onClick: () => toggleStatus(idx),
								children: r.status === "نشط" ? "إيقاف" : "تفعيل"
							})
						})
					]
				}, r.id)
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
			open: formOpen,
			onClose: () => setFormOpen(false),
			title: "إضافة تبرع متكرر",
			onSave: handleSave,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "اسم المتبرع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: formDonor,
					onChange: (e) => setFormDonor(e.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "المبلغ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					type: "number",
					value: formAmount,
					onChange: (e) => setFormAmount(e.target.value)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "التكرار"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: formFreq,
					onChange: (e) => setFormFreq(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "أسبوعي" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "شهري" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ربع سنوي" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "سنوي" })
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "المشروع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: formProject,
					onChange: (e) => setFormProject(e.target.value)
				})] })
			]
		}),
		confirmIdx >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			open: true,
			onClose: () => setConfirmIdx(-1),
			onConfirm: handleDelete,
			title: "تأكيد الحذف",
			message: "هل أنت متأكد من حذف التبرع المتكرر؟",
			confirmText: "حذف",
			variant: "destructive"
		})
	] });
};
//#endregion
export { SplitComponent as component };
