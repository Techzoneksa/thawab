import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { T as SquarePen, U as Plus, en as Building2, jt as Eye, v as Trash2 } from "../_libs/lucide-react.mjs";
import { N as showToast, S as MobilePageHeader, a as Btn, c as ConfirmDialog, g as ExportButton, h as EntityFormDrawer, i as Badge, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donor-orgs-KaRjZA4z.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [data, setData] = (0, import_react.useState)([
		{
			n: "الصندوق الخيري الوطني",
			cat: "حكومي",
			grants: 4,
			total: 48e5,
			status: "نشط"
		},
		{
			n: "صندوق الملك سلمان للإغاثة",
			cat: "حكومي",
			grants: 6,
			total: 82e5,
			status: "نشط"
		},
		{
			n: "بنك التنمية الإسلامي",
			cat: "دولي",
			grants: 2,
			total: 14e5,
			status: "نشط"
		},
		{
			n: "وزارة الموارد البشرية والتنمية الاجتماعية",
			cat: "حكومي",
			grants: 3,
			total: 19e5,
			status: "نشط"
		},
		{
			n: "هيئة الهلال الأحمر السعودي",
			cat: "شريك",
			grants: 1,
			total: 6e5,
			status: "نشط"
		}
	]);
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [confirmIdx, setConfirmIdx] = (0, import_react.useState)(-1);
	const [formName, setFormName] = (0, import_react.useState)("");
	const [formCat, setFormCat] = (0, import_react.useState)("حكومي");
	const handleSave = () => {
		if (!formName.trim()) {
			showToast("يرجى إدخال اسم الجهة", "error");
			return;
		}
		setData([{
			n: formName,
			cat: formCat,
			grants: 0,
			total: 0,
			status: "نشط"
		}, ...data]);
		showToast("تم إضافة الجهة المانحة بنجاح", "success");
		setFormOpen(false);
		setFormName("");
		setFormCat("حكومي");
	};
	const handleDelete = () => {
		setData(data.filter((_, i) => i !== confirmIdx));
		showToast("تم حذف الجهة المانحة", "success");
		setConfirmIdx(-1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
			breadcrumb: [
				"الرئيسية",
				"المنح والأوقاف",
				"الجهات المانحة"
			],
			title: "الجهات المانحة",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data,
				filename: "donor-orgs.csv"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => {
					setFormName("");
					setFormCat("حكومي");
					setFormOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إضافة جهة مانحة"]
			})] }),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "الجهات المانحة",
				count: `${data.length} جهة`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4",
				children: data.map((r, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3 min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { size: 20 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-bold truncate",
									children: r.n
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "info",
									children: r.cat
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
							{
								label: "عرض",
								icon: Eye,
								onClick: () => showToast(r.n, "info")
							},
							{
								label: "تعديل",
								icon: SquarePen,
								onClick: () => {
									setFormName(r.n);
									setFormCat(r.cat);
									setFormOpen(true);
								}
							},
							{
								label: "حذف",
								icon: Trash2,
								variant: "destructive",
								onClick: () => setConfirmIdx(idx)
							}
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "عدد المنح"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold",
							children: r.grants
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground",
							children: "إجمالي القيمة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold tabular-nums",
							children: fmtSAR(r.total)
						})] })]
					})]
				}, r.n))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
			open: formOpen,
			onClose: () => setFormOpen(false),
			title: "إضافة جهة مانحة",
			onSave: handleSave,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "text-xs font-semibold text-muted-foreground",
				children: "الاسم"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
				value: formName,
				onChange: (e) => setFormName(e.target.value)
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "text-xs font-semibold text-muted-foreground",
				children: "الفئة"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
				value: formCat,
				onChange: (e) => setFormCat(e.target.value),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "حكومي" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "دولي" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "شريك" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "خاص" })
				]
			})] })]
		}),
		confirmIdx >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			open: true,
			onClose: () => setConfirmIdx(-1),
			onConfirm: handleDelete,
			title: "تأكيد الحذف",
			message: "هل أنت متأكد من حذف الجهة المانحة؟",
			confirmText: "حذف",
			variant: "destructive"
		})
	] });
};
//#endregion
export { SplitComponent as component };
