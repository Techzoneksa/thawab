import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { B as Printer, Pt as Download, T as SquarePen, ln as ArrowRight } from "../_libs/lucide-react.mjs";
import { A as Table, N as showToast, O as SectionTitle, P as statusTone, a as Btn, i as Badge, j as Td, n as AppShell, s as Card, w as MobileTabBar } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { c as getBeneficiarySummary, s as getBeneficiary } from "./beneficiaries-aRDRq8QX.mjs";
import { t as Route } from "./beneficiaries._id-BFV4YTRB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/beneficiaries._id-DygqQXrG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const { id } = Route.useParams();
	const [tab, setTab] = (0, import_react.useState)("نظرة عامة");
	const [mobileTab, setMobileTab] = (0, import_react.useState)("نظرة عامة");
	const [isMobile, setIsMobile] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const check = () => setIsMobile(window.innerWidth < 1024);
		check();
		window.addEventListener("resize", check);
		return () => window.removeEventListener("resize", check);
	}, []);
	const { data: beneficiaryData, isLoading } = useQuery({
		queryKey: ["beneficiary", id],
		queryFn: () => getBeneficiary(id)
	});
	const { data: summaryData } = useQuery({
		queryKey: ["beneficiary-summary", id],
		queryFn: () => getBeneficiarySummary(id)
	});
	const beneficiary = beneficiaryData?.item;
	const aidHistory = beneficiaryData?.aidHistory || [];
	const linkedProjects = beneficiaryData?.linkedProjects || [];
	const tabs = [
		"نظرة عامة",
		"البيانات الشخصية",
		"البيانات الأسرية",
		"سجل المساعدات",
		"المشاريع المرتبطة",
		"التفاصيل"
	];
	const activeTab = isMobile ? mobileTab : tab;
	const isSuspended = beneficiary?.status === "موقوف";
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		breadcrumb: ["الرئيسية", "المستفيدون"],
		title: "جاري التحميل...",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!beneficiary) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		breadcrumb: ["الرئيسية", "المستفيدون"],
		title: "مستفيد غير موجود",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-6 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground mb-3",
				children: "المستفيد المطلوب غير موجود."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/beneficiaries",
				className: "text-primary font-semibold",
				children: "العودة إلى قائمة المستفيدين"
			})]
		})
	});
	const totalAid = summaryData?.totalAid ?? beneficiary.totalAid ?? 0;
	const aidCount = summaryData?.aidCount ?? beneficiary.aidCount ?? 0;
	const pendingAidCount = summaryData?.pendingAidCount ?? beneficiary.pendingAidCount ?? 0;
	const lastAidDate = summaryData?.lastAidDate ?? beneficiary.lastAidDate ?? null;
	const linkedProjectsCount = summaryData?.linkedProjectsCount ?? beneficiary.linkedProjectsCount ?? linkedProjects.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المستفيدون",
			beneficiary.name
		],
		title: beneficiary.name,
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => showToast("تم إرسال الملف للطباعة", "info"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { size: 15 }), " طباعة"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => showToast("تم تصدير تقرير المستفيد", "info"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 15 }), " تقرير"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => navigate({
					to: "/beneficiaries/$id/edit",
					params: { id }
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { size: 15 }), " تعديل"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-5 gap-2 lg:gap-3 mb-3 lg:mb-4",
				children: [
					{
						l: "إجمالي المساعدات",
						v: fmtSAR(totalAid),
						tone: "text-success"
					},
					{
						l: "عدد المساعدات",
						v: fmtNum(aidCount)
					},
					{
						l: "مساعدات قيد المعالجة",
						v: fmtNum(pendingAidCount),
						tone: "text-warning-foreground"
					},
					{
						l: "المشاريع المرتبطة",
						v: fmtNum(linkedProjectsCount),
						tone: "text-info"
					},
					{
						l: "عدد الأفراد",
						v: fmtNum(beneficiary.familyMembers || 1)
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] lg:text-xs text-muted-foreground truncate",
						children: s.l
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `text-sm lg:text-lg font-extrabold mt-0.5 tabular-nums truncate ${s.tone || ""}`,
						children: s.v
					})]
				}, s.l))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mb-3 lg:mb-4 p-4 lg:p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3 lg:gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-14 w-14 lg:h-16 lg:w-16 shrink-0 place-items-center rounded-full bg-info/15 text-info text-xl lg:text-2xl font-bold",
						children: beneficiary.name?.[0] || "؟"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex-1 min-w-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2 flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-base lg:text-lg font-bold truncate",
										children: beneficiary.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground font-mono mt-0.5",
										children: ["رقم الملف: ", beneficiary.fileNumber || beneficiary.id]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs text-muted-foreground mt-1 flex flex-wrap gap-x-3 gap-y-0.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: beneficiary.category }),
											beneficiary.city && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· ", beneficiary.city] }),
											beneficiary.phone && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· ", beneficiary.phone] })
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-end gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(beneficiary.status),
									children: beneficiary.status
								}), lastAidDate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-[10px] text-muted-foreground",
									children: ["آخر مساعدة: ", lastAidDate]
								})]
							})]
						})
					})]
				})
			}),
			isSuspended && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mb-3 lg:mb-4 p-3 bg-warning/10 border-warning",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "warning",
						children: "موقوف"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: "المستفيد موقوف — لا يمكن تسليم مساعدات جديدة له. المساعدات السابقة محفوظة."
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "px-2 hidden lg:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1 border-b px-2 overflow-x-auto",
					children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTab(t),
						className: `px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap ${tab === t ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`,
						children: t
					}, t))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTabBar, {
					tabs: tabs.slice(0, 5),
					active: mobileTab,
					onChange: setMobileTab
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4 lg:p-5",
				children: [
					activeTab === "نظرة عامة" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { title: "ملخص المستفيد" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
										label: "الحالة",
										value: beneficiary.status
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
										label: "الفئة",
										value: beneficiary.category
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
										label: "المدينة",
										value: beneficiary.city || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
										label: "عدد الأفراد",
										value: `${fmtNum(beneficiary.familyMembers || 1)} فرد`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
										label: "الدخل الشهري",
										value: fmtSAR(beneficiary.monthlyIncome || 0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryRow, {
										label: "الحالة الاجتماعية",
										value: beneficiary.maritalStatus || "—"
									})
								]
							}),
							beneficiary.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { title: "ملاحظات" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground leading-relaxed",
								children: beneficiary.notes
							})] })
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { title: "مؤشرات الاستحقاق" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KPIRow, {
									label: "نسبة الدخل لتغطية الأسرة",
									v: beneficiary.familyMembers && beneficiary.familyMembers > 0 ? Math.min(100, Math.round((beneficiary.monthlyIncome || 0) / (beneficiary.familyMembers * 1e3) * 100)) : 0
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KPIRow, {
									label: "استفادة من المساعدات",
									v: aidCount > 0 ? 100 : 0
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KPIRow, {
									label: "مشاريع مرتبطة",
									v: linkedProjectsCount > 0 ? Math.min(100, linkedProjectsCount * 25) : 0
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KPIRow, {
									label: "الجاهزية للاستلام",
									v: beneficiary.status === "مؤهل" ? 100 : 0
								})
							]
						})] })]
					}),
					activeTab === "البيانات الشخصية" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الاسم",
								value: beneficiary.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "رقم الملف",
								value: beneficiary.fileNumber || beneficiary.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "رقم الهوية",
								value: beneficiary.idNumber || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "رقم الجوال",
								value: beneficiary.phone || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "المدينة",
								value: beneficiary.city || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "العنوان",
								value: beneficiary.address || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الفئة",
								value: beneficiary.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الحالة",
								value: beneficiary.status
							})
						]
					}),
					activeTab === "البيانات الأسرية" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "عدد الأفراد",
								value: `${fmtNum(beneficiary.familyMembers || 1)} فرد`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الحالة الاجتماعية",
								value: beneficiary.maritalStatus || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الدخل الشهري",
								value: fmtSAR(beneficiary.monthlyIncome || 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الدخل لكل فرد",
								value: beneficiary.familyMembers && beneficiary.familyMembers > 0 ? fmtSAR((beneficiary.monthlyIncome || 0) / beneficiary.familyMembers) : "—"
							})
						]
					}),
					activeTab === "سجل المساعدات" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: aidHistory.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "لا توجد مساعدات مسجلة لهذا المستفيد."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							columns: [
								"رقم",
								"النوع",
								"المبلغ",
								"المشروع",
								"الحالة",
								"التاريخ"
							],
							rows: aidHistory,
							renderRow: (a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "font-mono text-xs",
									children: a.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "text-sm",
									children: a.type
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "tabular-nums font-bold",
									children: fmtSAR(a.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "text-sm text-muted-foreground",
									children: a.projectName || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(a.status),
									children: a.status
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "text-muted-foreground text-xs",
									children: a.createdAt
								})
							] })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:hidden space-y-2",
						children: aidHistory.slice(0, 10).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: statusTone(a.status),
										children: a.status
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-muted-foreground",
										children: a.id
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-base font-bold tabular-nums",
										children: fmtSAR(a.amount)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										children: a.type
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 text-xs text-muted-foreground flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a.projectName || "—" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a.createdAt })]
								})
							]
						}, a.id))
					})] }) }),
					activeTab === "المشاريع المرتبطة" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: linkedProjects.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "لا توجد مشاريع مرتبطة بمساعدات لهذا المستفيد."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							columns: [
								"رقم المشروع",
								"الاسم",
								"الحالة",
								""
							],
							rows: linkedProjects,
							renderRow: (p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "font-mono text-xs",
									children: p.code || p.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "font-semibold",
									children: p.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: p.status ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(p.status),
									children: p.status
								}) : "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/projects/$id",
									params: { id: p.id },
									className: "text-info text-xs font-semibold inline-flex items-center gap-1",
									children: ["عرض ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 12 })]
								}) })
							] })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:hidden space-y-2",
						children: linkedProjects.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/projects/$id",
							params: { id: p.id },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
								className: "p-3 hover:border-primary transition-colors",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground font-mono",
										children: p.code || p.id
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-bold mt-0.5",
										children: p.name
									}),
									p.status && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-1",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											tone: statusTone(p.status),
											children: p.status
										})
									})
								]
							})
						}, p.id))
					})] }) }),
					activeTab === "التفاصيل" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "المعرّف",
								value: beneficiary.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "رقم الملف",
								value: beneficiary.fileNumber || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الاسم",
								value: beneficiary.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الحالة",
								value: beneficiary.status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الفئة",
								value: beneficiary.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "رقم الهوية",
								value: beneficiary.idNumber || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الجوال",
								value: beneficiary.phone || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "المدينة",
								value: beneficiary.city || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "العنوان",
								value: beneficiary.address || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "عدد الأفراد",
								value: `${fmtNum(beneficiary.familyMembers || 1)} فرد`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الحالة الاجتماعية",
								value: beneficiary.maritalStatus || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الدخل الشهري",
								value: fmtSAR(beneficiary.monthlyIncome || 0)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "أنشأ بواسطة",
								value: beneficiary.createdBy || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "تاريخ الإنشاء",
								value: beneficiary.createdAt || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "آخر تحديث",
								value: beneficiary.updatedAt || "—"
							})
						]
					})
				]
			})
		]
	});
}
function SummaryRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between text-sm border-b pb-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-semibold",
			children: value
		})]
	});
}
function KPIRow({ label, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "font-bold",
			children: [v, "%"]
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-2 rounded-full bg-muted mt-1 overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full bg-success",
			style: { width: `${v}%` }
		})
	})] });
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-3 border-b pb-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-semibold text-muted-foreground min-w-[110px]",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex-1 font-semibold",
			children: value
		})]
	});
}
//#endregion
export { Page as component };
