import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { P as Search, jt as Eye, wt as Funnel } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, E as PrintButton, S as MobilePageHeader, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, g as ExportButton, h as EntityFormDrawer, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card } from "./actions-qTEe1ygX.mjs";
import { n as getAuditEntry, t as getAuditEntries } from "./audit-DP6UgtXG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-B-jyStyX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [userFilter, setUserFilter] = (0, import_react.useState)("الكل");
	const [actionFilter, setActionFilter] = (0, import_react.useState)("الكل");
	const [entityFilter, setEntityFilter] = (0, import_react.useState)("الكل");
	const [dateFrom, setDateFrom] = (0, import_react.useState)("");
	const [dateTo, setDateTo] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const { data, isLoading, error } = useQuery({
		queryKey: ["audit", {
			search: searchQuery,
			user: userFilter,
			action: actionFilter,
			entity: entityFilter,
			dateFrom,
			dateTo,
			page
		}],
		queryFn: () => getAuditEntries({
			search: searchQuery,
			userName: userFilter,
			action: actionFilter,
			entityType: entityFilter,
			dateFrom,
			dateTo,
			page,
			limit: 50
		})
	});
	const entries = data?.items || [];
	const total = data?.total || 0;
	const totalPages = Math.ceil(total / 50);
	const options = data?.options || {
		users: [],
		actions: [],
		entities: []
	};
	const { data: detailData } = useQuery({
		queryKey: ["audit-entry", detailId],
		queryFn: () => detailId ? getAuditEntry(detailId) : Promise.resolve(null),
		enabled: !!detailId
	});
	(0, import_react.useEffect)(() => {
		setPage(1);
	}, [
		searchQuery,
		userFilter,
		actionFilter,
		entityFilter,
		dateFrom,
		dateTo
	]);
	const stats = [
		{
			label: "إجمالي السجلات",
			value: total
		},
		{
			label: "عمليات اليوم",
			value: entries.filter((e) => {
				return e.timestamp && e.timestamp.length >= 10;
			}).length
		},
		{
			label: "مستخدمون مميزون",
			value: options.users.length
		},
		{
			label: "أنواع الكيانات",
			value: options.entities.length
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"التقارير والحوكمة",
			"سجل التدقيق"
		],
		title: "سجل التدقيق (Audit Trail)",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: entries.map((e) => ({
					الوقت: e.timestamp,
					المستخدم: e.userName,
					الإجراء: e.action,
					الكيان: e.entityType,
					"رقم السجل": e.entityId,
					الوصف: e.description,
					IP: e.ip
				})),
				filename: "سجل_التدقيق.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => setFilterOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 }), " تصفية"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base lg:text-xl font-extrabold mt-1 tabular-nums truncate",
						children: s.value
					})]
				}, s.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث بالمستخدم، الإجراء، الكيان، الوصف...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "المستخدم",
					options: ["الكل", ...options.users],
					value: userFilter,
					onChange: (e) => setUserFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "نوع الإجراء",
					options: ["الكل", ...options.actions],
					value: actionFilter,
					onChange: (e) => setActionFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الكيان",
					options: ["الكل", ...options.entities],
					value: entityFilter,
					onChange: (e) => setEntityFilter(e.target.value)
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "سجل التدقيق",
				count: `${total} سجل`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "min-h-[44px] min-w-[44px] grid place-items-center",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 18 })
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء تحميل سجل التدقيق",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => {
						window.location.reload();
					},
					children: "إعادة المحاولة"
				})
			}) : entries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد سجلات",
				description: "لم يتم تسجيل أي عمليات بعد. ستظهر جميع العمليات المؤتمتة هنا تلقائياً."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الوقت",
					"المستخدم",
					"الإجراء",
					"الكيان",
					"رقم السجل",
					""
				],
				rows: entries,
				renderRow: (a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs text-muted-foreground",
						children: a.timestamp
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-semibold",
						children: a.userName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: actionTone(a.action),
						children: a.action
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-xs",
						children: a.entityType
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs text-muted-foreground",
						children: a.entityId
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setDetailId(a.id),
						className: "text-info text-xs font-semibold inline-flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 12 }), " تفاصيل"]
					}) })
				] }),
				mobileCard: (a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold text-sm",
								children: a.userName
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: a.timestamp
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: actionTone(a.action),
								children: a.action
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs",
								children: a.entityType
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground line-clamp-2 mb-2",
							children: a.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted-foreground",
								children: a.entityId
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setDetailId(a.id),
								className: "text-info text-xs font-semibold inline-flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 12 }), " تفاصيل"]
							})]
						})
					]
				}, a.id)
			}),
			totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mt-3 px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: [
						"صفحة ",
						page,
						" من ",
						totalPages,
						" | ",
						total,
						" سجل"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "px-3 py-1.5 text-xs rounded-lg border bg-background hover:bg-muted disabled:opacity-40 min-h-[36px]",
						disabled: page <= 1,
						onClick: () => setPage((p) => Math.max(1, p - 1)),
						children: "السابق"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "px-3 py-1.5 text-xs rounded-lg border bg-background hover:bg-muted disabled:opacity-40 min-h-[36px]",
						disabled: page >= totalPages,
						onClick: () => setPage((p) => Math.min(totalPages, p + 1)),
						children: "التالي"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailId,
				onClose: () => setDetailId(null),
				title: "تفاصيل السجل",
				onSave: () => setDetailId(null),
				saveText: "إغلاق",
				children: detailData && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "p-3 bg-muted/30",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 gap-3 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "المستخدم",
										value: detailData.item.userName || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "الإجراء",
										value: detailData.item.action
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "نوع الكيان",
										value: detailData.item.entityType
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "رقم السجل",
										value: detailData.item.entityId
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "الوقت",
										value: detailData.item.timestamp || "—"
									}),
									detailData.item.ip && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "IP",
										value: detailData.item.ip
									})
								]
							})
						}),
						detailData.item.description && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-1",
							children: "الوصف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm p-3 bg-muted/30 rounded-lg",
							children: detailData.item.description
						})] }),
						(Boolean(detailData.before) || Boolean(detailData.after)) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-2",
							children: "التغييرات (Before / After)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 lg:grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SnapshotPanel, {
								title: "قبل",
								data: detailData.before,
								tone: "destructive"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SnapshotPanel, {
								title: "بعد",
								data: detailData.after,
								tone: "success"
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "p-3 bg-info/10 border-info",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: "⚠ سجل التدقيق للقراءة فقط — لا يمكن تعديل أو حذف السجلات من الواجهة."
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "بحث"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative mt-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								size: 16,
								className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "w-full rounded-xl border bg-background py-2.5 pr-9 pl-3 text-sm min-h-[44px]",
								placeholder: "بحث...",
								value: searchQuery,
								onChange: (e) => setSearchQuery(e.target.value)
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							label: "المستخدم",
							options: ["الكل", ...options.users],
							value: userFilter,
							onChange: (e) => setUserFilter(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							label: "نوع الإجراء",
							options: ["الكل", ...options.actions],
							value: actionFilter,
							onChange: (e) => setActionFilter(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							label: "الكيان",
							options: ["الكل", ...options.entities],
							value: entityFilter,
							onChange: (e) => setEntityFilter(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "التاريخ من"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: dateFrom,
							onChange: (e) => setDateFrom(e.target.value)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "التاريخ إلى"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "date",
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: dateTo,
							onChange: (e) => setDateTo(e.target.value)
						})] })
					]
				})
			})
		]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-[10px] text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-sm font-semibold break-words",
		children: value
	})] });
}
function SnapshotPanel({ title, data, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-lg border p-2 ${tone === "success" ? "bg-success/10" : "bg-destructive/10"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] font-semibold text-muted-foreground mb-1",
			children: title
		}), data == null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted-foreground italic",
			children: "لا توجد بيانات"
		}) : typeof data === "object" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "text-[10px] font-mono whitespace-pre-wrap break-words leading-relaxed",
			children: String(JSON.stringify(data, null, 2))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs break-words",
			children: String(data)
		})]
	});
}
function actionTone(action) {
	if (action.includes("حذف") || action.includes("إيقاف") || action.includes("إلغاء") || action.includes("رفض")) return "destructive";
	if (action.includes("إضافة") || action.includes("ترحيل") || action.includes("اعتماد") || action.includes("تفعيل") || action.includes("تسليم") || action.includes("تأهيل")) return "success";
	if (action.includes("تعديل") || action.includes("تحديث") || action.includes("عكس")) return "info";
	if (action.includes("بانتظار") || action.includes("مسودة")) return "warning";
	return "muted";
}
//#endregion
export { Page as component };
