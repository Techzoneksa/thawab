import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { B as Printer, Dt as FileText, Ht as CircleX, jt as Eye } from "../_libs/lucide-react.mjs";
import { A as Table, C as MobileSearchInput, D as PrintStyle, E as PrintButton, F as useAuth, N as showToast, S as MobilePageHeader, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/receipts-V3TMKoM5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var API_BASE = "/api/receipts";
async function getReceipts(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.type && filters.type !== "الكل") params.set("type", filters.type);
	if (filters.page) params.set("page", String(filters.page));
	if (filters.limit) params.set("limit", String(filters.limit));
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب الإيصالات");
	return res.json();
}
async function printReceipt(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "print"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في طباعة الإيصال");
	}
}
async function voidReceipt(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "void"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إلغاء الإيصال");
	}
	return (await res.json()).item;
}
async function deleteReceipt(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف الإيصال");
	}
}
function statusToneLocal(s) {
	if (s === "مرحّل") return "success";
	if (s === "ملغي") return "error";
	if (s === "معلق") return "warning";
	return "muted";
}
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [printTarget, setPrintTarget] = (0, import_react.useState)(null);
	const [voidTarget, setVoidTarget] = (0, import_react.useState)(null);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("الكل");
	const [apiFilters, setApiFilters] = (0, import_react.useState)({
		search: "",
		status: "",
		type: "",
		page: 1,
		limit: 50
	});
	const { data, isLoading, error } = useQuery({
		queryKey: ["receipts", apiFilters],
		queryFn: () => getReceipts(apiFilters)
	});
	const receipts = data?.items || [];
	const totalCount = data?.total || 0;
	(0, import_react.useEffect)(() => {
		setApiFilters((f) => ({
			...f,
			search: searchQuery,
			status: statusFilter,
			type: typeFilter
		}));
	}, [
		searchQuery,
		statusFilter,
		typeFilter
	]);
	const printMutation = useMutation({
		mutationFn: printReceipt,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["receipts"] });
			showToast("تم تجهيز الإيصال للطباعة", "success");
			setPrintTarget(null);
			window.print();
		},
		onError: (err) => showToast(err.message, "error")
	});
	const voidMutation = useMutation({
		mutationFn: voidReceipt,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["receipts"] });
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			showToast("تم إلغاء الإيصال بنجاح", "success");
			setVoidTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deleteReceipt,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["receipts"] });
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			showToast("تم حذف الإيصال بنجاح", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handlePrint = (r) => {
		printMutation.mutate({
			id: r.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleVoid = () => {
		if (voidTarget) voidMutation.mutate({
			id: voidTarget.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget,
			userId: user?.id,
			userName: user?.name
		});
	};
	const stats = [
		{
			label: "إجمالي الإيصالات",
			value: fmtSAR(receipts.reduce((s, r) => s + r.amount, 0))
		},
		{
			label: "مرحّل",
			value: receipts.filter((r) => r.status === "مرحّل").length
		},
		{
			label: "طباعة",
			value: receipts.filter((r) => r.printed).length
		},
		{
			label: "ملغي",
			value: receipts.filter((r) => r.status === "ملغي").length
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
			breadcrumb: [
				"الرئيسية",
				"التبرعات",
				"الإيصالات"
			],
			title: "الإيصالات الإلكترونية",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: receipts,
				filename: "الإيصالات.csv"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, { label: "طباعة دفعية" })] }),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
					children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground truncate",
							children: s.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold mt-1 tabular-nums truncate",
							children: s.value
						})]
					}, s.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1 min-w-[200px] hidden lg:block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {
							size: 14,
							className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
							placeholder: "بحث برقم الإيصال، اسم المتبرع...",
							value: searchQuery,
							onChange: (e) => setSearchQuery(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						label: "الحالة",
						options: [
							"الكل",
							"مرحّل",
							"ملغي"
						],
						value: statusFilter,
						onChange: (e) => setStatusFilter(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						label: "النوع",
						options: [
							"الكل",
							"تبرع",
							"مساعدة",
							"كفالة"
						],
						value: typeFilter,
						onChange: (e) => setTypeFilter(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
						variant: "ghost",
						className: "lg:hidden",
						onClick: () => setFilterOpen(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { size: 15 }), " تصفية"]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:hidden flex items-center gap-2 mb-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
						placeholder: "بحث عن إيصال...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
					title: "الإيصالات الإلكترونية",
					count: `${receipts.length} إيصال`
				}),
				isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center py-12",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
				}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "خطأ في تحميل البيانات",
					description: "حدث خطأ أثناء تحميل قائمة الإيصالات",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
						variant: "primary",
						onClick: () => queryClient.invalidateQueries({ queryKey: ["receipts"] }),
						children: "إعادة المحاولة"
					})
				}) : receipts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "لا توجد إيصالات",
					description: "الإيصالات ستظهر هنا عند إصدارها من التبرعات"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							columns: [
								"رقم الإيصال",
								"المتبرع",
								"المشروع",
								"المبلغ",
								"التاريخ",
								"الحالة",
								"مطبوع",
								""
							],
							rows: receipts,
							renderRow: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "font-mono text-xs",
									children: r.number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "font-semibold",
									children: r.donorName || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "text-muted-foreground text-xs",
									children: r.projectName || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "tabular-nums font-bold text-success",
									children: fmtSAR(r.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "text-muted-foreground text-xs",
									children: r.date
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusToneLocal(r.status),
									children: r.status
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: r.printed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "success",
									children: "نعم"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "muted",
									children: "لا"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getReceiptActions(r) }) })
							] })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:hidden space-y-2",
						children: receipts.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-sm",
										children: r.donorName || "—"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-muted-foreground",
										children: r.number
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-lg font-bold text-success",
									children: fmtSAR(r.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: r.date
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: statusToneLocal(r.status),
										children: r.status
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2 mt-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										className: "flex-1 rounded-lg bg-primary text-primary-foreground text-xs font-semibold py-2 min-h-[36px] flex items-center justify-center gap-1",
										onClick: () => handlePrint(r),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { size: 13 }), " طباعة"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => handlePrint(r),
										className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px] flex items-center justify-center gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { size: 13 }), " PDF"]
									})]
								})
							]
						}, r.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex items-center justify-between mt-4 text-xs text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"عرض ",
							receipts.length,
							" من ",
							totalCount,
							" إيصال"
						] })
					})
				] })
			]
		}),
		printTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiptPrintDrawer, {
			receipt: printTarget,
			onClose: () => setPrintTarget(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			open: !!voidTarget,
			onClose: () => setVoidTarget(null),
			onConfirm: handleVoid,
			title: "إلغاء الإيصال",
			message: `هل أنت متأكد من إلغاء إيصال ${voidTarget?.number}؟ سيتم تحديث حالة التبرع المرتبطة.`,
			confirmText: "إلغاء",
			cancelText: "التراجع",
			variant: "destructive"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
			open: !!deleteTarget,
			onClose: () => setDeleteTarget(null),
			onConfirm: handleDelete,
			title: "حذف الإيصال",
			message: "هل أنت متأكد من حذف هذا الإيصال؟",
			confirmText: "حذف",
			cancelText: "إلغاء",
			variant: "destructive"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
			open: filterOpen,
			onClose: () => setFilterOpen(false),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "الحالة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مرحّل" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ملغي" })
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "النوع"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
					value: typeFilter,
					onChange: (e) => setTypeFilter(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "تبرع" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مساعدة" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "كفالة" })
					]
				})] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintStyle, {})
	] });
	function getReceiptActions(r) {
		const actions = [{
			label: "طباعة",
			icon: Printer,
			onClick: () => handlePrint(r)
		}, {
			label: "عرض",
			icon: Eye,
			onClick: () => showToast(`${r.number}: ${r.donorName} - ${fmtSAR(r.amount)}`, "info")
		}];
		if (r.status !== "ملغي") actions.push({
			label: "إلغاء",
			icon: CircleX,
			variant: "destructive",
			onClick: () => setVoidTarget(r)
		});
		return actions;
	}
}
function ReceiptPrintDrawer({ receipt, onClose }) {
	(0, import_react.useEffect)(() => {
		window.print();
		onClose();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "print-only",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-8",
			dir: "rtl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center mb-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-bold",
						children: "ثواب — نظام إدارة الجمعيات الخيرية"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-semibold mt-2",
						children: "إيصال استلام تبرع"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "رقم الإيصال:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold",
								children: receipt.number
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "التاريخ:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: receipt.date })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المتبرع:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: receipt.donorName
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المشروع:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: receipt.projectName || "—" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "المبلغ:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold text-lg text-success",
								children: fmtSAR(receipt.amount)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "طريقة الدفع:" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: receipt.type })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 pt-4 border-t text-center text-sm text-muted-foreground",
					children: "هذا إيصال رسمي صادر من جمعية ثواب الخيرية"
				})
			]
		})
	});
}
//#endregion
export { Page as component };
