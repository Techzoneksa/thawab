import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.quotes._id.edit-BtuJe6Av.js
var $$splitComponentImporter = () => import("./procurement.quotes._id.edit-Cxnj7qcr.mjs");
var Route = createFileRoute("/procurement/quotes/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل عرض سعر — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
