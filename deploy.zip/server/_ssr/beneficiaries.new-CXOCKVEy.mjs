import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { n as MARITAL_STATUSES, r as createBeneficiary, t as ELIGIBILITY_STATUSES } from "./beneficiaries-aRDRq8QX.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/beneficiaries.new-CXOCKVEy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NewBeneficiaryPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const [name, setName] = (0, import_react.useState)("");
	const [fileNumber, setFileNumber] = (0, import_react.useState)("");
	const [idNumber, setIdNumber] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("أسرة");
	const [status, setStatus] = (0, import_react.useState)("جديد");
	const [familyMembers, setFamilyMembers] = (0, import_react.useState)("1");
	const [monthlyIncome, setMonthlyIncome] = (0, import_react.useState)("0");
	const [maritalStatus, setMaritalStatus] = (0, import_react.useState)("أعزب");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [saving, setSaving] = (0, import_react.useState)(false);
	const validate = () => {
		const e = {};
		if (!name.trim()) e.name = "اسم المستفيد مطلوب";
		if (!phone && !idNumber) e.phone = "رقم الجوال أو الهوية مطلوب";
		setErrors(e);
		return Object.keys(e).length === 0;
	};
	const handleSave = async (andClose) => {
		if (!validate()) {
			showToast("يرجى تصحيح الأخطاء قبل الحفظ", "error");
			return;
		}
		setSaving(true);
		try {
			const created = await createBeneficiary({
				name: name.trim(),
				fileNumber: fileNumber || void 0,
				idNumber: idNumber || void 0,
				phone: phone || void 0,
				city,
				address,
				category,
				status,
				familyMembers: parseInt(familyMembers) || 1,
				monthlyIncome: parseFloat(monthlyIncome) || 0,
				maritalStatus,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["beneficiaries"] });
			showToast(`تم تسجيل المستفيد ${created.name}`, "success");
			if (andClose) navigate({ to: "/beneficiaries" });
			else navigate({
				to: "/beneficiaries/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المستفيدون",
		breadcrumb: ["المستفيدون", "جديد"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [{
				label: "المستفيدون",
				to: "/beneficiaries"
			}, { label: "إضافة مستفيد" }],
			title: "إضافة مستفيد جديد",
			subtitle: "سجّل بيانات المستفيد لإضافته إلى قاعدة بيانات المستفيدين",
			draftNumber: "مسودة جديدة",
			status: {
				label: "جديد",
				tone: "info"
			},
			tabs: [
				{
					id: "personal",
					label: "البيانات الشخصية",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "بيانات المستفيد",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "الاسم",
								required: true,
								error: errors.name,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: name,
									onChange: (e) => setName(e.target.value),
									invalid: !!errors.name
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "رقم الملف",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: fileNumber,
									onChange: (e) => setFileNumber(e.target.value),
									dir: "ltr",
									className: "font-mono"
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "رقم الهوية",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: idNumber,
									onChange: (e) => setIdNumber(e.target.value),
									dir: "ltr",
									className: "font-mono"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "رقم الجوال",
								error: errors.phone,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: phone,
									onChange: (e) => setPhone(e.target.value),
									placeholder: "05xxxxxxxx",
									dir: "ltr",
									invalid: !!errors.phone
								})
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "المدينة",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: city,
									onChange: (e) => setCity(e.target.value)
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
								label: "العنوان",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
									value: address,
									onChange: (e) => setAddress(e.target.value)
								})
							})] })
						]
					})
				},
				{
					id: "family",
					label: "بيانات الأسرة",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "الحالة الأسرية والمالية",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "الحالة الاجتماعية",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
								value: maritalStatus,
								onChange: (e) => setMaritalStatus(e.target.value),
								children: MARITAL_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: s,
									children: s
								}, s))
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "عدد أفراد الأسرة",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
								type: "number",
								min: "1",
								value: familyMembers,
								onChange: (e) => setFamilyMembers(e.target.value),
								dir: "ltr",
								className: "font-mono tabular-nums"
							})
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "الدخل الشهري (ر.س)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
								type: "number",
								step: "0.01",
								value: monthlyIncome,
								onChange: (e) => setMonthlyIncome(e.target.value),
								dir: "ltr",
								className: "font-mono tabular-nums"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "فئة المستفيد",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
								value: category,
								onChange: (e) => setCategory(e.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "أسرة",
										children: "أسرة"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "يتيم",
										children: "يتيم"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "أرملة",
										children: "أرملة"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "مطلق",
										children: "مطلق"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "معاق",
										children: "معاق"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "طالب",
										children: "طالب"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "أخرى",
										children: "أخرى"
									})
								]
							})
						})] })]
					})
				},
				{
					id: "eligibility",
					label: "الأهلية والحالة",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "حالة الأهلية",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "حالة الأهلية",
							hint: "تستخدم لتحديد الأهلية لتلقي المساعدات",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
								value: status,
								onChange: (e) => setStatus(e.target.value),
								children: ELIGIBILITY_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: s,
									children: s
								}, s))
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-muted/40 p-3 text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-foreground",
									children: "ملاحظة:"
								}),
								" الأهلية تُحدّث آلياً بناءً على معايير الجمعية. الحالة الحالية هي «",
								status,
								"»."
							]
						})]
					})
				},
				{
					id: "notes",
					label: "الملاحظات",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
						title: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "ملاحظات",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
								value: notes,
								onChange: (e) => setNotes(e.target.value),
								rows: 6
							})
						})
					})
				}
			],
			defaultTab: "personal",
			loading: saving,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/beneficiaries" })
		})
	});
}
//#endregion
export { NewBeneficiaryPage as component };
