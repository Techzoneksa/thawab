import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.suppliers._id.edit-BQrBo6wP.js
var $$splitComponentImporter = () => import("./procurement.suppliers._id.edit-CeynAwYd.mjs");
var Route = createFileRoute("/procurement/suppliers/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل مورد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
