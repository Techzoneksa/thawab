import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.orders._id.edit-CBUFb_Ds.js
var $$splitComponentImporter = () => import("./procurement.orders._id.edit-COs4GwSh.mjs");
var Route = createFileRoute("/procurement/orders/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل أمر شراء — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
