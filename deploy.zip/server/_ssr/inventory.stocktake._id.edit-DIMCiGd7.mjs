import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.stocktake._id.edit-DIMCiGd7.js
var $$splitComponentImporter = () => import("./inventory.stocktake._id.edit-CRRjQT3u.mjs");
var Route = createFileRoute("/inventory/stocktake/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل جرد — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
