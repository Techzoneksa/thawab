//#region node_modules/.nitro/vite/services/ssr/assets/purchase-requests-CdC7mUrc.js
var API_BASE = "/api/procurement/requests";
var REQUEST_STATUSES = [
	"مسودة",
	"بانتظار الموافقة",
	"معتمد",
	"مرفوض",
	"محول إلى أمر شراء",
	"ملغي"
];
var REQUEST_PRIORITIES = [
	"عاجل",
	"متوسطة",
	"منخفضة"
];
async function getPurchaseRequests(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.department && filters.department !== "الكل") params.set("department", filters.department);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب طلبات الشراء");
	return res.json();
}
async function getPurchaseRequest(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات طلب الشراء");
	return res.json();
}
async function createPurchaseRequest(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة طلب الشراء");
	}
	return (await res.json()).item;
}
async function updatePurchaseRequest(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث طلب الشراء");
	}
	return (await res.json()).item;
}
async function workflowAction(action, options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || `فشل في تنفيذ الإجراء`);
	}
	return (await res.json()).item;
}
var submitPurchaseRequest = (o) => workflowAction("submit", o);
var approvePurchaseRequest = (o) => workflowAction("approve", o);
var rejectPurchaseRequest = (o) => workflowAction("reject", o);
var returnPurchaseRequestToDraft = (o) => workflowAction("returnToDraft", o);
var cancelPurchaseRequest = (o) => workflowAction("cancel", o);
async function deletePurchaseRequest(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف طلب الشراء");
	}
}
//#endregion
export { createPurchaseRequest as a, getPurchaseRequests as c, submitPurchaseRequest as d, updatePurchaseRequest as f, cancelPurchaseRequest as i, rejectPurchaseRequest as l, REQUEST_STATUSES as n, deletePurchaseRequest as o, approvePurchaseRequest as r, getPurchaseRequest as s, REQUEST_PRIORITIES as t, returnPurchaseRequestToDraft as u };
