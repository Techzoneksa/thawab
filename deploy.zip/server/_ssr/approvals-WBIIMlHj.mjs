import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Ht as CircleX, I as RotateCcw, Rt as Clock, Ut as CircleCheck, dn as ArrowLeft, wt as Funnel, yt as Inbox } from "../_libs/lucide-react.mjs";
import { E as PrintButton, N as showToast, P as statusTone, S as MobilePageHeader, _ as FilterBar, a as Btn, b as MobileFilterDrawer, g as ExportButton, h as EntityFormDrawer, i as Badge, k as Select, m as EmptyState, n as AppShell, s as Card, w as MobileTabBar } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, n as APPROVALS } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/approvals-WBIIMlHj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const [tab, setTab] = (0, import_react.useState)("بانتظار موافقتي");
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [approvals, setApprovals] = (0, import_react.useState)(APPROVALS.map((a) => ({
		...a,
		status: "بانتظار الموافقة"
	})));
	const [noteOpen, setNoteOpen] = (0, import_react.useState)(false);
	const [noteText, setNoteText] = (0, import_react.useState)("");
	const [noteTarget, setNoteTarget] = (0, import_react.useState)(null);
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("الكل");
	const [priorityFilter, setPriorityFilter] = (0, import_react.useState)("الكل");
	const tabs = [
		{
			name: "بانتظار موافقتي",
			count: 12,
			icon: Inbox
		},
		{
			name: "قمت بإنشائها",
			count: 8,
			icon: Clock
		},
		{
			name: "معتمدة",
			count: 142
		},
		{
			name: "مرفوضة",
			count: 6
		},
		{
			name: "مُعادة للتصحيح",
			count: 3
		}
	];
	const tabNames = tabs.map((t) => t.name);
	const [mobileTab, setMobileTab] = (0, import_react.useState)(tabNames[0]);
	const filtered = approvals.filter((a) => {
		if (typeFilter !== "الكل" && a.type !== typeFilter) return false;
		if (priorityFilter !== "الكل" && a.priority !== priorityFilter) return false;
		if (tab === "معتمدة" && a.status !== "معتمد") return false;
		if (tab === "مرفوضة" && a.status !== "مرفوض") return false;
		if (tab === "مُعادة للتصحيح" && a.status !== "مُعاد") return false;
		if (tab === "بانتظار موافقتي" && a.status !== "بانتظار الموافقة") return false;
		return true;
	});
	const handleApprove = (id) => {
		setApprovals((prev) => prev.map((a) => a.id === id ? {
			...a,
			status: "معتمد"
		} : a));
		showToast("تم اعتماد الطلب بنجاح", "success");
	};
	const handleReject = (id) => {
		setApprovals((prev) => prev.map((a) => a.id === id ? {
			...a,
			status: "مرفوض"
		} : a));
		showToast("تم رفض الطلب", "success");
	};
	const handleReturn = (id) => {
		setApprovals((prev) => prev.map((a) => a.id === id ? {
			...a,
			status: "مُعاد"
		} : a));
		showToast("تم إرجاع الطلب للتصحيح", "info");
	};
	const openNote = (id) => {
		setNoteTarget(id);
		setNoteText("");
		setNoteOpen(true);
	};
	const handleSaveNote = () => {
		if (noteText.trim()) {
			showToast(`تم إضافة الملاحظة: ${noteText}`, "info");
			setNoteOpen(false);
			setNoteText("");
		} else showToast("الرجاء كتابة الملاحظة", "error");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: ["الرئيسية", "الموافقات"],
		title: "صندوق الموافقات",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: approvals,
				filename: "الموافقات.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => setFilterOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 }), "تصفية"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
				variant: "primary",
				onClick: () => showToast("تم اعتماد الطلبات المحددة", "success"),
				children: "اعتماد المحدد"
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden lg:flex flex-wrap items-center gap-1 border-b mb-4",
				children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setTab(t.name),
					className: `px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${tab === t.name ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`,
					children: [
						t.name,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-1 text-xs rounded-full bg-muted px-2 py-0.5",
							children: t.count
						})
					]
				}, t.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, { title: "صندوق الموافقات" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTabBar, {
					tabs: tabNames,
					active: mobileTab,
					onChange: setMobileTab
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "النوع",
					options: [
						"الكل",
						"قيد يومية",
						"طلب شراء",
						"مساعدة",
						"ميزانية مشروع",
						"فاتورة مورد"
					],
					value: typeFilter,
					onChange: (e) => setTypeFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الأولوية",
					options: [
						"الكل",
						"عالية",
						"متوسطة",
						"منخفضة"
					],
					value: priorityFilter,
					onChange: (e) => setPriorityFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "المُنشِئ",
					options: [
						"الكل",
						"محاسب",
						"مشتريات",
						"باحث",
						"م. المشاريع"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الفترة",
					options: [
						"اليوم",
						"هذا الأسبوع",
						"هذا الشهر"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-5 gap-3 lg:gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-3 space-y-3",
					children: [filtered.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "لا توجد موافقات",
						description: "جميع الطلبات تمت معالجتها"
					}), filtered.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						className: "p-3 lg:p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								className: "mt-1 shrink-0",
								defaultChecked: i === 0 && a.status === "بانتظار الموافقة"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-[11px] text-muted-foreground",
												children: a.id
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												tone: "primary",
												children: a.type
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												tone: a.priority === "عالية" ? "destructive" : a.priority === "متوسطة" ? "warning" : "muted",
												children: a.priority
											}),
											a.status !== "بانتظار الموافقة" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												tone: statusTone(a.status),
												children: a.status
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
										className: "mt-1 font-semibold text-sm",
										children: a.subject
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-1 text-xs text-muted-foreground",
										children: [
											a.requester,
											" · المستوى: ",
											a.level,
											" · ",
											a.date
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex flex-col lg:flex-row lg:items-center justify-between gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "tabular-nums font-bold text-base lg:text-lg",
												children: fmtSAR(a.amount)
											}),
											a.status === "بانتظار الموافقة" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "hidden lg:flex gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														onClick: () => handleApprove(a.id),
														className: "inline-flex items-center gap-1.5 rounded-lg bg-success/15 text-success px-3 py-1.5 text-xs font-semibold hover:bg-success/25 min-h-[32px]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 14 }), " اعتماد"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														onClick: () => handleReturn(a.id),
														className: "inline-flex items-center gap-1.5 rounded-lg bg-warning/20 text-warning-foreground px-3 py-1.5 text-xs font-semibold hover:bg-warning/30 min-h-[32px]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 14 }), " إعادة"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														onClick: () => handleReject(a.id),
														className: "inline-flex items-center gap-1.5 rounded-lg bg-destructive/15 text-destructive px-3 py-1.5 text-xs font-semibold hover:bg-destructive/25 min-h-[32px]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { size: 14 }), " رفض"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														onClick: () => openNote(a.id),
														className: "inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold hover:bg-muted min-h-[32px]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 14 }), " إضافة ملاحظة"]
													})
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "lg:hidden grid grid-cols-2 gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														onClick: () => handleApprove(a.id),
														className: "rounded-lg bg-success/15 text-success py-2.5 text-xs font-semibold min-h-[36px]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
															size: 14,
															className: "inline ml-1"
														}), " اعتماد"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														onClick: () => handleReject(a.id),
														className: "rounded-lg bg-destructive/15 text-destructive py-2.5 text-xs font-semibold min-h-[36px]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, {
															size: 14,
															className: "inline ml-1"
														}), " رفض"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
														onClick: () => handleReturn(a.id),
														className: "rounded-lg bg-warning/20 text-warning-foreground py-2.5 text-xs font-semibold min-h-[36px]",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
															size: 14,
															className: "inline ml-1"
														}), " إعادة"]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														onClick: () => openNote(a.id),
														className: "rounded-lg border py-2.5 text-xs font-semibold min-h-[36px]",
														children: "ملاحظة"
													})
												]
											})] }),
											a.status !== "بانتظار الموافقة" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-xs text-muted-foreground",
												children: ["تمت المعالجة · ", a.status]
											})
										]
									})
								]
							})]
						})
					}, a.id))]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "hidden lg:block lg:col-span-2 p-5 h-fit sticky top-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-bold mb-1",
							children: APPROVALS[0].subject
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								APPROVALS[0].id,
								" · ",
								APPROVALS[0].type
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3 mt-4 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground text-xs",
									children: "المبلغ"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums",
									children: fmtSAR(APPROVALS[0].amount)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground text-xs",
									children: "مقدم الطلب"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-semibold",
									children: APPROVALS[0].requester
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground text-xs",
									children: "المركز"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "المركز المالي 41" })] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground text-xs",
									children: "المشروع"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: "السلال الغذائية الشهرية" })] })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-semibold text-sm mb-3",
								children: "مسار الاعتماد"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
								className: "relative border-r-2 border-muted pr-4 space-y-4",
								children: [
									{
										who: "محاسب: سارة الزهراني",
										when: "أمس 16:40",
										state: "تم الإنشاء",
										tone: "success"
									},
									{
										who: "محاسب أول: محمد الغامدي",
										when: "اليوم 09:12",
										state: "تمت المراجعة",
										tone: "success"
									},
									{
										who: "المدير المالي: سعد الغامدي",
										when: "بانتظار",
										state: "بانتظار الاعتماد",
										tone: "warning"
									},
									{
										who: "المدير التنفيذي",
										when: "—",
										state: "غير مفعّل",
										tone: "muted"
									}
								].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "relative",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute -right-[26px] top-1.5 h-3 w-3 rounded-full ring-4 ring-card ${s.tone === "success" ? "bg-success" : s.tone === "warning" ? "bg-warning" : "bg-muted-foreground/40"}` }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-semibold",
											children: s.who
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs text-muted-foreground",
											children: s.when
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											tone: s.tone,
											children: s.state
										})
									]
								}, i))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-semibold text-sm mb-2",
									children: "ملاحظات"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									rows: 3,
									className: "w-full rounded-lg border bg-background p-2 text-sm",
									placeholder: "اكتب ملاحظتك على الموافقة...",
									value: noteText,
									onChange: (e) => setNoteText(e.target.value)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-end gap-2 mt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
										variant: "outline",
										onClick: () => setNoteText(""),
										children: "حفظ كمسودة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
										variant: "primary",
										onClick: () => {
											if (noteText.trim()) {
												showToast(`تم إرسال الملاحظة: ${noteText}`, "success");
												setNoteText("");
											} else showToast("الرجاء كتابة الملاحظة", "error");
										},
										children: "اعتماد وإرسال"
									})]
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden fixed bottom-16 right-0 left-0 z-20 border-t bg-surface/95 backdrop-blur px-4 py-3 safe-area-bottom shadow-[0_-2px_6px_rgba(0,0,0,0.06)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground truncate",
							children: APPROVALS[0].subject
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm font-bold tabular-nums",
							children: fmtSAR(APPROVALS[0].amount)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => handleApprove(APPROVALS[0].id),
							className: "rounded-lg bg-success/15 text-success px-4 py-2 text-xs font-semibold min-h-[36px]",
							children: "اعتماد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => handleReject(APPROVALS[0].id),
							className: "rounded-lg bg-destructive/15 text-destructive px-4 py-2 text-xs font-semibold min-h-[36px]",
							children: "رفض"
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: noteOpen,
				onClose: () => setNoteOpen(false),
				title: "إضافة ملاحظة",
				onSave: handleSaveNote,
				saveText: "إضافة",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "الملاحظة"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					rows: 5,
					value: noteText,
					onChange: (e) => setNoteText(e.target.value),
					placeholder: "اكتب ملاحظتك..."
				})] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "النوع"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: typeFilter,
							onChange: (e) => setTypeFilter(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "قيد يومية" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "طلب شراء" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مساعدة" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ميزانية مشروع" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "فاتورة مورد" })
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الأولوية"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: priorityFilter,
							onChange: (e) => setPriorityFilter(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "عالية" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "متوسطة" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "منخفضة" })
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الفترة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "اليوم" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "هذا الأسبوع" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "هذا الشهر" })
							]
						})] })
					]
				})
			})
		]
	});
}
//#endregion
export { Page as component };
