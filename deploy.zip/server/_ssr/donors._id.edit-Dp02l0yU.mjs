import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, y as useParams } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, P as statusTone, i as Badge, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, o as FormSegmented, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { a as updateDonor, n as deleteDonor, r as getDonor } from "./donors-BTleOe7U.mjs";
import { a as getDonations } from "./donations-CspILvNi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donors._id.edit-Dp02l0yU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditDonorPage() {
	const { id } = useParams({ from: "/donors/$id/edit" });
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: donorData, isLoading } = useQuery({
		queryKey: ["donor", id],
		queryFn: () => getDonor(id),
		enabled: !!id
	});
	const { data: donationsData } = useQuery({
		queryKey: ["donations-for-donor", id],
		queryFn: () => getDonations({
			donorId: id,
			limit: 50
		}),
		enabled: !!id
	});
	const recentDonations = donationsData?.items || [];
	const donor = donorData;
	const [name, setName] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("فرد");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [tag, setTag] = (0, import_react.useState)("عام");
	const [recurring, setRecurring] = (0, import_react.useState)(false);
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [saving, setSaving] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (donor) {
			setName(donor.name || "");
			setType(donor.type || "فرد");
			setPhone(donor.phone || "");
			setEmail(donor.email || "");
			setCity(donor.city || "");
			setAddress(donor.address || "");
			setTag(donor.tag || "عام");
			setRecurring(donor.recurring || false);
			setNotes(donor.notes || "");
		}
	}, [donor]);
	const updateMutation = useMutation({
		mutationFn: (data) => updateDonor({
			id,
			...data
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donor", id] });
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast("تم تحديث المتبرع بنجاح", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: () => deleteDonor({
			id,
			userId: user?.id,
			userName: user?.name
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast("تم حذف المتبرع", "success");
			navigate({ to: "/donors" });
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleSave = async (andClose) => {
		const e = {};
		if (!name.trim()) e.name = "اسم المتبرع مطلوب";
		setErrors(e);
		if (Object.keys(e).length > 0) {
			showToast("يرجى تصحيح الأخطاء قبل الحفظ", "error");
			return;
		}
		setSaving(true);
		try {
			await updateMutation.mutateAsync({
				name: name.trim(),
				type,
				phone: phone || null,
				email: email || null,
				city,
				address,
				tag,
				recurring,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			if (andClose) navigate({ to: "/donors" });
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المتبرعون",
		breadcrumb: ["المتبرعون", "تحميل..."],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!donor) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المتبرعون",
		breadcrumb: ["المتبرعون"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center py-12",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-base font-bold mb-2",
				children: "المتبرع غير موجود"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => navigate({ to: "/donors" }),
				className: "text-primary hover:underline text-sm",
				children: "العودة إلى المتبرعين"
			})]
		})
	});
	const tabs = [
		{
			id: "basic",
			label: "البيانات الأساسية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات المتبرع",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الاسم",
						required: true,
						error: errors.name,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value),
							invalid: !!errors.name
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "النوع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: type,
							onChange: (e) => setType(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "فرد",
									children: "فرد"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "شركة",
									children: "شركة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "مؤسسة",
									children: "مؤسسة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "جهة حكومية",
									children: "جهة حكومية"
								})
							]
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "رقم الجوال",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: phone,
							onChange: (e) => setPhone(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "البريد الإلكتروني",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "email",
							value: email,
							onChange: (e) => setEmail(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المدينة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: city,
							onChange: (e) => setCity(e.target.value)
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "العنوان",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: address,
							onChange: (e) => setAddress(e.target.value)
						})
					})] })
				]
			})
		},
		{
			id: "categorization",
			label: "التصنيف",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "تصنيف المتبرع",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الوسم",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
						value: tag,
						onChange: (e) => setTag(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "عام",
								children: "عام"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "VIP",
								children: "VIP"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "متكرر",
								children: "متكرر"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "جديد",
								children: "جديد"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "غير نشط",
								children: "غير نشط"
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "متبرع متكرر",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSegmented, {
						value: recurring ? "yes" : "no",
						onChange: (v) => setRecurring(v === "yes"),
						options: [{
							value: "yes",
							label: "نعم — متبرع متكرر"
						}, {
							value: "no",
							label: "لا — تبرع لمرة واحدة"
						}]
					})
				})]
			})
		},
		{
			id: "history",
			label: "تاريخ التبرعات",
			badge: recentDonations.length || void 0,
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "آخر التبرعات",
				children: recentDonations.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "لا توجد تبرعات مسجلة بعد."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: recentDonations.slice(0, 10).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => navigate({
							to: "/donations/$id/edit",
							params: { id: d.id }
						}),
						className: "w-full text-right rounded-lg border bg-background p-3 hover:bg-muted/40 transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted-foreground",
								children: d.id
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(d.status),
								children: d.status
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: d.date
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-bold tabular-nums",
								children: fmtSAR(d.amount)
							})]
						})]
					}, d.id))
				})
			})
		},
		{
			id: "summary",
			label: "الملخص والإحصاءات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "إحصاءات المتبرع",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "إجمالي التبرعات",
							value: fmtSAR(donor.totalDonations),
							tone: "success"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "عدد التبرعات",
							value: fmtNum(donor.donationCount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "آخر تبرع",
							value: donor.lastDonation || "—"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "الحالة",
							value: donor.status
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "تاريخ التسجيل",
							value: donor.createdAt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
							label: "أنشأ بواسطة",
							value: donor.createdBy || "—"
						})
					]
				})
			})
		},
		{
			id: "notes",
			label: "ملاحظات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "ملاحظات داخلية",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 6
					})
				})
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المتبرعون",
		breadcrumb: ["المتبرعون", donor.name],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [{
				label: "المتبرعون",
				to: "/donors"
			}, { label: donor.name }],
			title: donor.name,
			subtitle: `${donor.type} · ${donor.city || "—"}`,
			draftNumber: donor.id,
			status: {
				label: donor.status,
				tone: statusTone(donor.status)
			},
			tabs,
			defaultTab: "basic",
			loading: saving || updateMutation.isPending,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/donors" }),
			extraActions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					if (window.confirm("هل تريد حذف هذا المتبرع؟")) deleteMutation.mutate();
				},
				disabled: deleteMutation.isPending,
				className: "inline-flex items-center justify-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 text-destructive px-3 py-2 text-sm font-medium hover:bg-destructive/20 transition-colors min-h-[40px]",
				children: "حذف"
			})
		})
	});
}
//#endregion
export { EditDonorPage as component };
