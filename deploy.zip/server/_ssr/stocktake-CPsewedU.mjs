//#region node_modules/.nitro/vite/services/ssr/assets/stocktake-CPsewedU.js
var API_BASE = "/api/inventory/stocktake";
var STOCKTAKE_STATUSES = [
	"مسودة",
	"بانتظار الاعتماد",
	"معتمد",
	"مغلق"
];
async function getStocktakes(filters = {}) {
	const params = new URLSearchParams();
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب عمليات الجرد");
	return res.json();
}
async function getStocktake(id) {
	const res = await fetch(`${API_BASE}?id=${id}`);
	if (!res.ok) throw new Error("فشل في جلب بيانات الجرد");
	return res.json();
}
async function createStocktake(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة الجرد");
	}
	return (await res.json()).item;
}
async function updateStocktake(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث الجرد");
	}
	return (await res.json()).item;
}
async function submitStocktake(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "submit"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إرسال الجرد للاعتماد");
	}
	return (await res.json()).item;
}
async function approveStocktake(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "approve"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في اعتماد الجرد");
	}
	return (await res.json()).item;
}
async function closeStocktake(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "close"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إغلاق الجرد");
	}
	return (await res.json()).item;
}
async function deleteStocktake(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف الجرد");
	}
}
//#endregion
export { deleteStocktake as a, submitStocktake as c, createStocktake as i, updateStocktake as l, approveStocktake as n, getStocktake as o, closeStocktake as r, getStocktakes as s, STOCKTAKE_STATUSES as t };
