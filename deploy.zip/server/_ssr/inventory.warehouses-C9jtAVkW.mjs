import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { P as Search, T as SquarePen, U as Plus, b as ToggleLeft, jt as Eye, o as Warehouse, v as Trash2, y as ToggleRight } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as deleteWarehouse, i as deactivateWarehouse, n as activateWarehouse, s as getWarehouses, t as WAREHOUSE_STATUSES } from "./warehouses-sU_fp7nA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/inventory.warehouses-C9jtAVkW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const { data, isLoading, error } = useQuery({
		queryKey: ["warehouses", {
			search: searchQuery,
			status: statusFilter
		}],
		queryFn: () => getWarehouses({
			search: searchQuery,
			status: statusFilter
		})
	});
	const detailQuery = useQuery({
		queryKey: ["warehouseDetail", detailId],
		queryFn: async () => detailId ? await fetch(`/api/inventory/warehouses?id=${detailId}`).then((r) => r.json()) : null,
		enabled: !!detailId
	});
	const activateMutation = useMutation({
		mutationFn: activateWarehouse,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["warehouses"] });
			showToast("تم تفعيل المستودع", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deactivateMutation = useMutation({
		mutationFn: deactivateWarehouse,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["warehouses"] });
			showToast("تم تعطيل المستودع", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deleteWarehouse,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["warehouses"] });
			showToast("تم حذف المستودع", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => {
		navigate({ to: "/inventory/warehouses/new" });
	};
	const openEdit = (w) => {
		navigate({
			to: "/inventory/warehouses/$id/edit",
			params: { id: w.id }
		});
	};
	const handleToggle = (w) => {
		if (w.status === "نشط") deactivateMutation.mutate({
			id: w.id,
			userId: user?.id,
			userName: user?.name
		});
		else activateMutation.mutate({
			id: w.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const items = data?.items || [];
	const total = data?.total || 0;
	const stats = {
		active: items.filter((w) => w.status === "نشط").length,
		inactive: items.filter((w) => w.status === "موقوف").length,
		totalCapacity: items.reduce((s, w) => s + (w.capacity || 0), 0),
		total
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المخزون",
			"المستودعات"
		],
		title: "المستودعات",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
			data: items.map((w) => ({
				id: w.id,
				name: w.name,
				location: w.location,
				manager: w.manager,
				capacity: w.capacity,
				status: w.status,
				notes: w.notes
			})),
			filename: "warehouses.csv"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: openAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "إضافة مستودع"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "إجمالي المستودعات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold tabular-nums",
							children: fmtSAR(stats.total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "نشط"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-success tabular-nums",
							children: fmtSAR(stats.active)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "موقوف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-muted-foreground tabular-nums",
							children: fmtSAR(stats.inactive)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "السعة الإجمالية"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-primary tabular-nums",
							children: fmtSAR(stats.totalCapacity)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:flex items-center gap-2 mb-3 hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "rounded-lg border bg-background py-1.5 px-3 text-sm",
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), WAREHOUSE_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "المستودعات",
				count: `${total} مستودع`
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء جلب المستودعات",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["warehouses"] }),
					children: "إعادة المحاولة"
				})
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد مستودعات",
				description: "ابدأ بإضافة أول مستودع لتخزين الأصناف",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة مستودع"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الاسم",
					"الموقع",
					"المسؤول",
					"السعة",
					"الحالة",
					""
				],
				rows: items,
				renderRow: (w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => navigate({
							to: "/inventory/warehouses/$id/edit",
							params: { id: w.id }
						}),
						className: "font-semibold hover:text-primary text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Warehouse, {
							size: 13,
							className: "inline ms-1 text-primary"
						}), w.name]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-muted-foreground",
						children: w.location || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-xs",
						children: w.manager || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums font-bold",
						children: fmtSAR(w.capacity)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(w.status),
						children: w.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getWarehouseActions(w, setDetailId, openEdit, handleToggle, setDeleteTarget) }) })
				] }),
				mobileCard: (w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(w.status),
								children: w.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-muted-foreground",
								children: ["السعة: ", fmtSAR(w.capacity)]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => navigate({
								to: "/inventory/warehouses/$id/edit",
								params: { id: w.id }
							}),
							className: "font-semibold text-right hover:text-primary",
							children: w.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted-foreground mt-1",
							children: [
								w.location || "—",
								" · ",
								w.manager || "بدون مسؤول"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 mt-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px]",
								onClick: () => openEdit(w),
								children: "تعديل"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "flex-1 rounded-lg border text-xs font-semibold py-2 min-h-[36px]",
								onClick: () => handleToggle(w),
								children: w.status === "نشط" ? "تعطيل" : "تفعيل"
							})]
						})
					]
				}, w.id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailId,
				onClose: () => setDetailId(null),
				title: `تفاصيل المستودع: ${detailQuery.data?.item?.name || ""}`,
				onSave: () => setDetailId(null),
				saveText: "إغلاق",
				children: detailQuery.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحالة",
									value: detailQuery.data.item.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الموقع",
									value: detailQuery.data.item.location || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "المسؤول",
									value: detailQuery.data.item.manager || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "السعة",
									value: fmtSAR(detailQuery.data.item.capacity)
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-primary/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-muted-foreground mb-2",
								children: "إحصائيات المستودع"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
										label: "عدد الأصناف",
										value: fmtSAR(detailQuery.data.itemCount)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
										label: "إجمالي الحركات",
										value: fmtSAR(detailQuery.data.movementCount)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
										label: "إجمالي الكمية",
										value: fmtSAR(detailQuery.data.totalQty)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatBox, {
										label: "نسبة الإشغال",
										value: `${detailQuery.data.item.capacity > 0 ? Math.round(detailQuery.data.totalQty / detailQuery.data.item.capacity * 100) : 0}%`
									})
								]
							})]
						}),
						detailQuery.data.item.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-1",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm",
							children: detailQuery.data.item.notes
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: () => {
					if (deleteTarget) deleteMutation.mutate({
						id: deleteTarget.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "تأكيد الحذف",
				message: deleteTarget ? `هل تريد حذف المستودع "${deleteTarget.name}"؟ لا يمكن الحذف إذا كان يحتوي على أصناف أو حركات.` : "",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			})
		]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-semibold",
			children: value
		})]
	});
}
function StatBox({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "font-bold tabular-nums",
			children: value
		})]
	});
}
function getWarehouseActions(w, setDetailId, openEdit, handleToggle, setDeleteTarget) {
	return [
		{
			label: "عرض التفاصيل",
			icon: Eye,
			onClick: () => setDetailId(w.id)
		},
		{
			label: "تعديل",
			icon: SquarePen,
			onClick: () => openEdit(w)
		},
		{
			label: w.status === "نشط" ? "تعطيل" : "تفعيل",
			icon: w.status === "نشط" ? ToggleLeft : ToggleRight,
			onClick: () => handleToggle(w)
		},
		{
			label: "حذف",
			icon: Trash2,
			variant: "destructive",
			onClick: () => setDeleteTarget(w)
		}
	];
}
//#endregion
export { Page as component };
