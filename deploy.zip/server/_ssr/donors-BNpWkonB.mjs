import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { J as Pencil, P as Search, d as UserPlus, jt as Eye, v as Trash2, wt as Funnel } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, E as PrintButton, F as useAuth, N as showToast, S as MobilePageHeader, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { a as updateDonor, i as getDonors, n as deleteDonor, t as createDonor } from "./donors-BTleOe7U.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donors-BNpWkonB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function tagTone(t) {
	return t === "ذهبي" ? "warning" : t === "فضي" ? "info" : "muted";
}
function Page() {
	const queryClient = useQueryClient();
	const navigate = useNavigate();
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("الكل");
	const [tagFilter, setTagFilter] = (0, import_react.useState)("الكل");
	const [cityFilter, setCityFilter] = (0, import_react.useState)("الكل");
	const [recurringFilter, setRecurringFilter] = (0, import_react.useState)("الكل");
	const [apiFilters, setApiFilters] = (0, import_react.useState)({
		search: "",
		type: "",
		tag: "",
		city: "",
		page: 1,
		limit: 50
	});
	const { data, isLoading, error } = useQuery({
		queryKey: ["donors", apiFilters],
		queryFn: () => getDonors(apiFilters)
	});
	const donors = data?.items || [];
	const total = data?.total || 0;
	(0, import_react.useEffect)(() => {
		setApiFilters((f) => ({
			...f,
			search: searchQuery,
			type: typeFilter,
			tag: tagFilter,
			city: cityFilter
		}));
	}, [
		searchQuery,
		typeFilter,
		tagFilter,
		cityFilter
	]);
	const { user } = useAuth();
	useMutation({
		mutationFn: createDonor,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast("تم إضافة المتبرع بنجاح", "success");
			setAddDonorOpen(false);
		},
		onError: (err) => showToast(err.message, "error")
	});
	useMutation({
		mutationFn: updateDonor,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast("تم تحديث بيانات المتبرع بنجاح", "success");
			setAddDonorOpen(false);
			setEditingDonor(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deleteDonor,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast("تم حذف المتبرع بنجاح", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAddDonor = () => {
		navigate({ to: "/donors/new" });
	};
	const openEditDonor = (d) => {
		navigate({
			to: "/donors/$id/edit",
			params: { id: d.id }
		});
	};
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget,
			userId: user?.id,
			userName: user?.name
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"التبرعات والمتبرعون",
			"المتبرعون"
		],
		title: "إدارة المتبرعين (CRM)",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: donors,
				filename: "المتبرعون.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: openAddDonor,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { size: 15 }), " متبرع جديد"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: [
					{
						l: "إجمالي المتبرعين",
						v: fmtNum(total || donors.length)
					},
					{
						l: "متبرعون نشطون",
						v: fmtNum(donors.filter((d) => d.status === "نشط").length)
					},
					{
						l: "متبرعون متكررون",
						v: fmtNum(donors.filter((d) => d.recurring).length)
					},
					{
						l: "متوسط التبرع",
						v: fmtSAR(420)
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate",
						children: s.l
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base lg:text-xl font-extrabold mt-1 tabular-nums",
						children: s.v
					})]
				}, s.l))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث باسم المتبرع، الجوال، البريد...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "النوع",
					options: [
						"الكل",
						"فرد",
						"شركة",
						"مؤسسة"
					],
					value: typeFilter,
					onChange: (e) => setTypeFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "التصنيف",
					options: [
						"الكل",
						"ذهبي",
						"فضي",
						"برونزي"
					],
					value: tagFilter,
					onChange: (e) => setTagFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "المدينة",
					options: [
						"الكل",
						"الرياض",
						"جدة",
						"الدمام",
						"مكة المكرمة"
					],
					value: cityFilter,
					onChange: (e) => setCityFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "متكرر",
					options: [
						"الكل",
						"نعم",
						"لا"
					],
					value: recurringFilter,
					onChange: (e) => setRecurringFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث عن متبرع...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "المتبرعون",
				count: `${donors.length} متبرع`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAddDonor,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { size: 15 })
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء تحميل قائمة المتبرعين",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["donors"] }),
					children: "إعادة المحاولة"
				})
			}) : donors.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا يوجد متبرعون",
				description: "ابدأ بإضافة أول متبرع للنظام",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAddDonor,
					children: "إضافة متبرع"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
					columns: [
						"الرقم",
						"اسم المتبرع",
						"النوع",
						"المدينة",
						"إجمالي التبرعات",
						"عدد العمليات",
						"متكرر",
						"التصنيف",
						""
					],
					rows: donors,
					renderRow: (d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "font-mono text-xs",
							children: d.id
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/donors/$id",
							params: { id: d.id },
							className: "font-semibold hover:text-primary",
							children: d.name
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "info",
							children: d.type
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "text-muted-foreground",
							children: d.city
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "tabular-nums font-bold",
							children: fmtSAR(d.totalDonations)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
							className: "tabular-nums",
							children: d.donationCount
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: d.recurring ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "success",
							children: "نعم"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "لا" }) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: tagTone(d.tag),
							children: d.tag
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
							{
								label: "عرض",
								icon: Eye,
								onClick: () => showToast(`${d.name} - إجمالي ${fmtSAR(d.totalDonations)}`, "info")
							},
							{
								label: "تعديل",
								icon: Pencil,
								onClick: () => openEditDonor(d)
							},
							{
								label: "حذف",
								icon: Trash2,
								onClick: () => setDeleteTarget(d.id),
								variant: "destructive"
							}
						] }) })
					] }),
					mobileCard: (d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/donors/$id",
						params: { id: d.id },
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "p-3 hover:border-primary transition-colors",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-primary to-info text-white text-sm font-bold",
									children: d.name[0]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-sm font-bold truncate",
													children: d.name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs text-muted-foreground",
													children: d.city
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													tone: tagTone(d.tag),
													children: d.tag
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
													{
														label: "عرض",
														icon: Eye,
														onClick: (e) => {
															e?.preventDefault?.();
															showToast(`${d.name} - إجمالي ${fmtSAR(d.totalDonations)}`, "info");
														}
													},
													{
														label: "تعديل",
														icon: Pencil,
														onClick: (e) => {
															e?.preventDefault?.();
															openEditDonor(d);
														}
													},
													{
														label: "حذف",
														icon: Trash2,
														onClick: (e) => {
															e?.preventDefault?.();
															setDeleteTarget(d.id);
														},
														variant: "destructive"
													}
												] })]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-muted-foreground",
												children: "إجمالي التبرعات"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-base font-bold tabular-nums",
												children: fmtSAR(d.totalDonations)
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-left",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs text-muted-foreground",
													children: "عدد العمليات"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-sm font-semibold",
													children: d.donationCount
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												tone: "info",
												children: d.type
											}), d.recurring && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
												tone: "success",
												children: "متكرر"
											})]
										})
									]
								})]
							})
						})
					}, d.id)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
					open: !!deleteTarget,
					onClose: () => setDeleteTarget(null),
					onConfirm: handleDelete,
					title: "حذف المتبرع",
					message: "هل أنت متأكد من حذف هذا المتبرع؟",
					confirmText: "حذف",
					cancelText: "إلغاء",
					variant: "destructive"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
					open: filterOpen,
					onClose: () => setFilterOpen(false),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold text-muted-foreground",
								children: "النوع"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
								value: typeFilter,
								onChange: (e) => setTypeFilter(e.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "فرد" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "شركة" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مؤسسة" })
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold text-muted-foreground",
								children: "التصنيف"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
								value: tagFilter,
								onChange: (e) => setTagFilter(e.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ذهبي" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "فضي" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "برونزي" })
								]
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-xs font-semibold text-muted-foreground",
								children: "المدينة"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
								value: cityFilter,
								onChange: (e) => setCityFilter(e.target.value),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الرياض" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "جدة" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الدمام" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مكة المكرمة" })
								]
							})] })
						]
					})
				})
			] })
		]
	});
}
//#endregion
export { Page as component };
