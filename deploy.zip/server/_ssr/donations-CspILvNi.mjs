//#region node_modules/.nitro/vite/services/ssr/assets/donations-CspILvNi.js
var API_BASE = "/api/donations";
async function getDonations(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	if (filters.method && filters.method !== "الكل") params.set("method", filters.method);
	if (filters.channel && filters.channel !== "الكل") params.set("channel", filters.channel);
	if (filters.donorId) params.set("donorId", filters.donorId);
	if (filters.projectId) params.set("projectId", filters.projectId);
	if (filters.page) params.set("page", String(filters.page));
	if (filters.limit) params.set("limit", String(filters.limit));
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب التبرعات");
	return res.json();
}
async function createDonation(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة التبرع");
	}
	return (await res.json()).item;
}
async function updateDonation(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث التبرع");
	}
	return (await res.json()).item;
}
async function deleteDonation(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف التبرع");
	}
}
async function confirmDonation(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "confirm"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تأكيد التبرع");
	}
	return (await res.json()).item;
}
async function cancelDonation(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "cancel"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إلغاء التبرع");
	}
	return (await res.json()).item;
}
async function issueReceipt(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "issueReceipt"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إصدار إيصال");
	}
	const d = await res.json();
	return {
		donation: d.item,
		receiptId: d.receiptId
	};
}
//#endregion
export { getDonations as a, deleteDonation as i, confirmDonation as n, issueReceipt as o, createDonation as r, updateDonation as s, cancelDonation as t };
