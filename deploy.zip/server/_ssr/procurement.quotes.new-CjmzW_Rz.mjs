import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { s as getSuppliers } from "./suppliers-CkCPjZYa.mjs";
import { c as getPurchaseRequests } from "./purchase-requests-CdC7mUrc.mjs";
import { r as createQuote, t as QUOTE_STATUSES } from "./quotes-8hMRJcKl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.quotes.new-CjmzW_Rz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NewQuotePage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const supQuery = useQuery({
		queryKey: ["suppliers-simple"],
		queryFn: () => getSuppliers({ limit: 1e3 })
	});
	const reqQuery = useQuery({
		queryKey: ["purchaseRequests-simple"],
		queryFn: () => getPurchaseRequests({ limit: 1e3 })
	});
	const suppliers = (supQuery.data?.items || []).filter((s) => s.status === "نشط");
	const requests = (reqQuery.data?.items || []).filter((r) => r.status === "معتمد" || r.status === "بانتظار الموافقة");
	const [supplierId, setSupplierId] = (0, import_react.useState)("");
	const [supplierName, setSupplierName] = (0, import_react.useState)("");
	const [requestId, setRequestId] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("");
	const [delivery, setDelivery] = (0, import_react.useState)("");
	const [warranty, setWarranty] = (0, import_react.useState)("");
	const [rating, setRating] = (0, import_react.useState)("3");
	const [validUntil, setValidUntil] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("بانتظار");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const handleSupplierChange = (sid) => {
		setSupplierId(sid);
		const s = suppliers.find((x) => x.id === sid);
		if (s) setSupplierName(s.name);
	};
	const handleSave = async (andClose) => {
		const errs = [];
		const supplier = supplierName.trim();
		if (!supplier) errs.push("اسم المورد مطلوب");
		if (!price || parseFloat(price) <= 0) errs.push("السعر يجب أن يكون أكبر من صفر");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			const created = await createQuote({
				supplierId: supplierId || void 0,
				supplier,
				requestId: requestId || void 0,
				price: parseFloat(price) || 0,
				delivery: delivery || void 0,
				warranty: warranty || void 0,
				rating: parseFloat(rating) || 0,
				validUntil: validUntil || void 0,
				status,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["quotes"] });
			showToast(`تم تسجيل عرض السعر`, "success");
			if (andClose) navigate({ to: "/procurement/quotes" });
			else navigate({
				to: "/procurement/quotes/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const tabs = [{
		id: "basic",
		label: "بيانات العرض",
		content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
			title: "بيانات عرض السعر",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "المورد",
					required: true,
					error: errors[0],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
						value: supplierId,
						onChange: (e) => handleSupplierChange(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "— اختر موردًا مسجلاً —"
						}), suppliers.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: s.id,
							children: [
								s.name,
								" ",
								s.activity ? `· ${s.activity}` : ""
							]
						}, s.id))]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "اسم المورد (يدوي)",
					hint: "إن لم يكن مسجلاً",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: supplierName,
						onChange: (e) => setSupplierName(e.target.value),
						placeholder: "اكتب اسم المورد هنا إذا لم تختر من القائمة"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "طلب الشراء المرتبط",
					hint: "اختياري",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
						value: requestId,
						onChange: (e) => setRequestId(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "— لا يوجد —"
						}), requests.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: r.id,
							children: [
								r.subject,
								" — ",
								r.department
							]
						}, r.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "السعر",
					required: true,
					error: errors[1],
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						min: "0",
						step: "0.01",
						value: price,
						onChange: (e) => setPrice(e.target.value),
						dir: "ltr",
						placeholder: "0.00"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "صالح حتى",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "date",
						value: validUntil,
						onChange: (e) => setValidUntil(e.target.value),
						dir: "ltr"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "مدة التسليم",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: delivery,
						onChange: (e) => setDelivery(e.target.value),
						placeholder: "مثال: 7 أيام"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الضمان",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						value: warranty,
						onChange: (e) => setWarranty(e.target.value),
						placeholder: "مثال: سنة كاملة"
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "التقييم",
					hint: "من 1 إلى 5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
						type: "number",
						min: "0",
						max: "5",
						step: "0.5",
						value: rating,
						onChange: (e) => setRating(e.target.value),
						dir: "ltr"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "الحالة",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
						value: status,
						onChange: (e) => setStatus(e.target.value),
						children: QUOTE_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s,
							children: s
						}, s))
					})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 3
					})
				})
			]
		})
	}];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "عروض الأسعار",
		breadcrumb: [
			"المشتريات",
			"عروض الأسعار",
			"جديد"
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المشتريات",
					to: "/procurement/requests"
				},
				{
					label: "عروض الأسعار",
					to: "/procurement/quotes"
				},
				{ label: "عرض جديد" }
			],
			title: "عرض سعر جديد",
			subtitle: supplierName || "أدخل بيانات العرض",
			draftNumber: "مسودة جديدة",
			status: {
				label: status,
				tone: status === "مقبول" ? "success" : status === "مرفوض" ? "destructive" : "warning"
			},
			tabs,
			defaultTab: "basic",
			loading: saving,
			validationErrors: errors,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/procurement/quotes" })
		})
	});
}
//#endregion
export { NewQuotePage as component };
