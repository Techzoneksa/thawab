import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projects._id-CRFKJ5jo.js
var $$splitComponentImporter = () => import("./projects._id-BCsHdfya.mjs");
var Route = createFileRoute("/projects/$id")({
	head: () => ({ meta: [{ title: "ملف المشروع — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
