import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { U as Plus, v as Trash2 } from "../_libs/lucide-react.mjs";
import { F as useAuth, N as showToast, P as statusTone, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { c as getAccounts } from "./accounts-i45ITZyC.mjs";
import { r as createBudget, t as BUDGET_STATUSES } from "./budgets-DCUxNMYq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.budgets.new--b5A2xO5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function newLine(key) {
	return {
		key,
		accountId: "",
		plannedAmount: 0,
		notes: ""
	};
}
function NewBudgetPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const { data: accData } = useQuery({
		queryKey: ["accounts-simple"],
		queryFn: () => getAccounts({ limit: 1e3 })
	});
	const accounts = (accData?.items || []).filter((a) => a.postable);
	const currentYear = String((/* @__PURE__ */ new Date()).getFullYear());
	const [name, setName] = (0, import_react.useState)(`موازنة ${currentYear}`);
	const [year, setYear] = (0, import_react.useState)(currentYear);
	const [status, setStatus] = (0, import_react.useState)("مسودة");
	const [department, setDepartment] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [lines, setLines] = (0, import_react.useState)([newLine("l1")]);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const totalPlanned = (0, import_react.useMemo)(() => lines.reduce((s, l) => s + (l.plannedAmount || 0), 0), [lines]);
	const handleSave = async (andClose) => {
		if (!name.trim() || !year.trim()) {
			showToast("اسم الموازنة والسنة مطلوبان", "error");
			return;
		}
		setSaving(true);
		try {
			const created = await createBudget({
				name: name.trim(),
				year,
				status,
				amount: totalPlanned,
				department: department || void 0,
				currency: "SAR",
				description: description || void 0,
				notes,
				lines: lines.filter((l) => l.accountId).map((l) => ({
					accountId: l.accountId,
					plannedAmount: l.plannedAmount,
					notes: l.notes || void 0
				})),
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["budgets"] });
			showToast(`تم إنشاء الموازنة ${created.name}`, "success");
			if (andClose) navigate({ to: "/finance/budgets" });
			else navigate({
				to: "/finance/budgets/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const addLine = () => setLines([...lines, newLine(`l${Date.now()}`)]);
	const removeLine = (key) => setLines(lines.filter((l) => l.key !== key));
	const updateLine = (key, patch) => setLines(lines.map((l) => l.key === key ? {
		...l,
		...patch
	} : l));
	const tabs = [
		{
			id: "basic",
			label: "البيانات الأساسية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات الموازنة",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم الموازنة",
						required: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "مثال: موازنة تشغيلية 2026"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "السنة المالية",
						required: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: year,
							onChange: (e) => setYear(e.target.value),
							dir: "ltr",
							placeholder: "2026"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الإدارة / القسم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: department,
							onChange: (e) => setDepartment(e.target.value),
							placeholder: "مثال: الإدارة المالية"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحالة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: status,
							onChange: (e) => setStatus(e.target.value),
							children: BUDGET_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								children: s
							}, s))
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "وصف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: description,
							onChange: (e) => setDescription(e.target.value),
							rows: 3
						})
					})
				]
			})
		},
		{
			id: "lines",
			label: "بنود الموازنة",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "توزيع المبلغ على الحسابات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border bg-card overflow-hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "min-w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-muted/60 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-10",
										children: "#"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground",
										children: "الحساب"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground w-40",
										children: "المبلغ المخطط"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-2 font-semibold text-muted-foreground",
										children: "ملاحظات"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-3 py-2 font-semibold text-muted-foreground w-10" })
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2 text-muted-foreground tabular-nums",
										children: i + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: l.accountId,
											onChange: (e) => updateLine(l.key, { accountId: e.target.value }),
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm min-h-[36px]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "",
												children: "— اختر —"
											}), accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
												value: a.id,
												children: [
													a.code,
													" — ",
													a.name
												]
											}, a.id))]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											step: "0.01",
											value: l.plannedAmount || "",
											onChange: (e) => updateLine(l.key, { plannedAmount: parseFloat(e.target.value) || 0 }),
											dir: "ltr",
											placeholder: "0",
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm font-mono tabular-nums min-h-[36px]"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: l.notes,
											onChange: (e) => updateLine(l.key, { notes: e.target.value }),
											className: "w-full rounded-lg border bg-background px-2 py-1.5 text-sm min-h-[36px]"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => removeLine(l.key),
											disabled: lines.length <= 1,
											className: "grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive disabled:opacity-30 disabled:cursor-not-allowed transition-colors",
											title: "حذف السطر",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 14 })
										})
									})
								]
							}, l.key)) })]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t bg-muted/30 px-3 py-3 flex items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: addLine,
							className: "inline-flex items-center gap-1.5 rounded-lg border bg-background px-3 py-1.5 text-xs font-semibold hover:bg-muted transition-colors min-h-[36px]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), "إضافة بند"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-bold tabular-nums",
							children: ["الإجمالي المخطط: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-foreground",
								children: fmtSAR(totalPlanned)
							})]
						})]
					})]
				})
			})
		},
		{
			id: "notes",
			label: "الملاحظات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
				title: "ملاحظات",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					label: "ملاحظات",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
						value: notes,
						onChange: (e) => setNotes(e.target.value),
						rows: 5
					})
				})
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الموازنات",
		breadcrumb: [
			"المالية",
			"الموازنات",
			"جديد"
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [
				{
					label: "المالية",
					to: "/finance/budgets"
				},
				{
					label: "الموازنات",
					to: "/finance/budgets"
				},
				{ label: "موازنة جديدة" }
			],
			title: "موازنة جديدة",
			subtitle: `سنة ${year} · ${fmtSAR(totalPlanned)} مخطط`,
			draftNumber: "مسودة جديدة",
			status: {
				label: status,
				tone: statusTone(status)
			},
			tabs,
			defaultTab: "basic",
			loading: saving,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/finance/budgets" })
		})
	});
}
//#endregion
export { NewBudgetPage as component };
