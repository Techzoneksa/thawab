import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { T as SquarePen, U as Plus, d as UserPlus, jt as Eye, u as UsersRound, v as Trash2 } from "../_libs/lucide-react.mjs";
import { N as showToast, S as MobilePageHeader, a as Btn, c as ConfirmDialog, g as ExportButton, h as EntityFormDrawer, i as Badge, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { i as BOARD_MEMBERS } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/memberships-t3-DCSUl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [data, setData] = (0, import_react.useState)(BOARD_MEMBERS.map((m) => ({
		...m,
		phone: "05xxxxxxxx",
		active: true
	})));
	const [formOpen, setFormOpen] = (0, import_react.useState)(false);
	const [subFormOpen, setSubFormOpen] = (0, import_react.useState)(false);
	const [confirmIdx, setConfirmIdx] = (0, import_react.useState)(-1);
	const [editingIdx, setEditingIdx] = (0, import_react.useState)(-1);
	const [formName, setFormName] = (0, import_react.useState)("");
	const [formRole, setFormRole] = (0, import_react.useState)("");
	const [formPhone, setFormPhone] = (0, import_react.useState)("");
	const [subName, setSubName] = (0, import_react.useState)("");
	const [subType, setSubType] = (0, import_react.useState)("سنوي");
	const openAddMember = () => {
		setEditingIdx(-1);
		setFormName("");
		setFormRole("");
		setFormPhone("");
		setFormOpen(true);
	};
	const openEditMember = (idx) => {
		const m = data[idx];
		setEditingIdx(idx);
		setFormName(m.name);
		setFormRole(m.role);
		setFormPhone(m.phone);
		setFormOpen(true);
	};
	const closeMemberForm = () => {
		setFormOpen(false);
		setEditingIdx(-1);
		setFormName("");
		setFormRole("");
		setFormPhone("");
	};
	const handleAddMember = () => {
		if (!formName.trim()) {
			showToast("يرجى إدخال اسم العضو", "error");
			return;
		}
		if (editingIdx >= 0) {
			const updated = [...data];
			updated[editingIdx] = {
				...updated[editingIdx],
				name: formName,
				role: formRole || updated[editingIdx].role,
				phone: formPhone
			};
			setData(updated);
			showToast("تم تحديث بيانات العضو بنجاح", "success");
		} else {
			setData([{
				name: formName,
				role: formRole || "عضو",
				since: "1446",
				attendance: 0,
				phone: formPhone,
				active: true
			}, ...data]);
			showToast("تم إضافة العضو بنجاح", "success");
		}
		closeMemberForm();
	};
	const handleAddSub = () => {
		if (!subName.trim()) {
			showToast("يرجى إدخال الاسم", "error");
			return;
		}
		showToast(`تم إضافة اشتراك ${subType} للعضو ${subName}`, "success");
		setSubFormOpen(false);
		setSubName("");
		setSubType("سنوي");
	};
	const handleDelete = () => {
		setData(data.filter((_, i) => i !== confirmIdx));
		showToast("تم حذف العضو", "success");
		setConfirmIdx(-1);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"الموارد",
			"العضويات"
		],
		title: "العضويات ومجلس الإدارة",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data,
				filename: "memberships.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => {
					setSubName("");
					setSubType("سنوي");
					setSubFormOpen(true);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { size: 15 }), " إضافة اشتراك"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: openAddMember,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إضافة عضو"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "العضويات ومجلس الإدارة",
				count: `${data.length} عضو مجلس`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4",
				children: [
					{
						l: "أعضاء الجمعية العمومية",
						v: "84"
					},
					{
						l: "مجلس الإدارة",
						v: String(data.length)
					},
					{
						l: "اشتراكات نشطة",
						v: "78"
					},
					{
						l: "حضور آخر اجتماع",
						v: "92%"
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: s.l
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-lg font-extrabold mt-1 tabular-nums",
						children: s.v
					})]
				}, s.l))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-bold mb-3",
					children: "مجلس الإدارة الحالي"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3",
					children: data.map((m, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 rounded-xl border p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-12 w-12 shrink-0 place-items-center rounded-full bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersRound, { size: 20 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-semibold truncate",
									children: m.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: [
										m.role,
										" · منذ ",
										m.since,
										"هـ"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									tone: "success",
									children: [m.attendance, "%"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
									{
										label: "عرض",
										icon: Eye,
										onClick: () => showToast(`${m.name} - ${m.role}`, "info")
									},
									{
										label: "تعديل",
										icon: SquarePen,
										onClick: () => openEditMember(idx)
									},
									{
										label: "حذف",
										icon: Trash2,
										variant: "destructive",
										onClick: () => setConfirmIdx(idx)
									}
								] })]
							})
						]
					}, m.name))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: formOpen,
				onClose: closeMemberForm,
				title: editingIdx >= 0 ? "تعديل عضو" : "إضافة عضو",
				onSave: handleAddMember,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الاسم"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						value: formName,
						onChange: (e) => setFormName(e.target.value),
						placeholder: "الاسم الكامل"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "المنصب"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						value: formRole,
						onChange: (e) => setFormRole(e.target.value),
						placeholder: "المسمى الوظيفي"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الجوال"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						value: formPhone,
						onChange: (e) => setFormPhone(e.target.value),
						placeholder: "05xxxxxxxx"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: subFormOpen,
				onClose: () => setSubFormOpen(false),
				title: "إضافة اشتراك",
				onSave: handleAddSub,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "اسم العضو"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: subName,
					onChange: (e) => setSubName(e.target.value),
					placeholder: "الاسم"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "text-xs font-semibold text-muted-foreground",
					children: "نوع الاشتراك"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
					value: subType,
					onChange: (e) => setSubType(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "سنوي" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "شهري" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "دائم" })
					]
				})] })]
			}),
			confirmIdx >= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: true,
				onClose: () => setConfirmIdx(-1),
				onConfirm: handleDelete,
				title: "تأكيد الحذف",
				message: "هل أنت متأكد من حذف العضو؟",
				confirmText: "حذف",
				variant: "destructive"
			})
		]
	});
};
//#endregion
export { SplitComponent as component };
