import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { Ht as CircleX, I as RotateCcw, T as SquarePen, Wt as CircleCheckBig, jt as Eye, v as Trash2, xt as HandHelping } from "../_libs/lucide-react.mjs";
import { A as Table, C as MobileSearchInput, F as useAuth, N as showToast, S as MobilePageHeader, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { o as getBeneficiaries } from "./beneficiaries-aRDRq8QX.mjs";
import { c as returnAidRecord, i as deliverAidRecord, o as getAidRecords, r as deleteAidRecord, s as rejectAidRecord, t as approveAidRecord } from "./aid-ytMo61mr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aid-a4Dwguwe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function statusToneLocal(s) {
	if (s === "تم التسليم") return "success";
	if (s === "معتمد") return "warning";
	if (s === "مرفوض") return "destructive";
	if (s === "بانتظار الموافقة") return "muted";
	return "info";
}
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [approveTarget, setApproveTarget] = (0, import_react.useState)(null);
	const [rejectTarget, setRejectTarget] = (0, import_react.useState)(null);
	const [deliverTarget, setDeliverTarget] = (0, import_react.useState)(null);
	const [returnTarget, setReturnTarget] = (0, import_react.useState)(null);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [typeFilter, setTypeFilter] = (0, import_react.useState)("الكل");
	const [page, setPage] = (0, import_react.useState)(1);
	const [apiFilters, setApiFilters] = (0, import_react.useState)({
		search: "",
		status: "",
		type: "",
		page: 1,
		limit: 50
	});
	const { data, isLoading, error } = useQuery({
		queryKey: ["aid", apiFilters],
		queryFn: () => getAidRecords(apiFilters)
	});
	const { data: beneficiariesData } = useQuery({
		queryKey: ["beneficiaries-simple"],
		queryFn: () => getBeneficiaries({
			status: "مؤهل",
			limit: 200
		})
	});
	const aidRecords = data?.items || [];
	const total = data?.total || 0;
	const totalPages = Math.ceil(total / 50);
	beneficiariesData?.items;
	(0, import_react.useEffect)(() => {
		setPage(1);
		setApiFilters((f) => ({
			...f,
			search: searchQuery,
			status: statusFilter,
			type: typeFilter,
			page: 1
		}));
	}, [
		searchQuery,
		statusFilter,
		typeFilter
	]);
	(0, import_react.useEffect)(() => {
		setApiFilters((f) => ({
			...f,
			page
		}));
	}, [page]);
	const deleteMutation = useMutation({
		mutationFn: deleteAidRecord,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["aid"] });
			showToast("تم حذف المساعدة بنجاح", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const approveMutation = useMutation({
		mutationFn: approveAidRecord,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["aid"] });
			showToast("تم اعتماد المساعدة بنجاح", "success");
			setApproveTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const rejectMutation = useMutation({
		mutationFn: rejectAidRecord,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["aid"] });
			showToast("تم رفض المساعدة", "success");
			setRejectTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deliverMutation = useMutation({
		mutationFn: deliverAidRecord,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["aid"] });
			queryClient.invalidateQueries({ queryKey: ["beneficiaries"] });
			showToast("تم تسليم المساعدة بنجاح", "success");
			setDeliverTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const returnMutation = useMutation({
		mutationFn: returnAidRecord,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["aid"] });
			showToast("تم إرجاع المساعدة للتعديل", "success");
			setReturnTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => navigate({ to: "/aid/new" });
	const openEdit = (r) => navigate({
		to: "/aid/$id/edit",
		params: { id: r.id }
	});
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleApprove = () => {
		if (approveTarget) approveMutation.mutate({
			id: approveTarget.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleReject = () => {
		if (rejectTarget) rejectMutation.mutate({
			id: rejectTarget.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleDeliver = () => {
		if (deliverTarget) deliverMutation.mutate({
			id: deliverTarget.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleReturn = () => {
		if (returnTarget) returnMutation.mutate({
			id: returnTarget.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const stats = [
		{
			label: "إجمالي السجلات",
			value: aidRecords.length
		},
		{
			label: "بانتظار الموافقة",
			value: aidRecords.filter((r) => r.status === "بانتظار الموافقة").length
		},
		{
			label: "معتمد",
			value: aidRecords.filter((r) => r.status === "معتمد").length
		},
		{
			label: "تم التسليم",
			value: aidRecords.filter((r) => r.status === "تم التسليم").length
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المشاريع والمستفيدون",
			"المساعدات"
		],
		title: "سجل المساعدات المصروفة",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
			data: aidRecords,
			filename: "المساعدات.csv"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: openAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandHelping, { size: 15 }), " إضافة مساعدة"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base lg:text-xl font-extrabold mt-1 tabular-nums",
						children: s.value
					})]
				}, s.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الحالة",
					options: [
						"الكل",
						"بانتظار الموافقة",
						"معتمد",
						"مرفوض",
						"تم التسليم"
					],
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "النوع",
					options: [
						"الكل",
						"مساعدة عاجلة",
						"مساعدة شهرية",
						"سلة غذائية",
						"علاج",
						"كسوة شتوية"
					],
					value: typeFilter,
					onChange: (e) => setTypeFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandHelping, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "المساعدات",
				count: `${aidRecords.length} سجل`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HandHelping, { size: 15 })
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء تحميل السجلات",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["aid"] }),
					children: "إعادة المحاولة"
				})
			}) : aidRecords.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد مساعدات",
				description: "ابدأ بإضافة أول مساعدة",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة مساعدة"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden lg:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
						columns: [
							"الرقم",
							"المستفيد",
							"النوع",
							"المبلغ",
							"المشروع",
							"التاريخ",
							"الحالة",
							""
						],
						rows: aidRecords,
						renderRow: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
								className: "font-mono text-xs",
								children: r.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
								className: "font-semibold",
								children: r.beneficiaryName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
								className: "text-muted-foreground text-xs",
								children: r.type
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
								className: "tabular-nums font-bold",
								children: fmtSAR(r.amount)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
								className: "text-muted-foreground text-xs",
								children: r.projectName || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
								className: "text-muted-foreground text-xs",
								children: r.date
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusToneLocal(r.status),
								children: r.status
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getAidActions(r) }) })
						] })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:hidden space-y-2",
					children: aidRecords.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusToneLocal(r.status),
									children: r.status
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono text-xs text-muted-foreground",
									children: r.id
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-semibold",
								children: r.beneficiaryName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: r.type
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums font-bold",
									children: fmtSAR(r.amount)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: r.projectName || "—"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: r.date
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-2 mt-2",
								children: getAidMobileActions(r)
							})
						]
					}, r.id))
				}),
				totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between mt-3 px-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: [
							"صفحة ",
							page,
							" من ",
							totalPages,
							" | ",
							total,
							" سجل"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "px-3 py-1.5 text-xs rounded-lg border bg-background hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed min-h-[36px]",
							disabled: page <= 1,
							onClick: () => setPage((p) => Math.max(1, p - 1)),
							children: "السابق"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "px-3 py-1.5 text-xs rounded-lg border bg-background hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed min-h-[36px]",
							disabled: page >= totalPages,
							onClick: () => setPage((p) => Math.min(totalPages, p + 1)),
							children: "التالي"
						})]
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: handleDelete,
				title: "حذف المساعدة",
				message: "هل أنت متأكد من حذف هذه المساعدة؟",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!approveTarget,
				onClose: () => setApproveTarget(null),
				onConfirm: handleApprove,
				title: "اعتماد المساعدة",
				message: `هل أنت متأكد من اعتماد مساعدة ${approveTarget?.beneficiaryName} بمبلغ ${approveTarget ? fmtSAR(approveTarget.amount) : ""}؟`,
				confirmText: "اعتماد",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!rejectTarget,
				onClose: () => setRejectTarget(null),
				onConfirm: handleReject,
				title: "رفض المساعدة",
				message: "هل أنت متأكد من رفض هذه المساعدة؟",
				confirmText: "رفض",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deliverTarget,
				onClose: () => setDeliverTarget(null),
				onConfirm: handleDeliver,
				title: "تسليم المساعدة",
				message: `هل أنت متأكد من تسليم مساعدة ${deliverTarget?.beneficiaryName} بمبلغ ${deliverTarget ? fmtSAR(deliverTarget.amount) : ""}؟`,
				confirmText: "تسليم",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!returnTarget,
				onClose: () => setReturnTarget(null),
				onConfirm: handleReturn,
				title: "إرجاع للتعديل",
				message: "هل تريد إرجاع هذه المساعدة للتعديل؟",
				confirmText: "إرجاع",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: statusFilter,
						onChange: (e) => setStatusFilter(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "بانتظار الموافقة" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "معتمد" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مرفوض" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "تم التسليم" })
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "النوع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: typeFilter,
						onChange: (e) => setTypeFilter(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مساعدة عاجلة" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مساعدة شهرية" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "سلة غذائية" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "علاج" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "كسوة شتوية" })
						]
					})] })]
				})
			})
		]
	});
	function getAidActions(r) {
		const actions = [{
			label: "عرض",
			icon: Eye,
			onClick: () => showToast(`${r.beneficiaryName} - ${fmtSAR(r.amount)}`, "info")
		}];
		if (r.status === "بانتظار الموافقة") actions.push({
			label: "اعتماد",
			icon: CircleCheckBig,
			onClick: () => setApproveTarget(r)
		}, {
			label: "رفض",
			icon: CircleX,
			onClick: () => setRejectTarget(r),
			variant: "destructive"
		}, {
			label: "تعديل",
			icon: SquarePen,
			onClick: () => openEdit(r)
		}, {
			label: "حذف",
			icon: Trash2,
			onClick: () => setDeleteTarget(r.id),
			variant: "destructive"
		});
		if (r.status === "معتمد") actions.push({
			label: "تسليم",
			icon: CircleCheckBig,
			onClick: () => setDeliverTarget(r)
		}, {
			label: "إرجاع",
			icon: RotateCcw,
			onClick: () => setReturnTarget(r)
		});
		return actions;
	}
	function getAidMobileActions(r) {
		const btns = [];
		if (r.status === "بانتظار الموافقة") btns.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "flex-1 rounded-lg bg-success/15 text-success text-xs font-semibold py-2 min-h-[36px]",
			onClick: () => setApproveTarget(r),
			children: "اعتماد"
		}, "approve"));
		if (r.status === "معتمد") btns.push(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "flex-1 rounded-lg bg-primary text-primary-foreground text-xs font-semibold py-2 min-h-[36px]",
			onClick: () => setDeliverTarget(r),
			children: "تسليم"
		}, "deliver"));
		return btns;
	}
}
//#endregion
export { Page as component };
