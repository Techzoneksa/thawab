import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.requests._id.edit-BZPrk1_u.js
var $$splitComponentImporter = () => import("./procurement.requests._id.edit-D8nrRfIL.mjs");
var Route = createFileRoute("/procurement/requests/$id/edit")({
	head: () => ({ meta: [{ title: "تعديل طلب شراء — ثواب" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
