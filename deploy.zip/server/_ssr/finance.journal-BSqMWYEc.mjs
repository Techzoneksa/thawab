import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { Ht as CircleX, I as RotateCcw, J as Pencil, P as Search, U as Plus, Wt as CircleCheckBig, jt as Eye, v as Trash2, wt as Funnel } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, E as PrintButton, F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { a as deleteJournalEntry, c as postJournalEntry, l as reverseJournalEntry, n as JOURNAL_STATUSES, o as getJournalEntries, r as cancelJournalEntry, s as getJournalEntry, t as JOURNAL_FUNDS } from "./journal-Da8V5shh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance.journal-BSqMWYEc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const navigate = useNavigate();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [fundFilter, setFundFilter] = (0, import_react.useState)("الكل");
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [page, setPage] = (0, import_react.useState)(1);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [actionTarget, setActionTarget] = (0, import_react.useState)(null);
	const [detailId, setDetailId] = (0, import_react.useState)(null);
	const { data, isLoading, error } = useQuery({
		queryKey: ["journal", {
			search: searchQuery,
			status: statusFilter,
			fund: fundFilter,
			page
		}],
		queryFn: () => getJournalEntries({
			search: searchQuery,
			status: statusFilter,
			fund: fundFilter,
			page,
			limit: 50
		})
	});
	const entries = data?.items || [];
	const total = data?.total || 0;
	const totalPages = Math.ceil(total / 50);
	const { data: detailData } = useQuery({
		queryKey: ["journal-entry", detailId],
		queryFn: () => detailId ? getJournalEntry(detailId) : Promise.resolve(null),
		enabled: !!detailId
	});
	(0, import_react.useEffect)(() => {
		setPage(1);
	}, [
		searchQuery,
		statusFilter,
		fundFilter
	]);
	const openAdd = () => navigate({ to: "/finance/journal/new" });
	const openEdit = (e) => {
		if (e.status !== "مسودة" && e.status !== "بانتظار الاعتماد") {
			showToast("لا يمكن تعديل قيد مرحّل أو معكوس. افتح التفاصيل لعرض السجل أو عكسه.", "error");
			return;
		}
		navigate({
			to: "/finance/journal/$id/edit",
			params: { id: e.id }
		});
	};
	const deleteMutation = useMutation({
		mutationFn: deleteJournalEntry,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["journal"] });
			showToast("تم حذف القيد بنجاح", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const actionMutation = useMutation({
		mutationFn: async (vars) => {
			return {
				post: postJournalEntry,
				reverse: reverseJournalEntry,
				cancel: cancelJournalEntry
			}[vars.action]({
				id: vars.id,
				userId: vars.userId,
				userName: vars.userName
			});
		},
		onSuccess: (_, vars) => {
			queryClient.invalidateQueries({ queryKey: ["journal"] });
			queryClient.invalidateQueries({ queryKey: ["journal-entry"] });
			showToast({
				post: "تم ترحيل القيد",
				reverse: "تم عكس القيد",
				cancel: "تم إلغاء القيد"
			}[vars.action], "success");
			setActionTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleActionConfirm = () => {
		if (actionTarget) actionMutation.mutate({
			id: actionTarget.id,
			action: actionTarget.action,
			userId: user?.id,
			userName: user?.name
		});
	};
	const stats = [
		{
			label: "إجمالي القيود",
			value: fmtNum(total)
		},
		{
			label: "مرحّلة",
			value: entries.filter((e) => e.status === "مرحّل").length
		},
		{
			label: "مسودات",
			value: entries.filter((e) => e.status === "مسودة").length
		},
		{
			label: "قيد الانتظار",
			value: entries.filter((e) => e.status === "بانتظار الاعتماد").length
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المالية",
			"قيود اليومية"
		],
		title: "قيود اليومية",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: entries,
				filename: "قيود_اليومية.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: openAdd,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " قيد جديد"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base lg:text-xl font-extrabold mt-1 tabular-nums truncate",
						children: s.value
					})]
				}, s.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث بالرقم أو الوصف...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الحالة",
					options: ["الكل", ...JOURNAL_STATUSES],
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "نوع الصندوق",
					options: ["الكل", ...JOURNAL_FUNDS],
					value: fundFilter,
					onChange: (e) => setFundFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "قيود اليومية",
				count: `${fmtNum(total)} قيد`,
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 })
				})
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء تحميل القيود",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["journal"] }),
					children: "إعادة المحاولة"
				})
			}) : entries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد قيود",
				description: "ابدأ بإضافة أول قيد يومية",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إضافة قيد"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الرقم",
					"التاريخ",
					"الوصف",
					"المبلغ",
					"الصندوق",
					"الحالة",
					""
				],
				rows: entries,
				renderRow: (e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: e.number
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-xs",
						children: e.date
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setDetailId(e.id),
						className: "font-semibold hover:text-primary text-right",
						children: e.description
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums font-bold",
						children: fmtSAR(e.amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-xs",
						children: e.fund
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(e.status),
						children: e.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getJournalActions(e, setDetailId, openEdit, setDeleteTarget, setActionTarget) }) })
				] }),
				mobileCard: (e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground font-mono",
									children: [
										e.number,
										" · ",
										e.date
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setDetailId(e.id),
									className: "text-sm font-bold hover:text-primary text-right mt-0.5 line-clamp-2",
									children: e.description
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(e.status),
								children: e.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex justify-between items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-base font-bold tabular-nums",
								children: fmtSAR(e.amount)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [(e.status === "مسودة" || e.status === "بانتظار الاعتماد") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => openEdit(e),
									className: "text-primary text-xs font-semibold",
									children: "تعديل"
								}), e.status === "مسودة" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setDeleteTarget(e.id),
									className: "text-destructive text-xs font-semibold",
									children: "حذف"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-xs text-muted-foreground",
							children: e.fund
						})
					]
				}, e.id)
			}),
			totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between mt-3 px-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs text-muted-foreground",
					children: [
						"صفحة ",
						page,
						" من ",
						totalPages,
						" | ",
						fmtNum(total),
						" قيد"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "px-3 py-1.5 text-xs rounded-lg border bg-background hover:bg-muted disabled:opacity-40 min-h-[36px]",
						disabled: page <= 1,
						onClick: () => setPage((p) => Math.max(1, p - 1)),
						children: "السابق"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "px-3 py-1.5 text-xs rounded-lg border bg-background hover:bg-muted disabled:opacity-40 min-h-[36px]",
						disabled: page >= totalPages,
						onClick: () => setPage((p) => Math.min(totalPages, p + 1)),
						children: "التالي"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailId,
				onClose: () => setDetailId(null),
				title: `القيد: ${detailData?.item?.number || ""}`,
				onSave: () => setDetailId(null),
				saveText: "إغلاق",
				children: detailData && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الرقم",
									value: detailData.item.number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "التاريخ",
									value: detailData.item.date
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحالة",
									value: detailData.item.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الصندوق",
									value: detailData.item.fund
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الوصف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm mt-1",
							children: detailData.item.description
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-muted-foreground mb-1",
								children: "السطور"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "space-y-1",
								children: detailData.lines.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border p-2 bg-muted/30 text-xs",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono font-bold",
												children: [
													l.accountCode,
													" - ",
													l.accountName
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: l.debit > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-success font-bold",
												children: ["مدين ", fmtSAR(l.debit)]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-info font-bold",
												children: ["دائن ", fmtSAR(l.credit)]
											}) })]
										}),
										l.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-muted-foreground mt-1",
											children: l.description
										}),
										l.costCenterName && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-muted-foreground mt-1",
											children: ["مركز التكلفة: ", l.costCenterName]
										})
									]
								}, l.id))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex justify-between rounded-lg bg-primary/10 p-2 text-sm font-bold",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "الإجمالي" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									"مدين ",
									fmtSAR(detailData.totals.debit),
									" | دائن ",
									fmtSAR(detailData.totals.credit)
								] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: detailData.totals.balanced ? "success" : "destructive",
									children: detailData.totals.balanced ? "متوازن ✓" : "غير متوازن ✗"
								})
							})
						] }),
						detailData.item.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm mt-1",
							children: detailData.item.notes
						})] }),
						detailData.reversedOf && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
							className: "p-2 bg-warning/10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs",
								children: [
									"هذا القيد عكس القيد:",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono",
										children: detailData.reversedOf.number
									})
								]
							})
						}),
						detailData.reversalEntries.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-2 bg-warning/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs",
								children: "القيد تم عكسه بواسطة:"
							}), detailData.reversalEntries.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-mono mt-0.5",
								children: r.number
							}, r.id))]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: handleDelete,
				title: "حذف القيد",
				message: "هل أنت متأكد من حذف هذا القيد؟ لا يمكن حذف قيد مرحّل أو معكوس.",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget,
				onClose: () => setActionTarget(null),
				onConfirm: handleActionConfirm,
				title: actionTarget ? actionTarget.action === "post" ? "ترحيل القيد" : actionTarget.action === "reverse" ? "عكس القيد" : "إلغاء القيد" : "",
				message: actionTarget ? `هل تريد ${actionTarget.action === "post" ? "ترحيل" : actionTarget.action === "reverse" ? "عكس" : "إلغاء"} القيد "${actionTarget.number}"؟` : "",
				confirmText: actionTarget ? actionTarget.action === "post" ? "ترحيل" : actionTarget.action === "reverse" ? "عكس" : "إلغاء" : "",
				cancelText: "رجوع",
				variant: actionTarget?.action === "cancel" ? "destructive" : "default"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: statusFilter,
						onChange: (e) => setStatusFilter(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), JOURNAL_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الصندوق"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: fundFilter,
						onChange: (e) => setFundFilter(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), JOURNAL_FUNDS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: f }, f))]
					})] })]
				})
			})
		]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-semibold",
			children: value
		})]
	});
}
function getJournalActions(e, setDetailId, openEdit, setDeleteTarget, setActionTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => setDetailId(e.id)
	}];
	if (e.status === "مسودة" || e.status === "بانتظار الاعتماد") {
		actions.push({
			label: "تعديل",
			icon: Pencil,
			onClick: () => openEdit(e)
		});
		actions.push({
			label: "ترحيل",
			icon: CircleCheckBig,
			onClick: () => setActionTarget({
				id: e.id,
				number: e.number,
				action: "post"
			})
		});
		if (e.status === "مسودة") {
			actions.push({
				label: "إلغاء",
				icon: CircleX,
				onClick: () => setActionTarget({
					id: e.id,
					number: e.number,
					action: "cancel"
				}),
				variant: "destructive"
			});
			actions.push({
				label: "حذف",
				icon: Trash2,
				onClick: () => setDeleteTarget(e.id),
				variant: "destructive"
			});
		}
	}
	if (e.status === "مرحّل") actions.push({
		label: "عكس",
		icon: RotateCcw,
		onClick: () => setActionTarget({
			id: e.id,
			number: e.number,
			action: "reverse"
		})
	});
	return actions;
}
//#endregion
export { Page as component };
