import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { A as ShieldCheck, I as RotateCcw, J as Pencil, U as Plus, Ut as CircleCheck, f as UserCog, on as Ban, st as Mail, v as Trash2 } from "../_libs/lucide-react.mjs";
import { N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, a as Btn, c as ConfirmDialog, g as ExportButton, h as EntityFormDrawer, i as Badge, j as Td, n as AppShell, s as Card, t as ActionMenu, y as MobileActionRow } from "./actions-qTEe1ygX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings.users-DzLXDC-r.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => {
	const [users, setUsers] = (0, import_react.useState)([
		{
			id: "USR-001",
			name: "د. عبدالله السبيعي",
			email: "ceo@albir.org.sa",
			role: "المدير التنفيذي",
			twofa: true,
			last: "اليوم 11:24",
			status: "نشط"
		},
		{
			id: "USR-002",
			name: "سعد الغامدي",
			email: "cfo@albir.org.sa",
			role: "المدير المالي",
			twofa: true,
			last: "اليوم 10:40",
			status: "نشط"
		},
		{
			id: "USR-003",
			name: "سارة الزهراني",
			email: "s.zahrani@albir.org.sa",
			role: "محاسب",
			twofa: true,
			last: "اليوم 09:58",
			status: "نشط"
		},
		{
			id: "USR-004",
			name: "فهد العتيبي",
			email: "f.otaibi@albir.org.sa",
			role: "مدير المشاريع",
			twofa: false,
			last: "أمس 17:12",
			status: "نشط"
		},
		{
			id: "USR-005",
			name: "خالد الدوسري",
			email: "k.dossari@albir.org.sa",
			role: "أخصائي مشتريات",
			twofa: true,
			last: "أمس 14:20",
			status: "إجازة"
		},
		{
			id: "USR-006",
			name: "منى السلمي",
			email: "m.salmi@albir.org.sa",
			role: "باحث اجتماعي",
			twofa: false,
			last: "1446/10/10",
			status: "نشط"
		}
	]);
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [inviteOpen, setInviteOpen] = (0, import_react.useState)(false);
	const [editOpen, setEditOpen] = (0, import_react.useState)(false);
	const [editUser, setEditUser] = (0, import_react.useState)(null);
	const [confirmOpen, setConfirmOpen] = (0, import_react.useState)(false);
	const [confirmAction, setConfirmAction] = (0, import_react.useState)(() => {});
	const [formName, setFormName] = (0, import_react.useState)("");
	const [formEmail, setFormEmail] = (0, import_react.useState)("");
	const [formPhone, setFormPhone] = (0, import_react.useState)("");
	const [formRole, setFormRole] = (0, import_react.useState)("محاسب");
	const [formBranch, setFormBranch] = (0, import_react.useState)("الفرع الرئيسي");
	const [formStatus, setFormStatus] = (0, import_react.useState)("نشط");
	const [formPerms, setFormPerms] = (0, import_react.useState)("صلاحيات مالية");
	const [inviteEmail, setInviteEmail] = (0, import_react.useState)("");
	const [inviteRole, setInviteRole] = (0, import_react.useState)("محاسب");
	const [inviteMsg, setInviteMsg] = (0, import_react.useState)("");
	const roles = [
		"المدير التنفيذي",
		"المدير المالي",
		"محاسب",
		"مدير المشاريع",
		"أخصائي مشتريات",
		"باحث اجتماعي"
	];
	const branches = [
		"الفرع الرئيسي",
		"فرع جدة",
		"فرع الدمام",
		"فرع أبها"
	];
	const permsOptions = [
		"صلاحيات مالية",
		"صلاحيات مشاريع",
		"صلاحيات مشتريات",
		"صلاحيات إدارية",
		"صلاحيات تقارير"
	];
	function handleAdd() {
		if (!formName.trim() || !formEmail.trim()) {
			showToast("يرجى تعبئة الحقول المطلوبة", "error");
			return;
		}
		const newUser = {
			id: `USR-${String(users.length + 1).padStart(3, "0")}`,
			name: formName,
			email: formEmail,
			role: formRole,
			twofa: false,
			last: "—",
			status: formStatus
		};
		setUsers([...users, newUser]);
		showToast(`تم إضافة المستخدم ${formName} بنجاح`, "success");
		setAddOpen(false);
		setFormName("");
		setFormEmail("");
		setFormPhone("");
		setFormRole("محاسب");
		setFormBranch("الفرع الرئيسي");
		setFormStatus("نشط");
		setFormPerms("صلاحيات مالية");
	}
	function handleInvite() {
		if (!inviteEmail.trim()) {
			showToast("يرجى إدخال البريد الإلكتروني", "error");
			return;
		}
		showToast(`تم إرسال دعوة التسجيل إلى ${inviteEmail}`, "success");
		setInviteOpen(false);
		setInviteEmail("");
		setInviteRole("محاسب");
		setInviteMsg("");
	}
	function handleEdit(u) {
		setEditUser(u);
		setFormName(u.name);
		setFormEmail(u.email);
		setFormPhone("");
		setFormRole(u.role);
		setFormBranch("الفرع الرئيسي");
		setFormStatus(u.status);
		setFormPerms("صلاحيات مالية");
		setEditOpen(true);
	}
	function handleSaveEdit() {
		if (!editUser) return;
		setUsers(users.map((u) => u.id === editUser.id ? {
			...u,
			name: formName,
			email: formEmail,
			role: formRole,
			status: formStatus
		} : u));
		showToast(`تم تعديل المستخدم ${formName} بنجاح`, "success");
		setEditOpen(false);
		setEditUser(null);
	}
	function toggleStatus(u) {
		const newStatus = u.status === "نشط" ? "موقوف" : "نشط";
		setUsers(users.map((x) => x.id === u.id ? {
			...x,
			status: newStatus
		} : x));
		showToast(`تم ${newStatus === "نشط" ? "تفعيل" : "إيقاف"} المستخدم ${u.name}`, "success");
	}
	function handleDelete(u) {
		if (u.name === "سعد الغامدي") {
			showToast("لا يمكن حذف المستخدم سعد الغامدي", "error");
			return;
		}
		setConfirmAction(() => () => {
			setUsers(users.filter((x) => x.id !== u.id));
			showToast(`تم حذف المستخدم ${u.name}`, "success");
		});
		setConfirmOpen(true);
	}
	function handleResetPassword(u) {
		showToast(`تم إرسال رابط إعادة تعيين كلمة المرور إلى ${u.email}`, "success");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"الإعدادات",
			"المستخدمون"
		],
		title: "إدارة المستخدمين",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
					data: users.map((u) => ({
						الرقم: u.id,
						الاسم: u.name,
						البريد: u.email,
						الدور: u.role,
						الحالة: u.status
					})),
					filename: "users.csv"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
					variant: "outline",
					onClick: () => setInviteOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { size: 15 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "hidden md:inline",
						children: "دعوة مستخدم"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
					variant: "primary",
					onClick: () => setAddOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "مستخدم جديد"]
				})
			]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "إدارة المستخدمين",
				count: `${users.length} مستخدم`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MobileActionRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => setInviteOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { size: 15 }), "دعوة مستخدم"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => setAddOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "إضافة مستخدم"]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-3 lg:mt-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الرقم",
					"المستخدم",
					"البريد",
					"الدور",
					"2FA",
					"آخر دخول",
					"الحالة",
					""
				],
				rows: users,
				renderRow: (u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: u.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, {
						className: "font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCog, {
							size: 13,
							className: "inline ms-1 text-primary"
						}), u.name]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs text-muted-foreground",
						children: u.email
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: u.role }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: u.twofa ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
						tone: "success",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
							size: 11,
							className: "inline ms-1"
						}), "مفعّل"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "warning",
						children: "غير مفعّل"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-muted-foreground text-xs",
						children: u.last
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(u.status),
						children: u.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: [
						{
							label: "تعديل",
							icon: Pencil,
							onClick: () => handleEdit(u)
						},
						{
							label: u.status === "نشط" ? "تعطيل" : "تفعيل",
							icon: u.status === "نشط" ? Ban : CircleCheck,
							onClick: () => toggleStatus(u)
						},
						{
							label: "إعادة تعيين كلمة المرور",
							icon: RotateCcw,
							onClick: () => handleResetPassword(u)
						},
						{
							label: "حذف مستخدم",
							icon: Trash2,
							variant: "destructive",
							onClick: () => handleDelete(u)
						}
					] }) })
				] }),
				mobileCard: (u) => {
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs",
										children: u.name.split(" ").map((s) => s[0]).join("")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-semibold text-sm",
										children: u.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										children: u.role
									})] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(u.status),
									children: u.status
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-xs text-muted-foreground",
								children: u.email
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mt-2",
								children: [u.twofa ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									tone: "success",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
										size: 11,
										className: "inline ms-1"
									}), "مفعّل"]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "warning",
									children: "غير مفعّل"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: ["آخر دخول: ", u.last]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2 mt-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
										variant: "outline",
										className: "flex-1 text-xs",
										onClick: () => handleEdit(u),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { size: 12 }), " تعديل"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
										variant: "outline",
										className: "flex-1 text-xs",
										onClick: () => toggleStatus(u),
										children: [u.status === "نشط" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ban, { size: 12 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 12 }), u.status === "نشط" ? "تعطيل" : "تفعيل"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
										variant: "outline",
										className: "flex-1 text-xs",
										onClick: () => handleResetPassword(u),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 12 })
									})
								]
							})
						]
					}, u.id);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: addOpen,
				onClose: () => setAddOpen(false),
				title: "إضافة مستخدم جديد",
				onSave: handleAdd,
				saveText: "إضافة",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الاسم *"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formName,
						onChange: (e) => setFormName(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "البريد الإلكتروني *"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formEmail,
						onChange: (e) => setFormEmail(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "رقم الجوال"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formPhone,
						onChange: (e) => setFormPhone(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الدور"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formRole,
						onChange: (e) => setFormRole(e.target.value),
						children: roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: r }, r))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الفرع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formBranch,
						onChange: (e) => setFormBranch(e.target.value),
						children: branches.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: b }, b))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formStatus,
						onChange: (e) => setFormStatus(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "نشط" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "موقوف" })]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الصلاحيات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formPerms,
						onChange: (e) => setFormPerms(e.target.value),
						children: permsOptions.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: p }, p))
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: inviteOpen,
				onClose: () => setInviteOpen(false),
				title: "دعوة مستخدم جديد",
				onSave: handleInvite,
				saveText: "إرسال الدعوة",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "البريد الإلكتروني *"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: inviteEmail,
						onChange: (e) => setInviteEmail(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الدور"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: inviteRole,
						onChange: (e) => setInviteRole(e.target.value),
						children: roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: r }, r))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "رسالة الترحيب"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm min-h-[80px]",
						value: inviteMsg,
						onChange: (e) => setInviteMsg(e.target.value)
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EntityFormDrawer, {
				open: editOpen,
				onClose: () => {
					setEditOpen(false);
					setEditUser(null);
				},
				title: "تعديل المستخدم",
				onSave: handleSaveEdit,
				saveText: "حفظ التغييرات",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الاسم"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formName,
						onChange: (e) => setFormName(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "البريد الإلكتروني"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formEmail,
						onChange: (e) => setFormEmail(e.target.value)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الدور"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formRole,
						onChange: (e) => setFormRole(e.target.value),
						children: roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: r }, r))
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "mt-1 w-full rounded-lg border bg-background p-2 text-sm",
						value: formStatus,
						onChange: (e) => setFormStatus(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "نشط" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "موقوف" })]
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: confirmOpen,
				onClose: () => setConfirmOpen(false),
				onConfirm: () => {
					confirmAction();
					setConfirmOpen(false);
				},
				title: "تأكيد حذف المستخدم",
				message: "هل أنت متأكد من حذف هذا المستخدم؟ لا يمكن التراجع عن هذا الإجراء.",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			})
		]
	});
};
//#endregion
export { SplitComponent as component };
