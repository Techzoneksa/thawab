import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { B as Printer, Ht as CircleX, J as Pencil, P as Search, U as Plus, Yt as Check, d as UserPlus, jt as Eye, v as Trash2, wt as Funnel } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, E as PrintButton, F as useAuth, N as showToast, S as MobilePageHeader, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu, v as MobileActionChips } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { i as getDonors } from "./donors-BTleOe7U.mjs";
import { a as getDonations, i as deleteDonation, n as confirmDonation, o as issueReceipt, r as createDonation, s as updateDonation, t as cancelDonation } from "./donations-CspILvNi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/donations-B77HjJTT.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function statusToneLocal(s) {
	if (s === "مؤكد" || s === "تم إصدار إيصال") return "success";
	if (s === "ملغي") return "error";
	if (s === "مسودة") return "muted";
	return "info";
}
function Page() {
	const queryClient = useQueryClient();
	const navigate = useNavigate();
	const { user } = useAuth();
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [addDonorOpen, setAddDonorOpen] = (0, import_react.useState)(false);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [methodFilter, setMethodFilter] = (0, import_react.useState)("الكل");
	const [channelFilter, setChannelFilter] = (0, import_react.useState)("الكل");
	const [formDonorId, setFormDonorId] = (0, import_react.useState)("");
	const [formAmount, setFormAmount] = (0, import_react.useState)("");
	const [formProject, setFormProject] = (0, import_react.useState)("");
	const [formMethod, setFormMethod] = (0, import_react.useState)("تحويل بنكي");
	const [formDate, setFormDate] = (0, import_react.useState)("");
	const [formNotes, setFormNotes] = (0, import_react.useState)("");
	const [newDonorName, setNewDonorName] = (0, import_react.useState)("");
	const [newDonorType, setNewDonorType] = (0, import_react.useState)("فرد");
	const [newDonorPhone, setNewDonorPhone] = (0, import_react.useState)("");
	const [newDonorEmail, setNewDonorEmail] = (0, import_react.useState)("");
	const [newDonorCity, setNewDonorCity] = (0, import_react.useState)("");
	const [apiFilters, setApiFilters] = (0, import_react.useState)({
		search: "",
		status: "",
		method: "",
		channel: "",
		page: 1,
		limit: 50
	});
	const [confirmTarget, setConfirmTarget] = (0, import_react.useState)(null);
	const [cancelTarget, setCancelTarget] = (0, import_react.useState)(null);
	const [receiptTarget, setReceiptTarget] = (0, import_react.useState)(null);
	const [addDonorLoading, setAddDonorLoading] = (0, import_react.useState)(false);
	const { data, isLoading, error } = useQuery({
		queryKey: ["donations", apiFilters],
		queryFn: () => getDonations(apiFilters)
	});
	const { data: donorsData } = useQuery({
		queryKey: ["donors-simple"],
		queryFn: () => getDonors({ limit: 200 })
	});
	const donations = data?.items || [];
	donorsData?.items;
	const totalCount = data?.total || 0;
	(0, import_react.useEffect)(() => {
		setApiFilters((f) => ({
			...f,
			search: searchQuery,
			status: statusFilter,
			method: methodFilter,
			channel: channelFilter
		}));
	}, [
		searchQuery,
		statusFilter,
		methodFilter,
		channelFilter
	]);
	useMutation({
		mutationFn: createDonation,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast("تم إضافة التبرع بنجاح", "success");
			setAddDonationOpen(false);
		},
		onError: (err) => showToast(err.message, "error")
	});
	useMutation({
		mutationFn: updateDonation,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast("تم تحديث التبرع بنجاح", "success");
			setAddDonationOpen(false);
			setEditingDonation(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deleteDonation,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast("تم حذف التبرع بنجاح", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const confirmMutation = useMutation({
		mutationFn: confirmDonation,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast("تم تأكيد التبرع بنجاح", "success");
			setConfirmTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const cancelMutation = useMutation({
		mutationFn: cancelDonation,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast("تم إلغاء التبرع بنجاح", "success");
			setCancelTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const receiptMutation = useMutation({
		mutationFn: issueReceipt,
		onSuccess: (data) => {
			queryClient.invalidateQueries({ queryKey: ["donations"] });
			queryClient.invalidateQueries({ queryKey: ["donors"] });
			showToast(`تم إصدار الإيصال بنجاح: ${data.receiptId}`, "success");
			setReceiptTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAddDonation = (_method) => {
		navigate({ to: "/donations/new" });
	};
	const openEditDonation = (d) => {
		navigate({
			to: "/donations/$id/edit",
			params: { id: d.id }
		});
	};
	const handleDelete = () => {
		if (deleteTarget) deleteMutation.mutate({
			id: deleteTarget,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleConfirm = () => {
		if (confirmTarget) confirmMutation.mutate({
			id: confirmTarget.id,
			amount: confirmTarget.amount,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleCancel = () => {
		if (cancelTarget) cancelMutation.mutate({
			id: cancelTarget.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const handleIssueReceipt = () => {
		if (receiptTarget) receiptMutation.mutate({
			id: receiptTarget.id,
			userId: user?.id,
			userName: user?.name
		});
	};
	const stats = [
		{
			label: "إجمالي التبرعات",
			value: fmtSAR(donations.reduce((s, d) => s + d.amount, 0))
		},
		{
			label: "مسودة",
			value: donations.filter((d) => d.status === "مسودة").length
		},
		{
			label: "مؤكد",
			value: donations.filter((d) => d.status === "مؤكد").length
		},
		{
			label: "تم إصدار إيصال",
			value: donations.filter((d) => d.status === "تم إصدار إيصال").length
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"التبرعات والمتبرعون",
			"التبرعات"
		],
		title: "إدارة التبرعات",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
				data: donations,
				filename: "التبرعات.csv"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintButton, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => setAddDonorOpen(true),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { size: 15 }), " إضافة متبرع"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => openAddDonation(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " تسجيل تبرع جديد"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileActionChips, { items: [
				{
					label: "تبرع نقدي",
					icon: Plus,
					onClick: () => openAddDonation("نقدي")
				},
				{
					label: "تحويل بنكي",
					icon: Plus,
					onClick: () => openAddDonation("تحويل بنكي")
				},
				{
					label: "متبرع جديد",
					icon: UserPlus,
					onClick: () => setAddDonorOpen(true)
				}
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: stats.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground truncate",
						children: s.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-base lg:text-xl font-extrabold mt-1 tabular-nums truncate",
						children: s.value
					})]
				}, s.label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث برقم التبرع، اسم المتبرع...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "القناة",
					options: [
						"الكل",
						"البوابة الإلكترونية",
						"تطبيق الجوال",
						"مقر الجمعية",
						"تحويل بنكي",
						"تبرع متكرر"
					],
					value: channelFilter,
					onChange: (e) => setChannelFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "طريقة الدفع",
					options: [
						"الكل",
						"نقدي",
						"مدى",
						"تحويل بنكي",
						"Apple Pay",
						"STC Pay",
						"صك عيني"
					],
					value: methodFilter,
					onChange: (e) => setMethodFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الحالة",
					options: [
						"الكل",
						"مسودة",
						"مؤكد",
						"تم إصدار إيصال",
						"ملغي"
					],
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 }), " تصفية"]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث عن تبرع...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "التبرعات",
				count: `${donations.length} تبرع`
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء تحميل قائمة التبرعات",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["donations"] }),
					children: "إعادة المحاولة"
				})
			}) : donations.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد تبرعات",
				description: "ابدأ بتسجيل أول تبرع في النظام",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => openAddDonation(),
					children: "تسجيل تبرع جديد"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"رقم التبرع",
					"المتبرع",
					"المشروع",
					"المبلغ",
					"طريقة الدفع",
					"التاريخ",
					"الحالة",
					""
				],
				rows: donations,
				renderRow: (d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: d.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-semibold",
						children: d.donorName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-muted-foreground text-xs",
						children: d.projectName || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums font-bold text-success",
						children: fmtSAR(d.amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-muted-foreground text-xs",
						children: d.method
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-muted-foreground text-xs",
						children: d.date
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusToneLocal(d.status),
						children: d.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getDonationActions(d) }) })
				] }),
				mobileCard: (d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-semibold truncate",
									children: d.donorName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: d.projectName || "—"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusToneLocal(d.status),
								children: d.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex items-end justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-bold text-success tabular-nums",
								children: fmtSAR(d.amount)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[11px] text-muted-foreground",
								children: [
									d.method,
									" · ",
									d.channel
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-mono text-muted-foreground",
									children: d.id
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-muted-foreground",
									children: d.date
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 pt-2 border-t flex justify-between items-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getDonationActions(d) })
						})
					]
				}, d.id)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-between mt-4 text-xs text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"عرض ",
					donations.length,
					" من ",
					totalCount,
					" تبرع"
				] })
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: addDonorOpen,
				onClose: () => setAddDonorOpen(false),
				onConfirm: () => {
					setAddDonorOpen(false);
					navigate({ to: "/donors/new" });
				},
				title: "إضافة متبرع جديد",
				message: "سيتم فتح نموذج المتبرع الكامل في صفحة مستقلة. هل تريد المتابعة؟",
				confirmText: "فتح نموذج المتبرع",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: handleDelete,
				title: "حذف التبرع",
				message: "هل أنت متأكد من حذف هذا التبرع؟ لا يمكن التراجع عن هذا الإجراء.",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!confirmTarget,
				onClose: () => setConfirmTarget(null),
				onConfirm: handleConfirm,
				title: "تأكيد التبرع",
				message: `هل أنت متأكد من تأكيد تبرع ${confirmTarget?.donorName} بمبلغ ${confirmTarget ? fmtSAR(confirmTarget.amount) : ""}؟`,
				confirmText: "تأكيد",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!cancelTarget,
				onClose: () => setCancelTarget(null),
				onConfirm: handleCancel,
				title: "إلغاء التبرع",
				message: "هل أنت متأكد من إلغاء هذا التبرع؟",
				confirmText: "إلغاء",
				cancelText: "التراجع",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!receiptTarget,
				onClose: () => setReceiptTarget(null),
				onConfirm: handleIssueReceipt,
				title: "إصدار إيصال",
				message: `هل تريد إصدار إيصال لتبرع ${receiptTarget?.donorName} بمبلغ ${receiptTarget ? fmtSAR(receiptTarget.amount) : ""}؟`,
				confirmText: "إصدار",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "القناة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: channelFilter,
							onChange: (e) => setChannelFilter(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "البوابة الإلكترونية" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "تطبيق الجوال" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مقر الجمعية" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "تحويل بنكي" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "تبرع متكرر" })
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "طريقة الدفع"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: methodFilter,
							onChange: (e) => setMethodFilter(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "نقدي" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "تحويل بنكي" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مدى" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "Apple Pay" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "STC Pay" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "صك عيني" })
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							className: "text-xs font-semibold text-muted-foreground",
							children: "الحالة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
							value: statusFilter,
							onChange: (e) => setStatusFilter(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مسودة" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "مؤكد" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "تم إصدار إيصال" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "ملغي" })
							]
						})] })
					]
				})
			})
		]
	});
	function getDonationActions(d) {
		const actions = [{
			label: "عرض",
			icon: Eye,
			onClick: () => showToast(`${d.id}: ${d.donorName} - ${fmtSAR(d.amount)}`, "info")
		}];
		if (d.status === "مسودة") actions.push({
			label: "تعديل",
			icon: Pencil,
			onClick: () => openEditDonation(d)
		}, {
			label: "تأكيد",
			icon: Check,
			onClick: () => setConfirmTarget(d)
		}, {
			label: "حذف",
			icon: Trash2,
			onClick: () => setDeleteTarget(d.id),
			variant: "destructive"
		});
		if (d.status === "مؤكد") actions.push({
			label: "إصدار إيصال",
			icon: Printer,
			onClick: () => setReceiptTarget(d)
		}, {
			label: "إلغاء",
			icon: CircleX,
			onClick: () => setCancelTarget(d),
			variant: "destructive"
		});
		return actions;
	}
}
//#endregion
export { Page as component };
