//#region node_modules/.nitro/vite/services/ssr/assets/cost-centers-Dv7ULNqn.js
var API_BASE = "/api/finance/cost-centers";
var COST_CENTER_STATUSES = [
	"نشط",
	"موقوف",
	"مغلق"
];
async function getCostCenters(filters = {}) {
	const params = new URLSearchParams();
	if (filters.search) params.set("search", filters.search);
	if (filters.status && filters.status !== "الكل") params.set("status", filters.status);
	const res = await fetch(`${API_BASE}?${params.toString()}`);
	if (!res.ok) throw new Error("فشل في جلب مراكز التكلفة");
	return res.json();
}
async function createCostCenter(data) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إضافة مركز التكلفة");
	}
	return (await res.json()).item;
}
async function updateCostCenter(data) {
	const res = await fetch(API_BASE, {
		method: "PUT",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify(data)
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تحديث مركز التكلفة");
	}
	return (await res.json()).item;
}
async function deleteCostCenter(options) {
	const params = new URLSearchParams({ id: options.id });
	if (options.userId) params.set("userId", options.userId);
	if (options.userName) params.set("userName", options.userName);
	const res = await fetch(`${API_BASE}?${params.toString()}`, { method: "DELETE" });
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في حذف مركز التكلفة");
	}
}
async function deactivateCostCenter(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "deactivate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في إيقاف مركز التكلفة");
	}
	return (await res.json()).item;
}
async function activateCostCenter(options) {
	const res = await fetch(API_BASE, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({
			...options,
			action: "activate"
		})
	});
	if (!res.ok) {
		const err = await res.json();
		throw new Error(err.error || "فشل في تفعيل مركز التكلفة");
	}
	return (await res.json()).item;
}
//#endregion
export { deleteCostCenter as a, deactivateCostCenter as i, activateCostCenter as n, getCostCenters as o, createCostCenter as r, updateCostCenter as s, COST_CENTER_STATUSES as t };
