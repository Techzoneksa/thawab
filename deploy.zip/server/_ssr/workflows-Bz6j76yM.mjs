import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { Ct as GitBranch, U as Plus, qt as ChevronLeft } from "../_libs/lucide-react.mjs";
import { N as showToast, S as MobilePageHeader, a as Btn, i as Badge, n as AppShell, s as Card } from "./actions-qTEe1ygX.mjs";
import { b as WORKFLOWS } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/workflows-Bz6j76yM.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"التقارير والحوكمة",
			"سير العمل"
		],
		title: "محرّك سير العمل والاعتمادات",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			disabled: true,
			title: "إنشاء/تعديل سير عمل — متاح في المرحلة 3D (الحوكمة المتقدمة)",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "سير عمل جديد"]
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "محرّك سير العمل والاعتمادات",
				count: `${WORKFLOWS.length} سير عمل`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg border border-info/30 bg-info/10 px-3 py-2 text-xs text-info-foreground mb-3",
				children: "محرّك سير العمل للعرض فقط في هذه المرحلة. التحكم الكامل (إنشاء/تعديل/تشغيل) متاح في المرحلة 3D."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 md:grid-cols-2 gap-4",
				children: WORKFLOWS.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2 mb-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-bold",
								children: w.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: [
									"متوسط الزمن: ",
									w.avg,
									" · جاري حالياً: ",
									w.active
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: "success",
								children: "مفعّل"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap items-center gap-1.5",
							children: w.steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-md bg-muted px-2 py-1 text-xs font-medium",
									children: s
								}), i < w.steps.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
									size: 14,
									className: "text-muted-foreground"
								})]
							}, i))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
								variant: "outline",
								disabled: true,
								title: "متاح في المرحلة 3D",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GitBranch, { size: 14 }), "تعديل"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "ghost",
								onClick: () => showToast(`عرض سجل "${w.name}" — سجل الاعتمادات متاح في المرحلة 3D`, "info"),
								children: "عرض السجل"
							})]
						})
					]
				}, w.name))
			})
		]
	});
}
//#endregion
export { Page as component };
