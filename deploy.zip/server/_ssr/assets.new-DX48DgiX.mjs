import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { a as FormSection, c as FormSummaryLine, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { i as createFixedAsset, n as ASSET_DEPRECIATION_METHODS, r as ASSET_STATUSES, t as ASSET_CONDITIONS } from "./assets-C0jGCeQN.mjs";
import { s as getSuppliers } from "./suppliers-CkCPjZYa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assets.new-DX48DgiX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CATEGORIES = [
	"أجهزة كمبيوتر",
	"أثاث مكتبي",
	"معدات",
	"سيارات",
	"مبانٍ",
	"أجهزة اتصال",
	"أخرى"
];
function NewAssetPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const suppliers = (useQuery({
		queryKey: ["suppliers-simple"],
		queryFn: () => getSuppliers({ limit: 1e3 })
	}).data?.items || []).filter((s) => s.status === "نشط");
	const [name, setName] = (0, import_react.useState)("");
	const [code, setCode] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("");
	const [location, setLocation] = (0, import_react.useState)("");
	const [cost, setCost] = (0, import_react.useState)("0");
	const [salvageValue, setSalvageValue] = (0, import_react.useState)("0");
	const [usefulLifeMonths, setUsefulLifeMonths] = (0, import_react.useState)("60");
	const [depreciationMethod, setDepreciationMethod] = (0, import_react.useState)("قسط ثابت");
	const [condition, setCondition] = (0, import_react.useState)("جيد");
	const [purchaseDate, setPurchaseDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [supplierId, setSupplierId] = (0, import_react.useState)("");
	const [serialNumber, setSerialNumber] = (0, import_react.useState)("");
	const [responsiblePerson, setResponsiblePerson] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("نشط");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [errors, setErrors] = (0, import_react.useState)([]);
	const bookValue = (0, import_react.useMemo)(() => Math.max(0, (parseFloat(cost) || 0) - (parseFloat(salvageValue) || 0)), [cost, salvageValue]);
	const handleSave = async (andClose) => {
		const errs = [];
		if (!name.trim()) errs.push("اسم الأصل مطلوب");
		const c = parseFloat(cost) || 0;
		const s = parseFloat(salvageValue) || 0;
		if (c < 0) errs.push("قيمة الشراء لا يمكن أن تكون سالبة");
		if (s < 0) errs.push("قيمة الإنقاذ لا يمكن أن تكون سالبة");
		if (s > c) errs.push("قيمة الإنقاذ لا يمكن أن تتجاوز قيمة الشراء");
		const life = parseInt(usefulLifeMonths) || 0;
		if (life <= 0) errs.push("العمر الافتراضي يجب أن يكون أكبر من صفر");
		if (errs.length) {
			setErrors(errs);
			return;
		}
		setErrors([]);
		setSaving(true);
		try {
			const created = await createFixedAsset({
				name: name.trim(),
				code: code || void 0,
				category: category || void 0,
				location: location || void 0,
				cost: c,
				salvageValue: s,
				usefulLifeMonths: life,
				depreciationMethod,
				condition,
				purchaseDate,
				supplierId: supplierId || void 0,
				serialNumber: serialNumber || void 0,
				responsiblePerson: responsiblePerson || void 0,
				notes: notes || void 0,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["fixedAssets"] });
			showToast(`تم إضافة الأصل ${created.name}`, "success");
			if (andClose) navigate({ to: "/assets" });
			else navigate({
				to: "/assets/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	const tabs = [
		{
			id: "basic",
			label: "بيانات الأصل",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "بيانات الأصل",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "اسم الأصل",
						required: true,
						error: errors[0],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "مثال: سيارة نيسان باترول 2024"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "رقم الأصل",
						hint: "اختياري",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: code,
							onChange: (e) => setCode(e.target.value),
							dir: "ltr",
							placeholder: "AST-001"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "التصنيف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— اختر —"
							}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c,
								children: c
							}, c))]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الموقع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: location,
							onChange: (e) => setLocation(e.target.value),
							placeholder: "المدينة، المبنى، المكتب..."
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الشخص المسؤول",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: responsiblePerson,
							onChange: (e) => setResponsiblePerson(e.target.value),
							placeholder: "اسم الشخص المسؤول عن الأصل"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الرقم التسلسلي",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							value: serialNumber,
							onChange: (e) => setSerialNumber(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "المورّد",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
							value: supplierId,
							onChange: (e) => setSupplierId(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "— لا يوجد —"
							}), suppliers.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s.id,
								children: s.name
							}, s.id))]
						})
					})
				]
			})
		},
		{
			id: "financial",
			label: "البيانات المالية",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "البيانات المالية",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "قيمة الشراء",
						required: true,
						hint: "ر.س",
						error: errors[1],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: cost,
							onChange: (e) => setCost(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "قيمة الإنقاذ",
						hint: "ر.س",
						error: errors[2] || errors[3],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "0",
							step: "0.01",
							value: salvageValue,
							onChange: (e) => setSalvageValue(e.target.value),
							dir: "ltr"
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "العمر الافتراضي",
						hint: "بالأشهر",
						required: true,
						error: errors[4],
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "number",
							min: "1",
							value: usefulLifeMonths,
							onChange: (e) => setUsefulLifeMonths(e.target.value),
							dir: "ltr"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "طريقة الإهلاك",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: depreciationMethod,
							onChange: (e) => setDepreciationMethod(e.target.value),
							children: ASSET_DEPRECIATION_METHODS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: m,
								children: m
							}, m))
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-lg bg-info/10 border border-info/30 px-3 py-2 text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "قيمة الشراء"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums",
									children: fmtSAR(parseFloat(cost) || 0)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "القيمة الدفترية الأولية"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums text-info",
									children: fmtSAR(bookValue)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "قيمة الإنقاذ"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums",
									children: fmtSAR(parseFloat(salvageValue) || 0)
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-muted-foreground",
									children: "الإهلاك الشهري (قسط ثابت)"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold tabular-nums",
									children: fmtSAR((parseInt(usefulLifeMonths) || 0) > 0 ? bookValue / (parseInt(usefulLifeMonths) || 1) : 0)
								})] })
							]
						})
					})
				]
			})
		},
		{
			id: "condition",
			label: "الحالة والملاحظات",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "الحالة والملاحظات",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحالة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: status,
							onChange: (e) => setStatus(e.target.value),
							children: ASSET_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								children: s
							}, s))
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "الحالة المادية",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
							value: condition,
							onChange: (e) => setCondition(e.target.value),
							children: ASSET_CONDITIONS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c,
								children: c
							}, c))
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "تاريخ الشراء",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
							type: "date",
							value: purchaseDate,
							onChange: (e) => setPurchaseDate(e.target.value),
							dir: "ltr"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
						label: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value),
							rows: 4
						})
					})
				]
			})
		},
		{
			id: "summary",
			label: "ملخص",
			content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
				title: "ملخص الأصل",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الاسم",
						value: name || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "رقم الأصل",
						value: code || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "التصنيف",
						value: category || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "الموقع",
						value: location || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "المسؤول",
						value: responsiblePerson || "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "تاريخ الشراء",
						value: purchaseDate
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "قيمة الشراء",
						value: fmtSAR(parseFloat(cost) || 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "قيمة الإنقاذ",
						value: fmtSAR(parseFloat(salvageValue) || 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "القيمة الدفترية",
						value: fmtSAR(bookValue),
						tone: "success"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "العمر الافتراضي",
						value: `${usefulLifeMonths} شهرًا`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSummaryLine, {
						label: "طريقة الإهلاك",
						value: depreciationMethod
					})
				]
			})
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "الأصول الثابتة",
		breadcrumb: [
			"المالية",
			"الأصول الثابتة",
			"جديد"
		],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [{
				label: "الأصول",
				to: "/assets"
			}, { label: "أصل جديد" }],
			title: "أصل جديد",
			subtitle: name || "أدخل بيانات الأصل",
			draftNumber: "مسودة جديدة",
			status: {
				label: status,
				tone: status === "نشط" ? "success" : "muted"
			},
			tabs,
			defaultTab: "basic",
			loading: saving,
			validationErrors: errors,
			primaryLabel: "حفظ ومتابعة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/assets" })
		})
	});
}
//#endregion
export { NewAssetPage as component };
