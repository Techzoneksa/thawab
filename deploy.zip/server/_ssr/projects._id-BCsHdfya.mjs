import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { B as Printer, Pt as Download, T as SquarePen } from "../_libs/lucide-react.mjs";
import { A as Table, N as showToast, O as SectionTitle, P as statusTone, a as Btn, i as Badge, j as Td, n as AppShell, s as Card, w as MobileTabBar } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, x as fmtNum } from "./sample-D8-YMyyC.mjs";
import { o as getProject, s as getProjectSummary } from "./projects-fdUGDKDE.mjs";
import { t as Route } from "./projects._id-CRFKJ5jo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/projects._id-BCsHdfya.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const { id } = Route.useParams();
	const navigate = useNavigate();
	const [tab, setTab] = (0, import_react.useState)("نظرة عامة");
	const [mobileTab, setMobileTab] = (0, import_react.useState)("نظرة عامة");
	const [isMobile, setIsMobile] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const check = () => setIsMobile(window.innerWidth < 1024);
		check();
		window.addEventListener("resize", check);
		return () => window.removeEventListener("resize", check);
	}, []);
	const { data: projectData, isLoading } = useQuery({
		queryKey: ["project", id],
		queryFn: () => getProject(id)
	});
	const { data: summaryData } = useQuery({
		queryKey: ["project-summary", id],
		queryFn: () => getProjectSummary(id)
	});
	const project = projectData?.item;
	const donations = projectData?.donations || [];
	const aid = projectData?.aid || [];
	const beneficiaries = projectData?.beneficiaries || [];
	const tabs = [
		"نظرة عامة",
		"الميزانية",
		"التبرعات",
		"المساعدات",
		"المستفيدون",
		"التفاصيل",
		"سجل التدقيق"
	];
	const activeTab = isMobile ? mobileTab : tab;
	const isReadOnly = project?.status === "مكتمل" || project?.status === "ملغي";
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		breadcrumb: ["الرئيسية", "المشاريع"],
		title: "جاري التحميل...",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex justify-center py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
		})
	});
	if (!project) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		breadcrumb: ["الرئيسية", "المشاريع"],
		title: "مشروع غير موجود",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-6 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground mb-3",
				children: "المشروع المطلوب غير موجود."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/projects",
				className: "text-primary font-semibold",
				children: "العودة إلى قائمة المشاريع"
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المشاريع",
			project.name
		],
		title: project.name,
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => showToast("تم إرسال المشروع للطباعة", "info"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { size: 15 }), " طباعة"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => showToast("تم تصدير تقرير المشروع", "info"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 15 }), " تقرير"]
			}),
			!isReadOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "primary",
				onClick: () => navigate({
					to: "/projects/$id/edit",
					params: { id }
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SquarePen, { size: 15 }), " تعديل"]
			})
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-5 gap-2 lg:gap-3 mb-3 lg:mb-4",
				children: [
					{
						l: "الميزانية المعتمدة",
						v: fmtSAR(project.budget)
					},
					{
						l: "إجمالي التبرعات",
						v: fmtSAR(project.donations),
						tone: "text-success"
					},
					{
						l: "إجمالي المنصرف",
						v: fmtSAR(project.spent),
						tone: "text-warning-foreground"
					},
					{
						l: "الرصيد المتاح",
						v: fmtSAR((project.budget > 0 ? project.budget : project.donations) - project.spent),
						tone: "text-primary"
					},
					{
						l: "المستفيدون",
						v: fmtNum(project.beneficiaryCount)
					}
				].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3 lg:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] lg:text-xs text-muted-foreground truncate",
						children: s.l
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `text-sm lg:text-lg font-extrabold mt-0.5 tabular-nums truncate ${s.tone || ""}`,
						children: s.v
					})]
				}, s.l))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mb-3 lg:mb-4 p-4 lg:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between mb-2 text-xs lg:text-sm flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "نسبة الإنجاز:" }),
							" ",
							project.progress,
							"%"
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-muted-foreground",
							children: [
								project.startDate || "—",
								" ← ",
								project.endDate || "—"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-2 lg:h-3 rounded-full bg-muted overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-gradient-to-l from-primary to-info",
							style: { width: `${project.progress}%` }
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5 mt-3",
						children: [
							"دراسة الجدوى",
							"التخطيط",
							"الإطلاق",
							"التنفيذ",
							"المتابعة",
							"الإغلاق"
						].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: i < Math.floor(project.progress / 16) ? "success" : "muted",
							children: s
						}, s))
					})
				]
			}),
			isReadOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mb-3 lg:mb-4 p-3 bg-warning/10 border-warning",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: "warning",
						children: "للقراءة فقط"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground",
						children: [
							"المشروع بحالة \"",
							project.status,
							"\" — لا يمكن التعديل، فقط الطباعة والتصدير."
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "px-2 hidden lg:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1 border-b px-2 overflow-x-auto",
					children: tabs.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setTab(t),
						className: `px-4 py-3 text-sm font-medium border-b-2 whitespace-nowrap ${tab === t ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`,
						children: t
					}, t))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTabBar, {
					tabs: tabs.slice(0, 5),
					active: mobileTab,
					onChange: setMobileTab
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4 lg:p-5",
				children: [
					activeTab === "نظرة عامة" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { title: "وصف المشروع" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground leading-relaxed",
								children: project.description || "لا يوجد وصف."
							}),
							project.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { title: "ملاحظات" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground leading-relaxed",
								children: project.notes
							})] })
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { title: "مؤشرات الأداء" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: [
								{
									l: "نسبة تحقيق الهدف",
									v: project.progress
								},
								{
									l: "كفاءة الصرف",
									v: project.budget > 0 ? Math.round(project.spent / project.budget * 100) : 0
								},
								{
									l: "الالتزام بالجدول الزمني",
									v: project.progress
								},
								{
									l: "نسبة جمع التبرعات",
									v: project.budget > 0 ? Math.round(project.donations / project.budget * 100) : 0
								}
							].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: k.l }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-bold",
									children: [k.v, "%"]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 rounded-full bg-muted mt-1 overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-success",
									style: { width: `${k.v}%` }
								})
							})] }, k.l))
						})] })]
					}),
					activeTab === "الميزانية" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							columns: [
								"البند",
								"المخصص",
								"المنصرف",
								"المتبقي",
								"النسبة"
							],
							rows: [{
								n: "إجمالي الميزانية",
								b: project.budget,
								s: project.spent
							}, {
								n: "التبرعات المحصلة",
								b: project.donations,
								s: project.spent
							}],
							renderRow: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "font-semibold",
									children: r.n
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "tabular-nums",
									children: fmtSAR(r.b)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "tabular-nums",
									children: fmtSAR(r.s)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "tabular-nums text-success",
									children: fmtSAR(r.b - r.s)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-2 w-32",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-1.5 flex-1 rounded-full bg-muted overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-full bg-primary",
											style: { width: `${r.b > 0 ? Math.round(r.s / r.b * 100) : 0}%` }
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xs tabular-nums",
										children: [r.b > 0 ? Math.round(r.s / r.b * 100) : 0, "%"]
									})]
								}) })
							] })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:hidden space-y-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold mb-2",
								children: "إجمالي الميزانية"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-2 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "المخصص: "
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: fmtSAR(project.budget)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "المنصرف: "
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold",
										children: fmtSAR(project.spent)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "المتبقي: "
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-semibold text-success",
										children: fmtSAR(project.budget - project.spent)
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "النسبة: "
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-semibold",
										children: [project.budget > 0 ? Math.round(project.spent / project.budget * 100) : 0, "%"]
									})] })
								]
							})]
						})
					})] }),
					activeTab === "التبرعات" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: donations.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "لا توجد تبرعات مرتبطة بهذا المشروع."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							columns: [
								"رقم",
								"المبلغ",
								"التاريخ",
								"الحالة"
							],
							rows: donations,
							renderRow: (d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "font-mono text-xs",
									children: d.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "tabular-nums text-success font-bold",
									children: fmtSAR(d.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: d.date || d.createdAt }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(d.status),
									children: d.status
								}) })
							] })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:hidden space-y-2",
						children: donations.slice(0, 10).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground font-mono",
										children: d.id
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-base font-bold text-success tabular-nums mt-1",
										children: fmtSAR(d.amount)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(d.status),
									children: d.status
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground mt-1",
								children: d.date || d.createdAt
							})]
						}, d.id))
					})] }) }),
					activeTab === "المساعدات" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: aid.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "لا توجد مساعدات مرتبطة بهذا المشروع."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							columns: [
								"رقم",
								"المبلغ",
								"الحالة",
								"تاريخ التسليم"
							],
							rows: aid,
							renderRow: (a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "font-mono text-xs",
									children: a.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "tabular-nums font-bold",
									children: fmtSAR(a.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(a.status),
									children: a.status
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "text-muted-foreground text-xs",
									children: a.deliveredAt || a.date
								})
							] })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:hidden space-y-2",
						children: aid.slice(0, 10).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between mb-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: statusTone(a.status),
										children: a.status
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-muted-foreground",
										children: a.id
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-base font-bold tabular-nums",
									children: fmtSAR(a.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground mt-1",
									children: a.deliveredAt || a.date
								})
							]
						}, a.id))
					})] }) }),
					activeTab === "المستفيدون" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: beneficiaries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "لا يوجد مستفيدون مرتبطون بمساعدات مسلّمة من هذا المشروع."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hidden lg:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
							columns: [
								"الرقم",
								"الاسم",
								"الفئة",
								"المدينة",
								"الحالة"
							],
							rows: beneficiaries,
							renderRow: (b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "font-mono text-xs",
									children: b.id
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "font-semibold",
									children: b.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: b.category || "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
									className: "text-muted-foreground",
									children: b.city || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: statusTone(b.status),
									children: b.status
								}) })
							] })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lg:hidden space-y-2",
						children: beneficiaries.slice(0, 10).map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-lg border p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-9 w-9 shrink-0 place-items-center rounded-full bg-info/15 text-info text-xs font-bold",
										children: b.name[0]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-semibold truncate",
											children: b.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-xs text-muted-foreground",
											children: [
												b.category || "—",
												" · ",
												b.city || "—"
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: statusTone(b.status),
										children: b.status
									})
								]
							})
						}, b.id))
					})] }) }),
					activeTab === "التفاصيل" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "رقم المشروع",
								value: project.code || project.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "اسم المشروع",
								value: project.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الحالة",
								value: project.status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "التصنيف",
								value: project.category || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "نوع المشروع",
								value: project.type || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "الفرع",
								value: project.branch || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "مدير المشروع",
								value: project.manager || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "نسبة الإنجاز",
								value: `${project.progress}%`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "تاريخ البداية",
								value: project.startDate || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "تاريخ النهاية",
								value: project.endDate || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "أنشأ بواسطة",
								value: project.createdBy || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
								label: "تاريخ الإنشاء",
								value: project.createdAt || "—"
							})
						]
					}),
					activeTab === "سجل التدقيق" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "يتم تسجيل جميع العمليات على هذا المشروع في سجل التدقيق (إضافة، تعديل، حذف، تغيير الحالة)."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 p-4 rounded-lg bg-muted/50 text-sm text-muted-foreground",
						children: "للاطلاع على السجل الكامل، راجع صفحة التقارير أو سجل التدقيق العام."
					})] })
				]
			})
		]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-3 border-b pb-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-semibold text-muted-foreground min-w-[110px]",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex-1 font-semibold",
			children: value
		})]
	});
}
//#endregion
export { Page as component };
