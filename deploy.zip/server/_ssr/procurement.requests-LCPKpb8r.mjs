import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { Ht as CircleX, N as Send, P as Search, T as SquarePen, U as Plus, Wt as CircleCheckBig, jt as Eye, ln as ArrowRight, v as Trash2, wt as Funnel, zt as ClipboardList } from "../_libs/lucide-react.mjs";
import { C as MobileSearchInput, F as useAuth, N as showToast, P as statusTone, S as MobilePageHeader, T as MobileTable, _ as FilterBar, a as Btn, b as MobileFilterDrawer, c as ConfirmDialog, g as ExportButton, i as Badge, j as Td, k as Select, m as EmptyState, n as AppShell, s as Card, t as ActionMenu } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR } from "./sample-D8-YMyyC.mjs";
import { c as getPurchaseRequests, d as submitPurchaseRequest, i as cancelPurchaseRequest, l as rejectPurchaseRequest, n as REQUEST_STATUSES, o as deletePurchaseRequest, r as approvePurchaseRequest, u as returnPurchaseRequestToDraft } from "./purchase-requests-CdC7mUrc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/procurement.requests-LCPKpb8r.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const queryClient = useQueryClient();
	const navigate = useNavigate();
	const { user } = useAuth();
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("الكل");
	const [departmentFilter, setDepartmentFilter] = (0, import_react.useState)("الكل");
	const [filterOpen, setFilterOpen] = (0, import_react.useState)(false);
	const [deleteTarget, setDeleteTarget] = (0, import_react.useState)(null);
	const [actionTarget, setActionTarget] = (0, import_react.useState)(null);
	const [rejectReason, setRejectReason] = (0, import_react.useState)("");
	const { data, isLoading, error } = useQuery({
		queryKey: ["purchaseRequests", {
			search: searchQuery,
			status: statusFilter,
			department: departmentFilter
		}],
		queryFn: () => getPurchaseRequests({
			search: searchQuery,
			status: statusFilter,
			department: departmentFilter
		})
	});
	const submitMutation = useMutation({
		mutationFn: submitPurchaseRequest,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			showToast("تم إرسال الطلب للموافقة", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const approveMutation = useMutation({
		mutationFn: approvePurchaseRequest,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			showToast("تم اعتماد الطلب بنجاح", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const rejectMutation = useMutation({
		mutationFn: rejectPurchaseRequest,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			showToast("تم رفض الطلب", "success");
			setActionTarget(null);
			setRejectReason("");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const returnMutation = useMutation({
		mutationFn: returnPurchaseRequestToDraft,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			showToast("تم إرجاع الطلب للمسودة", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const cancelMutation = useMutation({
		mutationFn: cancelPurchaseRequest,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			showToast("تم إلغاء الطلب", "success");
		},
		onError: (err) => showToast(err.message, "error")
	});
	const deleteMutation = useMutation({
		mutationFn: deletePurchaseRequest,
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] });
			showToast("تم حذف الطلب", "success");
			setDeleteTarget(null);
		},
		onError: (err) => showToast(err.message, "error")
	});
	const openAdd = () => navigate({ to: "/procurement/requests/new" });
	const openEdit = (r) => {
		if (r.status !== "مسودة" && r.status !== "مرفوض") {
			showToast("لا يمكن تعديل طلب في حالة حالية. أعده إلى المسودة أولاً.", "error");
			return;
		}
		navigate({
			to: "/procurement/requests/$id/edit",
			params: { id: r.id }
		});
	};
	const items = data?.items || [];
	const total = data?.total || 0;
	const stats = {
		draft: items.filter((r) => r.status === "مسودة").length,
		pending: items.filter((r) => r.status === "بانتظار الموافقة").length,
		approved: items.filter((r) => r.status === "معتمد").length,
		rejected: items.filter((r) => r.status === "مرفوض").length,
		converted: items.filter((r) => r.status === "محول إلى أمر شراء").length,
		cancelled: items.filter((r) => r.status === "ملغي").length,
		total
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: [
			"الرئيسية",
			"المشتريات",
			"طلبات الشراء"
		],
		title: "طلبات الشراء",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportButton, {
			data: items.map((r) => ({
				id: r.id,
				subject: r.subject,
				department: r.department,
				priority: r.priority,
				requester: r.requester,
				amount: r.amount,
				deliveryDate: r.deliveryDate,
				status: r.status,
				notes: r.notes
			})),
			filename: "purchase-requests.csv"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
			variant: "primary",
			onClick: openAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), "إنشاء طلب شراء"]
		})] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4 mb-3 lg:mb-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "إجمالي الطلبات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold tabular-nums",
							children: fmtSAR(stats.total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "بانتظار الموافقة"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-warning tabular-nums",
							children: fmtSAR(stats.pending)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "معتمد"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-success tabular-nums",
							children: fmtSAR(stats.approved)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-3 lg:p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted-foreground mb-1",
							children: "محول لأمر شراء"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-base lg:text-xl font-extrabold text-info tabular-nums",
							children: fmtSAR(stats.converted)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterBar, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 min-w-[200px] hidden lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						size: 14,
						className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full rounded-lg border bg-background py-1.5 pr-9 pl-3 text-sm",
						placeholder: "بحث...",
						value: searchQuery,
						onChange: (e) => setSearchQuery(e.target.value)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الحالة",
					options: ["الكل", ...REQUEST_STATUSES],
					value: statusFilter,
					onChange: (e) => setStatusFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					label: "الإدارة",
					options: [
						"الكل",
						"إدارة المساعدات",
						"تقنية المعلومات",
						"إدارة المشاريع",
						"الإدارة المالية",
						"المشتريات"
					],
					value: departmentFilter,
					onChange: (e) => setDepartmentFilter(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "ghost",
					className: "lg:hidden",
					onClick: () => setFilterOpen(true),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { size: 15 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lg:hidden flex items-center gap-2 mb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileSearchInput, {
					placeholder: "بحث...",
					value: searchQuery,
					onChange: (e) => setSearchQuery(e.target.value)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobilePageHeader, {
				title: "طلبات الشراء",
				count: `${total} طلب`
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-center py-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full" })
			}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "خطأ في تحميل البيانات",
				description: "حدث خطأ أثناء جلب طلبات الشراء",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: () => queryClient.invalidateQueries({ queryKey: ["purchaseRequests"] }),
					children: "إعادة المحاولة"
				})
			}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "لا توجد طلبات شراء",
				description: "ابدأ بإنشاء أول طلب شراء للموافقة عليه",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
					variant: "primary",
					onClick: openAdd,
					children: "إنشاء طلب شراء"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTable, {
				columns: [
					"الرقم",
					"الموضوع",
					"الإدارة",
					"المبلغ",
					"الحالة",
					""
				],
				rows: items,
				renderRow: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "font-mono text-xs",
						children: r.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setDetailId(r.id),
						className: "font-semibold hover:text-primary text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, {
							size: 13,
							className: "inline ms-1 text-primary"
						}), r.subject]
					}), r.requester && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: r.requester
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "text-muted-foreground",
						children: r.department
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
						className: "tabular-nums font-bold",
						children: fmtSAR(r.amount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						tone: statusTone(r.status),
						children: r.status
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionMenu, { actions: getRequestActions(r, setDetailId, openEdit, submitMutation, approveMutation, setActionTarget, deleteMutation, setDeleteTarget) }) })
				] }),
				mobileCard: (r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setDetailId(r.id),
									className: "text-sm font-bold truncate text-right hover:text-primary",
									children: r.subject
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: [
										r.department,
										" · ",
										r.deliveryDate || "—"
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: statusTone(r.status),
								children: r.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-bold tabular-nums",
								children: fmtSAR(r.amount)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground font-mono",
								children: r.id
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 pt-2 border-t flex gap-2",
							children: [
								r.status === "مسودة" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg bg-primary/15 text-primary py-2 text-xs font-semibold min-h-[36px]",
									onClick: () => submitMutation.mutate({
										id: r.id,
										userId: user?.id,
										userName: user?.name
									}),
									children: "إرسال للموافقة"
								}),
								r.status === "بانتظار الموافقة" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg bg-success/15 text-success py-2 text-xs font-semibold min-h-[36px]",
									onClick: () => approveMutation.mutate({
										id: r.id,
										userId: user?.id,
										userName: user?.name
									}),
									children: "اعتماد"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-lg border py-2 text-xs font-semibold min-h-[36px]",
									onClick: () => setDetailId(r.id),
									children: "تفاصيل"
								})
							]
						})
					]
				}, r.id)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!detailId,
				onClose: () => setDetailId(null),
				title: `تفاصيل الطلب: ${detailQuery.data?.item?.subject || ""}`,
				onSave: () => setDetailId(null),
				saveText: "إغلاق",
				children: detailQuery.data && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الحالة",
									value: detailQuery.data.item.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "القسم",
									value: detailQuery.data.item.department
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "الأولوية",
									value: detailQuery.data.item.priority
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "مقدم الطلب",
									value: detailQuery.data.item.requester || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "المبلغ",
									value: fmtSAR(detailQuery.data.item.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
									label: "تاريخ التوريد",
									value: detailQuery.data.item.deliveryDate || "—"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "p-3 bg-primary/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs font-semibold text-muted-foreground mb-1",
								children: "أوامر الشراء المرتبطة"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-base font-bold",
								children: fmtSAR(detailQuery.data.orderCount)
							})]
						}),
						detailQuery.data.item.notes && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs font-semibold text-muted-foreground mb-1",
							children: "ملاحظات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm whitespace-pre-wrap",
							children: detailQuery.data.item.notes
						})] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityFormDrawer, {
				open: !!actionTarget && actionTarget.action === "reject",
				onClose: () => {
					setActionTarget(null);
					setRejectReason("");
				},
				title: `رفض الطلب: ${actionTarget?.req.subject || ""}`,
				onSave: () => {
					if (actionTarget) rejectMutation.mutate({
						id: actionTarget.req.id,
						reason: rejectReason,
						userId: user?.id,
						userName: user?.name
					});
				},
				loading: rejectMutation.isPending,
				saveText: "تأكيد الرفض",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-warning/10 p-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold text-warning mb-1",
							children: "⚠ رفض طلب الشراء"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs",
							children: "سيتم رفض الطلب وإضافة السبب إلى الملاحظات."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "سبب الرفض"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1",
						rows: 3,
						value: rejectReason,
						onChange: (e) => setRejectReason(e.target.value),
						placeholder: "اذكر سبب الرفض..."
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget && actionTarget.action === "return",
				onClose: () => setActionTarget(null),
				onConfirm: () => {
					if (actionTarget) returnMutation.mutate({
						id: actionTarget.req.id,
						userId: user?.id,
						userName: user?.name
					});
					setActionTarget(null);
				},
				title: "إعادة للمسودة",
				message: `هل تريد إعادة الطلب "${actionTarget?.req.subject}" إلى المسودة؟`,
				confirmText: "إعادة للمسودة",
				cancelText: "إلغاء"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!actionTarget && actionTarget.action === "cancel",
				onClose: () => setActionTarget(null),
				onConfirm: () => {
					if (actionTarget) cancelMutation.mutate({
						id: actionTarget.req.id,
						userId: user?.id,
						userName: user?.name
					});
					setActionTarget(null);
				},
				title: "إلغاء الطلب",
				message: `هل تريد إلغاء الطلب "${actionTarget?.req.subject}"؟`,
				confirmText: "إلغاء",
				cancelText: "تراجع",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				open: !!deleteTarget,
				onClose: () => setDeleteTarget(null),
				onConfirm: () => {
					if (deleteTarget) deleteMutation.mutate({
						id: deleteTarget.id,
						userId: user?.id,
						userName: user?.name
					});
				},
				title: "تأكيد الحذف",
				message: deleteTarget ? `هل تريد حذف طلب الشراء "${deleteTarget.subject}"؟` : "",
				confirmText: "حذف",
				cancelText: "إلغاء",
				variant: "destructive"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileFilterDrawer, {
				open: filterOpen,
				onClose: () => setFilterOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الحالة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: statusFilter,
						onChange: (e) => setStatusFilter(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }), REQUEST_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "text-xs font-semibold text-muted-foreground",
						children: "الإدارة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						className: "w-full rounded-lg border bg-background p-3 text-sm mt-1 min-h-[44px]",
						value: departmentFilter,
						onChange: (e) => setDepartmentFilter(e.target.value),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الكل" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "إدارة المساعدات" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "تقنية المعلومات" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "إدارة المشاريع" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "الإدارة المالية" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "المشتريات" })
						]
					})] })]
				})
			})
		]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b pb-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-semibold",
			children: value
		})]
	});
}
function getRequestActions(r, setDetailId, openEdit, submitMutation, approveMutation, setActionTarget, deleteMutation, setDeleteTarget) {
	const actions = [{
		label: "عرض التفاصيل",
		icon: Eye,
		onClick: () => setDetailId(r.id)
	}];
	if (r.status === "مسودة") {
		actions.push({
			label: "تعديل",
			icon: SquarePen,
			onClick: () => openEdit(r)
		});
		actions.push({
			label: "إرسال للموافقة",
			icon: Send,
			onClick: () => submitMutation.mutate({ id: r.id })
		});
	}
	if (r.status === "بانتظار الموافقة") {
		actions.push({
			label: "اعتماد",
			icon: CircleCheckBig,
			onClick: () => approveMutation.mutate({ id: r.id })
		});
		actions.push({
			label: "رفض",
			icon: CircleX,
			onClick: () => setActionTarget({
				req: r,
				action: "reject"
			})
		});
	}
	if (r.status === "معتمد") actions.push({
		label: "إعادة للمسودة",
		icon: ArrowRight,
		onClick: () => setActionTarget({
			req: r,
			action: "return"
		})
	});
	if (r.status === "مرفوض") {
		actions.push({
			label: "تعديل",
			icon: SquarePen,
			onClick: () => openEdit(r)
		});
		actions.push({
			label: "إعادة للمسودة",
			icon: ArrowRight,
			onClick: () => setActionTarget({
				req: r,
				action: "return"
			})
		});
	}
	if (r.status !== "محول إلى أمر شراء" && r.status !== "ملغي") actions.push({
		label: "إلغاء",
		icon: CircleX,
		onClick: () => setActionTarget({
			req: r,
			action: "cancel"
		})
	});
	if (r.status === "مسودة" || r.status === "مرفوض" || r.status === "ملغي") actions.push({
		label: "حذف",
		icon: Trash2,
		variant: "destructive",
		onClick: () => {
			deleteMutation.mutate({ id: r.id });
			setDeleteTarget(r);
		}
	});
	return actions;
}
//#endregion
export { Page as component };
