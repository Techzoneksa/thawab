import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as useNavigate, v as useSearch } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { i as useQueryClient, n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { F as useAuth, N as showToast, n as AppShell } from "./actions-qTEe1ygX.mjs";
import { o as getBeneficiaries } from "./beneficiaries-aRDRq8QX.mjs";
import { n as createAidRecord } from "./aid-ytMo61mr.mjs";
import { a as FormSection, i as FormRow, l as FormTextarea, n as FormField, r as FormInput, s as FormSelect, t as EnterpriseFormLayout } from "./FormFields-BkWpq-HW.mjs";
import { c as getProjects } from "./projects-fdUGDKDE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aid.new-B9e8qMcF.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TYPES = [
	"مالية",
	"عينية",
	"غذائية",
	"طبية",
	"تعليمية",
	"إسكان",
	"كفالة"
];
var DELIVERY_METHODS = [
	"تحويل بنكي",
	"نقدًا",
	"استلام شخصي",
	"توصيل",
	"بريد"
];
function NewAidPage() {
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { user } = useAuth();
	const search = useSearch({ from: "/aid/new" });
	const { data: beneficiariesData } = useQuery({
		queryKey: ["beneficiaries-simple"],
		queryFn: () => getBeneficiaries({ limit: 500 })
	});
	const beneficiaries = beneficiariesData?.items || [];
	const { data: projectsData } = useQuery({
		queryKey: ["projects-simple"],
		queryFn: () => getProjects({ limit: 200 })
	});
	const projects = projectsData?.items || [];
	const [beneficiaryId, setBeneficiaryId] = (0, import_react.useState)(search.beneficiary || "");
	const [projectId, setProjectId] = (0, import_react.useState)("");
	const [type, setType] = (0, import_react.useState)("مالية");
	const [amount, setAmount] = (0, import_react.useState)("0");
	const [date, setDate] = (0, import_react.useState)((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
	const [deliveryMethod, setDeliveryMethod] = (0, import_react.useState)("تحويل بنكي");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	const [saving, setSaving] = (0, import_react.useState)(false);
	const validate = () => {
		const e = {};
		if (!beneficiaryId) e.beneficiaryId = "يرجى اختيار المستفيد";
		if (!type) e.type = "يرجى اختيار نوع المساعدة";
		if (type === "مالية" && (!amount || parseFloat(amount) <= 0)) e.amount = "يرجى إدخال مبلغ أكبر من صفر";
		setErrors(e);
		return Object.keys(e).length === 0;
	};
	const handleSave = async (andClose) => {
		if (!validate()) {
			showToast("يرجى تصحيح الأخطاء قبل الحفظ", "error");
			return;
		}
		setSaving(true);
		try {
			const created = await createAidRecord({
				beneficiaryId,
				projectId: projectId || void 0,
				type,
				amount: parseFloat(amount) || 0,
				date,
				notes,
				userId: user?.id,
				userName: user?.name
			});
			queryClient.invalidateQueries({ queryKey: ["aid"] });
			showToast(`تم تسجيل المساعدة للمستفيد`, "success");
			if (andClose) navigate({ to: "/aid" });
			else navigate({
				to: "/aid/$id/edit",
				params: { id: created.id }
			});
		} catch (err) {
			showToast(err instanceof Error ? err.message : "فشل الحفظ", "error");
		} finally {
			setSaving(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		title: "المساعدات",
		breadcrumb: ["المساعدات", "جديد"],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnterpriseFormLayout, {
			breadcrumb: [{
				label: "المساعدات",
				to: "/aid"
			}, { label: "مساعدة جديدة" }],
			title: "تسجيل مساعدة جديدة",
			subtitle: "سجّل مساعدة لمستفيد من قاعدة البيانات",
			draftNumber: "مسودة جديدة",
			status: {
				label: "بانتظار الاعتماد",
				tone: "warning"
			},
			tabs: [
				{
					id: "basic",
					label: "البيانات الأساسية",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "بيانات المساعدة",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "المستفيد",
							required: true,
							error: errors.beneficiaryId,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
								value: beneficiaryId,
								onChange: (e) => setBeneficiaryId(e.target.value),
								invalid: !!errors.beneficiaryId,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "— اختر مستفيداً —"
								}), beneficiaries.filter((b) => b.status === "مؤهل" || b.status === "قيد المراجعة").map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: b.id,
									children: [
										b.name,
										" ",
										b.fileNumber ? `(${b.fileNumber})` : ""
									]
								}, b.id))]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "تاريخ المساعدة",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
								type: "date",
								value: date,
								onChange: (e) => setDate(e.target.value),
								dir: "ltr"
							})
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "نوع المساعدة",
							required: true,
							error: errors.type,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
								value: type,
								onChange: (e) => setType(e.target.value),
								invalid: !!errors.type,
								children: TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: t,
									children: t
								}, t))
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "قيمة المساعدة (ر.س)",
							error: errors.amount,
							hint: "للمساعدات المالية فقط",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormInput, {
								type: "number",
								step: "0.01",
								value: amount,
								onChange: (e) => setAmount(e.target.value),
								disabled: type !== "مالية",
								dir: "ltr",
								className: "font-mono tabular-nums",
								invalid: !!errors.amount
							})
						})] })]
					})
				},
				{
					id: "allocation",
					label: "المشروع والتخصيص",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
						title: "تخصيص المساعدة",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "المشروع",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSelect, {
								value: projectId,
								onChange: (e) => setProjectId(e.target.value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "— خارج مشروع (مساعدة عامة) —"
								}), projects.filter((p) => p.status === "نشط" || p.status === "قيد التنفيذ").map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: p.id,
									children: p.name
								}, p.id))]
							})
						})
					})
				},
				{
					id: "delivery",
					label: "التسليم",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
						title: "طريقة التسليم",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "طريقة التسليم",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSelect, {
								value: deliveryMethod,
								onChange: (e) => setDeliveryMethod(e.target.value),
								children: DELIVERY_METHODS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: m,
									children: m
								}, m))
							})
						})
					})
				},
				{
					id: "notes",
					label: "الملاحظات",
					content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormSection, {
						title: "ملاحظات",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
							label: "ملاحظات",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormTextarea, {
								value: notes,
								onChange: (e) => setNotes(e.target.value),
								rows: 6
							})
						})
					})
				}
			],
			defaultTab: "basic",
			loading: saving,
			primaryLabel: "حفظ كمسودة",
			secondaryLabel: "حفظ وإغلاق",
			showSecondary: true,
			onPrimary: () => handleSave(false),
			onSecondary: () => handleSave(true),
			onCancel: () => navigate({ to: "/aid" })
		})
	});
}
//#endregion
export { NewAidPage as component };
