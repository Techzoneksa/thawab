import { _ as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { P as require_jsx_runtime } from "../_libs/@radix-ui/react-alert-dialog+[...].mjs";
import { At as FileChartColumnIncreasing, B as Printer, C as Target, Pt as Download, Tt as FolderKanban, U as Plus, Ut as CircleCheck, an as BellRing, cn as ArrowUpRight, fn as ArrowDownRight, g as TrendingUp, h as TriangleAlert, jt as Eye, l as Users, s as Wallet, sn as BadgeDollarSign, vt as Info } from "../_libs/lucide-react.mjs";
import { A as Table, N as showToast, O as SectionTitle, P as statusTone, a as Btn, d as DropdownMenuItem, f as DropdownMenuSeparator, i as Badge, j as Td, l as DropdownMenu, n as AppShell, p as DropdownMenuTrigger, s as Card, u as DropdownMenuContent, v as MobileActionChips, x as MobileKPIGrid } from "./actions-qTEe1ygX.mjs";
import { S as fmtSAR, f as KPIS, g as RECENT_TRANSACTIONS, h as PROJECTS, n as APPROVALS, o as CASH_FLOW_12M, r as BANK_ACCOUNTS, s as DONATIONS_BY_PROJECT, t as ALERTS, x as fmtNum, y as TOP_DONORS } from "./sample-D8-YMyyC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-nX4YoaD6.js
var import_jsx_runtime = require_jsx_runtime();
var KpiIcon = {
	primary: BadgeDollarSign,
	success: TrendingUp,
	warning: Wallet,
	info: Users
};
function KpiCard({ k }) {
	const Icon = k.unit === "%" ? Target : k.label.includes("مشاريع") ? FolderKanban : KpiIcon[k.tone] || BadgeDollarSign;
	const up = k.delta >= 0;
	const value = k.unit === "ر.س" ? fmtSAR(k.value) : k.unit === "%" ? `${k.value}%` : fmtNum(k.value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "p-4 lg:p-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground font-medium truncate",
						children: k.label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 lg:mt-2 text-xl lg:text-2xl font-extrabold tracking-tight truncate",
						children: value
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `mt-1 inline-flex items-center gap-1 text-xs font-semibold ${up ? "text-success" : "text-destructive"}`,
						children: [
							up ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 14 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownRight, { size: 14 }),
							Math.abs(k.delta),
							"%"
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-10 w-10 lg:h-11 lg:w-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 18 })
			})]
		})
	});
}
function DonationsByProjectChart() {
	const max = Math.max(...DONATIONS_BY_PROJECT.map((d) => d.value));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-2 lg:space-y-3",
		children: DONATIONS_BY_PROJECT.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex justify-between text-xs mb-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium truncate ml-1",
				children: d.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground tabular-nums shrink-0",
				children: fmtSAR(d.value)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-2 rounded-full bg-muted overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full rounded-full bg-gradient-to-l from-primary to-info",
				style: { width: `${d.value / max * 100}%` }
			})
		})] }, d.name))
	});
}
function CashFlowChart() {
	const max = Math.max(...CASH_FLOW_12M.map((c) => Math.max(c.in, c.out)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-end gap-1 lg:gap-2 h-36 lg:h-48",
		children: CASH_FLOW_12M.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 flex flex-col items-center gap-1 min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full flex items-end gap-0.5 h-28 lg:h-40",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 bg-gradient-to-t from-primary to-info/70 rounded-t transition-all",
					style: { height: `${c.in / max * 100}%` }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1 bg-gradient-to-t from-warning/80 to-warning/40 rounded-t transition-all",
					style: { height: `${c.out / max * 100}%` }
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-[9px] lg:text-[10px] text-muted-foreground truncate w-full text-center",
				children: c.m
			})]
		}, c.m))
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 lg:gap-4 text-xs text-muted-foreground mt-2 lg:mt-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-sm bg-primary shrink-0" }), " الواردات"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2.5 w-2.5 rounded-sm bg-warning shrink-0" }), " المصروفات"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ms-auto text-[10px]",
				children: "القيم بالآلاف"
			})
		]
	})] });
}
var alertIcon = {
	destructive: TriangleAlert,
	warning: BellRing,
	info: Info,
	success: CircleCheck
};
function Dashboard() {
	const navigate = useNavigate();
	const exportDashboard = () => {
		const csv = ["المؤشر,القيمة,الوحدة,التغيير", ...KPIS.map((k) => ({
			المؤشر: k.label,
			القيمة: k.value,
			الوحدة: k.unit,
			التغيير: `${k.delta >= 0 ? "+" : ""}${k.delta}%`
		})).map((r) => [
			r.المؤشر,
			r.القيمة,
			r.الوحدة,
			r.التغيير
		].join(","))].join("\r\n");
		const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8;bom" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "لوحة-المعلومات.csv";
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
		URL.revokeObjectURL(url);
		showToast("تم تصدير لوحة المعلومات", "success");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		breadcrumb: ["الرئيسية", "لوحة المعلومات التنفيذية"],
		title: "لوحة المعلومات التنفيذية",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: () => navigate({ to: "/approvals" }),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileChartColumnIncreasing, { size: 15 }), " الموافقات"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
				variant: "outline",
				onClick: exportDashboard,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 15 }), " تصدير"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
					variant: "primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), " إجراء سريع"]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
				align: "end",
				className: "min-w-[240px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/donations/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " تسجيل تبرع جديد"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/donors/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " إضافة متبرع جديد"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/beneficiaries/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " تسجيل مستفيد جديد"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/projects/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " إنشاء مشروع جديد"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/finance/journal/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " قيد يومية جديد"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/finance/budgets/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " موازنة جديدة"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/aid/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " صرف مساعدة"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/procurement/requests/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " طلب شراء جديد"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/procurement/orders/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " أمر شراء جديد"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/inventory/items/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " إضافة صنف"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/inventory/stocktake/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " جرد جديد"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						onSelect: () => navigate({ to: "/assets/new" }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " تسجيل أصل ثابت"]
					})
				]
			})] })
		] }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileActionChips, { items: [
				{
					label: "تبرع جديد",
					icon: Plus,
					onClick: () => navigate({ to: "/donations" })
				},
				{
					label: "مشروع جديد",
					icon: FolderKanban,
					onClick: () => navigate({ to: "/projects" })
				},
				{
					label: "قيد يومية",
					icon: FileChartColumnIncreasing,
					onClick: () => navigate({ to: "/finance/journal" })
				},
				{
					label: "تقرير سريع",
					icon: Eye,
					onClick: () => navigate({ to: "/reports" })
				},
				{
					label: "طباعة",
					icon: Printer,
					onClick: () => window.print()
				}
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileKPIGrid, { children: KPIS.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KpiCard, { k }, k.label)) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 xl:grid-cols-3 gap-3 lg:gap-4 mt-4 lg:mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4 lg:p-5 xl:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						title: "التدفق النقدي",
						hint: "واردات مقابل مصروفات",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Btn, {
							variant: "ghost",
							onClick: exportDashboard,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 14 }), " تصدير"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CashFlowChart, {})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4 lg:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						title: "التبرعات حسب المشروع",
						hint: "أعلى 7 مشاريع"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DonationsByProjectChart, {})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-3 lg:gap-4 mt-4 lg:mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4 lg:p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
								title: "آخر العمليات المالية",
								hint: "آخر القيود المرحلة",
								action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
									variant: "ghost",
									onClick: () => navigate({ to: "/finance/journal" }),
									children: "عرض الكل"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hidden lg:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-x-auto -mx-5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
										className: "min-w-full text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "text-right text-muted-foreground border-b",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-5 py-2 font-medium whitespace-nowrap",
													children: "رقم القيد"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-5 py-2 font-medium whitespace-nowrap",
													children: "التاريخ"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-5 py-2 font-medium",
													children: "الوصف"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-5 py-2 font-medium whitespace-nowrap",
													children: "المبلغ"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
													className: "px-5 py-2 font-medium whitespace-nowrap",
													children: "الحالة"
												})
											]
										}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: RECENT_TRANSACTIONS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
											className: "border-b last:border-0 hover:bg-muted/40",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-5 py-3 font-mono text-xs",
													children: t.id
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-5 py-3 text-muted-foreground",
													children: t.date
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-5 py-3",
													children: t.desc
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
													className: `px-5 py-3 tabular-nums font-semibold ${t.amount >= 0 ? "text-success" : "text-destructive"}`,
													children: [t.amount >= 0 ? "+" : "", fmtSAR(Math.abs(t.amount))]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
													className: "px-5 py-3",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
														tone: statusTone(t.status),
														children: t.status
													})
												})
											]
										}, t.id)) })]
									})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "lg:hidden space-y-2",
								children: RECENT_TRANSACTIONS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-lg border p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-sm font-semibold leading-tight line-clamp-2",
												children: t.desc
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-xs text-muted-foreground mt-0.5",
												children: [
													t.id,
													" · ",
													t.date
												]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											tone: statusTone(t.status),
											children: t.status
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: `mt-2 text-base font-bold tabular-nums ${t.amount >= 0 ? "text-success" : "text-destructive"}`,
										children: [t.amount >= 0 ? "+" : "", fmtSAR(Math.abs(t.amount))]
									})]
								}, t.id))
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4 lg:p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
						title: "تنبيهات الموافقات",
						hint: "بانتظار إجراءك"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2 lg:space-y-3",
						children: APPROVALS.slice(0, 4).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-lg border p-3 hover:border-primary transition-colors active:bg-muted/50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-semibold leading-tight line-clamp-2 flex-1",
										children: a.subject
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: a.priority === "عالية" ? "destructive" : a.priority === "متوسطة" ? "warning" : "muted",
										children: a.priority
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground mt-1",
									children: [
										a.requester,
										" · ",
										a.date
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm lg:text-base font-bold tabular-nums",
										children: fmtSAR(a.amount)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => showToast(`تم اعتماد الطلب "${a.subject}" بنجاح`, "success"),
											className: "rounded-md bg-success/15 text-success px-3 py-1.5 text-xs font-semibold min-h-[32px]",
											children: "اعتماد"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											onClick: () => showToast(`تم رفض الطلب "${a.subject}"`, "info"),
											className: "rounded-md bg-destructive/15 text-destructive px-3 py-1.5 text-xs font-semibold min-h-[32px]",
											children: "رفض"
										})]
									})]
								})
							]
						}, a.id))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-3 lg:gap-4 mt-4 lg:mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4 lg:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							title: "الحسابات البنكية",
							hint: "الأرصدة الحالية"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2 lg:space-y-3",
							children: BANK_ACCOUNTS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-lg border p-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-semibold truncate",
										children: b.bank
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "tabular-nums font-bold shrink-0",
										children: fmtSAR(b.balance)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] text-muted-foreground mt-0.5",
									children: b.type
								})]
							}, b.iban))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4 lg:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							title: "أكبر المتبرعين",
							hint: "هذا العام",
							action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "ghost",
								onClick: () => navigate({ to: "/donors" }),
								children: "الكل"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: TOP_DONORS.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-3 rounded-lg p-2 hover:bg-muted/50 active:bg-muted/80",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "grid h-8 w-8 lg:h-9 lg:w-9 shrink-0 place-items-center rounded-full bg-primary/10 text-primary font-bold text-sm",
										children: i + 1
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-semibold truncate",
											children: d.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-muted-foreground",
											children: d.type
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "tabular-nums font-bold text-sm shrink-0",
										children: fmtSAR(d.total)
									})
								]
							}, d.name))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						className: "p-4 lg:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							title: "تنبيهات النظام",
							hint: "آخر التحديثات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: ALERTS.map((a, i) => {
								const Icon = alertIcon[a.tone] || Info;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-start gap-3 rounded-lg p-2 hover:bg-muted/50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: `grid h-8 w-8 shrink-0 place-items-center rounded-lg ${a.tone === "destructive" ? "text-destructive bg-destructive/10" : a.tone === "warning" ? "text-warning-foreground bg-warning/20" : a.tone === "success" ? "text-success bg-success/10" : "text-info bg-info/10"}`,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 16 })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm",
											children: a.text
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] text-muted-foreground",
											children: a.time
										})]
									})]
								}, i);
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 lg:mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-4 lg:p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
							title: "حالة المشاريع",
							hint: "نسبة الإنجاز وتنفيذ الميزانية",
							action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Btn, {
								variant: "ghost",
								onClick: () => navigate({ to: "/projects" }),
								children: "عرض جميع المشاريع"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden lg:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, {
								columns: [
									"المشروع",
									"المدير",
									"الميزانية",
									"المنصرف",
									"التبرعات",
									"المستفيدون",
									"الإنجاز",
									"الحالة"
								],
								rows: PROJECTS.slice(0, 6),
								renderRow: (p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Td, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-semibold",
										children: p.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[11px] text-muted-foreground font-mono",
										children: p.id
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
										className: "text-muted-foreground",
										children: p.manager
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
										className: "tabular-nums",
										children: fmtSAR(p.budget)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
										className: "tabular-nums",
										children: fmtSAR(p.spent)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
										className: "tabular-nums text-success font-semibold",
										children: fmtSAR(p.donations)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, {
										className: "tabular-nums",
										children: fmtNum(p.beneficiaries)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 min-w-[140px]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-2 flex-1 rounded-full bg-muted overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full bg-gradient-to-l from-primary to-info",
												style: { width: `${p.progress}%` }
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs tabular-nums",
											children: [p.progress, "%"]
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Td, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										tone: statusTone(p.status),
										children: p.status
									}) })
								] })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "lg:hidden grid grid-cols-1 gap-3",
							children: PROJECTS.slice(0, 6).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg border p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0 flex-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-sm font-bold truncate",
												children: p.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] text-muted-foreground",
												children: p.manager
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
											tone: statusTone(p.status),
											children: p.status
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center justify-between text-xs text-muted-foreground",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["الميزانية: ", fmtSAR(p.budget)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "tabular-nums",
											children: [fmtNum(p.beneficiaries), " مستفيد"]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-2 flex-1 rounded-full bg-muted overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full bg-gradient-to-l from-primary to-info",
												style: { width: `${p.progress}%` }
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-xs tabular-nums font-bold",
											children: [p.progress, "%"]
										})]
									})
								]
							}, p.id))
						})
					]
				})
			})
		]
	});
}
//#endregion
export { Dashboard as component };
