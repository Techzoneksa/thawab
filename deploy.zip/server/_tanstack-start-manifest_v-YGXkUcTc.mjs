//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-YGXkUcTc.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/thawab/src/routes/__root.tsx",
		children: [
			"/",
			"/aid",
			"/approvals",
			"/assets",
			"/audit",
			"/beneficiaries",
			"/campaigns",
			"/distribution",
			"/donations",
			"/donor-orgs",
			"/donors",
			"/endowment-returns",
			"/endowments",
			"/grants",
			"/hr",
			"/login",
			"/meetings",
			"/memberships",
			"/notifications",
			"/permissions",
			"/projects",
			"/receipts",
			"/recurring",
			"/reports",
			"/workflows",
			"/api/aid",
			"/api/assets",
			"/api/audit",
			"/api/auth",
			"/api/beneficiaries",
			"/api/donations",
			"/api/donors",
			"/api/projects",
			"/api/receipts",
			"/finance/accounts",
			"/finance/budgets",
			"/finance/closing",
			"/finance/cost-centers",
			"/finance/journal",
			"/finance/ledger",
			"/finance/statements",
			"/inventory/items",
			"/inventory/stocktake",
			"/inventory/warehouses",
			"/procurement/orders",
			"/procurement/quotes",
			"/procurement/requests",
			"/procurement/suppliers",
			"/settings/backup",
			"/settings/branches",
			"/settings/integrations",
			"/settings/org",
			"/settings/system",
			"/settings/users",
			"/api/finance/accounts",
			"/api/finance/budgets",
			"/api/finance/cost-centers",
			"/api/finance/journal",
			"/api/finance/ledger",
			"/api/finance/periods",
			"/api/finance/statements",
			"/api/inventory/items",
			"/api/inventory/stocktake",
			"/api/inventory/warehouses",
			"/api/procurement/orders",
			"/api/procurement/quotes",
			"/api/procurement/requests",
			"/api/procurement/suppliers"
		],
		preloads: ["/assets/index-yddjI4dr.js", "/assets/actions-COc55jsm.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-yddjI4dr.js"
		} }]
	},
	"/": {
		filePath: "D:/thawab/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-daKAw6tm.js", "/assets/sample-CZpm18a2.js"]
	},
	"/aid": {
		filePath: "D:/thawab/src/routes/aid.tsx",
		children: ["/aid/new", "/aid/$id/edit"],
		preloads: [
			"/assets/aid-141MiXga.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/beneficiaries-Ca6Hqr-F.js",
			"/assets/aid-CLcZFT7b.js"
		]
	},
	"/approvals": {
		filePath: "D:/thawab/src/routes/approvals.tsx",
		children: void 0,
		preloads: ["/assets/approvals-iVAqlVA-.js", "/assets/sample-CZpm18a2.js"]
	},
	"/assets": {
		filePath: "D:/thawab/src/routes/assets.tsx",
		children: ["/assets/new", "/assets/$id/edit"],
		preloads: [
			"/assets/assets-CGHvENE1.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/assets-LWNdcw6a.js",
			"/assets/suppliers-Bs5fq9ia.js"
		]
	},
	"/audit": {
		filePath: "D:/thawab/src/routes/audit.tsx",
		children: void 0,
		preloads: ["/assets/audit-DnTcAoCY.js", "/assets/audit-DhRQokHf.js"]
	},
	"/beneficiaries": {
		filePath: "D:/thawab/src/routes/beneficiaries.tsx",
		children: ["/beneficiaries/$id", "/beneficiaries/new"],
		preloads: [
			"/assets/beneficiaries-CrDlOw59.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/beneficiaries-Ca6Hqr-F.js"
		]
	},
	"/campaigns": {
		filePath: "D:/thawab/src/routes/campaigns.tsx",
		children: void 0,
		preloads: ["/assets/campaigns-B6O31KcJ.js", "/assets/sample-CZpm18a2.js"]
	},
	"/distribution": {
		filePath: "D:/thawab/src/routes/distribution.tsx",
		children: void 0,
		preloads: ["/assets/distribution-DqrsrJoj.js", "/assets/sample-CZpm18a2.js"]
	},
	"/donations": {
		filePath: "D:/thawab/src/routes/donations.tsx",
		children: ["/donations/new", "/donations/$id/edit"],
		preloads: [
			"/assets/donations-DFzyXApL.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/donors-Cg6xTO1z.js",
			"/assets/donations-DzyDTPB0.js"
		]
	},
	"/donor-orgs": {
		filePath: "D:/thawab/src/routes/donor-orgs.tsx",
		children: void 0,
		preloads: ["/assets/donor-orgs-CgR_UcCq.js", "/assets/sample-CZpm18a2.js"]
	},
	"/donors": {
		filePath: "D:/thawab/src/routes/donors.tsx",
		children: ["/donors/$id", "/donors/new"],
		preloads: [
			"/assets/donors-D4Oz4S_N.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/donors-Cg6xTO1z.js"
		]
	},
	"/endowment-returns": {
		filePath: "D:/thawab/src/routes/endowment-returns.tsx",
		children: void 0,
		preloads: ["/assets/endowment-returns-DnTmgVld.js", "/assets/sample-CZpm18a2.js"]
	},
	"/endowments": {
		filePath: "D:/thawab/src/routes/endowments.tsx",
		children: void 0,
		preloads: ["/assets/endowments-2Ugwtti1.js", "/assets/sample-CZpm18a2.js"]
	},
	"/grants": {
		filePath: "D:/thawab/src/routes/grants.tsx",
		children: void 0,
		preloads: ["/assets/grants-BzWNS5rH.js", "/assets/sample-CZpm18a2.js"]
	},
	"/hr": {
		filePath: "D:/thawab/src/routes/hr.tsx",
		children: void 0,
		preloads: ["/assets/hr-CFDny1RH.js", "/assets/sample-CZpm18a2.js"]
	},
	"/meetings": {
		filePath: "D:/thawab/src/routes/meetings.tsx",
		children: void 0,
		preloads: ["/assets/meetings-DpUTa2yQ.js", "/assets/sample-CZpm18a2.js"]
	},
	"/memberships": {
		filePath: "D:/thawab/src/routes/memberships.tsx",
		children: void 0,
		preloads: ["/assets/memberships-C2qdFSUo.js", "/assets/sample-CZpm18a2.js"]
	},
	"/notifications": {
		filePath: "D:/thawab/src/routes/notifications.tsx",
		children: void 0,
		preloads: ["/assets/notifications-BLunXpAl.js", "/assets/sample-CZpm18a2.js"]
	},
	"/permissions": {
		filePath: "D:/thawab/src/routes/permissions.tsx",
		children: void 0,
		preloads: ["/assets/permissions-BOKBv3CG.js", "/assets/sample-CZpm18a2.js"]
	},
	"/projects": {
		filePath: "D:/thawab/src/routes/projects.tsx",
		children: ["/projects/$id", "/projects/new"],
		preloads: [
			"/assets/projects-LGgAKVRg.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/projects-DVcSogHi.js"
		]
	},
	"/receipts": {
		filePath: "D:/thawab/src/routes/receipts.tsx",
		children: void 0,
		preloads: [
			"/assets/receipts-B5AneAyf.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js"
		]
	},
	"/recurring": {
		filePath: "D:/thawab/src/routes/recurring.tsx",
		children: void 0,
		preloads: ["/assets/recurring-v671ns9G.js", "/assets/sample-CZpm18a2.js"]
	},
	"/reports": {
		filePath: "D:/thawab/src/routes/reports.tsx",
		children: void 0,
		preloads: ["/assets/reports-C0gAYLCs.js", "/assets/sample-CZpm18a2.js"]
	},
	"/workflows": {
		filePath: "D:/thawab/src/routes/workflows.tsx",
		children: void 0,
		preloads: ["/assets/workflows-D9lej3l9.js", "/assets/sample-CZpm18a2.js"]
	},
	"/aid/new": {
		filePath: "D:/thawab/src/routes/aid.new.tsx",
		children: void 0,
		preloads: [
			"/assets/aid.new-CP1I-lId.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/projects-DVcSogHi.js"
		]
	},
	"/assets/new": {
		filePath: "D:/thawab/src/routes/assets.new.tsx",
		children: void 0,
		preloads: ["/assets/assets.new-C_Wd9lu8.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/beneficiaries/$id": {
		filePath: "D:/thawab/src/routes/beneficiaries.$id.tsx",
		children: ["/beneficiaries/$id/edit"],
		preloads: ["/assets/beneficiaries._id-CAsVuFH9.js"]
	},
	"/beneficiaries/new": {
		filePath: "D:/thawab/src/routes/beneficiaries.new.tsx",
		children: void 0,
		preloads: ["/assets/beneficiaries.new-Bm-Bm6Vm.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/donations/new": {
		filePath: "D:/thawab/src/routes/donations.new.tsx",
		children: void 0,
		preloads: [
			"/assets/donations.new-BijnxhFb.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/projects-DVcSogHi.js"
		]
	},
	"/donors/$id": {
		filePath: "D:/thawab/src/routes/donors.$id.tsx",
		children: ["/donors/$id/edit"],
		preloads: ["/assets/donors._id-BG7GodL-.js"]
	},
	"/donors/new": {
		filePath: "D:/thawab/src/routes/donors.new.tsx",
		children: void 0,
		preloads: ["/assets/donors.new-DotIP-pP.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/finance/accounts": {
		filePath: "D:/thawab/src/routes/finance.accounts.tsx",
		children: ["/finance/accounts/new", "/finance/accounts/$id/edit"],
		preloads: [
			"/assets/finance.accounts-ClZNDP8E.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/accounts-BJOuOvPv.js"
		]
	},
	"/finance/budgets": {
		filePath: "D:/thawab/src/routes/finance.budgets.tsx",
		children: ["/finance/budgets/new", "/finance/budgets/$id/edit"],
		preloads: [
			"/assets/finance.budgets-BYdEkJ8Q.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/budgets-KHyURKRE.js"
		]
	},
	"/finance/closing": {
		filePath: "D:/thawab/src/routes/finance.closing.tsx",
		children: void 0,
		preloads: [
			"/assets/finance.closing-B4FzWXD8.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js"
		]
	},
	"/finance/cost-centers": {
		filePath: "D:/thawab/src/routes/finance.cost-centers.tsx",
		children: void 0,
		preloads: [
			"/assets/finance.cost-centers-0V9L0czz.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/cost-centers-zZ5Gw3qX.js"
		]
	},
	"/finance/journal": {
		filePath: "D:/thawab/src/routes/finance.journal.tsx",
		children: ["/finance/journal/new", "/finance/journal/$id/edit"],
		preloads: [
			"/assets/finance.journal-DqYMO8pB.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/journal-B3HGH6hT.js"
		]
	},
	"/finance/ledger": {
		filePath: "D:/thawab/src/routes/finance.ledger.tsx",
		children: void 0,
		preloads: ["/assets/finance.ledger-C_u0e-lo.js"]
	},
	"/finance/statements": {
		filePath: "D:/thawab/src/routes/finance.statements.tsx",
		children: void 0,
		preloads: [
			"/assets/finance.statements-BJh_LZxX.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/projects-DVcSogHi.js",
			"/assets/cost-centers-zZ5Gw3qX.js"
		]
	},
	"/inventory/items": {
		filePath: "D:/thawab/src/routes/inventory.items.tsx",
		children: ["/inventory/items/new", "/inventory/items/$id/edit"],
		preloads: [
			"/assets/inventory.items-BLQdUOwg.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/warehouses-qc3ff8PB.js",
			"/assets/inventory-items-Cdpycf6L.js"
		]
	},
	"/inventory/stocktake": {
		filePath: "D:/thawab/src/routes/inventory.stocktake.tsx",
		children: ["/inventory/stocktake/new", "/inventory/stocktake/$id/edit"],
		preloads: [
			"/assets/inventory.stocktake-yVTi3wZ8.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/warehouses-qc3ff8PB.js",
			"/assets/inventory-items-Cdpycf6L.js",
			"/assets/stocktake-CWQvDr45.js"
		]
	},
	"/inventory/warehouses": {
		filePath: "D:/thawab/src/routes/inventory.warehouses.tsx",
		children: ["/inventory/warehouses/new", "/inventory/warehouses/$id/edit"],
		preloads: [
			"/assets/inventory.warehouses-CsAvQT5F.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/warehouses-qc3ff8PB.js"
		]
	},
	"/procurement/orders": {
		filePath: "D:/thawab/src/routes/procurement.orders.tsx",
		children: ["/procurement/orders/new", "/procurement/orders/$id/edit"],
		preloads: [
			"/assets/procurement.orders-JvJF1kQ_.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/suppliers-Bs5fq9ia.js",
			"/assets/purchase-orders-D1YTFZv4.js",
			"/assets/purchase-requests-Dqy09wHN.js"
		]
	},
	"/procurement/quotes": {
		filePath: "D:/thawab/src/routes/procurement.quotes.tsx",
		children: ["/procurement/quotes/new", "/procurement/quotes/$id/edit"],
		preloads: [
			"/assets/procurement.quotes-CIQcalxg.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/suppliers-Bs5fq9ia.js",
			"/assets/purchase-requests-Dqy09wHN.js",
			"/assets/quotes-DhTFN_vf.js"
		]
	},
	"/procurement/requests": {
		filePath: "D:/thawab/src/routes/procurement.requests.tsx",
		children: ["/procurement/requests/new", "/procurement/requests/$id/edit"],
		preloads: [
			"/assets/procurement.requests-EuxptJlS.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/purchase-requests-Dqy09wHN.js"
		]
	},
	"/procurement/suppliers": {
		filePath: "D:/thawab/src/routes/procurement.suppliers.tsx",
		children: ["/procurement/suppliers/new", "/procurement/suppliers/$id/edit"],
		preloads: [
			"/assets/procurement.suppliers-OtvO0ayi.js",
			"/assets/useMutation-CoDEd5GJ.js",
			"/assets/sample-CZpm18a2.js",
			"/assets/suppliers-Bs5fq9ia.js"
		]
	},
	"/projects/$id": {
		filePath: "D:/thawab/src/routes/projects.$id.tsx",
		children: ["/projects/$id/edit"],
		preloads: ["/assets/projects._id-wEAPbSWF.js"]
	},
	"/projects/new": {
		filePath: "D:/thawab/src/routes/projects.new.tsx",
		children: void 0,
		preloads: ["/assets/projects.new-CdLslj-K.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/settings/backup": {
		filePath: "D:/thawab/src/routes/settings.backup.tsx",
		children: void 0,
		preloads: ["/assets/settings.backup-DTXHMSny.js"]
	},
	"/settings/branches": {
		filePath: "D:/thawab/src/routes/settings.branches.tsx",
		children: void 0,
		preloads: ["/assets/settings.branches-4FWdXvQ6.js"]
	},
	"/settings/integrations": {
		filePath: "D:/thawab/src/routes/settings.integrations.tsx",
		children: void 0,
		preloads: ["/assets/settings.integrations-CrV0qBGc.js", "/assets/sample-CZpm18a2.js"]
	},
	"/settings/org": {
		filePath: "D:/thawab/src/routes/settings.org.tsx",
		children: void 0,
		preloads: ["/assets/settings.org-0Fc3N-KD.js"]
	},
	"/settings/system": {
		filePath: "D:/thawab/src/routes/settings.system.tsx",
		children: void 0,
		preloads: ["/assets/settings.system-CVGR9rcu.js", "/assets/sample-CZpm18a2.js"]
	},
	"/settings/users": {
		filePath: "D:/thawab/src/routes/settings.users.tsx",
		children: void 0,
		preloads: ["/assets/settings.users-DLsztoiX.js"]
	},
	"/aid/$id/edit": {
		filePath: "D:/thawab/src/routes/aid.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/aid._id.edit-BjA3RuKv.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/projects-DVcSogHi.js"
		]
	},
	"/assets/$id/edit": {
		filePath: "D:/thawab/src/routes/assets.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/assets._id.edit-D4g1wUDL.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/audit-DhRQokHf.js"
		]
	},
	"/beneficiaries/$id/edit": {
		filePath: "D:/thawab/src/routes/beneficiaries.$id.edit.tsx",
		children: void 0,
		preloads: ["/assets/beneficiaries._id.edit-DJguBvz2.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/donations/$id/edit": {
		filePath: "D:/thawab/src/routes/donations.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/donations._id.edit-DOCDDlGG.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/projects-DVcSogHi.js"
		]
	},
	"/donors/$id/edit": {
		filePath: "D:/thawab/src/routes/donors.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/donors._id.edit-BzYB95Hp.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/donations-DzyDTPB0.js"
		]
	},
	"/finance/accounts/new": {
		filePath: "D:/thawab/src/routes/finance.accounts.new.tsx",
		children: void 0,
		preloads: ["/assets/finance.accounts.new-Cx-PMPES.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/finance/budgets/new": {
		filePath: "D:/thawab/src/routes/finance.budgets.new.tsx",
		children: void 0,
		preloads: [
			"/assets/finance.budgets.new-DwumhJph.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/accounts-BJOuOvPv.js"
		]
	},
	"/finance/journal/new": {
		filePath: "D:/thawab/src/routes/finance.journal.new.tsx",
		children: void 0,
		preloads: [
			"/assets/finance.journal.new-B8v9TUsz.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/projects-DVcSogHi.js",
			"/assets/accounts-BJOuOvPv.js"
		]
	},
	"/inventory/items/new": {
		filePath: "D:/thawab/src/routes/inventory.items.new.tsx",
		children: void 0,
		preloads: ["/assets/inventory.items.new-D7ypHx0n.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/inventory/stocktake/new": {
		filePath: "D:/thawab/src/routes/inventory.stocktake.new.tsx",
		children: void 0,
		preloads: ["/assets/inventory.stocktake.new-CO5u28y9.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/inventory/warehouses/new": {
		filePath: "D:/thawab/src/routes/inventory.warehouses.new.tsx",
		children: void 0,
		preloads: ["/assets/inventory.warehouses.new-BGAYyjmu.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/procurement/orders/new": {
		filePath: "D:/thawab/src/routes/procurement.orders.new.tsx",
		children: void 0,
		preloads: [
			"/assets/procurement.orders.new-Bg2bLRsf.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/inventory-items-Cdpycf6L.js"
		]
	},
	"/procurement/quotes/new": {
		filePath: "D:/thawab/src/routes/procurement.quotes.new.tsx",
		children: void 0,
		preloads: ["/assets/procurement.quotes.new-DF4xgLBm.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/procurement/requests/new": {
		filePath: "D:/thawab/src/routes/procurement.requests.new.tsx",
		children: void 0,
		preloads: ["/assets/procurement.requests.new-DqEhGPzj.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/procurement/suppliers/new": {
		filePath: "D:/thawab/src/routes/procurement.suppliers.new.tsx",
		children: void 0,
		preloads: ["/assets/procurement.suppliers.new-Bj8GKFMx.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/projects/$id/edit": {
		filePath: "D:/thawab/src/routes/projects.$id.edit.tsx",
		children: void 0,
		preloads: ["/assets/projects._id.edit-G1HcmtfD.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/finance/accounts/$id/edit": {
		filePath: "D:/thawab/src/routes/finance.accounts.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/finance.accounts._id.edit-VbKJo3Yq.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/audit-DhRQokHf.js"
		]
	},
	"/finance/budgets/$id/edit": {
		filePath: "D:/thawab/src/routes/finance.budgets.$id.edit.tsx",
		children: void 0,
		preloads: ["/assets/finance.budgets._id.edit-gXXuq0Uz.js", "/assets/FormFields-Bp_7xJTl.js"]
	},
	"/finance/journal/$id/edit": {
		filePath: "D:/thawab/src/routes/finance.journal.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/finance.journal._id.edit-ByINBcES.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/projects-DVcSogHi.js",
			"/assets/accounts-BJOuOvPv.js"
		]
	},
	"/inventory/items/$id/edit": {
		filePath: "D:/thawab/src/routes/inventory.items.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/inventory.items._id.edit-CqH1kXY4.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/audit-DhRQokHf.js"
		]
	},
	"/inventory/stocktake/$id/edit": {
		filePath: "D:/thawab/src/routes/inventory.stocktake.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/inventory.stocktake._id.edit-BR-X6urc.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/audit-DhRQokHf.js"
		]
	},
	"/inventory/warehouses/$id/edit": {
		filePath: "D:/thawab/src/routes/inventory.warehouses.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/inventory.warehouses._id.edit-DI2NVpF5.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/audit-DhRQokHf.js"
		]
	},
	"/procurement/orders/$id/edit": {
		filePath: "D:/thawab/src/routes/procurement.orders.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/procurement.orders._id.edit-5pj3jXHG.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/audit-DhRQokHf.js"
		]
	},
	"/procurement/quotes/$id/edit": {
		filePath: "D:/thawab/src/routes/procurement.quotes.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/procurement.quotes._id.edit-CZihgZx-.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/audit-DhRQokHf.js"
		]
	},
	"/procurement/requests/$id/edit": {
		filePath: "D:/thawab/src/routes/procurement.requests.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/procurement.requests._id.edit-DLAoIut8.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/audit-DhRQokHf.js"
		]
	},
	"/procurement/suppliers/$id/edit": {
		filePath: "D:/thawab/src/routes/procurement.suppliers.$id.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/procurement.suppliers._id.edit-BkPZ6cBP.js",
			"/assets/FormFields-Bp_7xJTl.js",
			"/assets/audit-DhRQokHf.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
